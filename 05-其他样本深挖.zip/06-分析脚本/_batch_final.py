# -*- coding: utf-8 -*-
"""批量分析剩余样本"""
import re, hashlib, os

samples = [
    ("Mirai", r"C:\malware_work\Mirai\1075519b2d23eb91d403fc61768c82bf_JaffaCakes118"),
    ("XMRig", r"C:\malware_work\XMRig\106f4faa59b8fbf4099cb8ce9909738f_JaffaCakes118"),
    ("LockBit", r"C:\malware_work\LockBit\0f7c57b8647f802f7e37d0701dfd4b63_JaffaCakes118"),
    ("GandCrab", r"C:\malware_work\GandCrab\109e409332dd0856d2ae2fbc32da86cb_JaffaCakes118"),
    ("NotPetya", r"C:\malware_work\NotPetya\NotPetya.exe"),
    ("Gh0stRAT", r"C:\malware_work\Gh0stRAT\10821cd91ff6959f89e8f2bd577bd5da_JaffaCakes118"),
    ("Gafgyt", r"C:\malware_work\Gafgyt\1065de06187d3eb33e7608a0848e49c3_JaffaCakes118"),
    ("Sality", r"C:\malware_work\Sality\2024-05-03_9783be18049743325d4ba283797691e2_darpapox_magniber_nymaim"),
    ("HawkEye", r"C:\malware_work\HawkEye\0ba173af7380bbe70d970caec82ffc36_JaffaCakes118"),
    ("MassLogger", r"C:\malware_work\MassLogger\ecf7e1dba888e815ec3b2a05dc2a4b13_JaffaCakes118"),
    ("Azorult", r"C:\malware_work\Azorult\1087dc61f973f13367ea32ba9ac5e3f9_JaffaCakes118"),
    ("Pony", r"C:\malware_work\Pony\106fabcf10a5c5486f09e47e794bfef6_JaffaCakes118"),
    ("Adwind", r"C:\malware_work\Adwind\108ae58447a634391c067400ce7bf618_JaffaCakes118"),
    ("Imminent", r"C:\malware_work\Imminent\10835bbaba51e62af438366f2128e5f5_JaffaCakes118"),
]

ioc_patterns = {
    "URL": rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}",
    "IP": rb"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "TG Bot": rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}",
    "邮箱": rb"[a-zA-Z0-9._%+\-]{4,64}@[a-zA-Z0-9.\-]{4,200}\.[a-z]{2,6}",
    "BTC": rb"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b",
    "ETH": rb"\b0x[a-fA-F0-9]{40}\b",
    "XMR": rb"\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b",
}

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 文件不存在:", path)
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    if data[:2] == b"MZ": print("PE")
    if data[:4] == b"\x7fELF": print("ELF")
    
    # 特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt", b"MSVBVM60",
               b"System.", b"cmd.exe", b"stratum+tcp", b"xmr", b"monero", b"LockBit",
               b"WannaCry", b"ONION", b"kernel32", b"tdll", b"bot", b"scan"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    # IOC
    for pname, pat in ioc_patterns.items():
        hits = set()
        for m in re.finditer(pat, data):
            hits.add(m.group().decode("ascii", "replace"))
            if len(hits) >= 15: break
        if hits:
            print(f"[{pname}] {len(hits)}:")
            for h in sorted(hits)[:10]:
                print(f"  {h[:160]}")
    print()
