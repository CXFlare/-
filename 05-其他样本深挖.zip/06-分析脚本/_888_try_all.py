# -*- coding: utf-8 -*-
"""888RAT - 尝试用 myAut2Exe 或自定义方法解密"""
# AutoIt EA06 的常见解密方法：
# 1. 使用 myAut2Exe 工具（有开源实现）
# 2. 直接找 AU3!EA06 之后的数据用 LZMA 或自定义算法解压
# 
# 分析发现：EA06M 后面是加密数据，EA06P 是另一个 payload
# 尝试直接用 7z 或 zlib 解压

import zlib, gzip, bz2, lzma, struct

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
m2 = data.find(b"AU3!EA06P")
print(f"EA06M: 0x{marker:x}  EA06P: 0x{m2:x}")

# EA06M 后的数据可能是 LZMA，但需要正确的头部
# AutoIt 使用的实际是自定义的 LZMA 变体
# 
# 试试直接从 0x26626b7 (EA06P) 开始
if m2 > 0:
    raw = data[m2:m2+64]
    print(f"\nEA06P 后 64 字节: {raw.hex()}")

# 检查数据段
# 从 EA06M+8 开始，可能是：4 字节未压缩大小、4 字节校验
blob_start = marker + 8
sz_uncmp = struct.unpack("<I", data[blob_start:blob_start+4])[0]
sz_cmp = struct.unpack("<I", data[blob_start+4:blob_start+8])[0]
print(f"\nEA06M+8: 未压缩大小 LE = {sz_uncmp} ({sz_uncmp/1024/1024:.2f} MB)")
print(f"EA06M+12: 压缩大小 LE = {sz_cmp} ({sz_cmp/1024/1024:.2f} MB)")

# 尝试用各种算法解压
blob = data[blob_start+16:blob_start+16+5_000_000]
print(f"\n[尝试从 EA06M+16 解压]")
for algo, fn in [("zlib", zlib.decompress), ("gzip", gzip.decompress),
                  ("bz2", bz2.decompress), ("lzma", lzma.decompress)]:
    for offset in [0, 4, 8, 12, 16]:
        try:
            result = fn(blob[offset:])
            if len(result) > 100:
                print(f"  {algo} @ +{offset}: {len(result)} 字节")
                try:
                    txt = result[:2000].decode("utf-8", "replace")
                    print(f"  预览: {txt[:300]}")
                except: pass
        except: pass

# 尝试从 0x26626b7 (EA06P) 开始
if m2 > 0:
    print(f"\n[尝试从 EA06P 后解压]")
    blob2 = data[m2:m2+5_000_000]
    for algo, fn in [("zlib", zlib.decompress), ("gzip", gzip.decompress),
                      ("bz2", bz2.decompress), ("lzma", lzma.decompress)]:
        for offset in [0, 4, 8, 12, 16, 20]:
            try:
                result = fn(blob2[offset:])
                if len(result) > 100:
                    print(f"  {algo} @ +{offset}: {len(result)} 字节")
                    try:
                        txt = result[:2000].decode("utf-8", "replace")
                        print(f"  预览: {txt[:300]}")
                    except: pass
            except: pass
