# -*- coding: utf-8 -*-
import hashlib, os, struct, datetime, math, re

path = r"C:\malware_work\NJRAT\b54802ccdd1ae31f129f6caabdb92f45_NeikiAnalytics.exe"

print("=" * 70)
print("NJRAT 样本静态分析")
print("=" * 70)

st = os.stat(path)
print(f"\n[1] 文件信息")
print(f"    大小: {st.st_size} 字节 ({st.st_size/1024:.1f} KB)")

with open(path, "rb") as f:
    data = f.read()

print(f"\n[2] 哈希")
print(f"    MD5:    {hashlib.md5(data).hexdigest()}")
print(f"    SHA1:   {hashlib.sha1(data).hexdigest()}")
print(f"    SHA256: {hashlib.sha256(data).hexdigest()}")

print(f"\n[3] DOS/PE 头")
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
print(f"    PE 头偏移: 0x{pe_off:X}")

machine = struct.unpack("<H", data[pe_off+4:pe_off+6])[0]
nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
opt_size = struct.unpack("<H", data[pe_off+20:pe_off+22])[0]
chars = struct.unpack("<H", data[pe_off+22:pe_off+24])[0]
machine_map = {0x14c: "i386 (x86)", 0x8664: "AMD64 (x64)", 0x1c0: "ARM", 0xaa64: "ARM64"}
print(f"    机器类型: 0x{machine:04X} ({machine_map.get(machine, '?')})")
print(f"    节数: {nsec}")
print(f"    时间戳: 0x{ts:08X} ({datetime.datetime.utcfromtimestamp(ts) if ts else '?'})")
print(f"    特征: 0x{chars:04X}")

print(f"\n[4] 节表")
sec_off = pe_off + 24 + opt_size
for i in range(nsec):
    s = sec_off + i * 40
    name = data[s:s+8].rstrip(b"\x00").decode("ascii", "replace")
    vsize = struct.unpack("<I", data[s+8:s+12])[0]
    vaddr = struct.unpack("<I", data[s+12:s+16])[0]
    rsize = struct.unpack("<I", data[s+16:s+20])[0]
    raw_off = struct.unpack("<I", data[s+20:s+24])[0]
    chars_s = struct.unpack("<I", data[s+36:s+40])[0]
    if rsize > 0:
        chunk = data[raw_off:raw_off+rsize]
        freq = [0]*256
        for b in chunk: freq[b] += 1
        ent = -sum((c/len(chunk))*math.log2(c/len(chunk)) for c in freq if c)
    else:
        ent = 0
    flags = ""
    if chars_s & 0x20000000: flags += "X"
    if chars_s & 0x80000000: flags += "W"
    if chars_s & 0x40000000: flags += "R"
    print(f"    {name:<10} VA=0x{vaddr:08X} VS=0x{vsize:08X} RAW=0x{raw_off:08X} RS=0x{rsize:08X} 熵={ent:.2f} {flags}")

print(f"\n[5] .NET 检测")
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
opt_type = "PE32" if magic == 0x10B else "PE32+" if magic == 0x20B else "?"
print(f"    可选头: {opt_type} (0x{magic:04X})")
dd_off = opt_off + (96 if magic == 0x10B else 112)
cli_rva = struct.unpack("<I", data[dd_off+14*8:dd_off+14*8+4])[0]
cli_size = struct.unpack("<I", data[dd_off+14*8+4:dd_off+14*8+8])[0]
is_dotnet = cli_rva and cli_size
print(f"    CLI 目录 RVA=0x{cli_rva:08X} Size=0x{cli_size:08X}")
print(f"    类型: {'*** .NET 程序集 -> 用 dnSpy ***' if is_dotnet else '原生 PE -> 用 IDA/x64dbg'}")

# 入口点
ep = struct.unpack("<I", data[opt_off+16:opt_off+20])[0]
print(f"    入口点 RVA: 0x{ep:08X}")

# 读字符串
print(f"\n[6] 提取字符串（URL / IP / 域名 / 注册表）")
def extract_strings(data, min_len=5):
    # ASCII
    pat = re.compile(rb"[\x20-\x7e]{" + str(min_len).encode() + rb",}")
    return [m.group().decode("ascii", "replace") for m in pat.finditer(data)]

strings = extract_strings(data, 5)
print(f"    共提取 {len(strings)} 条字符串")

# 过滤可疑
urls = set()
ips = set()
regs = set()
domains = set()
for s in strings:
    if "http://" in s or "https://" in s:
        urls.add(s[:200])
    for m in re.finditer(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", s):
        ips.add(m.group())
    for m in re.finditer(r"SOFTWARE\\[A-Za-z0-9\\_ ]+", s):
        regs.add(m.group()[:120])
    for m in re.finditer(r"\b[a-zA-Z0-9][a-zA-Z0-9\-]{1,62}\.[a-z]{2,6}\b", s):
        d = m.group()
        if "." in d and not d.endswith((".exe", ".dll", ".txt", ".dat", ".ini", ".log")):
            domains.add(d)

print(f"\n    === URL ({len(urls)}) ===")
for u in list(urls)[:20]: print(f"      {u}")

print(f"\n    === IP ({len(ips)}) ===")
for i in list(ips)[:20]: print(f"      {i}")

print(f"\n    === 注册表 ({len(regs)}) ===")
for r in list(regs)[:20]: print(f"      {r}")

print(f"\n    === 疑似域名 ({len(domains)}) ===")
for d in list(domains)[:30]: print(f"      {d}")

# NJRAT 特征
print(f"\n[7] NJRAT 家族特征检测")
features = {
    "NJRAT 典型字符串": ["njrat", "njw0rm", "njq8", "blabla", "AsyncClient", "Binder", "Lime", "Plugin"],
    "远控功能": ["Keylogger", "ScreenCapture", "Webcam", "Microphone", "RemoteDesktop", "Startup"],
    "命令行": ["cmd.exe", "powershell", "/c ", "schtasks", "reg add"],
    "持久化": ["Run", "RunOnce", "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion"],
}
all_str = "\n".join(strings).lower()
for cat, kws in features.items():
    hits = [k for k in kws if k.lower() in all_str]
    print(f"    {cat}: {hits if hits else '无'}")

print()
