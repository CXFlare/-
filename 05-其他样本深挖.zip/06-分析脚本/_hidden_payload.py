# -*- coding: utf-8 -*-
"""AgentTesla 隐藏 payload - 详细字符串分析"""
import struct, re, hashlib

p = r"C:\malware_work\AgentTesla\hidden_payload.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print(f"头部: {data[:32].hex()}")
print()

# PE 结构
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
machine = struct.unpack("<H", data[pe_off+4:pe_off+6])[0]
nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
opt_size = struct.unpack("<H", data[pe_off+20:pe_off+22])[0]
print(f"PE header @ 0x{pe_off:x}, machine=0x{machine:04x}, 节数={nsec}, ts=0x{ts:08x}")

# .NET?
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
cli_rva = struct.unpack("<I", data[dd_off+14*8:dd_off+14*8+4])[0]
print(f"CLI RVA: 0x{cli_rva:x}  ({'.NET' if cli_rva else 'native'})")
print()

# 节表
sec_off = pe_off + 24 + opt_size
print("[节表]")
for i in range(nsec):
    s = sec_off + i*40
    name = data[s:s+8].rstrip(b"\x00").decode("ascii", "replace")
    vsize = struct.unpack("<I", data[s+8:s+12])[0]
    vaddr = struct.unpack("<I", data[s+12:s+16])[0]
    rsize = struct.unpack("<I", data[s+16:s+20])[0]
    raw_off = struct.unpack("<I", data[s+20:s+24])[0]
    print(f"  {name:<10} VA=0x{vaddr:x} VS=0x{vsize:x} RAW=0x{raw_off:x} RS=0x{rsize:x}")

# .NET 命名空间
print()
print("[.NET 命名空间]")
ns = set(re.findall(rb"System\.[A-Z][A-Za-z0-9._]{3,50}", data))
for n in sorted(ns)[:25]:
    try: print(f"  {n.decode('ascii')}")
    except: pass

# 全部可打印字符串
print()
print("[关键字符串]")
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{8,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["smtp.", "telegram", "http://", "https://",
                              "bot", "chat_id", "password", "chrome",
                              "firefox", "outlook", "keylog", "agent",
                              "tesla", "stealer", "ftp.", "gate", "panel",
                              "api.telegram", "discord"]):
        if not any(x in tl for x in ["microsoft", "digicert", "schemas", "w3.org"]):
            print(f"  {t[:180]}")
