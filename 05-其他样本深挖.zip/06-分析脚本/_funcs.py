# -*- coding: utf-8 -*-
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

targets = ["0x408e94", "0x4089dc", "0x408ec4", "0x408bd0", "0x408bdc", "0x408a40"]

def extract_func(addr):
    hexaddr = addr[2:].lower()
    out = []
    started = False
    for line in lines:
        if line.startswith("sub_" + hexaddr + " @"):
            started = True
            out.append(line.rstrip())
            continue
        if started:
            if line.startswith("sub_"):
                break
            out.append(line.rstrip())
            if len(out) >= 45:
                break
    return out

for t in targets:
    print("=" * 60)
    print(f"函数 {t}")
    print("=" * 60)
    for line in extract_func(t):
        print(line)
    print()
