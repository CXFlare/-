# -*- coding: utf-8 -*-
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 看所有 jmp dword [...] 形式的行
print("所有 jmp dword [...] 形式：")
for i, line in enumerate(lines[:500]):
    if "jmp dword" in line:
        print(f"  L{i}: {line.rstrip()}")
