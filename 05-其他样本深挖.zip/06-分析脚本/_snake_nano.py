# -*- coding: utf-8 -*-
"""SnakeKeyLogger + Nanocore 反编译源码分析"""
import re, os

def analyze(name, path):
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 文件不存在")
        return
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except Exception as e:
        print(f"[!] 读取失败: {e}")
        return
    print(f"源码长度: {len(content)}")
    print(f"行数: {content.count(chr(10))}")
    print()
    
    # 找类名
    classes = set()
    for m in re.finditer(r"\b(?:class|struct|interface)\s+([A-Za-z_][A-Za-z0-9_]*)", content):
        classes.add(m.group(1))
    print(f"类 ({len(classes)}):")
    for c in sorted(classes)[:30]:
        print(f"  {c}")
    
    # 找敏感字符串
    print()
    print("[敏感字符串]")
    seen = set()
    cnt = 0
    for m in re.finditer(r'"([^"\\]{4,200})"', content):
        lit = m.group(1)
        if lit in seen: continue
        seen.add(lit)
        tl = lit.lower()
        if any(k in tl for k in ["smtp", "http://", "https://", "ftp", "telegram",
                                  "discord", "bot", "chat_id", "password",
                                  "browser", "chrome", "firefox", "outlook",
                                  "keylog", "clipboard", "wallet", "gate",
                                  ".php", ".exe", ".dll", "GetAsyncKeyState",
                                  "CreateFile", "WebClient", "HttpClient"]):
            if not any(x in tl for x in ["microsoft", "system.", "mscorlib",
                                            "w3.org", "schemas"]):
                print(f"  {lit[:170]}")
                cnt += 1
                if cnt >= 30: break
    
    # URL/IP
    print()
    print("[URL/IP]")
    urls = set(re.findall(r"https?://[\w\.\-:/?=&%_@#+~]{6,200}", content))
    for u in sorted(urls)[:15]:
        if not any(x in u.lower() for x in ["microsoft", "w3.org", "schemas"]):
            print(f"  {u[:180]}")
    ips = set(re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", content))
    for ip in sorted(ips)[:10]:
        print(f"  {ip}")
    print()

analyze("SnakeKeyLogger", r"C:\malware_work\SnakeKeyLogger\decompiled\FATURA VE BELGELER..native.cs")
analyze("Nanocore", r"C:\malware_work\Nanocore\decompiled\DiscordNSR.native.cs")
