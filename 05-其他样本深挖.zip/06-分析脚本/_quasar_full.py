# -*- coding: utf-8 -*-
"""Quasar 深度分析 - NSIS + MEW 壳"""
import hashlib, re

p = r"C:\malware_work\Quasar\r-c.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# Quasar 特征
print("[特征]")
for kw in [b"Quasar", b"quasar", b"Client", b"Server", b"mscorlib",
           b"System.", b"RegistryKey", b"ClientPlugin", b"TcpClient",
           b"SslStream", b"X509Certificate", b"DotNetZip", b"Mutex",
           b"EncryptedData", b"HostsEditor", b"RemoteShell", b"Keylogger",
           b"RemoteDesktop", b"FileManager", b".NET", b"CLR"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<25} x{c}")

# URL/IP
print()
print("[URLs]")
seen = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
    u = m.group().decode("ascii", "replace")
    if u in seen: continue
    seen.add(u)
    if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                          "verisign", "usertrust", "comodo",
                                          "globalsign", "schemas", "w3.org",
                                          "nsis.sf.net"]):
        print(f"  {u[:180]}")

# NSIS 和 C# 特征
print()
print("[关键字符串]")
seen = set()
cnt = 0
for m in re.finditer(rb"[\x20-\x7e]{15,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["quasar", "clientplugin", "rc4", "aes",
                              "password", "keylog", "remote desktop",
                              "certificate", "sslstream", "tcpclient"]):
        print(f"  {t[:180]}")
        cnt += 1
        if cnt >= 20: break
