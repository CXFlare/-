# -*- coding: utf-8 -*-
"""SnakeKeyLogger - 是否伪装成驾照系统"""
import re

p = r"C:\malware_work\SnakeKeyLogger\decompiled\FATURA VE BELGELER..native.cs"
with open(p, "r", encoding="utf-8", errors="replace") as f:
    content = f.read()

# 检查关键特征
print("[特征检查]")
features = {
    "驾照系统 SQL": ["Applications", "DetainedLicenses", "Drivers", "LicenseClasses", "TestAppointments"],
    "SnakeKeyLogger 特征": ["Keylogger", "GetAsyncKeyState", "Keylog", "Hook", "smtp", "SmtpClient"],
    "通用窃密": ["Chrome", "Firefox", "Outlook", "Password", "Clipboard", "Wallet"],
    "持久化": ["Run", "RunOnce", "Startup", "Registry"],
    "网络": ["WebClient", "HttpClient", "Socket", "TcpClient", "http://"],
}
for cat, kws in features.items():
    hits = []
    for kw in kws:
        c = content.count(kw)
        if c > 0:
            hits.append(f"{kw}x{c}")
    print(f"  {cat}: {hits}")

# 找最像恶意逻辑的类
print()
print("[可能的恶意类]")
classes = re.findall(r"class\s+([A-Za-z_][A-Za-z0-9_]*)", content)
unique_classes = sorted(set(classes))
for c in unique_classes[:40]:
    print(f"  {c}")

# 找前 100 行看模块
print()
print("[源码前 60 行]")
for i, line in enumerate(content.split("\n")[:60]):
    print(f"  {i+1}: {line}")
