# -*- coding: utf-8 -*-
"""NJRAT 深度逆向 - 关键函数 + API 调用点"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"

with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400), (0x9000, 0x213B0, 0x0), (0x2B000, 0x33D0, 0x8400), (0x2F000, 0xEA4, 0xB800), (0x30000, 0x1000, 0xCA00), (0x31000, 0x1200, 0xCC00)]
    for va_, vs, raw in secs:
        if va_ <= rva < va_ + max(vs, 1):
            return raw + (rva - va_)
    return None

# ===== 解析导入表 → IAT 顺序 =====
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = va2off(IMAGE_BASE + imp_rva)

def read_hint(va):
    off = va2off(va)
    if off is None: return None
    end = data.find(b"\x00", off+2, off+200)
    if end < 0: return None
    try: return data[off+2:end].decode("ascii")
    except: return None

ordered = []
i = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = va2off(IMAGE_BASE + name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_off = va2off(IMAGE_BASE + (oft or ft))
    j = 0
    while True:
        v = struct.unpack("<I", data[thunk_off+j*4:thunk_off+j*4+4])[0]
        if v == 0: break
        nm = read_hint(IMAGE_BASE + v) if not (v & 0x80000000) else f"#{v & 0x7FFFFFFF}"
        ordered.append(f"{dll}!{nm}")
        j += 1
    i += 1

# wrapper 映射
wrapper_apis = {}
for i in range(len(ordered)):
    wrapper_apis[0x408988 + 12*i] = ordered[i]

# API 名 → wrapper 地址
api_to_wrapper = {v: k for k, v in wrapper_apis.items()}

# ===== 分析关键函数 =====
def extract_func(addr, max_lines=300):
    target = f"sub_{addr[2:].lower()} @"
    out = []
    started = False
    for line in lines:
        if line.startswith(target):
            started = True
            out.append(line.rstrip())
            continue
        if started:
            if line.startswith("sub_"):
                break
            out.append(line.rstrip())
            if len(out) >= max_lines:
                break
    return out

print("=" * 70)
print("NJRAT 关键函数分析")
print("=" * 70)

# 分析主函数 sub_40129c（初始化）
print()
print("### sub_40129c — 初始化 + 加载 ntdll ###")
for line in extract_func("0x40129c", 60):
    print(line)

# 分析 sub_407edc（银行钓鱼窗口）
print()
print("### sub_407edc — 银行钓鱼窗口主逻辑 ###")
for line in extract_func("0x407edc", 80):
    print(line)
