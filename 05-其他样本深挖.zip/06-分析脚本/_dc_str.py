# -*- coding: utf-8 -*-
"""DarkComet - 静态字符串分析"""
import hashlib, re

pe = r"C:\malware_work\DarkComet\0faee8383e8088667c4e94ab44d8cf66_JaffaCakes118"
with open(pe, "rb") as f:
    data = f.read()

print(f"大小: {len(data)} 字节")
print(f"MD5:    {hashlib.md5(data).hexdigest()}")
print(f"SHA1:   {hashlib.sha1(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print()

# DarkComet 特征：Delphi 编写
print("[Delphi 特征]")
delphi_kws = [b"Embarcadero", b"Borland", b"Delphi", b"TForm1", b"TObject",
              b"System.pas", b"Classes.pas", b"Windows.pas", b"Forms.pas",
              b"DarkComet", b"DC_MUTEX", b"#DCMUTEX", b"DarkCometRAT",
              b"FWB", b"Microsoft_Corporation", b"DVCLAL"]
for kw in delphi_kws:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace')}: x{c}")

print()
print("[关键 API / 字符串]")
ascii_str = re.findall(rb"[\x20-\x7e]{6,}", data)
seen = set()
for s in ascii_str:
    try: t = s.decode("ascii")
    except: continue
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["darkcomet", "mutex", "http://", "https://", "ftp://",
                              "cmd.exe", "software\\", "regwrite", "socket",
                              "winsock", "wsastartup", "getasynckeystate",
                              "encrypt", "decrypt", "password"]):
        if 6 < len(t) < 180:
            print(f"  {t[:170]}")
