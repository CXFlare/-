# -*- coding: utf-8 -*-
"""批量分析：RisePRO / BlackGuard / BlankGrabber / KPot / Matiex / Monster / WSHRAT / ZGRat"""
import re, hashlib, os

samples = [
    ("RisePRO", r"C:\malware_work\RisePRO\6ba442bd4812adc7ac98101130cc1c12ae0155e8a94dbe3bf2e24979ac217407"),
    ("KPot", r"C:\malware_work\KPot\105cf23b2dd4fa045429abaa8125a1b6_JaffaCakes118"),
    ("Matiex", r"C:\malware_work\Matiex\0b52424adb115b1336d084cf0cfbb73e_JaffaCakes118"),
    ("MonsterV1", r"C:\malware_work\MonsterV1\XMoon.exe"),
    ("MonsterV2", r"C:\malware_work\MonsterV2\tunamor.exe"),
    ("WSHRAT", r"C:\malware_work\WSHRAT\test.JS"),
    ("ZGRat", r"C:\malware_work\ZGRat\bc415aafd68de975f42d71ef25868a7de65ddf166a0bb03246243c6d1b0a0af1"),
]

ioc_patterns = {
    "URL": rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}",
    "IP": rb"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "TG Bot": rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}",
    "Discord Webhook": rb"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+",
    "邮箱": rb"[a-zA-Z0-9._%+\-]{4,64}@[a-zA-Z0-9.\-]{4,200}\.[a-z]{2,6}",
    "BTC": rb"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b",
    "ETH": rb"\b0x[a-fA-F0-9]{40}\b",
}

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 文件不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    if data[:2] == b"MZ": print("PE 文件")
    if data[:4] == b"\x7fELF": print("ELF 文件")
    if b"WScript" in data[:2000] or b"CreateObject" in data[:2000]: print("WSH 脚本")
    
    # 特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt", b"MSVBVM60",
               b"System.", b"cmd.exe", b"Telegram", b"Discord", b"keylog", b"stealer",
               b"browser", b"clipboard", b"webcam", b"Chrome", b"Firefox", b"Outlook",
               b"wallet", b"password", b"Cookie", b"XMR", b"monero", b"stratum",
               b"powershell", b"WScript", b"Shell.Application", b"ActiveXObject"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    # IOC
    for pname, pat in ioc_patterns.items():
        hits = set()
        for m in re.finditer(pat, data):
            hits.add(m.group().decode("ascii", "replace"))
            if len(hits) >= 20: break
        if hits:
            print(f"[{pname}] {len(hits)}:")
            for h in sorted(hits)[:12]:
                print(f"  {h[:170]}")
    print()
