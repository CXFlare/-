# -*- coding: utf-8 -*-
"""AgentTesla PAGO.exe - 提取隐藏的 ZH 资源并解密"""
import re, struct

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}")
print(f"头部: {data[:32].hex()}")
print()

# .NET 资源藏在 .rsrc 节 + .resources 流里
# 找 "ZH" 名字
pos = data.find(b"ZH\x00")
print(f"'ZH' 名字位置: 0x{pos:x}")
for m in re.finditer(rb"ZH\x00", data):
    print(f"  ZH @ 0x{m.start():x}")

# 找 .resources 流
res_pos = data.find(b"PandaCafe.Properties.Resources")
print(f"\nResources 类: 0x{res_pos:x}")

# .NET 资源通常有独特结构：4 字节长度 + 4 字节类型 + 数据
# 找所有看起来像 PE 头（MZ）的位置
print()
print("[所有 MZ 位置]")
mzs = []
i = 0
while True:
    p_ = data.find(b"MZ", i)
    if p_ < 0 or p_ > len(data) - 0x100: break
    # 检查 PE
    if p_ + 0x40 < len(data):
        pe_off = struct.unpack("<I", data[p_+0x3C:p_+0x40])[0]
        if p_ + pe_off + 4 <= len(data) and data[p_+pe_off:p_+pe_off+4] == b"PE\x00\x00":
            machine = struct.unpack("<H", data[p_+pe_off+4:p_+pe_off+6])[0]
            mzs.append((p_, machine))
    i = p_ + 2

for p_, m in mzs:
    print(f"  MZ @ 0x{p_:x}  machine=0x{m:04x}")

# 找 XOR 密钥字节：53,52,56,66,72,69,51,53,90,56,83,72,55,56,56,56,71,83,66,89,68,57
key_bytes = [53,52,56,66,72,69,51,53,90,56,83,72,55,56,56,56,71,83,66,89,68,57]
print()
print(f"XOR Key: {''.join(chr(b) for b in key_bytes)}")

# .NET 资源格式：4 字节 magic 0xBEEFCACE + 4 字节 header version + 4 字节 header size
# 找 0xBEEFCACE
print()
print("[.NET resources 魔数 0xBEEFCACE]")
magic = b"\xce\xca\xef\xbe"
pos = 0
while True:
    pos = data.find(magic, pos)
    if pos < 0: break
    print(f"  0x{pos:x}")
    pos += 1
