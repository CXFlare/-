# -*- coding: utf-8 -*-
"""NJRAT 深度分析 - 全部函数与字符串引用"""
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 提取每个函数内的 push 42xxxx（字符串引用）
func_refs = {}
cur = None
for line in lines:
    m = re.match(r"^(sub_[0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = m.group(2)
        func_refs[cur] = []
    elif cur and "push 42" in line:
        for x in re.findall(r"push (42[0-9A-Fa-f]{4})h", line):
            func_refs[cur].append(int(x, 16))

# 读 exe
with open(r"C:\malware_work\NJRAT\njrat_decrypted.exe", "rb") as f:
    data = f.read()

def addr_to_off(addr):
    rva = addr - 0x400000
    secs = [(0x1000, 0x400, 0x7F6C), (0x9000, 0x0, 0x213B0), (0x2B000, 0x8400, 0x33D0), (0x2F000, 0xB800, 0xEA4), (0x30000, 0xCA00, 0x200), (0x31000, 0xCC00, 0x1200)]
    for va, raw, vs in secs:
        if va <= rva < va + vs: return raw + (rva - va)
    return None

def rs(addr):
    off = addr_to_off(addr)
    if off is None: return None
    e = data.find(b"\x00", off)
    if e < 0 or e - off > 200: return None
    try: return data[off:e].decode("ascii")
    except: return None

# 根据字符串分类函数
categories = {}
for addr, refs in func_refs.items():
    strs = [rs(r) for r in refs]
    strs = [s for s in strs if s]
    if not strs: continue
    text = " ".join(strs).lower()
    
    cat = "unknown"
    if "internetexplorer" in text or "<form" in text or "sign in" in text or "log in" in text:
        cat = "web_inject"
    elif "visa" in text or "mastercard" in text or "cvv" in text or "atm pin" in text:
        cat = "fake_bank_form"
    elif "crutop" in text or "index.php" in text:
        cat = "c2_config"
    elif "reg" in text and ("run" in text or "shellservice" in text):
        cat = "persistence"
    elif "ntdll" in text or "ntunmap" in text or "ntmap" in text:
        cat = "process_injection"
    elif "keylogger" in text or "hook" in text:
        cat = "keylogger"
    elif "screen" in text or "bitblt" in text or "desktop" in text:
        cat = "screen_capture"
    
    categories.setdefault(cat, []).append((addr, strs))

print("=" * 70)
print("函数分类")
print("=" * 70)
for cat, funcs in sorted(categories.items()):
    print(f"\n### {cat} ({len(funcs)} 个函数) ###")
    for addr, strs in funcs:
        print(f"  {addr}: {strs[0][:80]}")
