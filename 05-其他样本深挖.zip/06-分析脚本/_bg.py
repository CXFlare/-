# -*- coding: utf-8 -*-
"""BlackGuard 内层 UMF.Installer.exe"""
import re, hashlib, os, struct

p = r"C:\malware_work\BlackGuard\inner\UMF.Installer.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print(f"头部: {data[:32].hex()}")

if data[:2] == b"MZ":
    pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
    machine = struct.unpack("<H", data[pe_off+4:pe_off+6])[0]
    nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
    ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
    print(f"PE: machine=0x{machine:x}, 节={nsec}, 时间戳=0x{ts:x}")

# 特征
for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
           b"Install", b"Setup", b"keylog", b"stealer", b"browser",
           b"clipboard", b"webcam", b"chrome", b"firefox", b"outlook"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

# 字符串 IOC
print()
print("[IOC]")
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{8,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["http://", "https://", "telegram", "discord.com",
                              "bot", "chat_id", "keylog", "stealer", "wallet",
                              ".onion", "password", "chrome", "firefox",
                              "umf", "blackguard", "blackguard"]):
        print(f"  {t[:180]}")

# TG bot token
print()
print("[TG Bot Token 模式]")
for m in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}", data):
    print(f"  {m.group().decode('ascii')}")
