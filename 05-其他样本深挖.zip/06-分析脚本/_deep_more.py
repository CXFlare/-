# -*- coding: utf-8 -*-
"""继续深挖 - BlackMoon + BadRabbit + FakeAV 完整字符串分析"""
import re, hashlib, os

samples = [
    ("BlackMoon", r"C:\malware_work\BlackMoon\2024-05-03_eebffcc6416914b2b3c31f935bd802ca_icedid_xiaobaminer"),
    ("BadRabbit", r"C:\malware_work\BadRabbit\BadRabbit.exe"),
    ("FakeAV", r"C:\malware_work\FakeAV\90307e8421fc5314379ba87f56a11034_NeikiAnalytics.exe"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    
    # 打印所有可读字符串 >= 12 字符
    seen = set()
    interesting = []
    for m in re.finditer(rb"[\x20-\x7e]{12,200}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        # 过滤掉明显的证书/微软 URL 和编译器字符串
        if any(x in tl for x in ["microsoft", "digicert", "sectigo", "verisign",
                                  "comodo", "globalsign", "symantec", "thawte",
                                  "schemas.", "w3.org", "adobe", "entrust",
                                  "cybertrust", "trustwave", "godaddy", "starfield"]):
            continue
        if any(x in tl for x in ["http://", "https://", ".onion", ".php",
                                  "decrypt", "encrypt", "ransom", "readme",
                                  "bitcoin", "wallet", "miner", "xmr", "monero",
                                  "c2.", "panel", "gate", "watchdog",
                                  "cmd.exe", "powershell", "reg add", "schtasks",
                                  "vssadmin", "wevtutil", "diskpart"]):
            interesting.append(t)
    
    for t in interesting[:30]:
        print(f"  {t[:180]}")
    print()
