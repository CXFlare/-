# -*- coding: utf-8 -*-
"""WSHRAT JS 脚本 + MonsterV2 勒索 + BlackGuard 内层"""
import re, hashlib, os

# WSHRAT - JS 脚本
print("=" * 70)
print("WSHRAT (test.JS)")
print("=" * 70)
p = r"C:\malware_work\WSHRAT\test.JS"
with open(p, "rb") as f:
    raw = f.read()
# 尝试解码
try:
    txt = raw.decode("utf-16le", "replace")
except:
    txt = raw.decode("latin-1", "replace")
if len(txt) < len(raw):
    txt = raw.decode("utf-8", "replace")

# 关键：找 JS 特征
print(f"文件大小: {len(raw)}")
print(f"UTF-8 头部: {raw[:200]}")

# WSH 脚本混淆特征
for kw in ["ActiveXObject", "WScript.Shell", "Adodb.Stream", "MSXML2",
           "eval(", "fromCharCode", "unescape", "powershell",
           "cmd.exe", "http://", "https://", "base64"]:
    c = txt.count(kw)
    if c > 0:
        print(f"  {kw}: x{c}")

# 找 PowerShell 命令
print()
print("[PowerShell 命令]")
for m in re.finditer(r"[Pp]ower[Ss]hell.{0,300}", txt):
    print(f"  {m.group()[:280]}")
    break

# 找 URL
urls = set(re.findall(r"https?://[\w\.\-:/?=&%_@#+~]+", txt))
if urls:
    print()
    print("[URLs]")
    for u in sorted(urls)[:20]:
        print(f"  {u[:180]}")
else:
    # 找域名
    domains = set(re.findall(r"\b[a-zA-Z0-9][a-zA-Z0-9\-]+\.(?:com|net|org|ru|io|xyz|top|su|cc|tk|ml|ga|cf|gq|onion)\b", txt))
    print()
    print("[域名]")
    for d in sorted(domains)[:30]:
        print(f"  {d}")

# 找 IPv4
ips = set(re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", txt))
print()
print("[IPs]")
for ip in ips:
    parts = ip.split(".")
    if all(0 <= int(p) <= 255 for p in parts) and ip not in ["0.0.0.0", "6.0.0.0", "127.0.0.1"]:
        print(f"  {ip}")

print()
print("=" * 70)
print("MonsterV2 (勒索)")
print("=" * 70)
p2 = r"C:\malware_work\MonsterV2\tunamor.exe"
with open(p2, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
# 特征
for kw in [b".onion", b"torproject", b"bitcoin", b"ransom", b"encrypt",
           b"decrypt", b"ReadMe", b"README", b"file", b"AES", b"RSA",
           b"Monster", b"tunamor", b"btc", b"wallet"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace')}: x{c}")

# 字符串
print("[关键字符串]")
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{6,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["onion", "torproject", "bitcoin", "ransom",
                              "decrypt", "readme", "monster", "tunamor",
                              "encrypt", "wallet", "btc", "victim",
                              "your files", "payment"]):
        print(f"  {t[:180]}")
