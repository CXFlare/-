# -*- coding: utf-8 -*-
"""批量分析新解压样本"""
import re, hashlib, os

samples = [
    ("BlackMoon", r"C:\malware_work\BlackMoon\2024-05-03_eebffcc6416914b2b3c31f935bd802ca_icedid_xiaobaminer"),
    ("Sodinokibi", r"C:\malware_work\Sodinokibi\0f8ee1ed415794ec053dca928a409436_JaffaCakes118"),
    ("SmokeLoader", r"C:\malware_work\SmokeLoader\f9be6fbe073f8e75344c62adff1a729494acafa18ea7c778cd0b3177a77de0f3"),
    ("Pikachu", r"C:\malware_work\Pikachu\Pikachu.exe"),
    ("Maldal", r"C:\malware_work\Maldal\Maldal.exe"),
    ("CyberGate", r"C:\malware_work\CyberGate\f91b8fc07602d0d7c8639a7554bbcec478187c259f7441668beb6966421cf8cc"),
    ("SectopRAT", r"C:\malware_work\SectopRAT\7d4751c36750da3e6ec9e50271b103343467e5a4e98197faff15271030f505d5"),
]

tg_pat = rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}"
dc_pat = rb"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+"
ip_pat = rb"\b(?:\d{1,3}\.){3}\d{1,3}\b"
url_pat = rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}"

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    if data[:2] == b"MZ": print("PE")
    if data[:4] == b"\x7fELF": print("ELF")
    
    # 特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt", b"MSVBVM60",
               b"System.", b"cmd.exe", b"Telegram", b"Discord", b"keylog", b"stealer",
               b"browser", b"clipboard", b"Chrome", b"Firefox", b"Outlook",
               b"wallet", b"password", b"XMR", b"monero", b"stratum",
               b"IcedID", b"XiaoBa", b"ransom", b"encrypt", b"decrypt"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    # TG bot
    tg = set(m.group().decode("ascii", "replace") for m in re.finditer(tg_pat, data))
    if tg:
        print(f"[TG Bot]")
        for t in list(tg)[:3]: print(f"  {t}")
    
    # Discord
    dc = set(m.group().decode("ascii", "replace") for m in re.finditer(dc_pat, data))
    if dc:
        print(f"[Discord Webhook]")
        for t in list(dc)[:3]: print(f"  {t}")
    
    # URLs
    urls = set(m.group().decode("ascii", "replace") for m in re.finditer(url_pat, data))
    filtered = []
    for u in urls:
        if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "verisign",
                                          "usertrust", "comodo", "globalsign", "symantec",
                                          "schemas.", "w3.org", "adobe.com/xap", "ibsensoftware"]):
            continue
        filtered.append(u)
    if filtered:
        print(f"[URLs] {len(filtered)}:")
        for u in sorted(filtered)[:10]:
            print(f"  {u[:180]}")
    
    # IPs
    ips = set()
    for m in re.finditer(ip_pat, data):
        t = m.group().decode("ascii")
        parts = t.split(".")
        if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0","6.0.0.0","1.0.0.0","127.0.0.1","11.0.0.0","16.0.0.0","164.0.0.0","4.0.0.0","2.0.0.0","16.7.0.0"]:
            ips.add(t)
    if ips:
        print(f"[IPs] {len(ips)}:")
        for ip in sorted(ips)[:10]: print(f"  {ip}")
    print()
