# -*- coding: utf-8 -*-
"""NJRAT 分析：完整 API 调用图 + 关键行为识别"""
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# IAT wrapper 地址（从反汇编里 jmp dword [42Fxxx] 的形式推断）
# 通过反汇编里所有 "jmp dword [42Fxxx h]" 的模式找 wrapper
wrapper_by_iat = {}
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ 0x([0-9a-f]+)", line)
    if m:
        wrapper = int(m.group(2), 16)
        continue
    j = re.search(r"jmp dword \[42F([0-9A-Fa-f]{3})h\]", line)
    if j:
        iat = 0x42F000 + int(j.group(1), 16)
        wrapper_by_iat[wrapper] = iat

# 我们已知 113 个 API 的导入顺序。反过来从 IAT 表中找。
# IAT 从 0x42F000 开始（.idata 段）

# 找所有 call 目标
calls = {}
cur = None
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = m.group(2)
        calls[cur] = []
    elif cur:
        c = re.search(r"call 0040([0-9A-Fa-f]+)h", line)
        if c:
            calls[cur].append("0x40" + c.group(1).lower())

# 统计调用最多的 wrapper
call_count = {}
for f, cs in calls.items():
    for c in cs:
        call_count[c] = call_count.get(c, 0) + 1

print("=" * 70)
print("调用最多的 30 个函数")
print("=" * 70)
for c, n in sorted(call_count.items(), key=lambda x: -x[1])[:30]:
    print(f"  {c}: {n} 次")

# 找几个核心函数：可能包含全部功能的函数
# sub_40129c 调用 0x408bd0 (CreateFile?) 等
# 我们要识别"引擎" —— 看下哪些函数被 402a82（进程注入）、407947（持久化）调用

print()
print("=" * 70)
print("关键函数的调用链")
print("=" * 70)
for f in ["0x402a82", "0x407947", "0x404828", "0x401bf5", "0x407edc", "0x4073f8", "0x4071ca", "0x4066d2", "0x406c36"]:
    cs = calls.get(f, [])
    print(f"\n{f} 调用了 {len(cs)} 个函数:")
    for c in sorted(set(cs)):
        print(f"  → {c}")
