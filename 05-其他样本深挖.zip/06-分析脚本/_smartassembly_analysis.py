# -*- coding: utf-8 -*-
"""AgentTesla SmartAssembly payload 反编译分析"""
import re

p = r"C:\malware_work\AgentTesla\payload_decompiled\hidden_payload_full.native.cs"
try:
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
except Exception as e:
    print(f"读取失败: {e}")
    import sys; sys.exit()

print(f"源码长度: {len(content)}")
print()

# 找所有方法名
methods = re.findall(r"(?:public|private|internal|protected|static)[\w\s<>]*\(\s*\)\s*\{", content)
print(f"方法数: {len(methods)}")

# 找关键类名
classes = re.findall(r"(?:class|struct|interface)\s+([A-Za-z_][\w]*)", content)
print(f"类数: {len(classes)}")
for c in sorted(set(classes))[:30]:
    print(f"  {c}")

# 找字符串调用（SmartAssembly 的字符串解密调用）
print()
print("[字符串解密调用]")
calls = re.findall(r"SmartAssembly\.StringsEncoding\.GetString\([^)]*\)", content)
print(f"调用数: {len(calls)}")

# 找敏感调用
print()
print("[敏感调用]")
for kw in ["SmtpClient", "MailMessage", "Send", "HttpClient", "WebClient",
           "GetAsyncKeyState", "Clipboard", "RegistryKey", "Process.",
           "Assembly.Load", "Activator.CreateInstance", "TcpClient"]:
    cnt = content.count(kw)
    if cnt > 0:
        print(f"  {kw}: x{cnt}")

# 打印前 200 行
print()
print("[源码前 200 行]")
for i, line in enumerate(content.split("\n")[:200]):
    print(f"{i+1}: {line}")
