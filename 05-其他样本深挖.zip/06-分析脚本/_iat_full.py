# -*- coding: utf-8 -*-
"""完整 IAT 映射：通过 IAT 表逐项解析，再映射到 wrapper"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"

with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
sections = [
    (".text",  0x1000, 0x7F6C, 0x400, 0x7F6C),
    (".bss",   0x9000, 0x213B0, 0x0, 0x0),
    (".data",  0x2B000, 0x33D0, 0x8400, 0x33D0),
    (".idata", 0x2F000, 0xEA4, 0xB800, 0xEA4),
    (".fldo",  0x30000, 0x1000, 0xCA00, 0x200),
    (".l1",    0x31000, 0x1200, 0xCC00, 0x1200),
]
def rva2off(rva):
    for _, va, vs, raw, rs in sections:
        if va <= rva < va + max(vs, rs):
            return raw + (rva - va)
    return None

# 解析导入表，遍历顺序对应 IAT 表顺序
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = rva2off(imp_rva)

iat_list = []  # (IAT_VA, api_name)
i = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = rva2off(name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_rva = oft or ft
    thunk_off = rva2off(thunk_rva)
    j = 0
    while True:
        t = thunk_off + j*4
        if t+4 > len(data): break
        v = struct.unpack("<I", data[t:t+4])[0]
        if v == 0: break
        iat_va = IMAGE_BASE + ft + j*4
        if v & 0x80000000:
            name = f"{dll}!#{v & 0x7FFFFFFF}"
        else:
            h = rva2off(v)
            if h:
                end = data.find(b"\x00", h+2)
                name = f"{dll}!{data[h+2:end].decode('ascii', 'replace')}"
        iat_list.append((iat_va, name))
        j += 1
    i += 1

print(f"IAT 项: {len(iat_list)}")
for va, n in iat_list[:5]:
    print(f"  0x{va:x} -> {n}")
print("...")

# 建 map: IAT VA -> API 名
iat_map = dict(iat_list)

# 解析 wrapper
wrapper_map = {}
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ 0x([0-9a-f]+)", line)
    if m:
        cur = int(m.group(2), 16)
        continue
    jm = re.search(r"jmp dword \[42F([0-9A-Fa-f]{3})h\]", line)
    if jm:
        iat_va = 0x42F000 + int(jm.group(1), 16)
        if iat_va in iat_map:
            wrapper_map[cur] = iat_map[iat_va]

print(f"\nAPI wrapper: {len(wrapper_map)}")
print()
print("=" * 70)
print("关键 API 及其 wrapper 地址")
print("=" * 70)

key_kws = ["InternetOpen", "InternetConnect", "HttpOpenRequest", "HttpSendRequest", "InternetReadFile",
           "WSASocket", "connect", "send", "recv", "WSAStartup",
           "VirtualAllocEx", "WriteProcessMemory", "CreateRemoteThread", "NtUnmap", "NtMap", "ResumeThread",
           "SetWindowsHookEx", "GetAsyncKeyState", "GetForegroundWindow", "GetWindowText",
           "BitBlt", "GetDC", "CreateCompatibleDC", "CreateDIBSection",
           "RegCreate", "RegSetValue", "RegOpen", "RegQuery",
           "CreateProcess", "WinExec", "ShellExecute", "TerminateProcess", "OpenProcess",
           "IsDebugger", "CheckRemote", "NtQueryInformation",
           "CreateService", "ShellServiceObject", "RegisterServiceProcess",
           "GetUserName", "GetComputerName",
           "Sleep", "GetTickCount",
           "CreateMutex", "OpenMutex",
           "GetSystemDirectory", "GetTempPath", "GetWindowsDirectory", "GetModuleFileName"]

for kw in key_kws:
    for w, api in wrapper_map.items():
        if kw.lower() in api.lower():
            print(f"  {api:<45} wrapper=0x{w:x}")
            break
