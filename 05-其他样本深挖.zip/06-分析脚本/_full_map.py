# -*- coding: utf-8 -*-
"""完整 IAT 映射 —— IAT 位于 .l1 段（0x431000 RVA）"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"

with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000

def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400, 0x7F6C), (0x9000, 0x213B0, 0x0, 0x0), (0x2B000, 0x33D0, 0x8400, 0x33D0), (0x2F000, 0xEA4, 0xB800, 0xEA4), (0x30000, 0x1000, 0xCA00, 0x200), (0x31000, 0x1200, 0xCC00, 0x1200)]
    for va_, vs, raw, rs in secs:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

# 重新解析导入表（原文件就是解密后的 PE）
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = va2off(IMAGE_BASE + imp_rva)

# IAT 表：遍历顺序对应 IAT 项
iat_entries = []  # (order_idx, iat_va, api_name)
i = 0
idx = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = va2off(IMAGE_BASE + name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_rva = oft or ft
    thunk_off = va2off(IMAGE_BASE + thunk_rva)
    j = 0
    while True:
        t = thunk_off + j*4
        if t+4 > len(data): break
        v = struct.unpack("<I", data[t:t+4])[0]
        if v == 0: break
        iat_va = IMAGE_BASE + ft + j*4
        if v & 0x80000000:
            name = f"{dll}!#{v & 0x7FFFFFFF}"
        else:
            h = va2off(IMAGE_BASE + v)
            if h:
                end = data.find(b"\x00", h+2)
                name = f"{dll}!{data[h+2:end].decode('ascii', 'replace')}"
        iat_entries.append((idx, iat_va, name))
        j += 1
        idx += 1
    i += 1

print(f"IAT 项: {len(iat_entries)}")
for idx, va, n in iat_entries[:3]:
    print(f"  [{idx}] 0x{va:x} -> {n}")
print("...")

# IAT 表在 .idata 段里（从反汇编看是 0x42Fxxx）
# 我们反汇编里 jmp dword [42Fxxx] 就是 IAT 表项
# 42F000 落在 .idata 段（VA 0x2F000）
# 而 .idata 段的导入表 first_thunk 指向 0x31000（.l1 段）
# **结论**：反汇编的 42Fxxx 是导入跳转表，实际内容为 0x43xxxx 指针
# 42Fxxx 表项里的值指向 0x43xxxx，那才是真正的 IAT
# 
# 等等，反汇编读的是 42F4DC，实际是 [42F4DC] 的值 = 0x432144
# 0x432144 是 .l1 段的 IAT 表项！
# 
# 所以正确的顺序：
#   42Fxxx（.idata 段）=> 导入跳转表（jmp table）
#   表项内容 0x43xxxx => .l1 段的实际 IAT 表项
#   0x43xxxx 的值 => 真正的 API 地址

# 那就直接用导入表解析结果：IAT 项已经在 .l1 段里（0x4310xx 到 0x4321xx）
# 反汇编里的 jmp dword [42Fxxx]，42Fxxx 是跳转表
# 跳转表内容就是 .l1 段里的 IAT 地址

# 反汇编里 jmp 42Fxxx，从 42Fxxx 读值 => 0x43xxxx => 该地址是 IAT 表项，值是 API 函数地址

# 直接用导入表解析出的 IAT 项列表（iat_entries）与 42Fxxx 表位置对照

# 从反汇编里找 jmp dword [42Fxxx]
jmp_iat_table = {}  # 42Fxxx VA -> wrapper_va
cur = None
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = int(m.group(2), 16)
        continue
    j = re.search(r"jmp dword \[(42F[0-9A-Fa-f]{3})h\]", line)
    if j and cur:
        jmp_iat_table[int(j.group(1), 16)] = cur
        cur = None

# 看 42Fxxx 跳转表里存的值
print(f"\njmp dword [42Fxxx]: {len(jmp_iat_table)} 个")
for tgt_va in sorted(jmp_iat_table.keys())[:5]:
    off = va2off(tgt_va)
    if off:
        val = struct.unpack("<I", data[off:off+4])[0]
        print(f"  [0x{tgt_va:x}] = 0x{val:x}  (wrapper=0x{jmp_iat_table[tgt_va]:x})")

# 对照：0x43xxxx 是否在 IAT 表里
iat_by_va = {va: name for _, va, name in iat_entries}
print(f"\nIAT 表 VA 范围：")
vs = sorted(iat_by_va.keys())
print(f"  最小 0x{vs[0]:x}  最大 0x{vs[-1]:x}")

# 匹配 wrapper -> API
wrapper_to_api = {}
for jtgt, wrapper in jmp_iat_table.items():
    off = va2off(jtgt)
    if off:
        val = struct.unpack("<I", data[off:off+4])[0]
        if val in iat_by_va:
            wrapper_to_api[wrapper] = iat_by_va[val]

print(f"\n成功匹配: {len(wrapper_to_api)} 个 wrapper -> API")
print()
print("=" * 70)
print("API wrapper 完整列表")
print("=" * 70)
for w in sorted(wrapper_to_api.keys()):
    print(f"  0x{w:x}  ->  {wrapper_to_api[w]}")
