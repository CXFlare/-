# -*- coding: utf-8 -*-
"""分析 FakeAV + Mirai 深挖 + 888RAT 最后尝试"""
import re, hashlib, os

# FakeAV
print("=" * 70)
print("FakeAV")
print("=" * 70)
p = r"C:\malware_work\FakeAV\90307e8421fc5314379ba87f56a11034_NeikiAnalytics.exe"
if os.path.exists(p):
    with open(p, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    print(f"头部: {data[:32].hex()}")
    if data[:2] == b"MZ": print("PE")
    
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"MSVBVM60", b"System.", b"FakeAV", b"AV", b"antivirus",
               b"license", b"activate", b"scan", b"virus", b"detect",
               b"payment", b"credit", b"card", b"paypal"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    print("[关键字符串]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{8,150}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["fakeav", "antivirus", "virus", "activate",
                                  "payment", "credit", "card", "license",
                                  "virus scan", "warning", "infection"]):
            if 8 < len(t) < 150:
                print(f"  {t[:140]}")
    print()

# Mirai 深挖
print("=" * 70)
print("Mirai (ELF)")
print("=" * 70)
p = r"C:\malware_work\Mirai\1075519b2d23eb91d403fc61768c82bf_JaffaCakes118"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")

# 提所有可打印字符串
all_strs = set()
for m in re.finditer(rb"[\x20-\x7e]{6,200}", data):
    t = m.group().decode("ascii", "replace")
    all_strs.add(t)

# 关键 Mirai 特征
print()
print("[Mirai 特征字符串]")
for s in sorted(all_strs):
    tl = s.lower()
    if any(k in tl for k in ["telnet", "ssh", "exploit", "bot", "ddos",
                              "attack", "syn", "udp", "http/1.1", "user-agent",
                              "login", "password", "admin", "root",
                              "watchdog", "kill", "proc", "cgi",
                              "/bin/busybox", "wget", "tftp", "chmod"]):
        if len(s) < 150:
            print(f"  {s[:140]}")
