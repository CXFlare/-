# -*- coding: utf-8 -*-
"""DarkComet 完整字符串 + 特征"""
import re, hashlib

pe = r"C:\malware_work\DarkComet\0faee8383e8088667c4e94ab44d8cf66_JaffaCakes118"
with open(pe, "rb") as f:
    data = f.read()

print("=" * 70)
print("DarkComet 完整特征")
print("=" * 70)

# 全部可读 ASCII 字符串
ascii_str = re.findall(rb"[\x20-\x7e]{6,}", data)
seen = set()
all_strs = []
for s in ascii_str:
    try: t = s.decode("ascii")
    except: continue
    if t not in seen:
        seen.add(t)
        all_strs.append(t)

print(f"唯一 ASCII 字符串: {len(all_strs)}")
print()

# 分类
cats = {
    "网络": ["socket", "winsock", "ioctl", "connect", "send", "recv", "http", "port", "ip"],
    "持久化": ["run\\", "runonce", "startup", "shell folders", "winlogon", "msconfig"],
    "远程控制": ["remote", "desktop", "keylog", "webcam", "monitor", "cursor", "chat"],
    "文件操作": ["file", "download", "upload", "delete", "execute", "shell"],
    "注册表": ["software\\", "hklm", "hkcu", "registry"],
    "命令执行": ["cmd.exe", "exec", "process", "kill"],
    "加密": ["encrypt", "decrypt", "password", "crypt"],
}

for cat, kws in cats.items():
    hits = set()
    for t in all_strs:
        tl = t.lower()
        if any(k in tl for k in kws):
            if 5 < len(t) < 150:
                hits.add(t)
    if hits:
        print(f"\n### {cat} ({len(hits)}) ###")
        for h in sorted(hits)[:25]:
            print(f"  {h[:150]}")
