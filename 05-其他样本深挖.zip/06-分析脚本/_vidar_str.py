# -*- coding: utf-8 -*-
"""Vidar 全部关键字符串"""
import hashlib, re

p = r"C:\malware_work\Vidar\f74356e6d895188cc5b28c98d9305844.bin"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# 全部 6+ 字符可打印串，去重
all_str = set()
for m in re.finditer(rb"[\x20-\x7e]{6,200}", data):
    all_str.add(m.group().decode("ascii", "replace"))

print(f"唯一字符串: {len(all_str)}")
print()

# 打印含特定关键词的
print("[关键字符串]")
for s in sorted(all_str):
    tl = s.lower()
    if any(k in tl for k in ["vidar", "stealer", "xmr", "monero", "stratum",
                              "donate", "nicehash", "wallet", "btc",
                              "miner", "pool.", "tcp://", "ssl://",
                              "config", "c2", "gate", "panel"]):
        if len(s) < 200:
            print(f"  {s[:190]}")
