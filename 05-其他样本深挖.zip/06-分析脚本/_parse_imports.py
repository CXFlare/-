# -*- coding: utf-8 -*-
import json

path = r"C:\malware_work\NJRAT\symbols.json"
with open(path, "r", encoding="utf-8", errors="replace") as f:
    txt = f.read()

# 找到 JSON 部分
start = txt.find("{")
end = txt.rfind("}") + 1
if start < 0:
    print("无 JSON")
    exit()
data = json.loads(txt[start:end])

print("=" * 70)
print("导入表按 DLL 分组")
print("=" * 70)

imports = data.get("imports", [])
by_dll = {}
for imp in imports:
    if isinstance(imp, dict):
        dll = imp.get("dll") or imp.get("module") or "?"
        name = imp.get("name") or imp.get("symbol") or "?"
    elif isinstance(imp, list):
        dll, name = imp[0], imp[1]
    else:
        dll, name = "?", str(imp)
    by_dll.setdefault(dll, []).append(name)

for dll, names in sorted(by_dll.items()):
    print(f"\n### {dll} ({len(names)}) ###")
    for n in sorted(names):
        print(f"  {n}")

print()
print("=" * 70)
print("可疑 API（网络 / 注入 / 键盘 / 持久化 / 反调试）")
print("=" * 70)
all_names = " ".join(n for ns in by_dll.values() for n in ns).lower()
keywords = {
    "网络": ["socket", "connect", "send", "recv", "wsastartup", "internetopen", "httpsend", "internetread", "wininet", "winhttp"],
    "注入": ["virtualalloc", "writeprocessmemory", "createremotethread", "ntunmap", "ntmap", "setthreadcontext", "getthreadcontext", "resumethread"],
    "键盘/屏幕": ["setwindowshook", "getasynckeystate", "getkeystate", "bitblt", "getdc", "createdib", "getforeground", "getwindowtext"],
    "注册表/持久化": ["regcreate", "regsetvalue", "regopen", "regquery", "shellservice", "createservice"],
    "进程": ["createprocess", "winexec", "shellexecute", "terminateprocess", "openprocess", "getsystemdirectory", "getmodulefilename"],
    "反调试": ["isdebugger", "checkremotedebugger", "ntqueryinformation", "outputdebug"],
    "加密": ["crypt", "md5", "sha", "cryptgen"],
}
for cat, kws in keywords.items():
    hits = sorted(set(n for ns in by_dll.values() for n in ns if any(k in n.lower() for k in kws)))
    print(f"\n[{cat}] {len(hits)} 个:")
    for h in hits:
        print(f"  {h}")
