# -*- coding: utf-8 -*-
"""888RAT - 直接字符串提取"""
import re, hashlib

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

print(f"大小: {len(data)} 字节")
print(f"MD5:    {hashlib.md5(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print()

# ASCII 字符串
ascii_str = re.findall(rb"[\x20-\x7e]{8,}", data)
print(f"ASCII 字符串: {len(ascii_str)}")

# UTF-16LE
utf16_str = re.findall(rb"(?:[\x20-\x7e]\x00){6,}", data)
print(f"UTF-16LE 字符串: {len(utf16_str)}")
print()

# 关键 IOC 过滤
seen = set()
for s in ascii_str + utf16_str:
    try:
        t = s.decode("utf-16le" if b"\x00" in s else "ascii", "replace").strip("\x00")
    except: continue
    if not t or t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["http", "telegram", "discord", ".onion", "c2", "panel", "password=",
                              "apikey", "api_key", "token=", "bot_token", "chat_id",
                              "software\\", "hklm", "hkcu", "cmd.exe", "powershell",
                              "autoit", "smtp", "ftp://", "\\windows\\", "sysnative"]):
        if len(t) < 200:
            print(f"  {t[:180]}")
