# -*- coding: utf-8 -*-
"""Vidar 深度分析 - 内存 dump"""
import re, hashlib

p = r"C:\malware_work\Vidar\f74356e6d895188cc5b28c98d9305844.bin"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")

# Vidar 是 UPX 打包的内存 dump
# 关键特征
print("[Vidar 特征]")
for kw in [b"Vidar", b"vidar", b"XMR", b"monero", b"stratum", b"wallet",
           b"metamask", b"exodus", b"jaxx", b"electrum", b"bitcoin",
           b"telegram", b"discord.com/api", b"bot", b"chat_id",
           b"clipboard", b"password", b"browser", b"chrome", b"firefox",
           b"stealer", b"passwords", b"cookies"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

print()
print("[TG Bot Token]")
for m in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}", data):
    print(f"  {m.group().decode()}")

print()
print("[Discord Webhook]")
for m in re.finditer(rb"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+", data):
    print(f"  {m.group().decode()}")

print()
print("[XMR 钱包]")
for m in re.finditer(rb"\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b", data):
    print(f"  {m.group().decode()}")

print()
print("[关键 URL]")
seen = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
    u = m.group().decode("ascii", "replace")
    if u in seen: continue
    seen.add(u)
    if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                      "verisign", "usertrust", "comodo"]):
        continue
    print(f"  {u[:180]}")
