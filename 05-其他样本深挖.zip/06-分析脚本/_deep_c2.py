# -*- coding: utf-8 -*-
"""深挖有明确 C2 的样本"""
import re, os

# Pony - 有明确 C2
print("=" * 70)
print("Pony 深度分析")
print("=" * 70)
pony_path = r"C:\malware_work\Pony\106fabcf10a5c5486f09e47e794bfef6_JaffaCakes118"
with open(pony_path, "rb") as f:
    data = f.read()

# 提取所有 URL
urls = set(re.findall(rb"https?://[\w\.\-:/?=&%_@#+~]{4,200}", data))
print("[所有 URL]")
for u in sorted(urls):
    print(f"  {u.decode('ascii','replace')[:200]}")

# 提取所有域名
domains = set(re.findall(rb"\b[a-zA-Z0-9][a-zA-Z0-9\-]{1,62}\.(?:com|net|org|ru|io|xyz|top|su|cc|info|biz|eu|pl|cn|tk|ml|ga|cf|gq)\b", data))
print()
print("[所有域名]")
for d in sorted(domains)[:40]:
    print(f"  {d.decode('ascii','replace')}")

# Pony 特征配置
print()
print("[Pony 特征字符串]")
for kw in [b"gate.php", b"shit.exe", b"Pony", b"FTP", b"SMTP", b"IMAP", b"POP3",
           b"Browser", b"Mail", b"Steam", b"Wallet", b"Bitcoin", b"Litecoin",
           b"formgrabber", b"inject", b"panel", b"config", b"loader"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

print()
print("=" * 70)
print("Imminent 深度分析")
print("=" * 70)
imm_path = r"C:\malware_work\Imminent\10835bbaba51e62af438366f2128e5f5_JaffaCakes118"
with open(imm_path, "rb") as f:
    data = f.read()

urls = set(re.findall(rb"https?://[\w\.\-:/?=&%_@#+~]{4,200}", data))
print("[URLs]")
for u in sorted(urls):
    print(f"  {u.decode('ascii','replace')[:200]}")

ips = set(re.findall(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b", data))
print("[IPs]")
for ip in sorted(ips):
    t = ip.decode("ascii")
    parts = t.split(".")
    if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0", "6.0.0.0"]:
        print(f"  {t}")

# 字符串
print("[特征]")
for kw in [b"macros", b"t.php", b"stats", b"send", b"thread", b"loader", b"doc",
           b"vbs", b"js", b"powershell", b"wscript", b"russia", b"russian"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")
