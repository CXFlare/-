# -*- coding: utf-8 -*-
"""批量分析：Azorult / HawkEye / Adwind / Matiex / MassLogger / RisePRO 深挖"""
import re, hashlib, os

samples = [
    ("Azorult", r"C:\malware_work\Azorult\1087dc61f973f13367ea32ba9ac5e3f9_JaffaCakes118"),
    ("HawkEye", r"C:\malware_work\HawkEye\0ba173af7380bbe70d970caec82ffc36_JaffaCakes118"),
    ("Adwind", r"C:\malware_work\Adwind\108ae58447a634391c067400ce7bf618_JaffaCakes118"),
    ("Matiex", r"C:\malware_work\Matiex\0b52424adb115b1336d084cf0cfbb73e_JaffaCakes118"),
    ("MassLogger", r"C:\malware_work\MassLogger\ecf7e1dba888e815ec3b2a05dc2a4b13_JaffaCakes118"),
    ("RisePRO", r"C:\malware_work\RisePRO\6ba442bd4812adc7ac98101130cc1c12ae0155e8a94dbe3bf2e24979ac217407"),
    ("KPot", r"C:\malware_work\KPot\105cf23b2dd4fa045429abaa8125a1b6_JaffaCakes118"),
    ("ZGRat", r"C:\malware_work\ZGRat\bc415aafd68de975f42d71ef25868a7de65ddf166a0bb03246243c6d1b0a0af1"),
]

# 通用 TG bot / Discord webhook 搜索
tg_pat = rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}"
dc_pat = rb"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+"
ip_pat = rb"\b(?:\d{1,3}\.){3}\d{1,3}\b"
url_pat = rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}"
email_pat = rb"[a-zA-Z0-9._%+\-]{4,64}@[a-zA-Z0-9.\-]{4,200}\.[a-z]{2,6}"

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}")
    
    # TG bot
    tg = set(m.group().decode("ascii", "replace") for m in re.finditer(tg_pat, data))
    if tg:
        print(f"[TG Bot Token] {len(tg)}:")
        for t in list(tg)[:5]: print(f"  {t}")
    
    # Discord webhook
    dc = set(m.group().decode("ascii", "replace") for m in re.finditer(dc_pat, data))
    if dc:
        print(f"[Discord Webhook] {len(dc)}:")
        for t in list(dc)[:5]: print(f"  {t}")
    
    # URLs
    urls = set(m.group().decode("ascii", "replace") for m in re.finditer(url_pat, data))
    if urls:
        print(f"[URLs] {len(urls)}:")
        for u in sorted(urls)[:12]:
            # 过滤微软/证书的 URL
            if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "verisign", "thawte",
                                            "usertrust", "comodo", "globalsign", "symantec",
                                            "schemas.", "w3.org", "adobe.com/xap"]):
                continue
            print(f"  {u[:180]}")
    
    # IPs
    ips = set()
    for m in re.finditer(ip_pat, data):
        t = m.group().decode("ascii")
        parts = t.split(".")
        if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0", "6.0.0.0", "1.0.0.0", "127.0.0.1"]:
            ips.add(t)
    if ips:
        print(f"[IPs] {len(ips)}:")
        for ip in sorted(ips)[:12]: print(f"  {ip}")
    
    # 邮箱（过滤常见库的）
    emails = set()
    for m in re.finditer(email_pat, data):
        t = m.group().decode("ascii", "replace")
        if not any(x in t.lower() for x in ["example.com", "microsoft.com", "adobe.com",
                                              "w3.org", "schemas", "sectigo", "digicert"]):
            emails.add(t)
    if emails:
        print(f"[邮箱] {len(emails)}:")
        for e in sorted(emails)[:8]: print(f"  {e}")
    
    print()
