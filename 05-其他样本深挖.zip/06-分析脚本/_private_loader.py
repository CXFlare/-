# -*- coding: utf-8 -*-
"""PrivateLoader 深度分析"""
import hashlib, re

p = r"C:\malware_work\PrivateLoader\2024-05-03_68452609966ed034f6e024d4d6f30fc4_magniber_metamorfo"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print(f"头部: {data[:32].hex()}")
print()

# PrivateLoader 特征
print("[PrivateLoader 特征]")
for kw in [b"Magniber", b"Metamorfo", b"private", b"loader", b"gate",
           b"cmd.exe", b"powershell", b"CreateProcess", b"VirtualAlloc",
           b"WinExec", b"ShellExecute", b"http://", b"https://",
           b"browser", b"clipboard", b"Outlook", b"Firefox", b"password"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

# 提取 URL（过滤证书）
print()
print("[URLs]")
seen = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
    u = m.group().decode("ascii", "replace")
    if u in seen: continue
    seen.add(u)
    if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                          "verisign", "usertrust", "comodo",
                                          "globalsign", "symantec", "schemas.",
                                          "w3.org", "adobe", "entrust",
                                          "thawte", "wosign", "curl.se",
                                          "bugtrack", "tempuri", "purl.org",
                                          "startssl"]):
        print(f"  {u[:180]}")

# BTC
print()
print("[BTC / 钱包]")
for m in re.finditer(rb"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b", data):
    w = m.group().decode()
    if len(w) >= 26 and len(w) < 64:
        print(f"  {w}")
