# -*- coding: utf-8 -*-
"""深入分析 SnakeKeyLogger / Lumma / StealC / Raccoon - 需要找 C2、TG bot"""
import re, os

samples = [
    ("SnakeKeyLogger", r"C:\malware_work\SnakeKeyLogger\FATURA VE BELGELER..exe"),
    ("Lumma", r"C:\malware_work\Lumma\5ce704b101d2c1cb57abbe7dce3f3ce627340ac1766c0c5f165ed7d28d24fede"),
    ("StealC", r"C:\malware_work\StealC\da886b94c504088d53032e48ffcd264e3a3406b0342f38e44f8b1f3bbe37ef23"),
    ("Raccoon", r"C:\malware_work\Raccoon\0203ee4a4252b78a17796e7e4832dcfb921051b87e4a727eae172ea13d9424cd"),
]

# 通用 IOC 模式
patterns = {
    "URL": rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}",
    "IP": rb"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "域名": rb"\b[a-zA-Z0-9][a-zA-Z0-9\-]{1,62}\.(?:com|net|org|ru|io|xyz|top|su|cc|info|biz|onion)\b",
    "TG Bot Token": rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}",
    "邮箱": rb"[a-zA-Z0-9._%+\-]{4,64}@[a-zA-Z0-9.\-]{4,200}\.[a-z]{2,6}",
    "Base64 长串": rb"[A-Za-z0-9+/]{100,}={0,2}",
    "加密货币地址": rb"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b|\b0x[a-fA-F0-9]{40}\b",
}

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    
    for pname, pat in patterns.items():
        hits = set()
        for m in re.finditer(pat, data):
            hits.add(m.group().decode("ascii", "replace"))
            if len(hits) >= 20: break
        if hits:
            print(f"\n[{pname}] {len(hits)}:")
            for h in sorted(hits)[:15]:
                print(f"  {h[:180]}")
    print()
