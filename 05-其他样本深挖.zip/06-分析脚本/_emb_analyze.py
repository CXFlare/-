# -*- coding: utf-8 -*-
"""NJRAT 完整报告生成 + 提取 embedded_1 分析"""
import struct, re

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

# embedded_1 分析
with open(r"C:\malware_work\NJRAT\embedded_1.bin", "rb") as f:
    emb = f.read()
print("=" * 70)
print("embedded_1 分析（真实内嵌 PE）")
print("=" * 70)
strs = re.findall(rb"[\x20-\x7e]{5,}", emb)
for s in strs:
    try:
        t = s.decode("ascii")
        print(f"  {t[:120]}")
    except: pass

# embedded_2 分析
with open(r"C:\malware_work\NJRAT\embedded_2.bin", "rb") as f:
    emb2 = f.read()
print()
print("=" * 70)
print("embedded_2（主 PE 副本）")
print("=" * 70)
# 看它的关键字符串
strs2 = re.findall(rb"[\x20-\x7e]{8,}", emb2)
seen = set()
for s in strs2:
    try:
        t = s.decode("ascii")
        if "http" in t.lower() or "SOFTWARE" in t or "\x5c" in t:
            if t not in seen:
                seen.add(t)
                print(f"  {t[:130]}")
    except: pass
