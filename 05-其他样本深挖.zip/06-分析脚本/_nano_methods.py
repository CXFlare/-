# -*- coding: utf-8 -*-
"""Nanocore - 看关键方法实现"""
import re

p = r"C:\malware_work\Nanocore\decompiled\DiscordNSR.native.cs"
with open(p, "r", encoding="utf-8", errors="replace") as f:
    content = f.read()

# 找含关键 API 的行
print("=== Socket / Rijndael / MD5 / Registry 相关行 ===")
for i, line in enumerate(content.split("\n")):
    if any(k in line for k in ["Socket", "Rijndael", "MD5", "RegistryKey",
                                 "Activator", "Process.Start", "File.WriteAllBytes"]):
        print(f"  L{i+1}: {line.strip()[:180]}")

print()
print("=== 所有方法签名 ===")
# 找方法定义
methods = re.findall(r"^(?:[\s]*(?:public|private|internal|protected|static|virtual|override)\s+)+[\w<>\[\],\.\?]*\s+([A-Za-z_][\w]*)\s*\([^)]*\)", content, re.MULTILINE)
print(f"方法 {len(methods)} 个:")
for m in sorted(set(methods)):
    print(f"  {m}")

# 找所有字符串字面量
print()
print("=== 字符串字面量 ===")
seen = set()
for m in re.finditer(r'"([^"\\]{2,150})"', content):
    lit = m.group(1)
    if lit in seen: continue
    seen.add(lit)
    print(f"  {lit[:150]}")
