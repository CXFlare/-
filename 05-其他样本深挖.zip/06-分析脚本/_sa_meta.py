# -*- coding: utf-8 -*-
"""AgentTesla - 直接从 PE metadata 找加密字符串资源"""
import struct, hashlib, re

p = r"C:\malware_work\AgentTesla\hidden_payload_full.exe"
with open(p, "rb") as f:
    data = f.read()

# 找 metadata
# BSJB magic
bsjb = data.find(b"BSJB")
print(f"BSJB @ 0x{bsjb:x}")

if bsjb > 0:
    # BSJB header: 
    # 4 bytes magic
    # 2 bytes major version
    # 2 bytes minor version
    # 4 bytes reserved
    # 4 bytes version string length
    # N bytes version string
    # 2 bytes flags
    # 2 bytes streams
    # then stream headers
    ver_len = struct.unpack("<I", data[bsjb+12:bsjb+16])[0]
    print(f"ver_len: {ver_len}")
    ver_str = data[bsjb+16:bsjb+16+ver_len].rstrip(b"\x00").decode("ascii", "replace")
    print(f"version: {ver_str}")
    off = bsjb + 16 + ver_len
    # 对齐到 4 字节
    if off % 4: off += 4 - (off % 4)
    flags = struct.unpack("<H", data[off:off+2])[0]
    streams = struct.unpack("<H", data[off+2:off+4])[0]
    print(f"flags=0x{flags:x} streams={streams}")
    off += 4
    # 每个 stream header: 4 bytes offset + 4 bytes size + name (null-term, 4-byte aligned)
    for i in range(streams):
        s_off = struct.unpack("<I", data[off:off+4])[0]
        s_size = struct.unpack("<I", data[off+4:off+8])[0]
        name_start = off + 8
        name_end = data.find(b"\x00", name_start)
        name = data[name_start:name_end].decode("ascii", "replace")
        print(f"  {name}: offset=0x{s_off:x} size=0x{s_size:x}")
        off = name_end + 1
        # 对齐到 4 字节
        while off % 4: off += 1

# 找 "PADPADP" 附近 - 这是 .NET 资源对齐
print()
print("[PADPADP 附近]")
for m in re.finditer(re.escape(b"PADPADP"), data):
    pos = m.start()
    ctx = data[max(0, pos-32):pos+128]
    print(f"  0x{pos:x}: {ctx.hex()[:200]}")
    break

# 找资源数据区（位于 .resources 流末尾）
# .NET 嵌入资源在 .text 段里，紧跟在 metadata 后
# 直接找常见资源名 "07eefa3e" 或其 UTF-16 形式
for pat in [b"07eefa3e", b"07E" + b"E" + b"FA" + b"3E"]:
    for m in re.finditer(re.escape(pat), data):
        print(f"  资源名 @ 0x{m.start():x}")

# 找资源名（UTF-16LE）
guid_str = "07eefa3e-4bba-4508-ab41-20404168e31b"
guid_utf16 = guid_str.encode("utf-16le")
pos = data.find(guid_utf16)
print(f"GUID UTF-16 @ 0x{pos if pos > 0 else 'not found':x}" if pos >= 0 else "GUID UTF-16: 未找到")

# 尝试找另一个常见 SmartAssembly 资源
for name in ["SmartAssembly", "Strings", "{z}", "Resources"]:
    utf16 = name.encode("utf-16le")
    p_ = data.find(utf16)
    if p_ > 0:
        print(f"  '{name}' UTF-16 @ 0x{p_:x}")
