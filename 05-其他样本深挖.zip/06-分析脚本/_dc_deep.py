# -*- coding: utf-8 -*-
"""DarkComet 深度字符串 - 找 C2、命令、功能"""
import hashlib, re

pe = r"C:\malware_work\DarkComet\0faee8383e8088667c4e94ab44d8cf66_JaffaCakes118"
with open(pe, "rb") as f:
    data = f.read()

# 找所有 IPv4
print("[IP 地址]")
ips = set(re.findall(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b", data))
for ip in sorted(ips):
    t = ip.decode("ascii")
    parts = t.split(".")
    if all(0 <= int(p) <= 255 for p in parts):
        print(f"  {t}")

# 找 HTTP URL
print()
print("[URL]")
urls = set(re.findall(rb"https?://[\w\.\-:/?=&%_@#]{4,200}", data))
for u in sorted(urls)[:30]:
    print(f"  {u.decode('ascii','replace')[:180]}")

# 找 DarkComet 命令关键字
print()
print("[DarkComet 命令关键字]")
cmd_kws = [b"StartupFolder", b"StartupReg", b"StartupKey", b"HKLM", b"HKCU",
           b"RegRead", b"RegWrite", b"GetFile", b"PutFile", b"DeleteFile",
           b"ExecuteFile", b"DownloadFile", b"UploadFile", b"KillProcess",
           b"StartProcess", b"RemoteCMD", b"RegEdit", b"ServiceCreate",
           b"MonitorOff", b"MonitorOn", b"CursorHide", b"CursorShow",
           b"PCShutdown", b"PCRestart", b"PCLogoff", b"PCSuspend",
           b"RemoteDesktop", b"Keylogger", b"CameraCapture", b"AudioCapture",
           b"SendLogs", b"BlankScreen", b"Webcam"]
for kw in cmd_kws:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<25} x{c}")

# 找 Delphi form 名字
print()
print("[Delphi Form / 类名]")
forms = set(re.findall(rb"T[A-Z][A-Za-z0-9]{2,40}(?=\x00)", data))
for f in sorted(forms)[:60]:
    print(f"  {f.decode('ascii','replace')}")
