# -*- coding: utf-8 -*-
"""批量深度分析 5 个样本"""
import re, hashlib, os

samples = [
    ("XWorm", r"C:\malware_work\XWorm\op.exe"),
    ("Redline", r"C:\malware_work\Redline\4900-2-0x0000000000AB0000-0x0000000000B2EFAE-memory.dmp"),
    ("Remcos(VBS)", r"C:\malware_work\Remcos\sostener.vbs"),
    ("Nanocore", r"C:\malware_work\Nanocore\DiscordNSR.exe"),
    ("WarzoneRAT", r"C:\malware_work\WarzoneRAT\0fe23bfe4a1aff6b6e079d8a0c942d5b_JaffaCakes118"),
]

for name, path in samples:
    print("=" * 70)
    print(name + "  -  " + os.path.basename(path))
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 文件不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}")
    print(f"MD5:    {hashlib.md5(data).hexdigest()}")
    print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
    
    # PE?
    if data[:2] == b"MZ":
        print("PE 文件")
    elif b"WScript" in data or b"CreateObject" in data:
        print("VBScript 脚本")
    
    # 特征
    print("[特征]")
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"System.", b"Discord", b"Telegram", b"smtp", b"ftp://",
               b"keylog", b"stealer", b"browser", b"clipboard", b"webcam",
               b"Chrome", b"Firefox", b"Outlook", b"wallet", b"password"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<20} x{c}")
    
    # URL / 域名
    print("[关键 IOC]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{6,150}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["http://", "https://", "smtp.", "ftp.", "telegram",
                                  "discord.com/api", "bot", "chat_id", "password=",
                                  "apikey", "keylog", "clipboard", ".php", ".onion",
                                  "c2.", "gate", "panel"]):
            if 6 < len(t) < 200:
                print(f"  {t[:180]}")
    print()
