# -*- coding: utf-8 -*-
"""批量分析：5 个信息窃取家族"""
import re, hashlib, os

samples = [
    ("SnakeKeyLogger", r"C:\malware_work\SnakeKeyLogger\FATURA VE BELGELER..exe"),
    ("Lumma", r"C:\malware_work\Lumma\5ce704b101d2c1cb57abbe7dce3f3ce627340ac1766c0c5f165ed7d28d24fede"),
    ("Vidar", r"C:\malware_work\Vidar\f74356e6d895188cc5b28c98d9305844.bin"),
    ("StealC", r"C:\malware_work\StealC\da886b94c504088d53032e48ffcd264e3a3406b0342f38e44f8b1f3bbe37ef23"),
    ("Raccoon", r"C:\malware_work\Raccoon\0203ee4a4252b78a17796e7e4832dcfb921051b87e4a727eae172ea13d9424cd"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}")
    print(f"MD5:    {hashlib.md5(data).hexdigest()}")
    print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
    if data[:2] == b"MZ":
        print("PE 文件")
    
    print("[特征]")
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"System.", b"Telegram", b"smtp", b"ftp://", b"Discord",
               b"keylog", b"stealer", b"browser", b"clipboard", b"webcam",
               b"Chrome", b"Firefox", b"Outlook", b"wallet", b"password",
               b"Cookie", b"Crypto", b"Seed", b"wallet.dat"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<20} x{c}")
    
    print("[IOC]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{6,150}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["http://", "https://", "smtp.", "ftp.", "telegram",
                                  "discord.com/api", "bot", "chat_id", "apikey",
                                  "keylog", "clipboard", "wallet", ".php", ".onion",
                                  "password", "chrome", "firefox", "wallet.dat",
                                  "metamask", "exodus"]):
            if 6 < len(t) < 200:
                print(f"  {t[:180]}")
    print()
