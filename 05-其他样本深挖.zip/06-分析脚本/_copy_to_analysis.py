# -*- coding: utf-8 -*-
import os, shutil, csv

# 源分析成果在 C:\malware_work
src = r"C:\malware_work"
dst = r"C:\Users\洛天依\Desktop\新建文件夹\逆向\恶俗样本\分析"

# 1. 复制所有 CSV 报告
for f in os.listdir(src):
    if f.endswith(".csv"):
        shutil.copy(os.path.join(src, f), os.path.join(dst, f))
        print(f"复制: {f}")

# 2. 复制 NJRAT 完整产物到 analysis/samples
njrat_src = os.path.join(src, "NJRAT")
njrat_dst = os.path.join(dst, "samples", "NJRAT")
os.makedirs(njrat_dst, exist_ok=True)
for f in os.listdir(njrat_src):
    fp = os.path.join(njrat_src, f)
    if os.path.isfile(fp):
        shutil.copy(fp, os.path.join(njrat_dst, f))
print(f"复制 NJRAT 产物 {len(os.listdir(njrat_src))} 个文件")

# 3. 复制 DarkComet / Pony / MonsterV2 / Akira / GoldenEye 分析产物到 reports
for family in ["DarkComet", "Pony", "MonsterV2", "Akira", "GoldenEye", "FakeAV", "Mirai"]:
    src_dir = os.path.join(src, family)
    if os.path.isdir(src_dir):
        dst_dir = os.path.join(dst, "samples", family)
        os.makedirs(dst_dir, exist_ok=True)
        for f in os.listdir(src_dir):
            fp = os.path.join(src_dir, f)
            if os.path.isfile(fp) and os.path.getsize(fp) > 100:
                try:
                    shutil.copy(fp, os.path.join(dst_dir, f))
                except: pass
        print(f"复制 {family}")

print()
print("=== 最终目录结构 ===")
for root, dirs, files in os.walk(dst):
    level = root.replace(dst, "").count(os.sep)
    if level > 3: continue
    indent = "  " * level
    print(f"{indent}{os.path.basename(root)}/")
    if level <= 2:
        for f in files[:8]:
            sz = os.path.getsize(os.path.join(root, f))
            print(f"{indent}  {f} ({sz}B)")
        if len(files) > 8:
            print(f"{indent}  ... 还有 {len(files)-8} 个文件")
