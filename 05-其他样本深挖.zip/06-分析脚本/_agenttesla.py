# -*- coding: utf-8 -*-
"""AgentTesla 深度分析"""
import hashlib, re

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# AgentTesla 特征 - .NET
print("[.NET 命名空间]")
ns = set(re.findall(rb"System\.[A-Z][A-Za-z0-9._]{3,60}", data))
for n in sorted(ns)[:30]:
    try: print(f"  {n.decode('ascii')}")
    except: pass

print()
print("[AgentTesla 特征]")
for kw in [b"AgentTesla", b"agenttesla", b"SmtpClient", b"MailMessage",
           b"smtp.", b"ftp.", b"telegram", b"discord",
           b"keylog", b"GetAsyncKeyState", b"clipboard", b"Chrome",
           b"Firefox", b"Outlook", b"Edge", b"Password",
           b"Browser", b"Stealer", b"Logs", b"GetClipboard"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<25} x{c}")

# URL / SMTP
print()
print("[URLs / SMTP]")
seen = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
    u = m.group().decode("ascii", "replace")
    if u in seen: continue
    seen.add(u)
    if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                          "verisign", "usertrust", "comodo",
                                          "globalsign", "schemas", "w3.org",
                                          "crl.comodoca", "crt.comodoca",
                                          "ocsp.comodo", "usertrust"]):
        print(f"  {u[:180]}")

# SMTP 端口
print()
print("[SMTP/端口/邮箱]")
for m in re.finditer(rb"smtp\.[a-zA-Z0-9\.\-]+", data):
    print(f"  {m.group().decode()}")
for m in re.finditer(rb"[a-zA-Z0-9._%+\-]{4,64}@[a-zA-Z0-9.\-]{4,200}\.[a-z]{2,6}", data):
    em = m.group().decode("ascii", "replace")
    if not any(x in em.lower() for x in ["microsoft", "digicert", "sectigo",
                                           "verisign", "example.com"]):
        print(f"  {em}")
