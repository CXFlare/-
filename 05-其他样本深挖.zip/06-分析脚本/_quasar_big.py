# -*- coding: utf-8 -*-
import struct, hashlib
p = r"C:\malware_work\Quasar\extract_nsis\00044032-19429442.unknown"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print(f"头部 32: {data[:32].hex()}")
print(f"MZ?: {data[:2] == b'MZ'}")
print(f"NSIS?: {b'NSIS' in data[:200]}")
print(f"MEW?: {b'MEW' in data[:200]}")
if data[:2] == b"MZ":
    pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
    print(f"PE 头偏移: 0x{pe_off:x}")
    if data[pe_off:pe_off+4] == b"PE\x00\x00":
        machine = struct.unpack("<H", data[pe_off+4:pe_off+6])[0]
        nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
        ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
        print(f"machine: 0x{machine:04x}  节数: {nsec}  时间戳: 0x{ts:08x}")
        # 数据目录 CLR
        opt_off = pe_off + 24
        magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
        dd_off = opt_off + (96 if magic == 0x10B else 112)
        cli_rva = struct.unpack("<I", data[dd_off+14*8:dd_off+14*8+4])[0]
        print(f"CLI RVA: 0x{cli_rva:x}  ('.NET' if cli_rva else 'native')")
        # 找 .NET 特征
        for kw in [b"mscorlib", b"System.", b"Quasar", b"ClientPlugin",
                   b"System.Windows.Forms", b"RegistryKey", b"TcpClient",
                   b"SslStream", b"X509Certificate", b"Client", b"Server",
                   b"RemoteShell", b"Keylogger", b"RemoteDesktop", b"FileManager"]:
            c = data.count(kw)
            if c > 0:
                print(f"  {kw.decode('ascii','replace'):<25} x{c}")
