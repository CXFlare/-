# -*- coding: utf-8 -*-
"""SnakeKeyLogger + Nanocore - API/方法调用分析"""
import re, os

def analyze(name, path):
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        return
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
    
    # 找所有方法定义
    methods = re.findall(r"^(?:[\s]*(?:public|private|internal|protected|static|virtual|override|sealed|abstract)\s+)+[\w<>\[\],\.\?]*\s+([A-Za-z_][\w]*)\s*\(", content, re.MULTILINE)
    print(f"方法定义数: {len(methods)}")
    
    # 唯一方法名
    unique = set(methods)
    print(f"唯一方法名: {len(unique)}")
    
    # 找敏感 API 调用
    print()
    print("[敏感 API 调用]")
    for kw in ["GetAsyncKeyState", "SetWindowsHookEx", "GetForegroundWindow",
               "GetWindowText", "Clipboard", "GetClipboardData", "SetClipboardData",
               "GetKeyboardState", "MapVirtualKey", "Screen", "BitBlt", "GetDC",
               "RegistryKey", "Registry.CurrentUser", "Registry.LocalMachine",
               "WebClient", "HttpClient", "DownloadString", "DownloadFile",
               "UploadFile", "UploadString", "SmtpClient", "MailMessage",
               "Telegram", "SendMessage", "Socket", "TcpClient", "NetworkStream",
               "Process.Start", "cmd.exe", "powershell", "GetProcesses",
               "Assembly.Load", "Activator.CreateInstance", "GetTypes",
               "FileStream", "StreamReader", "StreamWriter", "File.WriteAllBytes",
               "Aes", "Rijndael", "SHA256", "MD5", "Base64"]:
        cnt = content.count(kw)
        if cnt > 0:
            print(f"  {kw}: x{cnt}")
    
    # 全部字符串字面量 - 按长度排序
    print()
    print("[长字符串 > 20 字符]")
    literals = re.findall(r'"([^"\\]{20,200})"', content)
    seen = set()
    for lit in literals:
        if lit in seen: continue
        seen.add(lit)
        if not any(x in lit.lower() for x in ["microsoft", "system.", "schemas",
                                                 "w3.org", "tempuri", "disrobe"]):
            print(f"  {lit[:180]}")
            if len(seen) > 40: break
    print()

analyze("SnakeKeyLogger", r"C:\malware_work\SnakeKeyLogger\decompiled\FATURA VE BELGELER..native.cs")
analyze("Nanocore", r"C:\malware_work\Nanocore\decompiled\DiscordNSR.native.cs")
