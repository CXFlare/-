# -*- coding: utf-8 -*-
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()
IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400), (0x9000, 0x213B0, 0x0), (0x2B000, 0x33D0, 0x8400), (0x2F000, 0xEA4, 0xB800), (0x30000, 0x1000, 0xCA00), (0x31000, 0x1200, 0xCC00)]
    for va_, vs, raw in secs:
        if va_ <= rva < va_ + max(vs, 1):
            return raw + (rva - va_)
    return None

off = va2off(0x42F500)
print(f"va2off(0x42F500) = {off}")
if off:
    print(f"bytes: {data[off:off+128].hex()}")
    print(f"text:  {data[off:off+128]}")
