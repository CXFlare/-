# -*- coding: utf-8 -*-
"""AgentTesla - 直接在 .rsrc 里找 ZH 资源原始数据"""
import struct, re

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()

# .rsrc 从 RAW=0x9e200 到 0xbc200
rsrc = data[0x9e200:0xbc200]
print(f".rsrc 段大小: {len(rsrc)}")

# 找 "ZH" 相关的 UTF-16 名（.NET 资源名是 UTF-16LE）
patterns = [
    b"Z\x00H\x00",  # UTF-16LE "ZH"
    b"ZH",             # ASCII
    b"Z\x00H\x00\x00\x00",  # UTF-16LE with 2-byte length prefix
]
for pat in patterns:
    print(f"\n[搜索 {pat}]")
    cnt = 0
    for m in re.finditer(re.escape(pat), rsrc):
        pos = m.start()
        # 打印上下文
        ctx = rsrc[max(0, pos-20):pos+60]
        print(f"  偏移 0x{pos:x}: {ctx.hex()}")
        cnt += 1
        if cnt > 10: break

# .NET 资源结构：
# - 前 4 字节 magic = 0xBEEFCACE（小端 ce ca ef be）
# - 但我们找不到，说明资源可能不在 rsrc，而是在 .NET metadata 里
# - 实际上，.NET 嵌入资源在 .text 段的 metadata 表里

print()
print("[在 .text 段找 .NET metadata 流]")
# .NET metadata 在 .text 里，找 #Strings 或资源表
for marker in [b"#Strings", b"#US", b"#Blob", b"#GUID", b"#~"]:
    pos = data.find(marker)
    if pos > 0:
        print(f"  {marker.decode()}: 0x{pos:x}")

# .NET ManifestResource 表项包含资源名和偏移
# 简单办法：找资源名 "PandaCafe.Properties.Resources.resources"
res_names = [
    b"PandaCafe.Properties.Resources.resources",
    b"PandaCafe.Properties.Resources",
    b"Resources.resources",
]
for rn in res_names:
    pos = data.find(rn)
    if pos > 0:
        print(f"  资源名 {rn.decode()}: 0x{pos:x}")

# 最直接：找连续的非零字节块，可能是隐藏 payload
# 隐藏在 .resources 流里，可以尝试从 0x3ca4 (发现魔数的位置) 提取

# 尝试从 .NET metadata 的 MANIFESTRESOURCE 表找资源偏移
print()
print("[尝试从 0x3ca4 手动解析 .NET resources]")
pos = 0x3ca4 + 4  # 跳过 magic
# 跳过 header version (4) + header size (4)
header_version = struct.unpack("<I", data[pos:pos+4])[0]
header_size = struct.unpack("<I", data[pos+4:pos+8])[0]
print(f"  header_version: 0x{header_version:x}, header_size: {header_size}")
pos += 8
# 然后读 reader type
reader_type = data[pos:pos+header_size].rstrip(b"\x00")
print(f"  reader type: {reader_type}")
pos += header_size
# reader version
reader_ver = data[pos:pos+header_size].rstrip(b"\x00")
print(f"  reader version: {reader_ver}")
pos += header_size
# num_resources + num_types + num_data
if pos + 12 <= len(data):
    num_resources = struct.unpack("<I", data[pos:pos+4])[0]
    num_types = struct.unpack("<I", data[pos+4:pos+8])[0]
    num_data = struct.unpack("<I", data[pos+8:pos+12])[0]
    print(f"  num_resources={num_resources} num_types={num_types} num_data={num_data}")
