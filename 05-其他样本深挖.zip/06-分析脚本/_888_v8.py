# -*- coding: utf-8 -*-
"""888RAT EA06 无果后，尝试最后方案：直接找加密数据里的字符串"""
import struct, re

p = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(p, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
print(f"EA06M @ 0x{marker:x}")
print(f"文件大小: {len(data)}")
print()

# EA06M 后第一个 4 字节 = 0x73ffa84d
# 关键：EA06 的加密不是简单的 LZMA，AutoIt 用了自定义的 crypt
# 但 EA06P（资源段）后面是明文结构
# 尝试直接从 EA06P 后读

m2 = data.find(b"AU3!EA06P")
print(f"EA06P @ 0x{m2:x}")
if m2 > 0:
    # EA06P 后结构
    # "AU3!EA06P" (8 bytes) + 4 bytes (unknown) + chunk header + chunk data
    # 每个 chunk: 4 bytes size + 4 bytes type + 4 bytes flags
    # 尝试从 m2 + 8 开始解析
    pos = m2 + 8
    chunk_count = 0
    while pos + 12 < len(data) and chunk_count < 50:
        # 读 chunk header
        if pos + 12 > len(data): break
        # 尝试作为小端 4 字节读
        val = struct.unpack("<I", data[pos:pos+4])[0]
        # 如果 val 看起来像 size（小于 1MB），尝试作为 chunk
        if val == 0: break
        if val > 100_000_000: break
        chunk_count += 1
        print(f"  chunk @ 0x{pos:x}: 4 字节 = 0x{val:08x} ({val})")
        pos += 4
        if chunk_count > 10: break

# 直接从 EA06M 后提取所有可打印字符串
print()
print("[EA06M 后数据的所有可打印字符串 > 8 字符]")
enc = data[marker+8:marker+8+40_000_000]
seen = set()
cnt = 0
for m in re.finditer(rb"[\x20-\x7e]{8,200}", enc[:5_000_000]):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    if not any(x in t.lower() for x in ["microsoft", "autoit", "dll", "exe",
                                          "system", "windows.common",
                                          "\x00"]):
        if len(t) > 8 and len(t) < 200:
            print(f"  {t[:180]}")
            cnt += 1
            if cnt > 30: break
print(f"总计: {len(seen)}")
