# -*- coding: utf-8 -*-
"""AgentTesla ZH 资源提取 + 解密"""
import struct, re

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()

# .NET 资源：找 .rsrc 节里包含 "ZH" 的部分
# PE 结构
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
opt_size = struct.unpack("<H", data[pe_off+20:pe_off+22])[0]
sec_off = pe_off + 24 + opt_size

# 列节表
print("[节表]")
for i in range(nsec):
    s = sec_off + i*40
    name = data[s:s+8].rstrip(b"\x00").decode("ascii", "replace")
    vsize = struct.unpack("<I", data[s+8:s+12])[0]
    vaddr = struct.unpack("<I", data[s+12:s+16])[0]
    rsize = struct.unpack("<I", data[s+16:s+20])[0]
    raw_off = struct.unpack("<I", data[s+20:s+24])[0]
    print(f"  {name:<10} VA=0x{vaddr:x} VS=0x{vsize:x} RAW=0x{raw_off:x} RS=0x{rsize:x}")

# 直接从 .rsrc 找 "ZH"
print()
print("[.rsrc 里的资源]")
# 找所有 "ZH" 位置
for m in re.finditer(rb"ZH", data):
    pos = m.start()
    # 看后续 2 字节是不是 0
    if data[pos+2:pos+4] == b"\x00\x00":
        # .NET resource name 长度 2 + 'ZH' + 0
        # 附近应该有资源数据
        print(f"  可能的位置: 0x{pos:x}")
        # 看后续 100 字节
        ctx = data[pos:pos+100]
        print(f"    上下文: {ctx.hex()[:120]}")

# 手工解析 .NET resources
# 找 0xBEEFCACE 魔数（在 PAGO.exe 里是 0x3ca4, 0x14374 等）
print()
print("[解析 .NET Resources]")
for magic_pos in [0x3ca4, 0x14374, 0x1442c, 0x15e74, 0x9d31c]:
    try:
        # 跳过 magic (4) + header version (4) + header size (4) = 12
        # 然后是 reader type (4) + reader version (4) + reader size (4)
        # 然后是 number of resource types (4)
        # 然后是 number of resource sets (4)
        # 然后是 number of resource data (4)
        # 每个 resource type:
        #   length (4) + name (utf16) + padding + num_sets (4)
        # 每个 set:
        #   length (4) + name (utf16) + padding + data_offset (4)
        pos = magic_pos + 12
        # 读 header
        reader_type_len = struct.unpack("<I", data[pos:pos+4])[0]
        print(f"  0x{magic_pos:x}: reader_type_len={reader_type_len}")
        pos += 4 + reader_type_len
        # 跳过 version
        version_len = struct.unpack("<I", data[pos:pos+4])[0]
        pos += 4 + version_len
        # 跳过 reader size
        pos += 4
        # num_types, num_sets, num_data
        num_types = struct.unpack("<I", data[pos:pos+4])[0]
        pos += 4
        num_sets = struct.unpack("<I", data[pos:pos+4])[0]
        pos += 4
        num_data = struct.unpack("<I", data[pos:pos+4])[0]
        pos += 4
        print(f"    types={num_types} sets={num_sets} data={num_data}")
        # 遍历 types
        for _t in range(num_types):
            tlen = struct.unpack("<I", data[pos:pos+4])[0]
            pos += 4
            tname = data[pos:pos+tlen].decode("utf-16le", "replace")
            pos += tlen
            print(f"    type: {tname}")
    except Exception as e:
        print(f"  0x{magic_pos:x}: {e}")
