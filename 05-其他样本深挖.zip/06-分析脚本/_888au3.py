# -*- coding: utf-8 -*-
import re, struct

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

print("=" * 70)
print("888RAT AutoIt 关键字扫描")
print("=" * 70)

au3_keywords = [
    b"Func ", b"EndFunc", b"NoTrayIcon",
    b"GUICreate", b"GUICtrlCreate", b"GUISetState",
    b"TCPConnect", b"TCPRecv", b"TCPSend", b"TCPListen",
    b"FileInstall", b"FileWrite", b"FileRead",
    b"ShellExecute", b"ScriptDir",
    b"BinaryToString", b"Crypt", b"Base64",
    b"REGWrite", b"RegRead",
    b"WinHttp", b"WinInet",
    b"HttpSendRequestW", b"InternetOpenW",
    b"ProcessClose", b"ProcessExists",
    b"GUIRegisterMsg", b"AdlibRegister",
]

found = {}
for kw in au3_keywords:
    positions = [m.start() for m in re.finditer(re.escape(kw), data)]
    if positions:
        found[kw.decode("ascii", "replace")] = len(positions)

for kw, cnt in sorted(found.items(), key=lambda x: -x[1]):
    print(f"  {kw:<25} x{cnt}")

print()
print("[可疑 AutoIt 脚本字符串]")
candidates = set()
for mm in re.finditer(rb"[\x20-\x7e]{15,200}", data):
    t = mm.group().decode("ascii", "replace")
    if any(k in t for k in ["TCP", "Func", "GUICreate", "http", "WinHttp",
                             "Telegram", "Discord", "keylog", "Script"]):
        candidates.add(t)
for c in sorted(candidates)[:50]:
    print(f"  {c[:180]}")

# 找 888RAT 特征字符串
print()
print("[888RAT 特征字符串]")
feats = [b"888", b"rat", b"cracked", b"panel", b"stealer", b"grabber", b"node"]
for f in feats:
    positions = [m.start() for m in re.finditer(re.escape(f), data, re.IGNORECASE)]
    print(f"  {f.decode()}: {len(positions)} 处")
