# -*- coding: utf-8 -*-
"""Lumma / Raccoon / StealC 深度分析"""
import hashlib, re, os

samples = [
    ("Lumma", r"C:\malware_work\Lumma\5ce704b101d2c1cb57abbe7dce3f3ce627340ac1766c0c5f165ed7d28d24fede"),
    ("Raccoon", r"C:\malware_work\Raccoon\0203ee4a4252b78a17796e7e4832dcfb921051b87e4a727eae172ea13d9424cd"),
    ("StealC", r"C:\malware_work\StealC\da886b94c504088d53032e48ffcd264e3a3406b0342f38e44f8b1f3bbe37ef23"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")

    # 特征
    print("[特征]")
    for kw in [b"lumma", b"Lumma", b"raccoon", b"Raccoon", b"stealc",
               b"StealC", b"telegram", b"discord", b"bot", b"chat_id",
               b"browser", b"chrome", b"firefox", b"outlook", b"password",
               b"cookie", b"wallet", b"metamask", b"exodus", b"steam",
               b"clipboard", b"jabber", b"ftp", b"smtp", b"vpn"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<20} x{c}")

    # TG / Discord
    print("[TG Bot]")
    for m in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}", data):
        print(f"  {m.group().decode()}")
    print("[Discord Webhook]")
    for m in re.finditer(rb"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+", data):
        print(f"  {m.group().decode()}")

    # URLs
    print("[URLs]")
    seen = set()
    for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
        u = m.group().decode("ascii", "replace")
        if u in seen: continue
        seen.add(u)
        if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                              "verisign", "usertrust", "comodo",
                                              "globalsign", "symantec", "schemas",
                                              "w3.org", "adobe", "entrust",
                                              "thawte", "wosign"]):
            print(f"  {u[:180]}")
            if len(seen) > 10: break
    print()
