# -*- coding: utf-8 -*-
"""批量分析：XWorm + Redline + 汇总"""
import re, hashlib, os

samples = [
    ("XWorm", r"C:\malware_work\XWorm\op.exe"),
    ("Redline", r"C:\malware_work\Redline\4900-2-0x0000000000AB0000-0x0000000000B2EFAE-memory.dmp"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("文件不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}")
    print(f"MD5:    {hashlib.md5(data).hexdigest()}")
    print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
    
    # 是否 PE
    if data[:2] == b"MZ":
        print("是 PE")
    else:
        print("非 PE")
    
    print("[特征]")
    for kw in [b".NET", b"mscorlib", b"Delphi", b"Borland", b"UPX", b"AutoIt",
               b"NSIS", b"System.", b"Microsoft.", b"keylog", b"stealer",
               b"smtp", b"telegram", b"ftp", b"discord", b"wallet",
               b"passwords", b"browser", b"clipboard", b"webcam"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<20} x{c}")
    
    print("[关键 IOC]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{6,150}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["http://", "https://", "smtp.", "ftp.", "telegram",
                                  "bot", "chat_id=", "password=", "apikey",
                                  "mozilla", "chrome", "firefox", "outlook",
                                  "keylog", "clipboard", "wallet",
                                  ".php", ".onion", "c2", "gate"]):
            if 6 < len(t) < 200:
                print(f"  {t[:180]}")
    print()
