# -*- coding: utf-8 -*-
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 反汇编里 API wrapper 通常是 "jmp [42Fxxx]" 或 "jmp qword [42Fxxx]" 等
# 打印 0x408f00 等高频函数的反汇编
def extract_func(addr, max_lines=20):
    out = []
    started = False
    target = "sub_" + addr[2:].lower() + " @"
    for line in lines:
        if line.startswith(target):
            started = True
            out.append(line.rstrip())
            continue
        if started:
            if line.startswith("sub_"):
                break
            out.append(line.rstrip())
            if len(out) >= max_lines:
                break
    return out

print("=== 高频 wrapper 函数 ===")
for addr in ["0x408f00", "0x408f3c", "0x408f18", "0x408a60", "0x408db0", "0x408c6c"]:
    print(f"\n--- {addr} ---")
    for line in extract_func(addr, 8):
        print(line)
