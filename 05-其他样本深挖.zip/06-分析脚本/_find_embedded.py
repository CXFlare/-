# -*- coding: utf-8 -*-
"""找内嵌 PE - capabilities 报告在 0x91f8 处有 embedded PE"""
import struct

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

# 扫描所有 MZ 签名
print("=" * 70)
print("扫描内嵌 MZ / PE")
print("=" * 70)

mz_positions = []
i = 0
while True:
    pos = data.find(b"MZ", i)
    if pos < 0: break
    # 验证 PE 头
    if pos + 0x40 < len(data):
        pe_off = struct.unpack("<I", data[pos+0x3C:pos+0x40])[0]
        if pos + pe_off + 4 <= len(data) and data[pos+pe_off:pos+pe_off+4] == b"PE\x00\x00":
            # 是有效 PE
            machine = struct.unpack("<H", data[pos+pe_off+4:pos+pe_off+6])[0]
            nsec = struct.unpack("<H", data[pos+pe_off+6:pos+pe_off+8])[0]
            ts = struct.unpack("<I", data[pos+pe_off+8:pos+pe_off+12])[0]
            mz_positions.append((pos, pe_off, machine, nsec, ts))
            print(f"  MZ @ 0x{pos:x} (PE@0x{pos+pe_off:x}) 机器=0x{machine:x} 节数={nsec} 时间戳=0x{ts:x}")
    i = pos + 2

if mz_positions:
    # 提取第一个内嵌 PE
    pos, pe_off, _, nsec, _ = mz_positions[0]
    print(f"\n[提取] 内嵌 PE 位于 0x{pos:x}")
    # 确定 PE 大小
    # 找最大的 RS+RS 大小
    sec_off = pos + pe_off + 24 + struct.unpack("<H", data[pos+pe_off+20:pos+pe_off+22])[0]
    max_end = pos + pe_off
    for j in range(nsec):
        s = sec_off + j*40
        raw_off = struct.unpack("<I", data[s+20:s+24])[0]
        rsize = struct.unpack("<I", data[s+16:s+20])[0]
        end = pos + raw_off + rsize
        if end > max_end:
            max_end = end
    size = max_end - pos
    print(f"  大小估计: {size} 字节 ({size/1024:.1f} KB)")
    
    # 保存
    out = r"C:\malware_work\NJRAT\embedded_pe.bin"
    with open(out, "wb") as f:
        f.write(data[pos:pos+size])
    print(f"  已保存: {out}")
