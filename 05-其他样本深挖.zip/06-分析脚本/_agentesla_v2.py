# -*- coding: utf-8 -*-
"""AgentTesla - 修正：解密更大范围"""
import struct, re

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()

key = bytes([53, 52, 56, 66, 72, 69, 51, 53, 90, 56, 83, 72, 55, 56, 56, 56, 71, 83, 66, 89, 68, 57])

def decrypt_v2(original, key):
    n = len(original)
    if n < 2: return b""
    out = bytearray(n)
    orig = bytes(original)
    for i in range(n):
        local8 = orig[i]
        local10 = orig[(i+1) % n]
        local11 = key[i % len(key)]
        out[i] = ((local8 ^ local11) - local10 + 256) & 255
    return bytes(out)

start = 0x3d6e

# 尝试更大解密范围
for length in [0x40000, 0x80000, 0x100000, 0x200000]:
    chunk = data[start:start+length]
    if len(chunk) < 0x1000:
        print(f"length={length}: 数据不足 ({len(chunk)} 字节)")
        continue
    dec = decrypt_v2(chunk, key)
    if dec[:2] != b"MZ":
        continue
    pe_off = struct.unpack("<I", dec[0x3C:0x40])[0]
    if dec[pe_off:pe_off+4] != b"PE\x00\x00":
        continue
    nsec = struct.unpack("<H", dec[pe_off+6:pe_off+8])[0]
    opt_size = struct.unpack("<H", dec[pe_off+20:pe_off+22])[0]
    sec_off = pe_off + 24 + opt_size
    max_end = pe_off
    for i in range(nsec):
        s = sec_off + i*40
        raw_off = struct.unpack("<I", dec[s+20:s+24])[0]
        rsize = struct.unpack("<I", dec[s+16:s+20])[0]
        end = raw_off + rsize
        if end > max_end: max_end = end
    print(f"length={length} (0x{length:x}): PE 大小应为 0x{max_end:x} ({max_end} 字节)")
    if max_end <= length:
        out_path = r"C:\malware_work\AgentTesla\hidden_payload_full.exe"
        with open(out_path, "wb") as f:
            f.write(dec[:max_end])
        print(f"  已保存完整 PE: {out_path} ({max_end} 字节)")
        
        # 内部字符串
        print(f"  [关键字符串]")
        seen = set()
        for m in re.finditer(rb"[\x20-\x7e]{8,200}", dec[:max_end]):
            t = m.group().decode("ascii", "replace")
            if t in seen: continue
            seen.add(t)
            tl = t.lower()
            if any(k in tl for k in ["smtp.", "telegram", "http://", "https://",
                                      "bot", "chat_id", "password", "chrome",
                                      "firefox", "outlook", "keylog", "agent",
                                      "tesla", "stealer", "ftp.", "gate"]):
                if not any(x in tl for x in ["microsoft", "digicert", "schemas", "w3.org"]):
                    print(f"    {t[:170]}")
                    if len(seen) > 40: break
        break
    else:
        print(f"  PE 大小 0x{max_end:x} 超过解密长度 0x{length:x}，继续尝试更大")
