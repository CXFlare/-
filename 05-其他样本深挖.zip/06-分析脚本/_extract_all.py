# -*- coding: utf-8 -*-
import struct

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

def extract_pe(data, pos):
    pe_off = struct.unpack("<I", data[pos+0x3C:pos+0x40])[0]
    nsec = struct.unpack("<H", data[pos+pe_off+6:pos+pe_off+8])[0]
    opt_size = struct.unpack("<H", data[pos+pe_off+20:pos+pe_off+22])[0]
    sec_off = pos + pe_off + 24 + opt_size
    max_end = pos + pe_off
    for j in range(nsec):
        s = sec_off + j*40
        raw_off = struct.unpack("<I", data[s+20:s+24])[0]
        rsize = struct.unpack("<I", data[s+16:s+20])[0]
        end = pos + raw_off + rsize
        if end > max_end: max_end = end
    return data[pos:max_end]

# 提取第二个内嵌 PE (0x91f8)
for idx, pos in enumerate([0x91f8, 0x23c74]):
    sub = extract_pe(data, pos)
    out = rf"C:\malware_work\NJRAT\embedded_{idx+1}.bin"
    with open(out, "wb") as f:
        f.write(sub)
    print(f"[{idx+1}] 0x{pos:x} -> {len(sub)} 字节 -> {out}")
    # 分析这个 PE 的字符串
    import re
    strs = re.findall(rb"[\x20-\x7e]{6,}", sub)
    print(f"     字符串: {len(strs)} 条")
    # 找 API URL
    for s in strs:
        try:
            t = s.decode("ascii")
            if "http://" in t or "https://" in t or "SOFTWARE\\" in t:
                print(f"       {t[:120]}")
        except: pass
