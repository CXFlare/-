# -*- coding: utf-8 -*-
"""888RAT - 深挖 AutoIt 脚本明文"""
import re, struct

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

# AutoIt 编译脚本的标记
markers = [
    b"AU3!EA06", b"AU3!EA05", b">>>AUTOIT SCRIPT<<<", b"AutoIt3ExecuteScript",
    b"This is a third-party compiled AutoIt script",
    b"MYSTERIOUS", b"<AutoIt3>",
]

print("=" * 70)
print("888RAT AutoIt 脚本定位")
print("=" * 70)
for m in markers:
    pos = data.find(m)
    if pos >= 0:
        print(f"  找到 [{m.decode('ascii','replace')}] @ 0x{pos:x}")

# 找所有 AU3! 标记
print()
print("[所有 AU3! 标记]")
for mm in re.finditer(rb"AU3![\w!]{2,6}", data):
    print(f"  0x{mm.start():x}  {mm.group().decode('ascii','replace')}")

# 找所有 HTTP URL
print()
print("[HTTP/HTTPS URLs]")
urls = set()
for mm in re.finditer(rb"https?://[\w\.\-/:?=&%_@#]{8,}", data):
    u = mm.group().decode("ascii", "replace")
    if u not in urls:
        urls.add(u)
        print(f"  {u[:180]}")
print(f"  共 {len(urls)} 个唯一 URL")

# 找 Telegram Bot Token 模式
print()
print("[Telegram Bot Token 模式]")
for mm in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,40}", data):
    print(f"  {mm.group().decode('ascii')}")

# 找 IP 地址
print()
print("[IP 地址]")
ips = set(re.findall(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b", data))
for ip in sorted(ips):
    t = ip.decode("ascii")
    # 排除明显非 IP 的数字
    parts = t.split(".")
    if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0", "1.0.0.0", "127.0.0.1"]:
        print(f"  {t}")
