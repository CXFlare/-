# -*- coding: utf-8 -*-
"""GoldenEye JS + EXE 分析"""
import re, hashlib, os

# GoldenEye JS
print("=" * 70)
print("GoldenEye.js 分析")
print("=" * 70)
p = r"C:\malware_work\GoldenEye\GoldenEye.js"
with open(p, "rb") as f:
    raw = f.read()
print(f"大小: {len(raw)}  MD5: {hashlib.md5(raw).hexdigest()}")
print(f"头部: {raw[:200]}")
print()

try:
    txt = raw.decode("utf-8", "replace")
except:
    txt = raw.decode("latin-1", "replace")

# JS 混淆特征
for kw in ["eval(", "Function(", "fromCharCode", "unescape", "decodeURI",
           "ActiveXObject", "WScript.Shell", "MSXML2", "Adodb.Stream",
           "powershell", "cmd.exe", "new Function"]:
    c = txt.count(kw)
    if c > 0:
        print(f"  {kw}: x{c}")

# URL 提取
urls = set(re.findall(r"https?://[\w\.\-:/?=&%_@#+~]{6,200}", txt))
if urls:
    print(f"\n[URLs]")
    for u in sorted(urls)[:15]:
        print(f"  {u[:180]}")

# 域名
domains = set(re.findall(r"\b[a-zA-Z0-9][a-zA-Z0-9\-]+\.(?:com|net|org|ru|io|xyz|top|su|cc|info|biz|tk|ml|ga|cf|gq|onion)\b", txt))
if domains:
    print(f"\n[域名]")
    for d in sorted(domains)[:20]:
        print(f"  {d}")

# EXE
print()
print("=" * 70)
print("GoldenEye.exe 分析")
print("=" * 70)
p = r"C:\malware_work\GoldenEye\GoldenEye.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
           b"System.", b"cmd.exe", b"keylog", b"stealer", b"browser"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")
