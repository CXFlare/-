# -*- coding: utf-8 -*-
"""批量分析 7 个 loader / RAT"""
import re, hashlib, os

samples = [
    ("SmokeLoader", r"C:\malware_work\SmokeLoader\f9be6fbe073f8e75344c62adff1a729494acafa18ea7c778cd0b3177a77de0f3"),
    ("Sodinokibi", r"C:\malware_work\Sodinokibi\0f8ee1ed415794ec053dca928a409436_JaffaCakes118"),
    ("StealC", r"C:\malware_work\StealC\da886b94c504088d53032e48ffcd264e3a3406b0342f38e44f8b1f3bbe37ef23"),
    ("GootLoader", r"C:\malware_work\GootLoader\are serval cats legal in texas 70354.js"),
    ("PrivateLoader", r"C:\malware_work\PrivateLoader\2024-05-03_68452609966ed034f6e024d4d6f30fc4_magniber_metamorfo"),
    ("Amadey", r"C:\malware_work\Amadey\662119ffeb5cc0951c36e30f2f2f9c537349292775ef4a4b26a6ec219ea9db95"),
    ("GULoader", r"C:\malware_work\GULoader\586 R1  M-LINE - GEORGIA 03.05.2024.exe"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    print(f"头部: {data[:16].hex()}")
    if data[:2] == b"MZ": print("PE")
    if data[:4] == b"\x7fELF": print("ELF")
    
    # 特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt", b"MSVBVM60",
               b"System.", b"cmd.exe", b"keylog", b"stealer", b"browser",
               b"clipboard", b"wallet", b"password", b"XMR", b"monero",
               b"ransom", b"encrypt", b"decrypt", b"loader", b"gate",
               b"powershell", b"WScript", b"ActiveXObject", b"MSXML2"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    # IPs
    ips = set()
    for m in re.finditer(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b", data):
        t = m.group().decode("ascii")
        parts = t.split(".")
        if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0","6.0.0.0","1.0.0.0","127.0.0.1","10.0.0.0","11.0.0.0","16.0.0.0","164.0.0.0","4.0.0.0","2.0.0.0"]:
            ips.add(t)
    if ips:
        print(f"[IPs]")
        for ip in sorted(ips)[:10]: print(f"  {ip}")
    
    # URLs
    urls = set()
    for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
        u = m.group().decode("ascii", "replace")
        if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "verisign",
                                          "usertrust", "comodo", "globalsign", "symantec",
                                          "schemas.", "w3.org", "adobe.com/xap", "ibsensoftware",
                                          "thawte", "wosign", "graphviz"]):
            continue
        urls.add(u)
    if urls:
        print(f"[URLs]")
        for u in sorted(urls)[:12]:
            print(f"  {u[:180]}")
    print()
