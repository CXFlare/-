# -*- coding: utf-8 -*-
"""NJRAT 反汇编的所有 API 调用点（找 call 目标在 0x408988 + 12*i 范围内）"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# wrapper 地址范围：0x408988 起，每 12 字节一个
# 从 0x408988 到 0x408988 + 12*112 = 0x408988 + 0x540 = 0x408EC8
def wrapper_va_for(idx):
    return 0x408988 + 12*idx

wrapper_range = set(wrapper_va_for(i) for i in range(130))

# 找所有 call
calls_found = {}
cur = None
for i, line in enumerate(lines):
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = m.group(2)
        continue
    c = re.search(r"call 0040([0-9A-Fa-f]+)h", line)
    if c:
        called = int("0x40" + c.group(1), 16)
        if called in wrapper_range:
            idx = (called - 0x408988) // 12
            calls_found.setdefault(idx, []).append((cur, i, line.strip()))

# 从导入表顺序对应 API 名（前面已解析，这里复用）
import sys
sys.path.insert(0, r"C:\malware_work")
# 直接内联已解析的 ordered API 列表
ordered = [
    "ole32.DLL!CoCreateInstance","ole32.DLL!CLSIDFromString","ole32.DLL!CoInitialize","ole32.DLL!CoUninitialize",
    "OLEAUT32.DLL!SysAllocString","WININET.DLL!DeleteUrlCacheEntry","WININET.DLL!FindFirstUrlCacheEntryA","WININET.DLL!FindNextUrlCacheEntryA",
    "KERNEL32.DLL!ExitProcess","KERNEL32.DLL!ExpandEnvironmentStringsA","KERNEL32.DLL!GetCommandLineA","KERNEL32.DLL!GetComputerNameA",
    "KERNEL32.DLL!GetCurrentProcessId","KERNEL32.DLL!GetCurrentThreadId","KERNEL32.DLL!GetExitCodeThread","KERNEL32.DLL!GetFileSize",
    "KERNEL32.DLL!GetModuleFileNameA","KERNEL32.DLL!GetModuleHandleA","KERNEL32.DLL!CloseHandle","KERNEL32.DLL!GetProcAddress",
    "KERNEL32.DLL!GetSystemDirectoryA","KERNEL32.DLL!GetTempPathA","KERNEL32.DLL!GetTickCount","KERNEL32.DLL!GetVersion",
    "KERNEL32.DLL!GetVersionExA","KERNEL32.DLL!GetWindowsDirectoryA","KERNEL32.DLL!GlobalMemoryStatus","KERNEL32.DLL!CopyFileA",
    "KERNEL32.DLL!InterlockedIncrement","KERNEL32.DLL!IsBadReadPtr","KERNEL32.DLL!IsBadWritePtr","KERNEL32.DLL!LoadLibraryA",
    "KERNEL32.DLL!LocalAlloc","KERNEL32.DLL!LocalFree","KERNEL32.DLL!OpenMutexA","KERNEL32.DLL!CreateFileA",
    "KERNEL32.DLL!ReadFile","KERNEL32.DLL!RtlUnwind","KERNEL32.DLL!SetFilePointer","KERNEL32.DLL!CreateMutexA",
    "KERNEL32.DLL!Sleep","KERNEL32.DLL!TerminateProcess","KERNEL32.DLL!VirtualQuery","KERNEL32.DLL!CreateProcessA",
    "KERNEL32.DLL!WaitForSingleObject","KERNEL32.DLL!WideCharToMultiByte","KERNEL32.DLL!WinExec","KERNEL32.DLL!WriteFile",
    "KERNEL32.DLL!lstrlenA","KERNEL32.DLL!lstrlenW","KERNEL32.DLL!CreateThread","KERNEL32.DLL!DeleteFileA",
    "USER32.DLL!GetWindowTextA","USER32.DLL!GetWindowRect","USER32.DLL!FindWindowA","USER32.DLL!GetWindow",
    "USER32.DLL!GetClassNameA","USER32.DLL!SetFocus","USER32.DLL!GetForegroundWindow","USER32.DLL!LoadCursorA",
    "USER32.DLL!LoadIconA","USER32.DLL!SetTimer","USER32.DLL!RegisterClassA","USER32.DLL!MessageBoxA",
    "USER32.DLL!GetMessageA","USER32.DLL!GetWindowLongA","USER32.DLL!SetWindowLongA","USER32.DLL!CreateDesktopA",
    "USER32.DLL!SetThreadDesktop","USER32.DLL!GetThreadDesktop","USER32.DLL!TranslateMessage","USER32.DLL!DispatchMessageA",
    "USER32.DLL!SendMessageA","USER32.DLL!PostQuitMessage","USER32.DLL!ShowWindow","USER32.DLL!CreateWindowExA",
    "USER32.DLL!DestroyWindow","USER32.DLL!MoveWindow","USER32.DLL!DefWindowProcA","USER32.DLL!CallWindowProcA",
    "GDI32.DLL!GetStockObject","GDI32.DLL!SetBkColor","GDI32.DLL!SetTextColor","GDI32.DLL!CreateBrushIndirect",
    "GDI32.DLL!CreateFontA","ADVAPI32.DLL!GetUserNameA","ADVAPI32.DLL!RegCreateKeyExA","ADVAPI32.DLL!RegCloseKey",
    "ADVAPI32.DLL!RegOpenKeyExA","ADVAPI32.DLL!RegQueryValueExA","ADVAPI32.DLL!RegSetValueExA","ADVAPI32.DLL!GetSecurityInfo",
    "ADVAPI32.DLL!SetSecurityInfo","ADVAPI32.DLL!SetEntriesInAclA",
]

print("=" * 70)
print("API 调用点统计")
print("=" * 70)
for idx in sorted(calls_found.keys()):
    if idx < len(ordered):
        api = ordered[idx]
        calls = calls_found[idx]
        print(f"\n### {api} ({len(calls)} 处) ###")
        for cur, line_no, line in calls[:6]:
            print(f"  在 {cur}: {line.strip()}")
