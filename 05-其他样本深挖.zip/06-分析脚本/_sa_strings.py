# -*- coding: utf-8 -*-
"""AgentTesla payload - SmartAssembly 字符串解密尝试"""
import re, struct

p = r"C:\malware_work\AgentTesla\payload_decompiled\hidden_payload_full.native.cs"
with open(p, "r", encoding="utf-8", errors="replace") as f:
    content = f.read()

# SmartAssembly GetFromResource(stringID) - 从资源读加密字符串
# 找调用点
print("[GetFromResource 调用]")
for m in re.finditer(r"GetFromResource\((\d+)\)", content):
    print(f"  ID={m.group(1)}")

print()
print("[GetCachedOrResource 调用]")
for m in re.finditer(r"GetCachedOrResource\((\d+)\)", content):
    print(f"  ID={m.group(1)}")

# SmartAssembly 资源名
print()
print("[资源名称]")
for m in re.finditer(r'"([^"]*)"', content):
    t = m.group(1)
    if len(t) > 3 and any(c.isdigit() or c.isalpha() for c in t):
        if len(t) < 100 and not any(x in t for x in ["disrobe", "Unknown Header", "Wrong Header"]):
            pass

# 找所有可见的字符串
print()
print("[字符串字面量]")
seen = set()
for m in re.finditer(r'"([^"]{3,200})"', content):
    lit = m.group(1)
    if lit in seen: continue
    seen.add(lit)
    print(f"  {lit[:190]}")

# 找所有 ldstr 指令
print()
print("[ldc.i4 / 关键常量]")
consts = set()
for m in re.finditer(r"(?:ldc\.i4|ldc\.i4\.s)\s+(\d+)", content):
    consts.add(int(m.group(1)))
big = [c for c in consts if c > 1000]
print(f"  常量 > 1000: {sorted(big)[:30]}")
