# -*- coding: utf-8 -*-
"""SnakeKeyLogger 伪装分析 + 内层真实恶意代码查找"""
import re

p = r"C:\malware_work\SnakeKeyLogger\decompiled\FATURA VE BELGELER..native.cs"
with open(p, "r", encoding="utf-8", errors="replace") as f:
    content = f.read()
lines = content.split("\n")

# 找所有 "// " 后面的模块名（disrobe 注释）
print("[disrobe 模块注释]")
modules = set()
for m in re.finditer(r"//\s+(DVLD_Buisness\.[A-Za-z0-9_]+)", content):
    modules.add(m.group(1))
for mod in sorted(modules)[:30]:
    print(f"  {mod}")
print(f"\nDVLD_Buisness 类: {len(modules)}")

# 找关键入口（Main 或 Form Load）
print()
print("[关键入口]")
for i, line in enumerate(lines):
    if any(k in line for k in ["static void Main", "static int Main",
                                 "Form1_Load", "Form_Load", "frmMain_Load",
                                 "this.Load", "add_Load"]):
        # 打印该行和前后 10 行
        start = max(0, i - 2)
        end = min(len(lines), i + 8)
        for j in range(start, end):
            print(f"  L{j+1}: {lines[j][:150]}")
        print()

# 找所有 "SnakeKeyLogger" 之类真实恶意标志
print("[真实恶意标志]")
for kw in ["Snake", "snake", "keylogger", "GetAsyncKeyState", "Hook",
           "Webhook", "Discord", "Telegram", "http://", "https://"]:
    positions = [i for i, l in enumerate(lines) if kw in l]
    if positions:
        print(f"  {kw}: L{positions[:5]}")
