# -*- coding: utf-8 -*-
import hashlib, os, struct, re, json

# 直接对解密后的 PE 做分析
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

print("=" * 70)
print("NJRAT 深度分析 · 补充")
print("=" * 70)

# ============ 1. 提取完整字符串表 ============
ascii_str = re.findall(rb"[\x20-\x7e]{4,}", data)
print(f"\n[1] ASCII 字符串: {len(ascii_str)} 条")
utf16_str = re.findall(rb"(?:[\x20-\x7e]\x00){4,}", data)
print(f"[2] UTF-16LE 字符串: {len(utf16_str)} 条")

# 分类统计
categories = {
    "C2/URL": [], "文件路径": [], "注册表": [], "进程/命令": [],
    "网络 API": [], "键盘/鼠标": [], "屏幕/摄像头": [],
    "银行/支付": [], "浏览器": [], "协议/命令": [],
}
for s in ascii_str:
    try:
        t = s.decode("ascii")
    except: continue
    tl = t.lower()
    if "http://" in tl or "https://" in tl:
        categories["C2/URL"].append(t)
    elif "\\" in t and any(x in tl for x in [".dll", ".exe", ".dat", ".pif", ".vxd", ".com"]):
        categories["文件路径"].append(t)
    elif "software\\" in tl or "currentversion" in tl or "hkey" in tl:
        categories["注册表"].append(t)
    elif any(x in tl for x in ["cmd.exe", "cmd.pif", "win exec", "/c ", "schtasks"]):
        categories["进程/命令"].append(t)
    elif any(x in tl for x in ["socket", "ws2_", "connect", "send", "recv"]):
        categories["网络 API"].append(t)
    elif any(x in tl for x in ["key", "hook", "cursor", "input"]):
        categories["键盘/鼠标"].append(t)
    elif any(x in tl for x in ["screen", "bitblt", "webcam", "desktop", "capture"]):
        categories["屏幕/摄像头"].append(t)
    elif any(x in tl for x in ["paypal", "ebay", "bank", "visa", "mastercard", "cvv", "atm", "pin"]):
        categories["银行/支付"].append(t)
    elif any(x in tl for x in ["iexplore", "ieframe", "mozilla", "firefox", "chrome", "browser"]):
        categories["浏览器"].append(t)
    elif any(x in tl for x in ["x-okrecv", "command", "response"]):
        categories["协议/命令"].append(t)

for cat, items in categories.items():
    uniq = list(dict.fromkeys(items))
    print(f"\n### {cat} ({len(uniq)}) ###")
    for it in uniq[:25]:
        print(f"  {it[:130]}")
