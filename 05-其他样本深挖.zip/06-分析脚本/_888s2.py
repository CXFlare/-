# -*- coding: utf-8 -*-
import re, hashlib

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

print(f"大小: {len(data)}")
print(f"MD5:    {hashlib.md5(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print()

utf16_str = re.findall(rb"(?:[\x20-\x7e]\x00){6,}", data)
print(f"UTF-16LE 字符串: {len(utf16_str)}")
print()

seen = set()
for s in utf16_str:
    try: t = s.decode("utf-16le", "replace").strip("\x00")
    except: continue
    if not t or t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["http", "tcp", "func ", "gui", "winhttp", "script",
                              "msgbox", "filewrite", "shell", "exec", "regwrite",
                              "crypt", "telegram", "discord", "keylog", "screen",
                              "cmd.exe", "windows\\", "temp\\", "appdata\\"]):
        if 6 < len(t) < 200:
            print(f"  {t[:180]}")

print()
print("=" * 70)
print("[AutoIt Func 定义]")
print("=" * 70)
for m in re.finditer(rb"F\x00u\x00n\x00c\x00 \x00[\x20-\x7e\x00]{10,150}", data):
    try:
        t = m.group().decode("utf-16le", "replace")
        print(f"  {t[:150]}")
    except: pass
