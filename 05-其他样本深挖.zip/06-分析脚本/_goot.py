# -*- coding: utf-8 -*-
"""GootLoader JS 脚本分析"""
import re

p = r"C:\malware_work\GootLoader\are serval cats legal in texas 70354.js"
with open(p, "rb") as f:
    raw = f.read()
print(f"大小: {len(raw)}")
print(f"头部 200 字节: {raw[:200]}")
print()

# 前部可能是混淆的
txt = raw.decode("utf-8", "replace")

# GootLoader 特征：大量变量 + eval/Function
for kw in ["eval(", "Function(", "fromCharCode", "unescape", "decodeURIComponent",
           "ActiveXObject", "WScript", "MSXML2", "ADODB.Stream", "powershell",
           "new Function", "split", "reverse", "join"]:
    c = txt.count(kw)
    if c > 0:
        print(f"  {kw}: x{c}")

# 找 URL
urls = re.findall(r"https?://[\w\.\-:/?=&%_@#+~]+", txt)
if urls:
    print()
    print("[URLs]")
    for u in sorted(set(urls))[:20]:
        print(f"  {u[:180]}")

# 找 Base64 大块
print()
print("[Base64 块 > 1000]")
for m in re.finditer(r"[A-Za-z0-9+/]{1000,}={0,2}", txt):
    b64 = m.group()[:200]
    print(f"  长度 {len(m.group())}: {b64}...")
    # 尝试解码
    import base64
    try:
        decoded = base64.b64decode(m.group()[:4000] + "====")
        print(f"  解码前 200 字节: {decoded[:200]}")
    except: pass
    break
