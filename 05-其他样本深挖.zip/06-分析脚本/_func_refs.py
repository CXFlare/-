# -*- coding: utf-8 -*-
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 提取所有函数的指令数
funcs = []
cur = None
cnt = 0
for line in lines:
    m = re.match(r"^(sub_[0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        if cur: funcs.append((cur, cnt))
        cur = m.group(2)
        cnt = 0
    elif cur is not None and line.startswith("  0x"):
        cnt += 1
if cur: funcs.append((cur, cnt))

# 大函数按规模排序
print("=" * 70)
print("大函数列表（指令数 > 30）")
print("=" * 70)
for addr, n in sorted(funcs, key=lambda x: -x[1]):
    if n > 30:
        print(f"  {addr}  {n} 条指令")

# 提取几个关键大函数的字符串引用
def get_refs(addr):
    """提取函数内所有引用的字符串"""
    start = False
    refs = []
    for line in lines:
        if line.startswith(f"sub_{addr[2:].lower()} @"):
            start = True
            continue
        if start:
            if line.startswith("sub_"):
                break
            m = re.findall(r"push (42[0-9A-Fa-f]{4})h", line)
            for x in m:
                refs.append(int(x, 16))
    return refs

# 读 exe 提取字符串
with open(r"C:\malware_work\NJRAT\njrat_decrypted.exe", "rb") as f:
    data = f.read()

def addr_to_off(addr):
    rva = addr - 0x400000
    sections = [(0x1000, 0x400, 0x7F6C), (0x9000, 0x0, 0x213B0), (0x2B000, 0x8400, 0x33D0), (0x2F000, 0xB800, 0xEA4), (0x30000, 0xCA00, 0x200), (0x31000, 0xCC00, 0x1200)]
    for va, raw, vs in sections:
        if va <= rva < va + vs:
            return raw + (rva - va)
    return None

def read_str(addr):
    off = addr_to_off(addr)
    if off is None: return None
    end = data.find(b"\x00", off)
    if end < 0 or end - off > 150: return None
    try: return data[off:end].decode("ascii")
    except: return None

print()
print("=" * 70)
print("关键函数的字符串引用")
print("=" * 70)
# 挑几个大函数
big_funcs = [f[0] for f in sorted(funcs, key=lambda x: -x[1])[:15]]
for addr in big_funcs:
    refs = get_refs(addr)
    strs = []
    for r in refs:
        s = read_str(r)
        if s and len(s) > 3: strs.append(s)
    if strs:
        print(f"\n{addr}  ({len(strs)} 字符串引用):")
        for s in strs[:20]:
            print(f"  {repr(s)[:130]}")
