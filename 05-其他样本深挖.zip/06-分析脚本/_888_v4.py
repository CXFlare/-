# -*- coding: utf-8 -*-
"""888RAT - 用 myAut2Exe 思路解决 EA06
   
AutoIt EA06M 结构：
- "AU3!EA06M" (8 bytes)
- 加密的 LZMA 流（非标准头）
- 解密算法：使用文件中后部的 EA06P 段里的额外数据

参考 myAut2Exe 源码：
EA06M 部分是真的恶意脚本，EA06P 是资源段。
"""
import struct, lzma, zlib

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
m2 = data.find(b"AU3!EA06P")
print(f"EA06M @ 0x{marker:x}, EA06P @ 0x{m2:x}")

# EA06M 后的数据长度：一直到下一个标记或文件末尾
# 计算 M 段长度
next_marker = m2 if m2 > 0 else len(data)
m_len = next_marker - marker - 8
print(f"EA06M 段数据长度: {m_len} 字节")

# 尝试 EA06 专用的 LZMA 变体
# AutoIt 的 LZMA 头是 5 字节的 "raw" 格式
# 尝试强制解析
blob = data[marker+8:next_marker]
print(f"EA06M 后前 64 字节: {blob[:64].hex()}")

# 尝试各种偏移的 LZMA 原始解压
for skip in range(0, 100):
    chunk = blob[skip:skip+1_000_000]
    if len(chunk) < 100: break
    # FORMAT_RAW: filter=LZMA1, dict_size=8MB, lc=3, lp=0, pb=2
    for dict_size in [0x1000000, 0x800000, 0x400000, 0x100000]:
        filters = [{"id": lzma.FILTER_LZMA1, "dict_size": dict_size,
                    "lc": 3, "lp": 0, "pb": 2}]
        try:
            decomp = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=filters)
            result = decomp.decompress(chunk[:500_000])
            if len(result) > 500 and any(k in result[:5000] for k in [b"Func", b"#include", b"MsgBox", b"GUICreate"]):
                print(f"  成功 @ skip={skip} dict_size=0x{dict_size:x}: {len(result)} 字节")
                out = r"C:\malware_work\888RAT\decrypted.au3"
                with open(out, "wb") as f:
                    f.write(result)
                print(f"  已保存")
                print(f"  预览: {result[:500].decode('utf-8','replace')}")
                raise SystemExit(0)
        except SystemExit: raise
        except Exception:
            pass

print()
print("标准 LZMA / FORMAT_RAW 都失败，EA06 使用自定义算法")
print("提示：需要专门的 myAut2Exe 工具才能解")
print()
print("[EA06M 标记后特征]")
print(f"  byte[8:12]  = {blob[:4].hex()}  (可能也是 key)")
print(f"  byte[12:16] = {blob[4:8].hex()}")
