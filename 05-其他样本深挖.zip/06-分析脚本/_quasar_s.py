# -*- coding: utf-8 -*-
"""Quasar - 字符串提取 + 特征"""
import re, hashlib

pe = r"C:\malware_work\Quasar\r-c.exe"
with open(pe, "rb") as f:
    data = f.read()

print(f"大小: {len(data)} 字节")
print(f"MD5:    {hashlib.md5(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print()

# Quasar 是 C# 编写的 RAT
# 找 .NET / C# 特征
print("[.NET / C# 特征]")
for kw in [b"mscorlib", b"System.Windows.Forms", b"Quasar", b"RAT", b"Client",
           b"Server", b"Persistence", b"RegistryKey", b"ClientPlugin",
           b"DotNetZip", b"Mutex", b"EncryptedData", b"HostsEditor",
           b"RemoteShell", b"Keylogger", b"RemoteDesktop", b"FileManager",
           b"Tls", b"SslStream", b"TcpClient", b"X509Certificate"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace')}: x{c}")

# 字符串
print()
print("[关键字符串]")
seen = set()
for s in re.findall(rb"[\x20-\x7e]{6,}", data):
    try: t = s.decode("ascii")
    except: continue
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["quasar", "http", "mutex", "persistence", "registry",
                              "tcp", "ssl", "certificate", "password", "encrypt",
                              "cmd.exe", "software\\", "windows\\"]):
        if 6 < len(t) < 180:
            print(f"  {t[:170]}")
