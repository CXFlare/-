# -*- coding: utf-8 -*-
"""NJRAT 分析：IAT 映射 + API 调用点"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"

with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
sections = [
    (".text",  0x1000, 0x7F6C, 0x400, 0x7F6C),
    (".bss",   0x9000, 0x213B0, 0x0, 0x0),
    (".data",  0x2B000, 0x33D0, 0x8400, 0x33D0),
    (".idata", 0x2F000, 0xEA4, 0xB800, 0xEA4),
    (".fldo",  0x30000, 0x1000, 0xCA00, 0x200),
    (".l1",    0x31000, 0x1200, 0xCC00, 0x1200),
]
def rva2off(rva):
    for _, va, vs, raw, rs in sections:
        if va <= rva < va + max(vs, rs):
            return raw + (rva - va)
    return None

# ============ 解析导入表 ============
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = rva2off(imp_rva)

# iat_rva -> API 名
iat_map = {}
descs = []
i = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = rva2off(name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_rva = oft or ft
    thunk_off = rva2off(thunk_rva)
    j = 0
    while True:
        t = thunk_off + j*4
        if t+4 > len(data): break
        v = struct.unpack("<I", data[t:t+4])[0]
        if v == 0: break
        iat_entry_rva = ft + j*4
        if v & 0x80000000:
            name = f"{dll}!#{v & 0x7FFFFFFF}"
        else:
            h = rva2off(v)
            if h:
                end = data.find(b"\x00", h+2)
                name = f"{dll}!{data[h+2:end].decode('ascii', 'replace')}"
        iat_map[iat_entry_rva] = name
        j += 1
    descs.append((dll, ft, j))
    i += 1

print(f"导入表：{len(iat_map)} 个 IAT 项")
print(f"DLL 数：{len(descs)}")

# ============ 找 wrapper：jmp dword [42Fxxx] ============
wrapper_to_api = {}
cur_wrapper = None
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur_wrapper = int(m.group(2), 16)
        continue
    j = re.search(r"jmp dword \[42F([0-9A-Fa-f]{3})h\]", line)
    if j and cur_wrapper:
        # IAT 表位于 .idata 段：VA=0x2F000 => 地址 0x42F000
        # 但反汇编里写的是 42Fxxx，注意这才是 VA 而不是 RVA
        iat_va = 0x42F000 + int(j.group(1), 16)
        iat_rva = iat_va - IMAGE_BASE
        if iat_rva in iat_map:
            wrapper_to_api[cur_wrapper] = iat_map[iat_rva]
        cur_wrapper = None

print(f"找到 {len(wrapper_to_api)} 个 API wrapper")
print()

# 打印所有 wrapper -> API
print("=" * 70)
print("所有 API Wrapper")
print("=" * 70)
for w, a in sorted(wrapper_to_api.items()):
    print(f"  0x{w:x}  ->  {a}")
