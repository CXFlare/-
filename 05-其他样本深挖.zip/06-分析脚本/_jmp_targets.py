# -*- coding: utf-8 -*-
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"

with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    sections = [(0x1000, 0x400, 0x7F6C), (0x9000, 0x0, 0x213B0), (0x2B000, 0x8400, 0x33D0), (0x2F000, 0xB800, 0xEA4), (0x30000, 0xCA00, 0x200), (0x31000, 0xCC00, 0x1200)]
    for va_, vs, raw, rs in [(v[0], v[1], v[2], v[3]) for v in sections]:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

# 从反汇编收集所有 jmp dword [XXX] 的目标
# 格式可能是 42Fxxx, 43xxxx, 41xxxx
jmp_targets = set()
cur = None
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ 0x([0-9a-f]+)", line)
    if m:
        cur = int(m.group(2), 16)
        continue
    j = re.search(r"jmp dword \[(4[0-9A-Fa-f]+)h\]", line)
    if j:
        jmp_targets.add(int(j.group(1), 16))

print(f"jmp dword [...] 目标: {len(jmp_targets)} 个")
for t in sorted(jmp_targets)[:50]:
    print(f"  0x{t:x}")
