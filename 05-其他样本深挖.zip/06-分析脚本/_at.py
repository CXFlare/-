# -*- coding: utf-8 -*-
"""AgentTesla - PAGO.exe 分析"""
import re, hashlib, struct

pe = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(pe, "rb") as f:
    data = f.read()

print(f"大小: {len(data)} 字节")
print(f"MD5:    {hashlib.md5(data).hexdigest()}")
print(f"SHA1:   {hashlib.sha1(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print()

# PE 头
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
machine = struct.unpack("<H", data[pe_off+4:pe_off+6])[0]
nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
print(f"PE 头: 0x{pe_off:x}, machine=0x{machine:04x}, 节数={nsec}, 时间戳=0x{ts:x}")
import datetime
try: print(f"编译时间: {datetime.datetime.utcfromtimestamp(ts)}")
except: pass

# .NET 检测
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
cli_rva = struct.unpack("<I", data[dd_off+14*8:dd_off+14*8+4])[0]
print(f"CLI RVA: 0x{cli_rva:x}  ({'是 .NET' if cli_rva else '不是 .NET'})")
print()

# .NET 特征
print("[.NET 特征]")
for kw in [b"mscorlib", b"System.", b"Microsoft.VisualBasic", b"AgentTesla",
           b"PAGO", b"SMTP", b"Telegram", b"FTP", b"HTTP", b"Keylog",
           b"Clipboard", b"Screen", b"Webcam", b"Chrome", b"Firefox",
           b"Outlook", b"Password", b"Browser", b"Stealer", b"GetAsyncKeyState"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<30} x{c}")

# 字符串
print()
print("[关键字符串]")
seen = set()
for s in re.findall(rb"[\x20-\x7e]{6,}", data):
    try: t = s.decode("ascii")
    except: continue
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["smtp", "telegram", "http", "ftp", "bot", "chat_id",
                              "apikey", "password=", "chrome", "firefox", "outlook",
                              "keylog", "clipboard", "screen", "webcam",
                              "software\\", "appdata", "browser", "wallet",
                              "pago", "agent", "tesla"]):
        if 6 < len(t) < 180:
            print(f"  {t[:170]}")
