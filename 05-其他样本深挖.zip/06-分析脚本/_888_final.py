# -*- coding: utf-8 -*-
"""888RAT EA06 解密 - 使用 myAut2Exe 算法
   
myAut2Exe 核心算法：EA06 使用 LZMA，但需要先通过自定义 key 解密
key 通常藏在 PE 里，用 EA06 标记后的数据也参与

参考：https://github.com/kavdev/myAut2Exe (原理分析)
实际算法：
1. EA06M 后面的数据是 LZMA 压缩
2. LZMA 头可能被加密
"""
import lzma, struct

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
print(f"EA06M @ 0x{marker:x}")

# 从 marker + 8 开始
# myAut2Exe 的经典做法：EA06M 后 4 字节是 checksum，再后面是 LZMA 数据
# LZMA 头可能是修改过的
start = marker + 8

# 扫描 5D 00 00 (LZMA 标准头) 附近
for offset in range(start, start + 2000):
    if data[offset:offset+5] == b"\x5D\x00\x00\x00\x00":
        # 标准 LZMA 头，dict_size = 0
        print(f"  5D 00 00 00 00 @ 0x{offset:x}")
        # 尝试用修正的方式构造 LZMA 头
        for dict_size in [0x10000, 0x100000, 0x1000000, 0x4000000]:
            header = b"\x5D" + struct.pack("<I", dict_size) + b"\x00" * 8
            blob = header + data[offset+13:offset+13+10_000_000]
            try:
                result = lzma.decompress(blob)
                if len(result) > 100:
                    print(f"    dict_size=0x{dict_size:x} → {len(result)} 字节")
                    out = r"C:\malware_work\888RAT\decrypted.au3"
                    with open(out, "wb") as f:
                        f.write(result)
                    print(f"    已保存")
                    txt = result[:2000].decode("utf-8", "replace")
                    print(f"    预览: {txt[:400]}")
                    break
            except: pass

# 也试试直接找 marker 后面的 LZMA 数据，手动构造头
print()
print("[扫描 marker 后 3000 字节，尝试各种偏移]")
import itertools
for offset in range(marker, marker + 3000):
    for offset2 in [offset, offset+1, offset+2, offset+3]:
        # 手工构造 LZMA 头
        for ds in [0x1000000]:
            try:
                header = b"\x5D" + struct.pack("<I", ds) + b"\x00" * 8
                blob = header + data[offset2:offset2+5_000_000]
                decomp = lzma.LZMADecompressor()
                result = decomp.decompress(blob[:2_000_000])
                if len(result) > 500 and b"Func" in result[:50000]:
                    print(f"  成功 @ 0x{offset2:x}: {len(result)} 字节")
                    out = r"C:\malware_work\888RAT\decrypted.au3"
                    with open(out, "wb") as f:
                        f.write(result)
                    print(f"  已保存")
                    txt = result[:2000].decode("utf-8", "replace")
                    print(f"  预览:\n{txt[:800]}")
                    raise SystemExit(0)
            except SystemExit: raise
            except: pass
