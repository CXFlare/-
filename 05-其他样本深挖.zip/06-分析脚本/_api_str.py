# -*- coding: utf-8 -*-
"""关键：42F5xx 段的 API 名字被 4 字节分组，每 12 字节一个 API 名（4 字节名 + 4 字节 hint + 4 字节填充）"""
import re, struct

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400, 0x7F6C), (0x9000, 0x213B0, 0x0, 0x0), (0x2B000, 0x33D0, 0x8400, 0x33D0), (0x2F000, 0xEA4, 0xB800, 0xEA4), (0x30000, 0x1000, 0xCA00, 0x200), (0x31000, 0x1200, 0xCC00, 0x1200)]
    for va_, vs, raw, rs in secs:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

# 直接读取 0x42F500 到 0x430000 的连续字节
off_start = va2off(0x42F500)
off_end = va2off(0x42FE00)
raw = data[off_start:off_end]

# 解析：每 12 字节一个条目（4 字节 chunk + 空 + 4 字节 hint + 4 字节空）
# 观察前几个：
#   0x42f508 'Crea'
#   0x42f50c 'teIn'
#   0x42f510 'stan'
#   => 'CreateInstance' 跨了 3 个 4 字节组
# 
# 所以字符串在连续字节里，只是 4 字节对齐
# 完整拼接即可

# 拼接所有字节（去掉 0x00 填充）
# 直接遍历 42F500 - 430000，跳过 0x00 分隔，形成若干字符串
text = bytearray()
strings = []
cur = bytearray()
for b in raw:
    if b == 0:
        if len(cur) >= 3:
            try:
                s = cur.decode("ascii")
                if all(32 <= c < 127 for c in s):
                    strings.append(s)
            except: pass
        cur = bytearray()
    else:
        cur.append(b)
if len(cur) >= 3:
    try:
        s = cur.decode("ascii")
        if all(32 <= c < 127 for c in s):
            strings.append(s)
    except: pass

# 打印所有 > 5 字符的字符串
print(f"总数: {len(strings)}")
print()
for s in strings:
    if len(s) >= 5:
        print(f"  {repr(s)}")
