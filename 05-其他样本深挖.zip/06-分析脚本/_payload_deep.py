# -*- coding: utf-8 -*-
import re, hashlib

p = r"C:\malware_work\AgentTesla\hidden_payload_full.exe"
with open(p, "rb") as f:
    data = f.read()

print(f"大小: {len(data)}")
print()

# 提取 base64 / hex 编码的数据块
print("[高熵数据块 > 200 字节]")
for m in re.finditer(rb"[A-Za-z0-9+/=]{200,}", data):
    chunk = m.group()
    if len(chunk) < 5000:
        print(f"  @0x{m.start():x} len={len(chunk)}: {chunk[:100].decode('ascii','replace')}")
        print()

# 找所有 UTF-16LE 字符串
print("[UTF-16LE 字符串]")
seen = set()
for m in re.finditer(rb"(?:[\x20-\x7e]\x00){6,200}", data):
    try:
        t = m.group().decode("utf-16le", "replace")
    except: continue
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["smtp", "http", "ftp", "telegram", "bot",
                              "password", "chrome", "firefox", "outlook",
                              "keylog", "agent", "tesla", "stealer"]):
        if not any(x in tl for x in ["microsoft", "digicert", "schemas", "w3.org"]):
            print(f"  {t[:190]}")

# 全部明文 http URL
print()
print("[HTTP URLs]")
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
    u = m.group().decode("ascii", "replace")
    if not any(x in u.lower() for x in ["microsoft", "digicert", "schemas", "w3.org"]):
        print(f"  {u[:180]}")

# SMTP
print()
print("[SMTP 服务器]")
for m in re.finditer(rb"smtp[\w\.\-]{2,100}", data):
    print(f"  {m.group().decode('ascii','replace')}")
for m in re.finditer(rb"(?:mail|email)[\w\.\-]{2,80}\.[a-z]{2,6}", data):
    t = m.group().decode("ascii", "replace")
    if not any(x in t.lower() for x in ["microsoft", "digicert"]):
        print(f"  {t}")
