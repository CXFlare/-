# -*- coding: utf-8 -*-
import re, hashlib, os

samples = [
    ("Sodinokibi", r"C:\malware_work\Sodinokibi\0f8ee1ed415794ec053dca928a409436_JaffaCakes118"),
    ("SmokeLoader", r"C:\malware_work\SmokeLoader\f9be6fbe073f8e75344c62adff1a729494acafa18ea7c778cd0b3177a77de0f3"),
    ("StealC", r"C:\malware_work\StealC\da886b94c504088d53032e48ffcd264e3a3406b0342f38e44f8b1f3bbe37ef23"),
    ("Amadey", r"C:\malware_work\Amadey\662119ffeb5cc0951c36e30f2f2f9c537349292775ef4a4b26a6ec219ea9db95"),
    ("GULoader", r"C:\malware_work\GULoader\586 R1  M-LINE - GEORGIA 03.05.2024.exe"),
    ("PrivateLoader", r"C:\malware_work\PrivateLoader\2024-05-03_68452609966ed034f6e024d4d6f30fc4_magniber_metamorfo"),
    ("Vidar", r"C:\malware_work\Vidar\f74356e6d895188cc5b28c98d9305844.bin"),
    ("Lumma", r"C:\malware_work\Lumma\5ce704b101d2c1cb57abbe7dce3f3ce627340ac1766c0c5f165ed7d28d24fede"),
    ("Raccoon", r"C:\malware_work\Raccoon\0203ee4a4252b78a17796e7e4832dcfb921051b87e4a727eae172ea13d9424cd"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    try:
        with open(path, "rb") as f:
            data = f.read()
    except Exception as e:
        print(f"[!] 读取失败: {e}")
        continue
    
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")

    # 关键特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"MSVBVM60", b"System.", b"cmd.exe", b"keylog", b"stealer",
               b"browser", b"clipboard", b"Chrome", b"Firefox", b"Outlook",
               b"wallet", b"password", b"XMR", b"monero", b"stratum",
               b"ransom", b"encrypt", b"decrypt", b"readme", b"onion",
               b"smoke", b"amadey", b"stealc", b"vidar", b"lumma",
               b"raccoon", b"magniber", b"metamorfo", b"telegram"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats[:15]))

    # URLs (过滤证书)
    urls = set()
    for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
        u = m.group().decode("ascii", "replace")
        if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "verisign",
                                          "usertrust", "comodo", "globalsign", "symantec",
                                          "schemas.", "w3.org", "adobe", "entrust",
                                          "thawte", "wosign", "cybertrust", "starfield",
                                          "godaddy", "tempuri", "purl.org"]):
            continue
        urls.add(u)
    if urls:
        print(f"[URLs] {len(urls)}")
        for u in sorted(urls)[:8]: print(f"  {u[:170]}")

    # TG token
    tg = set()
    for m in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}", data):
        tg.add(m.group().decode("ascii"))
    if tg:
        print(f"[TG Bot] {len(tg)}")
        for t in list(tg)[:3]: print(f"  {t}")

    # Crypto wallets
    btc = set()
    for m in re.finditer(rb"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b", data):
        btc.add(m.group().decode("ascii"))
    if btc:
        print(f"[BTC] {len(btc)}")
        for b in list(btc)[:3]: print(f"  {b}")

    xmr = set()
    for m in re.finditer(rb"\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b", data):
        xmr.add(m.group().decode("ascii"))
    if xmr:
        print(f"[XMR] {len(xmr)}")
        for x in list(xmr)[:3]: print(f"  {x}")

    print()
