# -*- coding: utf-8 -*-
"""Redline 内存 dump 深度分析"""
import hashlib, re

p = r"C:\malware_work\Redline\4900-2-0x0000000000AB0000-0x0000000000B2EFAE-memory.dmp"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# Redline 特征
print("[Redline 特征]")
for kw in [b"RedLine", b"redline", b"stealer", b"browser", b"chrome",
           b"firefox", b"outlook", b"password", b"cookie", b"autofill",
           b"wallet", b"metamask", b"exodus", b"telegram", b"discord",
           b"ftp", b"smtp", b"vpn", b"clipboard"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

# 关键字符串
print()
print("[关键字符串]")
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{8,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["redline", "gate", "c2", "panel", "telegram",
                              "discord", "http://", "https://", "smtp",
                              "ftp.", "chrome", "firefox", "wallet"]):
        if not any(x in tl for x in ["microsoft", "digicert"]):
            print(f"  {t[:180]}")
            if len(seen) > 30: break
