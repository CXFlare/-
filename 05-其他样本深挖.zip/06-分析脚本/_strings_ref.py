# -*- coding: utf-8 -*-
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 找 WinMain / 主入口 —— 找引用 "Startup" 之类的函数
# 先找所有字符串引用
strings_in_code = {}
for i, line in enumerate(lines):
    m = re.search(r"push (42[0-9A-Fa-f]{4})h", line)
    if m:
        addr = m.group(1)
        strings_in_code.setdefault(addr, []).append(i)

# 提取 .data 段里 0x42xxxx 附近的字符串
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

# 手动映射 0x42xxxx -> 文件偏移
# .data: VA=0x2B000, RAW=0x8400 -> 地址 0x42B000 = 偏移 0x8400
def addr_to_off(addr):
    rva = addr - 0x400000
    sections = [
        (0x1000, 0x400, 0x7F6C),
        (0x9000, 0x0, 0x213B0),
        (0x2B000, 0x8400, 0x33D0),
        (0x2F000, 0xB800, 0xEA4),
        (0x30000, 0xCA00, 0x200),
        (0x31000, 0xCC00, 0x1200),
    ]
    for va, raw, vs in sections:
        if va <= rva < va + vs:
            return raw + (rva - va)
    return None

def read_str(addr):
    off = addr_to_off(addr)
    if off is None: return None
    end = data.find(b"\x00", off)
    if end < 0 or end - off > 200: return None
    s = data[off:end]
    try:
        return s.decode("ascii")
    except:
        return None

# 打印所有被 push 的字符串引用
seen = set()
for addr, _ in sorted(strings_in_code.items()):
    a = int(addr, 16)
    s = read_str(a)
    if s and s not in seen:
        seen.add(s)
        print(f"0x{addr}  ->  {s[:150]}")
