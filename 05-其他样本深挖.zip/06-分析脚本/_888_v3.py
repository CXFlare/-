# -*- coding: utf-8 -*-
"""888RAT EA06 解密 - 尝试完整算法还原

AutoIt EA06 加密算法（参考 myAut2Exe / exe2au3）:
1. EA06M 标记后 4 字节是魔术
2. 后面是 XOR 加密的 LZMA 数据
3. XOR key 从 PE 特征/时间戳推导
"""
import struct, lzma, hashlib

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

# 找到 EA06M 和 EA06P 标记
marker = data.find(b"AU3!EA06M")
marker2 = data.find(b"AU3!EA06P")
print(f"EA06M: 0x{marker:x}  EA06P: 0x{marker2:x}")

# EA06M 后 4 字节 = 0x73ffa84d
key1 = struct.unpack("<I", data[marker+8:marker+12])[0]
print(f"Key1: 0x{key1:08x}")

# EA06P 后结构解析
# EA06P 后是 "AU3!EA06P\x00\x00\x01\x00\x04..." 
if marker2 > 0:
    chunk = data[marker2:marker2+32]
    print(f"EA06P 后 32 字节: {chunk.hex()}")
    print(f"EA06P 后 ASCII:   {chunk}")

# 888RAT 的 888RAT 1.1.1 cracked.exe 是自解压安装包
# 它包含 NSIS 头，真实 payload 在后面
# 先找所有 AU3 标记
print()
print("[所有 AU3! 标记]")
import re
for m in re.finditer(rb"AU3![\x00-\xff]{0,8}", data):
    pos = m.start()
    print(f"  0x{pos:x}  {m.group()}")

# 找所有 LZMA / zlib / gzip 可能的头
print()
print("[压缩头搜索]")
patterns = [
    (b"\x1F\x8B\x08", "GZIP"),
    (b"\x78\x01", "ZLIB1"),
    (b"\x78\x9C", "ZLIB-default"),
    (b"\x78\xDA", "ZLIB-best"),
    (b"\x5D\x00\x00", "LZMA"),
    (b"BZh", "BZIP2"),
    (b"PK\x03\x04", "ZIP"),
]
found = []
for pat, name in patterns:
    positions = [m.start() for m in re.finditer(re.escape(pat), data[:20_000_000])]
    if positions:
        print(f"  {name}: {len(positions)} 处（前 5）")
        for p in positions[:5]:
            print(f"    0x{p:x}")
        found.append((name, positions[:5]))

# 888RAT 内部可能包含第二个 PE
print()
print("[内部 MZ 搜索]")
mzs = []
i = 0
while True:
    p = data.find(b"MZ", i)
    if p < 0 or p > 30_000_000: break
    if p + 0x40 < len(data):
        pe_off = struct.unpack("<I", data[p+0x3C:p+0x40])[0]
        if p + pe_off + 4 <= len(data) and data[p+pe_off:p+pe_off+4] == b"PE\x00\x00":
            machine = struct.unpack("<H", data[p+pe_off+4:p+pe_off+6])[0]
            ts = struct.unpack("<I", data[p+pe_off+8:p+pe_off+12])[0]
            mzs.append((p, machine, ts))
    i = p + 2

print(f"  发现 {len(mzs)} 个内嵌 PE")
for p, m, t in mzs[:10]:
    print(f"    0x{p:x}  machine=0x{m:04x}  ts=0x{t:08x}")
