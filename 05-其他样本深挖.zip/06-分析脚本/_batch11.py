# -*- coding: utf-8 -*-
"""批量分析：Metasploit(AvosLocker) / CobaltStrike / Ploutus / MiMiKatz"""
import re, hashlib, os

samples = [
    ("AvosLocker", r"C:\malware_work\Metasploit\2024-05-03_6d67a3bdd5317d782d550ce7bc4fef46_avoslocker"),
    ("CobaltStrike", r"C:\malware_work\CobaltStrike\2024-05-03_f3b8c1bb3f2b7d4dafcdf8bf6ed2af55_cobalt-strike_cobaltstrike"),
    ("Ploutus", r"C:\malware_work\Ploutus\Tis_Park_Server.exe"),
    ("Gh0stRAT", r"C:\malware_work\Gh0stRAT\10821cd91ff6959f89e8f2bd577bd5da_JaffaCakes118"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    print(f"头部: {data[:16].hex()}")
    
    # 特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"System.", b"Cobalt", b"Beacon", b"SMB", b"psexec", b"wmi",
               b"AVos", b"Avos", b"ransom", b"encrypt", b"decrypt",
               b"Ploutus", b"ATM", b"cash", b"dispenser", b"XFS",
               b"Gh0st", b"gh0st", b"pcMain", b"BcServer", b"SYN"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    # URLs (过滤微软/证书)
    urls = set()
    for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
        u = m.group().decode("ascii", "replace")
        if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "verisign",
                                          "usertrust", "comodo", "globalsign", "symantec",
                                          "schemas.", "w3.org", "adobe", "ibsensoftware",
                                          "thawte", "wosign", "graphviz", "entrust",
                                          "tempuri", "purl.org"]):
            continue
        urls.add(u)
    if urls:
        print(f"[URLs]")
        for u in sorted(urls)[:10]: print(f"  {u[:180]}")
    
    # IPs
    ips = set()
    for m in re.finditer(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b", data):
        t = m.group().decode("ascii")
        parts = t.split(".")
        if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0","6.0.0.0","1.0.0.0","127.0.0.1"]:
            ips.add(t)
    if ips and len(ips) < 20:
        print(f"[IPs]")
        for ip in sorted(ips)[:10]: print(f"  {ip}")
    print()
