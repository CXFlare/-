# -*- coding: utf-8 -*-
"""批量分析：Neshta / Tinba / Ramnit / Berbew / Dirdex / HawkEyeReborn"""
import re, hashlib, os

samples = [
    ("Neshta", r"C:\malware_work\Neshta\e8d9e77c555569d9d719fe5ff5c4c4f1047e157f5cbb00e7c43033bc8aefa384"),
    ("Tinba", r"C:\malware_work\Tinba\0fe4698657dc7c60cf27898465620075_JaffaCakes118"),
    ("Ramnit", r"C:\malware_work\Ramnit\106d8addd8e99bb801f5b8d93868b720_JaffaCakes118"),
    ("Berbew", r"C:\malware_work\Berbew\b11d1b2b87231dcb87b3bae27195e661.exe"),
    ("Dirdex", r"C:\malware_work\Dirdex\106616b4d3c012a99a747f9d0e951596_JaffaCakes118"),
    ("HawkEyeReborn", r"C:\malware_work\HawkEyeReborn\0def4e4fe77fc4499d9ade8db0f9c82a_JaffaCakes118"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    print(f"头部: {data[:16].hex()}")
    if data[:2] == b"MZ": print("PE")
    if data[:4] == b"\x7fELF": print("ELF")
    
    # 特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"System.", b"Neshta", b"Tinba", b"Ramnit", b"Berbew",
               b"inject", b"HTML", b"HTM", b"htm", b"exe",
               b"cmd.exe", b"keylog", b"browser", b"bank",
               b"password", b"stealer", b"Chrome", b"Firefox", b"Outlook"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    if feats: print("[特征] " + " ".join(feats))
    
    # 可疑字符串
    print("[关键字符串]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{8,200}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["http://", "https://", "neshta", "tinba",
                                  "ramnit", "berbew", "inject", ".htm", "bank",
                                  "stealer", "keylog", "c2.", "gate"]):
            if 8 < len(t) < 180:
                print(f"  {t[:170]}")
    print()
