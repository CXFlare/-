# -*- coding: utf-8 -*-
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 找所有引用到的 0x42xxxx 地址
refs = set()
for line in lines:
    for m in re.finditer(r"42[0-9A-Fa-f]{4}h", line):
        refs.add(int(m.group(0)[:-1], 16))

# 映射到文件偏移并读取字符串
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

def addr_to_off(addr):
    rva = addr - 0x400000
    sections = [
        (0x1000, 0x400, 0x7F6C),
        (0x9000, 0x0, 0x213B0),
        (0x2B000, 0x8400, 0x33D0),
        (0x2F000, 0xB800, 0xEA4),
        (0x30000, 0xCA00, 0x200),
        (0x31000, 0xCC00, 0x1200),
    ]
    for va, raw, vs in sections:
        if va <= rva < va + vs:
            return raw + (rva - va)
    return None

def read_str(addr, maxlen=200):
    off = addr_to_off(addr)
    if off is None: return None
    end = data.find(b"\x00", off)
    if end < 0 or end - off > maxlen: return None
    try:
        return data[off:end].decode("ascii")
    except: return None

# 找所有引用的字符串并按长度排序
all_strs = {}
for addr in refs:
    s = read_str(addr)
    if s:
        all_strs[addr] = s

print(f"总引用字符串: {len(all_strs)}")
print()
print("=" * 80)
print("所有被引用的字符串（按地址排序）")
print("=" * 80)
for addr in sorted(all_strs.keys()):
    s = all_strs[addr]
    if len(s) >= 2:
        print(f"0x{addr:X}  {repr(s)[:200]}")
