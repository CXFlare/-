# -*- coding: utf-8 -*-
import struct, lzma, re

p = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(p, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
enc = data[marker+8:marker+8+2_000_000]  # 只取 2MB
print(f"EA06M @ 0x{marker:x}  数据长度: {len(enc)}")
print(f"前 32 字节: {enc[:32].hex()}")
print()

# 扫描所有 LZMA 候选
found = False
for m in re.finditer(rb"\x5D\x00\x00", enc[:1_000_000]):
    pos = m.start()
    if pos + 13 > len(enc): break
    dict_size = struct.unpack("<I", enc[pos+1:pos+5])[0]
    if 0x1000 <= dict_size <= 0x40000000:
        print(f"LZMA 候选 @ 0x{pos:x} ds=0x{dict_size:x}")
        try:
            d = lzma.LZMADecompressor(format=lzma.FORMAT_ALONE)
            r = d.decompress(enc[pos:pos+1_000_000])
            if len(r) > 100:
                print(f"  成功: {len(r)} 字节")
                print(f"  前 200: {r[:200]}")
                with open(r"C:\malware_work\888RAT\decrypted.au3", "wb") as f:
                    f.write(r)
                found = True
                break
        except Exception as e:
            pass
print("未找到 LZMA 或解密失败" if not found else "已解密")
