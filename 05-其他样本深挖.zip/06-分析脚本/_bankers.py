# -*- coding: utf-8 -*-
"""分析银行木马：Emotet, QakBot, TrickBot, ICEDid"""
import re, hashlib, os

samples = [
    ("Emotet", r"C:\malware_work\Emotet\106fb5f7a2b5d0e0af8609949ef37543_JaffaCakes118"),
    ("QakBot", r"C:\malware_work\QakBot\0fb531c7f6e841e36cefbaff58c70949_JaffaCakes118"),
    ("TrickBot", r"C:\malware_work\TrickBot\10975711461fb80b5f653a46930925af_JaffaCakes118"),
    ("ICEDid", r"C:\malware_work\ICEDid\0e582f1d214712c263429692549010ef_JaffaCakes118"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}")
    print(f"MD5:    {hashlib.md5(data).hexdigest()}")
    print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
    if data[:2] == b"MZ":
        print("PE 文件")
    if data[:4] == b"\x7fELF":
        print("ELF 文件")
    
    # 头部 32 字节
    print(f"头部: {data[:32].hex()}")
    
    # 特征
    print("[特征]")
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"System.", b"MZ", b"This program cannot", b"PE\x00\x00",
               b"banking", b"bank", b"bot", b"plugin", b"dll",
               b"webinject", b"formgrab", b"socks", b"vnc"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<22} x{c}")
    
    print("[IOC]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{8,150}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["http://", "https://", "bot", "plugin",
                                  "dll", "sys", ".onion", "panel", "bank",
                                  "webinject", "gate", "config"]):
            if 8 < len(t) < 180:
                print(f"  {t[:180]}")
    print()
