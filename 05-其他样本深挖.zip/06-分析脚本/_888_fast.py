# -*- coding: utf-8 -*-
"""888RAT 深度分析 - 不依赖 disrobe"""
import hashlib, re

p = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# 全部 AU3 标记
print("[所有 AU3! 标记]")
for m in re.finditer(rb"AU3![\x00-\xff]{0,8}", data):
    print(f"  0x{m.start():x}  {m.group()}")

# NSIS 特征
print()
print("[NSIS 特征]")
for kw in [b"NSIS", b"Nullsoft", b"nsis.sf.net", b"7z SFX", b"InstallOptions"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace')}: x{c}")

# 找所有 HTTP/HTTPS
print()
print("[URLs]")
seen = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{4,200}", data):
    u = m.group().decode("ascii", "replace")
    if u in seen: continue
    seen.add(u)
    if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                          "verisign", "usertrust", "comodo",
                                          "globalsign", "symantec", "schemas.",
                                          "w3.org", "adobe", "entrust",
                                          "thawte", "wosign", "nsis.sf.net",
                                          "autoitscript", "ibsensoftware"]):
        print(f"  {u[:180]}")

# 关键字符串
print()
print("[关键字符串 (15+ 字符)]")
seen = set()
cnt = 0
for m in re.finditer(rb"[\x20-\x7e]{15,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["telegram", "discord", "http", "cmd.exe",
                              "powershell", "reg add", "reg write",
                              "winlogon", "shellservice", "888rat",
                              "keylog", "crypt", "wallet", "btc",
                              "cluster", "bot", "888"]):
        if not any(x in tl for x in ["microsoft", "autoit", "windows.common"]):
            print(f"  {t[:180]}")
            cnt += 1
            if cnt >= 20: break
