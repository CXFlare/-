# -*- coding: utf-8 -*-
"""NJRAT 深挖 - 检测 .NET 痕迹 + 完整字符串"""
import re

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

# 关键：寻找 .NET 特征字符串
print("=" * 70)
print("NJRAT 深挖 2 - .NET / 平台痕迹")
print("=" * 70)

# NJRAT 一般是 VB.NET 或 C# 编译
dotnet_kws = [
    "System.", "mscorlib", "Microsoft.VisualBasic", "System.Windows.Forms",
    "System.Drawing", "System.Net.Sockets", "Microsoft.VisualBasic.CompilerServices",
    "My.Computer", "My.Project", "Microsoft.VisualBasic.ApplicationServices",
    "System.Runtime.CompilerServices", "RuntimeHelpers", "CompileGenerated",
    "System.Reflection", "Assembly", "MethodInfo",
    "NewLateBinding", "Conversions.ToString", "ProjectData",
    "WindowsApplication", "Form1", "Timer1", "TextBox", "Label",
    "Button", "ComboBox", "MySql", "TextBox1",
]
found = {}
for kw in dotnet_kws:
    c = data.count(kw.encode())
    if c > 0:
        found[kw] = c

print("\n[.NET / VB.NET 特征]")
for kw, c in sorted(found.items(), key=lambda x: -x[1]):
    print(f"  {kw:<50} x{c}")

# 找所有 ".NET" 相关的命名空间
print()
print("[所有 System.* 命名空间]")
ns = set(re.findall(rb"System\.[A-Z][A-Za-z0-9._]{3,60}", data))
for n in sorted(ns):
    try: print(f"  {n.decode('ascii')}")
    except: pass

# NJRAT 经典 VB.NET 命名空间
print()
print("[VB.NET 特有]")
vb = set(re.findall(rb"(Microsoft\.VisualBasic[A-Za-z0-9._]{0,60}|My\.[A-Z][A-Za-z0-9._]{1,50}|ProjectData[A-Za-z0-9._]{0,50})", data))
for n in sorted(vb):
    try: print(f"  {n.decode('ascii')}")
    except: pass
