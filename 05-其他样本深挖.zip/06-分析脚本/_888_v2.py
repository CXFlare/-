# -*- coding: utf-8 -*-
"""888RAT EA06 - 尝试 myAut2Exe 标准解密算法"""
import struct, lzma

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
# 已知 EA06M+8 处 4 字节 = 0x73ffa84d = 解密 key
key = struct.unpack("<I", data[marker+8:marker+12])[0]
print(f"Key: 0x{key:08x}")

# 尝试用 key 作为 4 字节 XOR key 循环解密密文
start = marker + 12
end = min(start + 20_000_000, len(data))
blob = bytearray(data[start:end])
key_bytes = struct.pack("<I", key)

# 尝试多种 XOR 周期
for period in [1, 2, 4, 8]:
    dec = bytearray(blob)
    for i in range(len(dec)):
        dec[i] ^= key_bytes[i % period]
    
    # 检查是否像 LZMA
    if dec[:3] == b"\x5D\x00\x00" or dec[:1] == b"\x5D":
        print(f"  period={period}: 头部={dec[:8].hex()}")
        try:
            result = lzma.decompress(bytes(dec[:5_000_000]))
            if len(result) > 500:
                print(f"    成功: {len(result)} 字节")
                out = r"C:\malware_work\888RAT\decrypted.au3"
                with open(out, "wb") as f:
                    f.write(result)
                print(f"    已保存")
                print(f"    预览: {result[:500].decode('utf-8','replace')}")
                break
        except: pass

# 也尝试先 XOR 再找 LZMA 头
print()
print("[用 key 异或后扫 LZMA 头]")
key_bytes = struct.pack("<I", key)
for period in [4]:
    for offset in range(0, 1024):
        chunk = data[start + offset:start + offset + 3]
        if len(chunk) < 3: break
        dec = bytes(b ^ key_bytes[i % period] for i, b in enumerate(chunk))
        if dec[:3] == b"\x5D\x00\x00":
            print(f"  找到 XOR 后 LZMA @ +{offset}")
            # 解密更大块
            big = data[start + offset:start + offset + 5_000_000]
            dec_big = bytes(b ^ key_bytes[i % 4] for i, b in enumerate(big))
            try:
                result = lzma.decompress(dec_big)
                print(f"    成功: {len(result)} 字节")
                with open(r"C:\malware_work\888RAT\decrypted.au3", "wb") as f:
                    f.write(result)
                print(f"    已保存")
                break
            except Exception as e:
                print(f"    解压失败: {e}")
