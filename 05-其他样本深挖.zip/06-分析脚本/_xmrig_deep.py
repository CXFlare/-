# -*- coding: utf-8 -*-
"""XMRig 脱壳后深度分析 - 提取矿池信息"""
import re, hashlib

p = r"C:\malware_work\XMRig\unpacked_upx\unpacked.exe"
with open(p, "rb") as f:
    data = f.read()

print("=== XMRig 矿池配置提取 ===")
# XMRig 关键字段
patterns = {
    "矿池地址": rb"(?:pool|stratum|tcp|ssl)\.[a-zA-Z0-9\.\-]+(?::\d+)?",
    "端口": rb"(?::\d{2,5})\b",
    "钱包地址": rb"\b(?:4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}|[48][0-9AB][1-9A-HJ-NP-Za-km-z]{93})\b",
    "NiceHash": rb"nicehash[a-zA-Z0-9\.\-]*",
    "矿池 URL": rb"(?:stratum\+tcp|stratum\+ssl)://[a-zA-Z0-9\.\-:]+",
    "donate": rb"donate[a-zA-Z0-9\.\-:]*",
}
for name, pat in patterns.items():
    hits = set(m.group().decode("ascii", "replace") for m in re.finditer(pat, data))
    if hits:
        print(f"\n[{name}] {len(hits)}:")
        for h in sorted(hits)[:10]:
            print(f"  {h[:150]}")

# 提取所有 http/https
print()
print("[所有 HTTP/HTTPS URLs]")
urls = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{4,200}", data):
    u = m.group().decode("ascii", "replace")
    if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "w3.org"]):
        urls.add(u)
for u in sorted(urls)[:15]:
    print(f"  {u}")

# 找 donate 级别配置（XMRig 特有）
print()
print("[XMRig donate 配置]")
for m in re.finditer(rb"donate[a-zA-Z0-9._-]{0,50}", data):
    print(f"  {m.group().decode()}")

# 找 config 相关
print()
print("[矿池可能地址]")
for m in re.finditer(rb"[a-z][a-z0-9.\-]{5,40}\.(?:com|net|org|io|xyz|ru|cn|top)\b", data):
    host = m.group().decode("ascii", "replace")
    if not any(x in host.lower() for x in ["microsoft", "adobe", "mozilla", "w3.org"]):
        print(f"  {host}")
