# -*- coding: utf-8 -*-
"""批量分析剩余样本 - 快速扫描"""
import re, hashlib, os

samples = [
    ("DarkCloud", r"C:\malware_work\DarkCloud\0a8cd02d2ce087bd385a07dc8c27e8af85bfb4a0.zip"),
    ("Gozi", r"C:\malware_work\Gozi\f5756ad8d0d3ae0256852fe7c575272f1160978625a5660e0fa64e3e6eef2c21"),
    ("GoziIFSB", r"C:\malware_work\GoziIFSB\453286093b6b2d791b2505384bda59ccadebc3078ad66f13bf4a0262011aa954"),
    ("IcedID", r"C:\malware_work\IcedID\0e582f1d214712c263429692549010ef_JaffaCakes118"),
    ("MeltingScreen", r"C:\malware_work\MeltingScreen\MeltingScreen.exe"),
    ("XenorRat", r"C:\malware_work\XenorRat\Odeme -(Mayis).lnk.lnk"),
    ("Stormkitty", r"C:\malware_work\Stormkitty\wert.exe"),
    ("QNodeService", r"C:\malware_work\QNodeService\Adwind.exe"),
    ("SystemMBC", r"C:\malware_work\SystemMBC\05135a36e3f36578a55ec1a8d0e3628a4f8912bf3c65f865cf793b58db27f357.exe"),
    ("Happy99", r"C:\malware_work\Happy99\Happy99.exe"),
    ("Upatre", r"C:\malware_work\Upatre\1bbd1a1ffaab13b7d54822fbd0087d68"),
    ("Pikachu", r"C:\malware_work\Pikachu\Pikachu.exe"),
    ("Maldal", r"C:\malware_work\Maldal\Maldal.exe"),
    ("Berbew", r"C:\malware_work\Berbew\b11d1b2b87231dcb87b3bae27195e661.exe"),
    ("Dirdex", r"C:\malware_work\Dirdex\106616b4d3c012a99a747f9d0e951596_JaffaCakes118"),
    ("HawkEyeReborn", r"C:\malware_work\HawkEyeReborn\0def4e4fe77fc4499d9ade8db0f9c82a_JaffaCakes118"),
    ("Sodinokibi", r"C:\malware_work\Sodinokibi\0f8ee1ed415794ec053dca928a409436_JaffaCakes118"),
    ("SmokeLoader", r"C:\malware_work\SmokeLoader\f9be6fbe073f8e75344c62adff1a729494acafa18ea7c778cd0b3177a77de0f3"),
    ("Amadey", r"C:\malware_work\Amadey\662119ffeb5cc0951c36e30f2f2f9c537349292775ef4a4b26a6ec219ea9db95"),
]

print("=" * 70)
print("批量快速扫描 - 剩余样本")
print("=" * 70)

for name, path in samples:
    if not os.path.exists(path):
        continue
    with open(path, "rb") as f:
        data = f.read()
    
    # 关键特征
    feats = []
    for kw in [b".NET", b"mscorlib", b"Delphi", b"UPX", b"NSIS", b"AutoIt",
               b"MSVBVM60", b"System.", b"cmd.exe", b"keylog", b"stealer",
               b"browser", b"clipboard", b"Chrome", b"Firefox", b"Outlook",
               b"wallet", b"password", b"XMR", b"ransom", b"encrypt",
               b"inject", b"HTML", b"bot", b"gate", b"c2", b"panel",
               b"Bank", b"bank", b"FTP", b"SMTP"]:
        c = data.count(kw)
        if c > 0: feats.append(f"{kw.decode('ascii','replace')}x{c}")
    
    print(f"\n[{name}] {len(data)}B MD5={hashlib.md5(data).hexdigest()}")
    if feats: print("  特征: " + " ".join(feats[:12]))
    
    # TG bot
    for m in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}", data):
        print(f"  TG: {m.group().decode('ascii')}")
        break
    
    # IPs
    ips = set()
    for m in re.finditer(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b", data):
        t = m.group().decode("ascii")
        parts = t.split(".")
        if all(0 <= int(p) <= 255 for p in parts) and t not in ["0.0.0.0","6.0.0.0","1.0.0.0","127.0.0.1","10.0.0.0","11.0.0.0","16.0.0.0","164.0.0.0","4.0.0.0","2.0.0.0","15.0.0.0","15.6.0.0"]:
            ips.add(t)
    if ips and len(ips) < 15:
        print(f"  IPs: {', '.join(sorted(ips)[:8])}")
    
    # URLs (关键)
    urls = set()
    for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,160}", data):
        u = m.group().decode("ascii", "replace")
        if any(x in u.lower() for x in ["microsoft", "digicert", "sectigo", "verisign",
                                          "usertrust", "comodo", "globalsign", "symantec",
                                          "schemas.", "w3.org", "adobe", "ibsensoftware",
                                          "thawte", "wosign", "graphviz", "entrust",
                                          "tempuri", "purl.org", "w3c"]):
            continue
        urls.add(u)
    if urls:
        print(f"  URLs: {', '.join(sorted(urls)[:5])}")
