# -*- coding: utf-8 -*-
"""AgentTesla 反编译后源码搜索"""
import os, re

root = r"C:\malware_work\AgentTesla\decompiled"
if not os.path.isdir(root):
    print("目录不存在:", root)
    exit()

# 找所有 .cs 文件
cs_files = []
for r, d, files in os.walk(root):
    for f in files:
        if f.endswith(".cs") or f.endswith(".txt") or f.endswith(".il"):
            cs_files.append(os.path.join(r, f))

print(f"找到 {len(cs_files)} 个源码文件")
print()

# 搜索关键词
keywords = ["smtp", "SmtpClient", "MailMessage", "ftp", "telegram",
            "HttpClient", "WebClient", "Chrome", "Firefox", "Outlook",
            "Password", "GetAsyncKeyState", "Clipboard",
            "https://api.telegram.org", "discord.com/api",
            "BotToken", "ChatID", "AgentTesla", "PAGO"]

results = {}
for f in cs_files:
    try:
        with open(f, "r", encoding="utf-8", errors="replace") as fh:
            content = fh.read()
    except: continue
    for kw in keywords:
        if kw.lower() in content.lower():
            results.setdefault(kw, []).append(f)

print("[命中关键词]")
for kw, files in sorted(results.items()):
    print(f"\n{kw}: {len(files)} 个文件")
    for f in files[:3]:
        print(f"  {f}")

# 找 SMTP / URL
print()
print("[SMTP / URL 提取]")
all_text = ""
for f in cs_files[:50]:
    try:
        with open(f, "r", encoding="utf-8", errors="replace") as fh:
            all_text += fh.read() + "\n"
    except: pass

urls = set(re.findall(r"https?://[\w\.\-:/?=&%_@#+~]+", all_text))
for u in sorted(urls)[:20]:
    if not any(x in u.lower() for x in ["microsoft", "schemas", "w3.org"]):
        print(f"  {u[:180]}")

smtps = set(re.findall(r"smtp\.[a-zA-Z0-9\.\-]+", all_text))
for s in sorted(smtps)[:10]:
    print(f"  SMTP: {s}")

emails = set(re.findall(r"[a-zA-Z0-9._%+\-]{4,64}@[a-zA-Z0-9.\-]{4,200}\.[a-z]{2,6}", all_text))
for e in sorted(emails)[:15]:
    if not any(x in e.lower() for x in ["microsoft", "example.com", "schemas"]):
        print(f"  Email: {e}")
