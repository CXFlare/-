# -*- coding: utf-8 -*-
"""888RAT - 尝试定位 AutoIt EA06 脚本段"""
import re, struct

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

# EA06 标记位置
marker1 = data.find(b"AU3!EA06M")
marker2 = data.find(b"AU3!EA06P")
print(f"AU3!EA06M 位于: 0x{marker1:x}")
print(f"AU3!EA06P 位于: 0x{marker2:x}")

# EA06 结构：AU3!EA06 后跟压缩数据
# 看 marker 附近 100 字节
if marker1 > 0:
    ctx = data[marker1:marker1+128]
    print(f"\n[0x{marker1:x} 附近]")
    print(f"  hex: {ctx.hex()[:200]}")
    print(f"  ascii: {ctx[:100]}")
    
    # 后续字节可能是 zlib / lzma
    # 常见的 EA06 = LZMA 压缩的脚本
    # 跳过 24 字节 header，看后面
    for off in range(marker1+12, marker1+64, 4):
        ch = data[off:off+8]
        if ch[:2] == b"\x5D\x00" or ch[:2] == b"\x78\x9C" or ch[:1] == b"\xFD" or ch[:4] == b"\x37\x7A\xBC\xAF":
            print(f"  在 0x{off:x} 发现可能的压缩头: {ch.hex()}")

# 找 UTF-16LE 的 AU3! 标记
for m in re.finditer(rb"A\x00U\x003\x00!\x00E\x00A\x006\x00", data):
    print(f"  UTF-16 AU3!EA06 @ 0x{m.start():x}")

# 找 LZMA 头
print()
print("[LZMA 头扫描]")
for m in re.finditer(rb"\x5D\x00\x00", data):
    pos = m.start()
    # LZMA 头 13 字节，第一个字节 0x5D 表示 lc=3, lp=0, pb=2
    # 后面 4 字节是 dict size
    if pos + 13 < len(data):
        dict_size = struct.unpack("<I", data[pos+1:pos+5])[0]
        if 0x1000 <= dict_size <= 0x40000000:
            print(f"  可能 LZMA 头 @ 0x{pos:x} dict_size=0x{dict_size:x}")
