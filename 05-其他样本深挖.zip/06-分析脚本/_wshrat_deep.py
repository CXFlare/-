# -*- coding: utf-8 -*-
"""WSHRAT JS 深挖 - c2 关键字出现 977 次"""
import hashlib, re

p = r"C:\malware_work\WSHRAT\test.JS"
with open(p, "rb") as f:
    raw = f.read()
print(f"大小: {len(raw)}  MD5: {hashlib.md5(raw).hexdigest()}")

# 尝试各种编码
for enc in ["utf-8", "utf-16le", "latin-1"]:
    try:
        txt = raw.decode(enc, "replace")
        if "ActiveXObject" in txt or "WScript" in txt or "eval" in txt:
            print(f"编码: {enc}")
            break
    except: pass

# WSHRAT 通常高度混淆，用 eval/Function 包装
# 找关键字符串
print(f"\n[关键字符串]")
for kw in ["ActiveXObject", "WScript.Shell", "Scripting.FileSystemObject",
           "MSXML2", "Adodb.Stream", "fromCharCode", "eval(",
           "powershell", "cmd.exe", "http://", "https://", "base64"]:
    c = txt.count(kw)
    if c > 0:
        print(f"  {kw}: x{c}")

# 找 URL
print(f"\n[URLs]")
urls = set(re.findall(r"https?://[\w\.\-:/?=&%_@#+~]{6,200}", txt))
for u in sorted(urls)[:20]:
    if not any(x in u.lower() for x in ["microsoft", "w3.org", "schemas"]):
        print(f"  {u[:180]}")

# 找 Base64 大块
print(f"\n[Base64 大块 > 500]")
import base64
for m in re.finditer(r"[A-Za-z0-9+/]{500,}={0,2}", txt):
    b64 = m.group()
    print(f"  长度 {len(b64)}")
    try:
        dec = base64.b64decode(b64[:2000] + "=" * (4 - len(b64[:2000]) % 4))
        print(f"  解码前 200 字节: {dec[:200]}")
        print(f"  UTF-8 预览: {dec[:300].decode('utf-8','replace')}")
    except Exception as e:
        print(f"  解码失败: {e}")
    break

# WSHRAT 一般是 var _0x... = [...] 的混淆数组
# 找大数组
arrays = re.findall(r"var\s+_0x[0-9a-f]+\s*=\s*\[([^\]]{200,})\]", txt)
print(f"\n[混淆数组] {len(arrays)} 个")
if arrays:
    # 第一个数组
    arr = arrays[0]
    # 解析里面的字符串
    strings = re.findall(r"'([^']*)'", arr)
    print(f"数组项数: {len(strings)}")
    for s in strings[:50]:
        print(f"  {s[:150]}")
