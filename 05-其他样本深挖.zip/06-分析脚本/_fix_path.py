# -*- coding: utf-8 -*-
import os, shutil
wrong = r'C:\\Users\\洛天依\\Desktop\\新建文件夹\\逆向\\恶俗样本\\分析\\REVERSE_REPORT.md'
right = os.path.join('C:', os.sep, 'Users', '洛天依', 'Desktop', '新建文件夹', '逆向', '恶俗样本', '分析', 'REVERSE_REPORT.md')
print('wrong:', wrong, os.path.exists(wrong))
print('right:', right, os.path.exists(right))

# 从 wrong 移到 right
if os.path.exists(wrong):
    os.makedirs(os.path.dirname(right), exist_ok=True)
    shutil.move(wrong, right)
    print('moved')

# 验证最终位置
print('final exists:', os.path.exists(right))
if os.path.exists(right):
    with open(right, 'r', encoding='utf-8') as f:
        c = f.read()
    print('chars:', len(c))
    print('lines:', c.count(chr(10)))
    print('first 200:', c[:200])