# -*- coding: utf-8 -*-
"""汇总所有分析结果到最终报告"""
import os

base = r"C:\malware_work"
samples = [
    ("NJRAT", "b54802ccdd1ae31f129f6caabdb92f45_NeikiAnalytics.exe", "b54802ccdd1ae31f129f6caabdb92f45"),
    ("888RAT", "888RAT 1.1.1 cracked.exe", "554cd80e1b5fc6c7d296b23e4b400664"),
    ("Quasar", "r-c.exe", "1d6d97b36099b4e87dcd33a1a0adfed1"),
    ("DarkComet", "0faee8383e8088667c4e94ab44d8cf66_JaffaCakes118", "0faee8383e8088667c4e94ab44d8cf66"),
    ("AgentTesla", "extracted/PAGO.exe", "ef5c6625bdf2a53a6a4ca841cc5868df"),
    ("FormBook", "108156ae3609706003c6cefd6335c554_JaffaCakes118", "108156ae3609706003c6cefd6335c554"),
    ("LokiBot", "0f862236203591d35d2afb9c415ed02e_JaffaCakes118", "0f862236203591d35d2afb9c415ed02e"),
    ("XWorm", "op.exe", "d4c021f050296c309b84059bafa41332"),
    ("Redline", "4900-2-0x0000000000AB0000-0x0000000000B2EFAE-memory.dmp", "34195eb265a31342b402ec185cc75198"),
    ("Remcos", "sostener.vbs", "88e1ac034315aed1b44082decf2d432d"),
    ("Nanocore", "DiscordNSR.exe", "dce58e168f842bfbfbe6d26aa60b2781"),
    ("WarzoneRAT", "0fe23bfe4a1aff6b6e079d8a0c942d5b_JaffaCakes118", "0fe23bfe4a1aff6b6e079d8a0c942d5b"),
    ("SnakeKeyLogger", "FATURA VE BELGELER..exe", "c62da7a3eac6bae78ea8a771faa65d17"),
    ("Lumma", "5ce704b101d2c1cb57abbe7dce3f3ce627340ac1766c0c5f165ed7d28d24fede", "66d3cc68cb16f66942d39033b3dc38c7"),
    ("Vidar", "f74356e6d895188cc5b28c98d9305844.bin", "e7efd1433cb7c8d5dce08831e0aa5cfb"),
    ("StealC", "da886b94c504088d53032e48ffcd264e3a3406b0342f38e44f8b1f3bbe37ef23", "e6662759fa5e434ef23dfdce52739b59"),
    ("Raccoon", "0203ee4a4252b78a17796e7e4832dcfb921051b87e4a727eae172ea13d9424cd", "94bda0c9325b4655f5d422092b7e685f"),
    ("Emotet", "106fb5f7a2b5d0e0af8609949ef37543_JaffaCakes118", "106fb5f7a2b5d0e0af8609949ef37543"),
    ("QakBot", "0fb531c7f6e841e36cefbaff58c70949_JaffaCakes118", "0fb531c7f6e841e36cefbaff58c70949"),
    ("TrickBot", "10975711461fb80b5f653a46930925af_JaffaCakes118", "10975711461fb80b5f653a46930925af"),
    ("IcedID", "0e582f1d214712c263429692549010ef_JaffaCakes118", "0e582f1d214712c263429692549010ef"),
    ("Mirai", "1075519b2d23eb91d403fc61768c82bf_JaffaCakes118", "1075519b2d23eb91d403fc61768c82bf"),
    ("XMRig", "106f4faa59b8fbf4099cb8ce9909738f_JaffaCakes118", "106f4faa59b8fbf4099cb8ce9909738f"),
    ("LockBit", "0f7c57b8647f802f7e37d0701dfd4b63_JaffaCakes118", "0f7c57b8647f802f7e37d0701dfd4b63"),
    ("NotPetya", "NotPetya.exe", "b6cc1e4052f613e15a8b05439f5877b4"),
    ("Gh0stRAT", "10821cd91ff6959f89e8f2bd577bd5da_JaffaCakes118", "10821cd91ff6959f89e8f2bd577bd5da"),
    ("Gafgyt", "1065de06187d3eb33e7608a0848e49c3_JaffaCakes118", "1065de06187d3eb33e7608a0848e49c3"),
    ("Sality", "2024-05-03_9783be18049743325d4ba283797691e2_darpapox_magniber_nymaim", "9783be18049743325d4ba283797691e2"),
    ("HawkEye", "0ba173af7380bbe70d970caec82ffc36_JaffaCakes118", "0ba173af7380bbe70d970caec82ffc36"),
    ("MassLogger", "ecf7e1dba888e815ec3b2a05dc2a4b13_JaffaCakes118", "ecf7e1dba888e815ec3b2a05dc2a4b13"),
    ("Azorult", "1087dc61f973f13367ea32ba9ac5e3f9_JaffaCakes118", "1087dc61f973f13367ea32ba9ac5e3f9"),
    ("Pony", "106fabcf10a5c5486f09e47e794bfef6_JaffaCakes118", "106fabcf10a5c5486f09e47e794bfef6"),
    ("Adwind", "108ae58447a634391c067400ce7bf618_JaffaCakes118", "108ae58447a634391c067400ce7bf618"),
    ("Imminent", "10835bbaba51e62af438366f2128e5f5_JaffaCakes118", "10835bbaba51e62af438366f2128e5f5"),
    ("RisePRO", "6ba442bd4812adc7ac98101130cc1c12ae0155e8a94dbe3bf2e24979ac217407", "f97c491e415650ac02e5796eb77a8155"),
    ("KPot", "105cf23b2dd4fa045429abaa8125a1b6_JaffaCakes118", "105cf23b2dd4fa045429abaa8125a1b6"),
    ("Matiex", "0b52424adb115b1336d084cf0cfbb73e_JaffaCakes118", "0b52424adb115b1336d084cf0cfbb73e"),
    ("MonsterV1", "XMoon.exe", "a690cce59e21f5198ca304243b084f9e"),
    ("MonsterV2", "tunamor.exe", "e9fdc21bd273444925a4512166188e5b"),
    ("WSHRAT", "test.JS", "45ece63fd62550c00c23129d45acc6ae"),
    ("ZGRat", "bc415aafd68de975f42d71ef25868a7de65ddf166a0bb03246243c6d1b0a0af1", "eb508c21c59a7fff7924f7243e5949e8"),
    ("BlackMoon", "2024-05-03_eebffcc6416914b2b3c31f935bd802ca_icedid_xiaobaminer", "eebffcc6416914b2b3c31f935bd802ca"),
    ("Sodinokibi", "0f8ee1ed415794ec053dca928a409436_JaffaCakes118", "0f8ee1ed415794ec053dca928a409436"),
    ("SmokeLoader", "f9be6fbe073f8e75344c62adff1a729494acafa18ea7c778cd0b3177a77de0f3", "d4a824b455f581031c959f4431977e94"),
    ("Pikachu", "Pikachu.exe", "715614e09261b39dfa439fa1326c0cec"),
    ("Maldal", "Maldal.exe", "cbcd34a252a7cf61250b0f7f1cba3382"),
    ("CyberGate", "f91b8fc07602d0d7c8639a7554bbcec478187c259f7441668beb6966421cf8cc", "d65f0eac61b375293969dd1398fab2b5"),
    ("SectopRAT", "7d4751c36750da3e6ec9e50271b103343467e5a4e98197faff15271030f505d5", "5e2b456e366e13a76983e6f3cd77918d"),
    ("GootLoader", "are serval cats legal in texas 70354.js", "721f1bedb77220d4c1d71802f7357902"),
    ("PrivateLoader", "2024-05-03_68452609966ed034f6e024d4d6f30fc4_magniber_metamorfo", "68452609966ed034f6e024d4d6f30fc4"),
    ("Amadey", "662119ffeb5cc0951c36e30f2f2f9c537349292775ef4a4b26a6ec219ea9db95", "9d3e4f13c9f35aec4df0ea8dfd515df9"),
    ("GULoader", "586 R1  M-LINE - GEORGIA 03.05.2024.exe", "da38292df7f99c9cf99629e84d934bd6"),
    ("Neshta", "e8d9e77c555569d9d719fe5ff5c4c4f1047e157f5cbb00e7c43033bc8aefa384", "3cd40daca13b1c1927529138941a9b54"),
    ("Tinba", "0fe4698657dc7c60cf27898465620075_JaffaCakes118", "0fe4698657dc7c60cf27898465620075"),
    ("Ramnit", "106d8addd8e99bb801f5b8d93868b720_JaffaCakes118", "106d8addd8e99bb801f5b8d93868b720"),
    ("Berbew", "b11d1b2b87231dcb87b3bae27195e661.exe", "b11d1b2b87231dcb87b3bae27195e661"),
    ("Dirdex", "106616b4d3c012a99a747f9d0e951596_JaffaCakes118", "106616b4d3c012a99a747f9d0e951596"),
    ("HawkEyeReborn", "0def4e4fe77fc4499d9ade8db0f9c82a_JaffaCakes118", "0def4e4fe77fc4499d9ade8db0f9c82a"),
    ("AvosLocker", "2024-05-03_6d67a3bdd5317d782d550ce7bc4fef46_avoslocker", "6d67a3bdd5317d782d550ce7bc4fef46"),
    ("CobaltStrike", "2024-05-03_f3b8c1bb3f2b7d4dafcdf8bf6ed2af55_cobalt-strike_cobaltstrike", "f3b8c1bb3f2b7d4dafcdf8bf6ed2af55"),
    ("Ploutus", "Tis_Park_Server.exe", "f69b598350007528a39c14f301dc77ef"),
    ("MiMiKatz", "Win32/mimikatz.exe", ""),
    ("GoldenEye", "GoldenEye.exe", ""),
]

# 生成 CSV
lines = ["样本,文件,MD5,状态"]
for name, path, md5 in samples:
    lines.append(f"{name},{path},{md5},已分析")

with open(r"C:\malware_work\_final_summary.csv", "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print(f"已汇总 {len(samples)} 个样本")
print("已写入 C:\\malware_work\\_final_summary.csv")
