# -*- coding: utf-8 -*-
"""888RAT - EA06 结构深度分析"""
import struct

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
print(f"EA06M 标记: 0x{marker:x}")

# EA06 结构:
# 0x00: "AU3!EA06M" (8 字节)
# 0x08: 4 字节 未压缩大小
# 0x0C: 4 字节 压缩后大小 (?)  
# 0x10: 4 字节 CRC
# 0x14: 压缩数据

print()
print("[AU3!EA06M 头部结构解析]")
raw = data[marker:marker+64]
print(f"raw: {raw.hex()}")
for i in range(0, 64, 4):
    if i+4 <= len(raw):
        val_le = struct.unpack("<I", raw[i:i+4])[0]
        val_be = struct.unpack(">I", raw[i:i+4])[0]
        print(f"  +{i:02d}: {raw[i:i+4].hex()}  LE=0x{val_le:08x} ({val_le})  BE=0x{val_be:08x}")

# 尝试从 +20 开始解压
print()
print("[从 +20 尝试解压]")
import lzma
for offset in [marker+20, marker+24, marker+16, marker+22, marker+18]:
    for end in [None, 40*1024*1024]:
        blob = data[offset:offset + (end or 40000000)]
        try:
            result = lzma.decompress(blob)
            if len(result) > 100:
                print(f"  成功 @ 0x{offset:x}: {len(result)} 字节")
                try:
                    txt = result.decode("utf-8", "replace")
                    if any(k in txt[:3000] for k in ["Func ", "#include", "MsgBox", "GUICreate", "If ", "Then"]):
                        print(f"  [确认是 AU3 脚本]")
                        out_path = r"C:\malware_work\888RAT\decrypted.au3"
                        with open(out_path, "wb") as f:
                            f.write(result)
                        print(f"  已保存: {out_path}")
                        print(f"\n  [前 2000 字符]")
                        print(txt[:2000])
                        break
                except: pass
        except Exception as e:
            pass
