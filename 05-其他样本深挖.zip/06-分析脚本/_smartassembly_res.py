# -*- coding: utf-8 -*-
"""AgentTesla - 找 SmartAssembly 加密资源 "{07eefa3e-4bba-4508-ab41-20404168e31b}""""
import re, struct, zlib, hashlib

p = r"C:\malware_work\AgentTesla\hidden_payload_full.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# 找资源 GUID 字符串
guid = b"07eefa3e-4bba-4508-ab41-20404168e31b"
pos = data.find(guid)
print(f"资源 GUID 位置: 0x{pos:x}")

# 找 "{07eefa3e" 的模式（UTF-16 或 ASCII）
for pat in [guid, guid.upper(), b"{07eefa3e".upper()]:
    for p_ in [x.start() for x in re.finditer(re.escape(pat), data)]:
        print(f"  {pat} @ 0x{p_:x}")

# 看 GUID 附近的数据
if pos > 0:
    ctx = data[max(0, pos-64):pos+128]
    print(f"\n[GUID 附近]")
    print(f"  hex: {ctx.hex()}")
    print(f"  ascii: {ctx}")

# .NET ManifestResource 表通常在 metadata 里
# .NET 资源名的长度前缀是 7-bit encoded
# 找 "07eefa3e" 或 "SmartAssembly" 附近
print()
print("[SmartAssembly resource 名称]")
for m in re.finditer(rb"SmartAssembly\.[A-Za-z0-9]{4,30}", data):
    print(f"  0x{m.start():x}: {m.group().decode()}")

# 尝试 SmartAssembly 字符串解密
# SmartAssembly 加密字符串存储在 .resources 里，用 {z} 头
# 格式：2 字节 name length (7-bit encoded) + name + 4 字节 data length + data
# 每个字符串单独用 XOR 加密（32 位 key 分 4 通道）

# 找所有高熵块
def ent(b):
    from collections import Counter
    import math
    freq = Counter(b)
    e = 0
    for c in freq.values():
        p_ = c / len(b)
        e -= p_ * math.log2(p_)
    return e

# 找 {z} 头
print()
print("[{z} 压缩资源]")
for m in re.finditer(rb"\{z\}", data):
    print(f"  {{z}} @ 0x{m.start():x}")

# 找 "PADPADP" 填充（.NET 资源对齐）
pad = b"PADPADP"
for m in re.finditer(re.escape(pad), data):
    print(f"  PADPADP @ 0x{m.start():x}")
    # 打印附近数据
    ctx = data[m.start():m.start()+64]
    print(f"    {ctx.hex()}")
