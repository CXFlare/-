# -*- coding: utf-8 -*-
"""正确解析：0x42F4xx 是 hint/name 表，每个条目 = 2字节 hint + ASCII + 2~4字节对齐"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400), (0x9000, 0x213B0, 0x0), (0x2B000, 0x33D0, 0x8400), (0x2F000, 0xEA4, 0xB800), (0x30000, 0x1000, 0xCA00), (0x31000, 0x1200, 0xCC00)]
    for va_, vs, raw in secs:
        if va_ <= rva < va_ + max(vs, 1):
            return raw + (rva - va_)
    return None

# ===== 解析导入表（hint/name 项） =====
def parse_hint_table(va):
    """从 va 处读取 hint (2 bytes) + ASCII 名"""
    off = va2off(va)
    if off is None: return None
    # 跳过 hint
    end = data.find(b"\x00", off+2, off+200)
    if end < 0: return None
    try:
        return data[off+2:end].decode("ascii")
    except:
        return None

# 从 .idata 段导入表里解析每项对应的 hint/name VA
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = va2off(IMAGE_BASE + imp_rva)

# 每个 IAT 项 (VA) -> API 名
iat_to_name = {}
i = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = va2off(IMAGE_BASE + name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_rva = oft or ft
    thunk_off = va2off(IMAGE_BASE + thunk_rva)
    j = 0
    while True:
        t = thunk_off + j*4
        if t+4 > len(data): break
        v = struct.unpack("<I", data[t:t+4])[0]
        if v == 0: break
        iat_va = IMAGE_BASE + ft + j*4
        if v & 0x80000000:
            nm = f"#{v & 0x7FFFFFFF}"
        else:
            nm = parse_hint_table(IMAGE_BASE + v) or f"raw_0x{v:x}"
        iat_to_name[iat_va] = f"{dll}!{nm}"
        j += 1
    i += 1

print(f"IAT 项: {len(iat_to_name)}")
# 打印前 10 个
for va, n in list(iat_to_name.items())[:10]:
    print(f"  0x{va:x}  {n}")

# ===== 找 42Fxxx 表：实际是指向 43xxxx 的指针（IAT 值） =====
# 反汇编里 jmp dword [42Fxxx] 就是 IAT 的指针
# 42Fxxx 处的 4 字节 = IAT 表的 VA (0x43xxxx)
# 那 0x43xxxx 就是 IAT 表项，它的值 = API 函数地址

# 尝试：直接从 42Fxxx 读 4 字节 = IAT VA
# 检查 42F30C 处：之前 dump 出来是 e8 00 00 00 00 58 05 ... 是代码
# 所以 42Fxxx 处不是数据，反汇编器把 jmp 指令的目标解析错了

# 换个思路：IAT 表在 .l1 段（0x431000 到 0x431490）
# 反汇编里所有 call 0x408xxx 的 API wrapper，这些 wrapper 里是 jmp [42Fxxx]
# 42Fxxx 是 API 名字符串？不，反汇编说 jmp [42Fxxx] 是间接跳转

# **结论**：反汇编器把某些 42Fxxx 的地址当成了 IAT，但它们其实是代码。
# 所以自动识别失败。只能**直接按导入表顺序**假设每个 wrapper 对应一个 API。

# 观察：
# 0x408988 是第 1 个 wrapper
# 0x408994 是第 2 个
# ...每 12 字节一个
# 12 字节对应一条 6 字节指令（jmp dword [42Fxxx] + nop + nop）+ 6 字节填充
# 我们有 110 个 wrapper 和 113 个 API，非常接近

# 所以：wrapper_va = 0x408988 + 12 * i
# 对应 API = iat_to_name 里按顺序的第 i 个

# 按 iat_to_name 顺序取出（字典保序）

ordered_apis = list(iat_to_name.values())
print()
print(f"顺序 API: {len(ordered_apis)}")

wrapper_apis = {}
for i in range(len(ordered_apis)):
    wrapper_va = 0x408988 + 12 * i
    wrapper_apis[wrapper_va] = ordered_apis[i]

print()
print("=" * 70)
print("wrapper -> API 完整映射（修正版）")
print("=" * 70)
for w in sorted(wrapper_apis.keys()):
    print(f"  0x{w:x}  ->  {wrapper_apis[w]}")
