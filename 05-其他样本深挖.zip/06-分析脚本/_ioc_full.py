# -*- coding: utf-8 -*-
"""NJRAT 完整 IOC + 持久化 + 注入分析"""
import re, struct

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()
IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400), (0x9000, 0x213B0, 0x0), (0x2B000, 0x33D0, 0x8400), (0x2F000, 0xEA4, 0xB800), (0x30000, 0x1000, 0xCA00), (0x31000, 0x1200, 0xCC00)]
    for va_, vs, raw in secs:
        if va_ <= rva < va_ + max(vs, 1):
            return raw + (rva - va_)
    return None

print("=" * 70)
print("NJRAT IOC 完整清单")
print("=" * 70)

# 全部 C2 URL
urls = []
for va in range(0x42B094, 0x42B450, 4):
    off = va2off(va)
    if off is None: continue
    end = data.find(b"\x00", off)
    if end < 0 or end - off > 200: continue
    try:
        s = data[off:end].decode("ascii")
        if s.startswith("http://") or s.startswith("https://"):
            urls.append((va, s))
    except: pass

print(f"\n[1] C2 服务器列表 ({len(urls)} 个):")
for va, s in urls:
    print(f"  0x{va:x}  {s}")

# 持久化相关
print()
print("[2] 持久化位置:")
persist = [
    "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
    "Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce",
    "ShellServiceObjectDelayLoad",
    "Software\\Microsoft\\IE Setup\\Setup",
    "Internet Settings\\Zones",
    "Software\\Microsoft",
]
for p in persist:
    if p.replace("\\", "\").encode() in data:
        print(f"  {p.replace('\\\\', chr(92))}")

# 文件名 / 自启动
print()
print("[3] 落地文件名:")
landfiles = ["kk32.dll", "kk32.vxd", "dnkk.dll", "surf.dat", "cmd.pif", "command.pif",
             "cmd.exe", "command.com", "\Iexplore.exe", "Rtdx1", "\Rtdx1"]
for lf in landfiles:
    if lf.replace("\\", "\").encode() in data:
        print(f"  {lf.replace('\\\\', chr(92))}")

# 注册表互斥 / CLSID
print()
print("[4] 互斥/标识:")
mutexes = ["{79FEACFF-FFCE-815E-A900-316290B5B738}", "ofs_kk", "vvpupkin", "crutop",
           "KingKarton", "KingKarton_10", "blind_user", "X-okRecv11", "IEFrame",
           "MicroSoft-Corp", "Web Event Logger", "DocObject", "Explorer", "frm2"]
for m in mutexes:
    if m.encode() in data:
        print(f"  {m}")

# 银行/钓鱼 URL
print()
print("[5] 银行钓鱼 / 目标网站:")
banks = [".paypal.com", "signin.ebay.", ".yahoo.com", "webmail.juno.com",
         "my.juno.com", ".juno.com", ".earthlink.", "Sign in", "Log In",
         "Sign In", "Sign in", "ATM PIN", "CVV2", "Visa", "MasterCard"]
for b in banks:
    if b.encode() in data:
        print(f"  {b}")

# 关键行为函数
print()
print("[6] 关键行为函数地址:")
funcs_beh = {
    "初始化 + CoInitialize": "0x40129c",
    "主窗体 / 鼠标键盘钩子": "0x401bf5",
    "屏幕监控": "0x40544c",
    "网页注入": "0x404828",
    "持久化 / KingKarton_10": "0x407947",
    "银行钓鱼窗口": "0x407edc",
    "进程注入 (ntdll)": "0x402a82",
    "C2 通信": "0x4073f8",
    "Web 注入模板": "0x405a48",
}
for k, v in funcs_beh.items():
    print(f"  {v}  {k}")
