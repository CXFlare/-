# -*- coding: utf-8 -*-
"""发现：jmp table 里存的是 IAT 名称指针，不是 IAT 值。需要按索引对照。"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400, 0x7F6C), (0x9000, 0x213B0, 0x0, 0x0), (0x2B000, 0x33D0, 0x8400, 0x33D0), (0x2F000, 0xEA4, 0xB800, 0xEA4), (0x30000, 0x1000, 0xCA00, 0x200), (0x31000, 0x1200, 0xCC00, 0x1200)]
    for va_, vs, raw, rs in secs:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

# 反汇编里的 42Fxxx = 跳转表项，每项 4 字节，内容是指向 API 名字符串的指针
# 直接用这个指针读 API 名
jt_entries = {}
cur = None
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = int(m.group(2), 16)
        continue
    j = re.search(r"jmp dword \[(42F[0-9A-Fa-f]{3})h\]", line)
    if j and cur:
        jt_entries[int(j.group(1), 16)] = cur
        cur = None

print(f"跳转表项: {len(jt_entries)}")
# 读取每项指向的 API 名
wrapper_to_api = {}
for jtgt, wrapper in jt_entries.items():
    off = va2off(jtgt)
    if off is None: continue
    ptr = struct.unpack("<I", data[off:off+4])[0]
    # ptr 指向 hint/name 表项（2字节 hint + 字符串）
    name_off = va2off(ptr)
    if name_off is None: continue
    end = data.find(b"\x00", name_off + 2, name_off + 200)
    if end < 0: continue
    try:
        name = data[name_off+2:end].decode("ascii")
        wrapper_to_api[wrapper] = name
    except: pass

print(f"成功映射: {len(wrapper_to_api)}")
print()
print("=" * 70)
print("wrapper -> API（按 wrapper 排序）")
print("=" * 70)
for w in sorted(wrapper_to_api.keys()):
    print(f"  0x{w:x}  ->  {wrapper_to_api[w]}")
