# -*- coding: utf-8 -*-
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

# 找 sub_40129c（第二大函数，1679 条指令）
def extract_func(name_prefix, max_lines=250):
    out = []
    started = False
    for line in lines:
        if line.startswith(name_prefix):
            started = True
            out.append(line.rstrip())
            continue
        if started:
            if line.startswith("sub_"):
                break
            out.append(line.rstrip())
            if len(out) >= max_lines:
                break
    return out

print("=" * 70)
print("sub_40129c — 疑似主函数（1679 条指令）")
print("=" * 70)
for line in extract_func("sub_40129c @"):
    print(line)
