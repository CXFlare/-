# -*- coding: utf-8 -*-
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

def extract_func(name_prefix, max_lines=120):
    out = []
    started = False
    for line in lines:
        if line.startswith(name_prefix):
            started = True
            out.append(line.rstrip())
            continue
        if started:
            if line.startswith("sub_"):
                break
            out.append(line.rstrip())
            if len(out) >= max_lines:
                break
    return out

# 关键：找所有 call 目标，看哪些是导入表函数
calls = {}
for line in lines:
    m = re.search(r"call 0040([0-9A-Fa-f]+)h", line)
    if m:
        tgt = "0x40" + m.group(1).lower()
        calls[tgt] = calls.get(tgt, 0) + 1

print("=" * 60)
print("调用最多的函数 Top 20")
print("=" * 60)
for tgt, n in sorted(calls.items(), key=lambda x: -x[1])[:20]:
    print(f"  {tgt}: {n} 次")

print()
print("=" * 60)
print("sub_404828（第 3 大函数，793 条）")
print("=" * 60)
for line in extract_func("sub_404828 @"):
    print(line)

print()
print("=" * 60)
print("sub_407edc（第 5 大函数，592 条）")
print("=" * 60)
for line in extract_func("sub_407edc @"):
    print(line)
