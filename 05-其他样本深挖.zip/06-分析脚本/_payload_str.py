# -*- coding: utf-8 -*-
"""SmartAssembly payload - 关键字符串提取"""
import re, hashlib

p = r"C:\malware_work\AgentTesla\hidden_payload_full.exe"
with open(p, "rb") as f:
    data = f.read()

print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# SmartAssembly 混淆特征
print("[SmartAssembly 特征]")
for kw in [b"SmartAssembly", b"ConfusedByAttribute", b"<Module>",
           b"System.Runtime.CompilerServices", b"RuntimeHelpers",
           b"AssemblyRef", b"mscorlib", b"Microsoft.VisualBasic",
           b"AgentTesla", b"smtp", b"SmtpClient", b"MailMessage"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<40} x{c}")

print()
print("[全部字符串]")
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{6,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["smtp", "mail", "http", "ftp", "telegram",
                              "bot", "chat_id", "password", "browser",
                              "chrome", "firefox", "outlook", "keylog",
                              "clipboard", "screen", "stealer", "agent",
                              "tesla", "smartassembly", "log", "steam"]):
        if not any(x in tl for x in ["microsoft", "digicert", "schemas", "w3.org"]):
            print(f"  {t[:190]}")
