# -*- coding: utf-8 -*-
"""FormBook + LokiBot 快速分析"""
import re, hashlib

for name, path in [
    ("FormBook", r"C:\malware_work\FormBook\108156ae3609706003c6cefd6335c554_JaffaCakes118"),
    ("LokiBot", r"C:\malware_work\LokiBot\0f862236203591d35d2afb9c415ed02e_JaffaCakes118"),
]:
    print("=" * 70)
    print(name)
    print("=" * 70)
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}")
    print(f"MD5:    {hashlib.md5(data).hexdigest()}")
    print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
    
    # 特征扫描
    print("[特征]")
    for kw in [b".NET", b"mscorlib", b"Delphi", b"Borland", b"UPX", b"AutoIt",
               b"NSIS", b"http://", b"https://", b"System.", b"Microsoft.",
               b"keylog", b"stealer", b"formbook", b"lokibot", b"clipboard",
               b"smtp", b"telegram", b"ftp"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<20} x{c}")
    
    # 关键 URL/域名
    print("[关键 IOC]")
    seen = set()
    for m in re.finditer(rb"[\x20-\x7e]{6,150}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["http://", "https://", "smtp.", "ftp.", "telegram",
                                  "bot", "chat_id=", "password=", "apikey",
                                  "mozilla", "chrome", "firefox", "outlook",
                                  "keylog", "clipboard", "wallet.dat",
                                  ".php", ".onion"]):
            if 6 < len(t) < 200:
                print(f"  {t[:180]}")
    print()
