# -*- coding: utf-8 -*-
"""AgentTesla - 正确解析 .NET 资源并提取 ZH"""
import struct, re

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()

# 从 0x3ca4 正确解析 .NET Resources
start = 0x3ca4
assert data[start:start+4] == b"\xce\xca\xef\xbe", "magic mismatch"
pos = start + 4

# header version (4) + header size (4)
header_version = struct.unpack("<I", data[pos:pos+4])[0]
header_size = struct.unpack("<I", data[pos+4:pos+8])[0]
pos += 8
print(f"header_version={header_version}, header_size={header_size}")

# reader type string (header_size 字节)
reader_type_raw = data[pos:pos+header_size]
reader_type = reader_type_raw.split(b"#")[0].split(b"\x00")[0]
print(f"reader type: {reader_type[:80]}")
pos += header_size

# reader version string
reader_version = data[pos:pos+header_size]
reader_version_clean = reader_version.split(b"\x00")[0]
print(f"reader version: {reader_version_clean[:40]}")
pos += header_size

# 然后是 num_resources + num_types + num_data
# 等等，让我检查一下格式。实际上 .NET ResourceReader 的格式：
# - magic (4)
# - header version (4)  
# - header size (4) -- 但这是 reader type 的长度，实际上
# - reader type (header_size 字节)
# - reader version size (4) + reader version
# - num resources (4) + num types (4) + num data (4)
# - 类型表
# - 数据表
# - 数据本身

# 重新解析
pos = start + 4 + 4  # 跳过 magic + header_version
reader_type_len = struct.unpack("<I", data[pos:pos+4])[0]
pos += 4
reader_type_str = data[pos:pos+reader_type_len].rstrip(b"\x00")
print(f"reader_type_len={reader_type_len}")
print(f"reader_type: {reader_type_str[:60]}")
pos += reader_type_len

reader_version_len = struct.unpack("<I", data[pos:pos+4])[0]
pos += 4
reader_version_str = data[pos:pos+reader_version_len].rstrip(b"\x00")
print(f"reader_version_len={reader_version_len}")
print(f"reader_version: {reader_version_str[:60]}")
pos += reader_version_len

num_resources = struct.unpack("<I", data[pos:pos+4])[0]
num_types = struct.unpack("<I", data[pos+4:pos+8])[0]
num_data = struct.unpack("<I", data[pos+8:pos+12])[0]
print(f"\nnum_resources={num_resources}, num_types={num_types}, num_data={num_data}")
pos += 12

# 解析类型表
types = []
for i in range(num_types):
    type_len = struct.unpack("<I", data[pos:pos+4])[0]
    pos += 4
    type_name = data[pos:pos+type_len].decode("utf-16le", "replace")
    types.append(type_name)
    print(f"  Type {i}: {type_name}")
    pos += type_len
    # 对齐到 4 字节
    if pos % 4 != 0: pos += 4 - (pos % 4)
    num_set = struct.unpack("<I", data[pos:pos+4])[0]
    pos += 4
    print(f"    sets: {num_set}")
    for j in range(num_set):
        set_len = struct.unpack("<I", data[pos:pos+4])[0]
        pos += 4
        set_name = data[pos:pos+set_len].decode("utf-16le", "replace")
        print(f"    Set {j}: {set_name}")
        pos += set_len
        if pos % 4 != 0: pos += 4 - (pos % 4)
        data_offset = struct.unpack("<I", data[pos:pos+4])[0]
        pos += 4
        print(f"    data_offset: 0x{data_offset:x}")

# 现在 num_data 个数据项
# 每个数据项：4 字节 value offset
print(f"\nData table @ 0x{pos:x}")
data_offsets = []
for i in range(num_data):
    off = struct.unpack("<I", data[pos:pos+4])[0]
    data_offsets.append(off)
    pos += 4

# 找资源实际数据
# .NET 资源：每个资源有 name + value
# 查找 ZH 资源的字节
# 资源数据区从 data_start 开始
data_start = start + num_resources  # 这是一个启发式

# 更直接的方式：找内嵌 PE
# 我们的目标是找到加密后的 ZH 字节数组，然后用 XOR key 解密

# ZH 名字在 0x289f 附近，在 metadata 里
# 资源数据可能在 0x3ca4 + offset 处
# 让我直接扫描整个 PE 找 .NET 资源数据

# 从 0x3ca4 之后的 data 区域，找“ZH”名字的资源条目
# 资源数据通常是 UTF-16 名字 + 4 字节 value length + value bytes

# 尝试另一种方式：直接找按 XOR key 解密后是 MZ 头的 21 字节序列
# 实际上，我们从代码知道：ZH 资源包含加密字节数组，解密算法是：
# local12 = (((local8 ^ local11) - local10) + 256) & 255
# 其中 local11 是密钥字节循环，local10 是 payload 里的下一个字节

# 硬核方案：在 PE 里找 0x4D5A ("MZ") 出现的位置，找恰好 21 字节的段
# 但 payload 是加密的，不是 MZ

# 最靠谱：直接在 PAGO.exe 里找隐藏 payload
# 它应该是一段高熵的字节数组

# 找所有高熵区域
def entropy(b):
    from collections import Counter
    import math
    freq = Counter(b)
    e = 0
    for c in freq.values():
        p = c / len(b)
        e -= p * math.log2(p)
    return e

# 找 .resources 流之后
# .NET 嵌入资源通常有 4 字节大小 prefix + 数据
# 找位于 0x3ca4 到 0x14374 之间的高熵块
print("\n[扫描高熵区]")
offset = 0x3ca4 + 4000  # 跳过 metadata header
while offset < 0x14374:
    chunk = data[offset:offset+4096]
    e = entropy(chunk)
    if e > 7.5:
        print(f"  高熵块 @ 0x{offset:x} (entropy {e:.2f})")
    offset += 4096
