# -*- coding: utf-8 -*-
"""NJRAT 完整通信协议分析"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400), (0x9000, 0x213B0, 0x0), (0x2B000, 0x33D0, 0x8400), (0x2F000, 0xEA4, 0xB800), (0x30000, 0x1000, 0xCA00), (0x31000, 0x1200, 0xCC00)]
    for va_, vs, raw in secs:
        if va_ <= rva < va_ + max(vs, 1):
            return raw + (rva - va_)
    return None

# ===== 解析导入表 → IAT 顺序（113 个）=====
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = va2off(IMAGE_BASE + imp_rva)

def read_hint(va):
    off = va2off(va)
    if off is None: return None
    end = data.find(b"\x00", off+2, off+200)
    if end < 0: return None
    try: return data[off+2:end].decode("ascii")
    except: return None

ordered = []
i = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = va2off(IMAGE_BASE + name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_off = va2off(IMAGE_BASE + (oft or ft))
    j = 0
    while True:
        v = struct.unpack("<I", data[thunk_off+j*4:thunk_off+j*4+4])[0]
        if v == 0: break
        nm = read_hint(IMAGE_BASE + v) if not (v & 0x80000000) else f"#{v & 0x7FFFFFFF}"
        ordered.append(f"{dll}!{nm}")
        j += 1
    i += 1

wrapper_apis = {}
for idx in range(len(ordered)):
    wrapper_apis[0x408988 + 12*idx] = ordered[idx]
api_to_wrapper = {v: k for k, v in wrapper_apis.items()}

# ===== 找关键 API 的调用点 =====
target_apis = ["CreateProcessA", "WinExec", "RegSetValueExA", "RegCreateKeyExA",
               "CreateFileA", "WriteFile", "ReadFile", "LoadLibraryA", "GetProcAddress",
               "CreateMutexA", "OpenMutexA", "GetSystemDirectoryA", "GetTempPathA",
               "CreateThread", "Sleep", "GetTickCount", "TerminateProcess",
               "GetForegroundWindow", "GetWindowTextA", "FindWindowA", "GetClassNameA",
               "RegOpenKeyExA", "RegQueryValueExA", "CoCreateInstance"]

# 把 wrapper 地址转成从反汇编提取 call 目标的形式
tgt_wrappers = {}
for name in target_apis:
    if name in api_to_wrapper:
        tgt_wrappers[api_to_wrapper[name]] = name

print("=" * 70)
print("关键 API 调用点")
print("=" * 70)

# 遍历反汇编所有 call，找调用这些 wrapper 的地方
calls = {}  # caller_func -> [(line_no, called_va, api_name)]
cur = None
for i, line in enumerate(lines):
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = m.group(2)
        continue
    c = re.search(r"call 0040([0-9A-Fa-f]+)h", line)
    if c and cur:
        called = int("0x40" + c.group(1), 16)
        if called in tgt_wrappers:
            calls.setdefault(tgt_wrappers[called], []).append((i, cur, line.strip()))

for api in target_apis:
    if api in calls:
        cs = calls[api]
        print(f"\n### {api} ({len(cs)} 处调用) ###")
        for lineno, func, linetext in cs[:8]:
            print(f"  {linetext}   [in {func}]")

# ===== 找 NJRAT 的通信/命令协议 =====
print()
print("=" * 70)
print("字符串 - 命令名 / 协议关键字")
print("=" * 70)

# 遍历 .data 段所有字符串，找命令相关的
strings = []
for va in range(0x42B000, 0x42E400, 4):
    off = va2off(va)
    if off is None: continue
    end = data.find(b"\x00", off)
    if end < 0 or end - off > 100: continue
    try:
        s = data[off:end].decode("ascii")
        if all(32 <= ord(c) < 127 for c in s) and len(s) >= 4:
            strings.append((va, s))
    except: pass

# 找命令/协议相关
keywords_cmd = ["ll", "kl", "rn", "up", "pc", "cam", "th", "CAP", "rss", "pwd", "rn ", "cmd", "EXEC"]
seen = set()
for va, s in strings:
    if s in seen: continue
    seen.add(s)
    if any(k in s for k in ["ll", "kl", "cmd", "pass", "info", "scr", "cam", "mic", "chat"]):
        if len(s) < 60:
            print(f"  0x{va:x}  {repr(s)}")
