# -*- coding: utf-8 -*-
"""NJRAT 是 Native PE，但内嵌了 .NET 引用。看是不是混合程序集（Mixed Mode Assembly）"""
import struct

pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(pe, "rb") as f:
    data = f.read()

# 检查是否 Mixed Mode
# PE32 的 Load Config Directory 有 ILOnly 标记，COM descriptor 有 FLAGS
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
# 数据目录
dd_off = opt_off + (96 if magic == 0x10B else 112)

# 遍历 16 个数据目录
names = ["Export", "Import", "Resource", "Exception", "Certificate",
         "BaseReloc", "Debug", "Architecture", "GlobalPtr", "TLS",
         "LoadConfig", "BoundImport", "IAT", "DelayImport", "CLR", "Reserved"]
print("数据目录:")
for i, name in enumerate(names):
    rva = struct.unpack("<I", data[dd_off+i*8:dd_off+i*8+4])[0]
    sz = struct.unpack("<I", data[dd_off+i*8+4:dd_off+i*8+8])[0]
    if rva or sz:
        print(f"  [{i:2}] {name:<12} RVA=0x{rva:08X} size=0x{sz:X}")

# 看是否真的是 Mixed Mode：找 CLR 相关字符串
print()
print("[CLR 相关字符串出现次数]")
for kw in [b"mscoree", b"_CorExeMain", b"_CorDllMain", b"mscorlib", b"System.", b"Microsoft.VisualBasic"]:
    c = data.count(kw)
    print(f"  {kw.decode():<30} x{c}")

# 找所有 PE 节名字
print()
print("[PE 节表]")
nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
opt_size = struct.unpack("<H", data[pe_off+20:pe_off+22])[0]
sec_off = pe_off + 24 + opt_size
for i in range(nsec):
    s = sec_off + i*40
    name = data[s:s+8].rstrip(b"\x00").decode("ascii", "replace")
    vsize = struct.unpack("<I", data[s+8:s+12])[0]
    rsize = struct.unpack("<I", data[s+16:s+20])[0]
    chars = struct.unpack("<I", data[s+36:s+40])[0]
    print(f"  {name:<10} VS=0x{vsize:X} RS=0x{rsize:X} 特征=0x{chars:X}")
