# -*- coding: utf-8 -*-
"""Nanocore - 提取网络配置（Host/Port/加密）"""
import re

p = r"C:\malware_work\Nanocore\decompiled\DiscordNSR.native.cs"
with open(p, "r", encoding="utf-8", errors="replace") as f:
    content = f.read()
lines = content.split("\n")

# 找 AddHostEntry
print("[AddHostEntry 实现]")
for i, l in enumerate(lines):
    if "AddHostEntry" in l:
        start = max(0, i - 5)
        end = min(len(lines), i + 30)
        for j in range(start, end):
            print(f"  L{j+1}: {lines[j][:150]}")
        print()
        break

# 找所有 StringBuilder / 拼接字符串
print("[字符串拼接调用]")
for i, l in enumerate(lines):
    if ".Append(" in l or "Concat(" in l or "Format(" in l:
        print(f"  L{i+1}: {l.strip()[:150]}")

# 找所有 #= 开头的混淆标识符及其调用的位置
print()
print("[混淆标识符调用统计]")
obs = re.findall(r"#=q[0-9A-Za-z_=]+", content)
from collections import Counter
cnt = Counter(obs)
for name, c in cnt.most_common(20):
    print(f"  {name}: x{c}")
