# -*- coding: utf-8 -*-
"""修正：hint 表 2 字节 hint 后才是 ASCII 名，但可能需要检查不同情况"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400, 0x7F6C), (0x9000, 0x213B0, 0x0, 0x0), (0x2B000, 0x33D0, 0x8400, 0x33D0), (0x2F000, 0xEA4, 0xB800, 0xEA4), (0x30000, 0x1000, 0xCA00, 0x200), (0x31000, 0x1200, 0xCC00, 0x1200)]
    for va_, vs, raw, rs in secs:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

# 收集 jmp 表
jt_entries = {}
cur = None
for line in lines:
    m = re.match(r"^sub_([0-9a-f]+) @ (0x[0-9a-f]+)", line)
    if m:
        cur = int(m.group(2), 16)
        continue
    j = re.search(r"jmp dword \[(42F[0-9A-Fa-f]{3})h\]", line)
    if j and cur:
        jt_entries[int(j.group(1), 16)] = cur
        cur = None

# 第一个 jt 的原始字节和指针
print("前 5 个 jt 的 raw dump：")
for jtgt in sorted(jt_entries.keys())[:5]:
    off = va2off(jtgt)
    ptr = struct.unpack("<I", data[off:off+4])[0]
    # 看 ptr 指向的字节
    p_off = va2off(ptr)
    raw = data[p_off:p_off+32] if p_off else b""
    print(f"  jt_va=0x{jtgt:x} ptr=0x{ptr:x} p_off=0x{p_off if p_off else 0:x}  raw={raw.hex()}")

# 手动解析第一个
if jt_entries:
    jt0 = sorted(jt_entries.keys())[0]
    off = va2off(jt0)
    ptr = struct.unpack("<I", data[off:off+4])[0]
    p_off = va2off(ptr)
    print(f"\n第一个 jt 详细：")
    print(f"  ptr = 0x{ptr:x}")
    print(f"  ptr 处前 32 字节 = {data[p_off:p_off+32]}")
    print(f"  ptr 处按 hex = {data[p_off:p_off+32].hex()}")
    # hint 应该 2 字节，然后 ASCII
    print(f"  跳过 2 字节后 = {data[p_off+2:p_off+32]}")
