# -*- coding: utf-8 -*-
"""AgentTesla - 直接扫描并解密 ZH 资源"""
import struct, re
from collections import Counter
import math

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()

# XOR key（按反编译代码还原）
key = bytes([53, 52, 56, 66, 72, 69, 51, 53, 90, 56, 83, 72, 55, 56, 56, 56, 71, 83, 66, 89, 68, 57])
print(f"Key: {key}  长度: {len(key)}")

def decrypt(original):
    """按反编译算法解密"""
    n = len(original)
    result = bytearray(n)
    for i in range(n):
        # local8 = original[i]
        # local10 = original[(i+1) % n]
        # local11 = key[i % keylen]
        local8 = original[i]
        local10 = original[(i+1) % n]
        local11 = key[i % len(key)]
        v = ((local8 ^ local11) - local10 + 256) & 255
        result[i] = v
    return bytes(result)

# 直接扫描整个 PE 找能解出 MZ 头的位置
print("\n[扫描并解密候选]")
found = []
for start in range(0, len(data) - 64):
    # 取 64 字节
    chunk = data[start:start+64]
    if len(chunk) < 64: break
    dec = decrypt(chunk)
    if dec[:2] == b"MZ":
        # 进一步验证 PE
        try:
            pe_off = struct.unpack("<I", dec[0x3C:0x40])[0]
            if 0x40 <= pe_off <= 0x200:
                if dec[pe_off:pe_off+4] == b"PE\x00\x00":
                    found.append((start, pe_off))
                    print(f"  有效 PE @ 0x{start:x}  PE header offset=0x{pe_off:x}")
        except: pass

print(f"\n共找到 {len(found)} 个有效 PE 起点")

# 扫描几个关键的 .NET 资源位置
# 0x14374 是 .NET 资源 header 附近
if not found:
    print("\n[尝试其他策略：扫描更多候选]")
    for start in range(0x3ca4, 0x14374):
        chunk = data[start:start+64]
        if len(chunk) < 64: break
        dec = decrypt(chunk)
        if dec[:2] == b"MZ":
            print(f"  MZ @ 0x{start:x}")
            found.append((start, 0))
    
    # 尝试从 metadata 后的 data 区开始
    print("\n[尝试 .NET 资源数据区]")
    # 找位置 0x3ca4 之后的位置
    for start in range(0x3ca4, 0x3ca4 + 20000):
        # 假设数据从 start 开始，尝试各种长度
        for test_len in [0x1000, 0x2000, 0x4000, 0x8000, 0x10000, 0x20000, 0x40000]:
            chunk = data[start:start+test_len]
            if len(chunk) < test_len: break
            dec = decrypt(chunk)
            if dec[:2] == b"MZ":
                try:
                    pe_off = struct.unpack("<I", dec[0x3C:0x40])[0]
                    if 0x40 <= pe_off <= 0x200 and dec[pe_off:pe_off+4] == b"PE\x00\x00":
                        print(f"  PE @ 0x{start:x} len=0x{test_len:x}")
                        # 保存
                        with open(r"C:\malware_work\AgentTesla\hidden_payload.bin", "wb") as out:
                            out.write(dec)
                        found.append((start, test_len))
                        break
                except: pass
            if found: break
        if found: break
    if not found:
        print("  未找到")

# 如果没有找到 PE，尝试打印解密后的高熵数据
if not found:
    print("\n[打印从 0x3ca4+1000 处解密后的内容]")
    dec = decrypt(data[0x3ca4+1000:0x3ca4+1000+512])
    print(f"  前 64 字节: {dec[:64].hex()}")
    print(f"  可打印: {''.join(chr(b) if 32 <= b < 127 else '.' for b in dec[:100])}")
