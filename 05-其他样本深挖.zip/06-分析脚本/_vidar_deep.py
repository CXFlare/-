# -*- coding: utf-8 -*-
"""Vidar 内存 dump 深度分析"""
import hashlib, re

p = r"C:\malware_work\Vidar\f74356e6d895188cc5b28c98d9305844.bin"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
print()

# Vidar 关键特征
print("[Vidar 特征]")
for kw in [b"Vidar", b"vidar", b"stealer", b"wallet", b"metamask",
           b"exodus", b"jaxx", b"electrum", b"bitcoin", b"binance",
           b"telegram", b"discord", b"browser", b"chrome", b"firefox",
           b"password", b"cookie", b"clipboard", b"autofill",
           b"jabber", b"ftp", b"smtp", b"vpn", b"steam", b"filezilla"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

# 提取所有 URL（过滤证书）
print()
print("[URLs]")
seen = set()
for m in re.finditer(rb"https?://[\w\.\-:/?=&%_@#+~]{6,200}", data):
    u = m.group().decode("ascii", "replace")
    if u in seen: continue
    seen.add(u)
    if not any(x in u.lower() for x in ["microsoft", "digicert", "sectigo",
                                          "verisign", "usertrust", "comodo",
                                          "globalsign", "symantec", "schemas.",
                                          "w3.org", "adobe", "entrust",
                                          "thawte", "wosign"]):
        print(f"  {u[:180]}")

# 钱包路径
print()
print("[钱包路径]")
paths = [b"wallet.dat", b"Electrum", b"Exodus", b"MetaMask", b"Jaxx",
         b"Bitcoin", b"Ethereum", b"Zcash", b"Monero"]
for p_ in paths:
    c = data.count(p_)
    if c > 0:
        print(f"  {p_.decode()}: x{c}")

# TG bot 和 Discord
print()
print("[TG Token]")
for m in re.finditer(rb"\d{8,12}:[A-Za-z0-9_\-]{30,45}", data):
    print(f"  {m.group().decode()}")

print()
print("[Discord Webhook]")
for m in re.finditer(rb"https://discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+", data):
    print(f"  {m.group().decode()}")
