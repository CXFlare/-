# -*- coding: utf-8 -*-
"""embedded_1 深入分析 - 看是不是独立 payload"""
import struct, hashlib

with open(r"C:\malware_work\NJRAT\embedded_1.bin", "rb") as f:
    data = f.read()

print("=" * 70)
print("embedded_1 详细分析")
print("=" * 70)
print(f"大小: {len(data)} 字节")
print(f"MD5:    {hashlib.md5(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")

# PE 结构
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
machine = struct.unpack("<H", data[pe_off+4:pe_off+6])[0]
nsec = struct.unpack("<H", data[pe_off+6:pe_off+8])[0]
ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
print(f"PE 头: 0x{pe_off:x}, machine=0x{machine:x}, 节数={nsec}, 时间戳=0x{ts:x}")

# 导入表
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
print(f"导入表 RVA: 0x{imp_rva:x}")

# 找 DLL 名和 API
import re
# 直接找字符串
dlls = re.findall(rb"[A-Za-z0-9_]+\.DLL", data, re.IGNORECASE)
print(f"引用的 DLL: {set(d.decode('ascii','replace') for d in dlls)}")

# 关键 API
kws = [b"ExitProcess", b"WinExec", b"OpenMutexA", b"GetSystemDirectoryA", b"CreateFileA", b"CreateProcessA"]
for kw in kws:
    if kw in data:
        print(f"  含 API: {kw.decode()}")
