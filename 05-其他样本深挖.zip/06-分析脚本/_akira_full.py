# -*- coding: utf-8 -*-
"""Akira 勒索软件完整分析"""
import re, hashlib

p = r"C:\malware_work\Akira\9fd1338920e1e43932073399d021ef0cebfeb140100dd6f13b9143b37093131d.bin.sample"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}")
print(f"MD5: {hashlib.md5(data).hexdigest()}")
print(f"SHA256: {hashlib.sha256(data).hexdigest()}")
print(f"头部: {data[:32].hex()}")
print()

# Akira 勒索特征
print("[Akira 特征]")
for kw in [b"Akira", b"akira", b"akira_readme", b".akira", b"akiranew",
           b"readme.txt", b"RECOVER", b"decrypt", b"decryption",
           b"ChaCha", b"AES", b"RSA", b"Curve25519", b"salsa20",
           b"x25519", b"libsodium", b"encrypt", b"key"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

print()
print("[勒索信全文]")
# Akira 勒索信通常是 akira_readme.txt
for m in re.finditer(rb"akira_readme[^\x00]{0,200}", data):
    print(f"  {m.group()[:200]}")

# 找赎金信主体
print()
print("[完整赎金信内容（片段）]")
for m in re.finditer(rb"[\x20-\x7e\r\n\t]{100,5000}", data):
    t = m.group().decode("ascii", "replace")
    if "onion" in t.lower() and any(k in t for k in ["Akira", "chat", "blog", "TOR"]):
        print(t[:2000])
        print("---")
        break

# 找所有 .onion
print()
print("[所有 .onion 地址]")
onions = set(re.findall(rb"[a-z2-7]{16,56}\.onion", data))
for o in sorted(onions):
    print(f"  {o.decode()}")

# 加密货币
print()
print("[BTC 钱包]")
btc = set(re.findall(rb"\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b", data))
for b in sorted(btc):
    print(f"  {b.decode()}")

print()
print("[XMR 钱包]")
xmr = set(re.findall(rb"\b4[0-9AB][1-9A-HJ-NP-Za-km-z]{93}\b", data))
for x in sorted(xmr):
    print(f"  {x.decode()}")
