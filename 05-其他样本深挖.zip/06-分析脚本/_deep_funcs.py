# -*- coding: utf-8 -*-
"""NJRAT 深度分析 - 关键函数反汇编快照"""
import re

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()

def extract_func(addr, max_lines=200):
    out = []
    started = False
    for line in lines:
        if line.startswith(f"sub_{addr[2:].lower()} @"):
            started = True
            out.append(line.rstrip())
            continue
        if started:
            if line.startswith("sub_"):
                break
            out.append(line.rstrip())
            if len(out) >= max_lines:
                break
    return out

# 分析函数 0x402a82（进程注入）
print("=" * 70)
print("sub_402a82 — 进程注入（引用 ntdll）")
print("=" * 70)
for line in extract_func("0x402a82"):
    print(line)

print()
print("=" * 70)
print("sub_407947 — 持久化（KingKarton_10 + RegisterServiceProcess）")
print("=" * 70)
for line in extract_func("0x407947", 150):
    print(line)
