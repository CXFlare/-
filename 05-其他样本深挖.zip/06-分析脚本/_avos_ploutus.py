# -*- coding: utf-8 -*-
"""AvosLocker + Ploutus 深度分析"""
import re, hashlib, os

# AvosLocker - .NET
print("=" * 70)
print("AvosLocker 深度分析")
print("=" * 70)
p = r"C:\malware_work\Metasploit\2024-05-03_6d67a3bdd5317d782d550ce7bc4fef46_avoslocker"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")

# 找 .NET 命名空间
ns = set(re.findall(rb"[A-Z][a-zA-Z0-9.]+\.[A-Z][a-zA-Z0-9.]+(?=\x00)", data))
print("[.NET 命名空间 / 关键字符串]")
seen = set()
for s in ns:
    try:
        t = s.decode("ascii")
        if t in seen: continue
        seen.add(t)
        if len(t) < 80 and any(k in t for k in ["Avos", "Locker", "Ransom", "Encrypt", "Crypt",
                                                  "System.IO", "System.Security", "System.Net"]):
            print(f"  {t}")
    except: pass

# AvosLocker 特征
print()
print("[AvosLocker 特征字符串]")
for kw in [b"Avos", b"AvosLocker", b"RECOVER", b"recover", b"Readme", b"README",
           b"Decrypt", b"decrypt", b"AES", b"RSA", b"ChaCha", b"wallet",
           b"Monero", b"Bitcoin", b"onion", b"tor", b".avos", b".avos2"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

# 找扩展名
print()
print("[可能的加密扩展名]")
exts = set(re.findall(rb"\.[a-z]{3,6}(?=\x00)", data))
exts_filtered = [e.decode() for e in exts if any(x in e.lower() for x in [b"avos", b"lock", b"enc", b"crypt", b"ransom"])]
for e in exts_filtered:
    print(f"  {e}")

# Ploutus
print()
print("=" * 70)
print("Ploutus (ATM 恶意软件)")
print("=" * 70)
p = r"C:\malware_work\Ploutus\Tis_Park_Server.exe"
with open(p, "rb") as f:
    data = f.read()
print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")

# Ploutus 特征
print("[Ploutus 特征]")
for kw in [b"Ploutus", b"ATM", b"XFS", b"dispenser", b"cash", b"card",
           b"PIN", b"Withdraw", b"KAL", b"Diebold", b"NCR", b"Wincor",
           b".NET", b"mscorlib", b"Test", b"Admin", b"Config"]:
    c = data.count(kw)
    if c > 0:
        print(f"  {kw.decode('ascii','replace'):<20} x{c}")

# 找 C2
print()
print("[Ploutus URLs/IOCs]")
seen = set()
for m in re.finditer(rb"[\x20-\x7e]{8,200}", data):
    t = m.group().decode("ascii", "replace")
    if t in seen: continue
    seen.add(t)
    tl = t.lower()
    if any(k in tl for k in ["http://", "https://", "ploutus", "atm", "dispenser",
                              "xfs", "kal", "diebold", "ncr", "wincor"]):
        if 8 < len(t) < 200:
            print(f"  {t[:180]}")
