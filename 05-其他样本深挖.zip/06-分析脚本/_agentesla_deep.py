# -*- coding: utf-8 -*-
"""AgentTesla - 深入 0x3d6e 处的 MZ"""
import struct

p = r"C:\malware_work\AgentTesla\extracted\PAGO.exe"
with open(p, "rb") as f:
    data = f.read()

key = bytes([53, 52, 56, 66, 72, 69, 51, 53, 90, 56, 83, 72, 55, 56, 56, 56, 71, 83, 66, 89, 68, 57])

def decrypt(original):
    n = len(original)
    if n < 2: return bytes(n)
    result = bytearray(n)
    for i in range(n):
        local8 = original[i]
        local10 = original[(i+1) % n]
        local11 = key[i % len(key)]
        result[i] = ((local8 ^ local11) - local10 + 256) & 255
    return bytes(result)

# 重要：解密是循环的，需要知道原始数组边界
# 反编译代码说：local1 是原始数组，local6 = local1.ToArray()
# 循环 i 从 0 到 n-1，local11 = local2[local3 % local2.Count]，
# 而 local2 是解密后的结果（初始为空？）
# 
# 重新读代码：
#   local1 = (byte[])local0.GetObject("ZH");   <- 原始数组
#   local2 = new List<byte>();  <- 结果容器
#   local3 = 0;
#   local6 = local1.ToArray();
#   local7 = 0;
#   while (local7 < local6.Length) {
#       local8 = local6[local7];
#       local9 = (local3 + 1) % local1.Length;
#       local10 = local1[local9];
#       local11 = local2[local3 % local2.Count];
#       local12 = ((local8 ^ local11) - local10 + 256) & 255;
#       local1[local3] = local12;
#       local3++;
#       local7++;
#   }
#
# 问题：local2 是空的，local2[local3 % local2.Count] 会崩
# 所以反编译代码有问题 —— disrobe 可能没还原完整
# 
# 可能真实的算法是：
#   local2 包含了密钥字节序列（从 .cctor 或硬编码）
#   或者 local2 就是那个 22 字节 key

# 重新看：
# new List<byte>().Add(53);  (多行)
# 这实际上构建了一个包含 22 个字节的列表
# 那个列表在反编译里赋给了 local2? 但 local2 是 new List<byte>()
# 
# 更可能的真实代码：
# local2 = new List<byte> { 53, 52, 56, 66, 72, 69, 51, 53, 90, 56, 83, 72, 55, 56, 56, 56, 71, 83, 66, 89, 68, 57 };
# local1 = (byte[])local0.GetObject("ZH");
#
# 但循环里的逻辑仍是：先取 local2 的字节作为 key

# 我之前的解密算法就是这个逻辑，但可能 key 是 local2 的内容
# 而 local10 = local1[(local3+1) % n] 是原数组的下一个字节（之前已被替换）

# 尝试：不修改原数组，而是直接用两个不同的变量
def decrypt_v2(original, key):
    n = len(original)
    if n < 2: return b""
    out = bytearray(n)
    orig_copy = bytes(original)
    for i in range(n):
        local8 = orig_copy[i]
        local10 = orig_copy[(i+1) % n]
        local11 = key[i % len(key)]
        out[i] = ((local8 ^ local11) - local10 + 256) & 255
    return bytes(out)

# 找到 0x3d6e - 但这是文件位置还是资源内偏移？
# 之前脚本里 start 是文件位置
# 0x3d6e 是文件的 0x3d6e 位置
start = 0x3d6e
chunk = data[start:start+4096]
dec = decrypt_v2(chunk, key)
print(f"位置 0x{start:x} 处解密后前 32 字节: {dec[:32].hex()}")
print(f"是不是 MZ: {dec[:2]}")

# 尝试解密更大范围
for length in [0x1000, 0x2000, 0x4000, 0x8000, 0x10000, 0x20000, 0x40000, 0x80000, 0x100000]:
    chunk = data[start:start+length]
    dec = decrypt_v2(chunk, key)
    if dec[:2] == b"MZ":
        pe_off = struct.unpack("<I", dec[0x3C:0x40])[0] if len(dec) > 0x40 else 0
        if 0x40 <= pe_off <= 0x200 and len(dec) > pe_off + 4 and dec[pe_off:pe_off+4] == b"PE\x00\x00":
            print(f"  ✅ 有效 PE! length={length} (0x{length:x})")
            machine = struct.unpack("<H", dec[pe_off+4:pe_off+6])[0]
            nsec = struct.unpack("<H", dec[pe_off+6:pe_off+8])[0]
            ts = struct.unpack("<I", dec[pe_off+8:pe_off+12])[0]
            print(f"     machine=0x{machine:04x} 节数={nsec} 时间戳=0x{ts:08x}")
            # 保存
            out_path = rf"C:\malware_work\AgentTesla\hidden_payload_{length}.bin"
            with open(out_path, "wb") as f:
                f.write(dec)
            print(f"     已保存: {out_path}")
            
            # 看内部字符串
            import re as _re
            print(f"     [内嵌字符串]")
            seen = set()
            for m in _re.finditer(rb"[\x20-\x7e]{8,150}", dec[:min(200000, len(dec))]):
                t = m.group().decode("ascii", "replace")
                if t in seen: continue
                seen.add(t)
                tl = t.lower()
                if any(k in tl for k in ["smtp", "telegram", "http", "ftp", "bot",
                                          "password", "chrome", "firefox", "outlook",
                                          "keylog", "agent", "tesla", "stealer"]):
                    print(f"       {t[:150]}")
                    if len(seen) > 30: break
            break
