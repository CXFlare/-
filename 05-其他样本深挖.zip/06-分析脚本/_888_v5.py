# -*- coding: utf-8 -*-
"""888RAT EA06 深度解密 - 基于 myAut2Exe 算法
   
AutoIt EA06 结构（参考 https://github.com/ik0z/myAut2Exe）：
- AU3!EA06 标记后跟加密数据
- 加密算法：XOR + LZMA
- key 从 PE 特征推导

关键结构：
  0x00: "AU3!EA06M"
  0x08: 4 bytes 魔数（XOR key 种子）
  0x0C: 4 bytes 未压缩大小（加密）
  0x10: LZMA 加密数据
  
解密流程：
1. 从文件特征生成 key
2. XOR 解密 LZMA 头
3. 解压 LZMA
"""
import struct, hashlib, lzma, re

pe = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(pe, "rb") as f:
    data = f.read()

print(f"文件大小: {len(data)}")
marker = data.find(b"AU3!EA06M")
m2 = data.find(b"AU3!EA06P")
print(f"EA06M @ 0x{marker:x}")
print(f"EA06P @ 0x{m2:x}")
print()

# EA06M 后 4 字节
key_seed = struct.unpack("<I", data[marker+8:marker+12])[0]
print(f"Key seed: 0x{key_seed:08x}")

# 尝试各种 key 推导
# 1. key seed 本身
# 2. key seed 与 PE 时间戳异或
# 3. key seed 与文件大小异或
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
pe_ts = struct.unpack("<I", data[pe_off+8:pe_off+12])[0]
print(f"PE 时间戳: 0x{pe_ts:08x}")
print()

# 尝试每个候选 key 去 XOR EA06M 之后的数据，然后尝试 LZMA 解压
candidates = [
    key_seed,
    key_seed ^ pe_ts,
    key_seed ^ (len(data) & 0xFFFFFFFF),
    pe_ts,
    (key_seed + pe_ts) & 0xFFFFFFFF,
    (key_seed - pe_ts) & 0xFFFFFFFF,
]

# EA06M 后的数据（跳过 8 字节标记）
enc_start = marker + 8
enc_data = data[enc_start:enc_start+10_000_000]

# 尝试多个偏移（EA06 头可能有多字节）
for cidx, key in enumerate(candidates):
    print(f"[候选 {cidx}] key=0x{key:08x}")
    
    # XOR key 的 4 字节循环模式
    key_bytes = struct.pack("<I", key)
    
    # 尝试各种偏移
    for offset in range(0, 32):
        chunk = enc_data[offset:offset+1_000_000]
        # XOR 解密
        dec = bytes(b ^ key_bytes[i % 4] for i, b in enumerate(chunk))
        
        # 检查是不是 LZMA 头
        if dec[:3] == b"\x5D\x00\x00":
            print(f"  LZMA 头 @ offset={offset}")
            try:
                result = lzma.decompress(dec[:500_000])
                print(f"  解压成功: {len(result)} 字节")
                out = r"C:\malware_work\888RAT\decrypted.au3"
                with open(out, "wb") as f:
                    f.write(result)
                print(f"  已保存: {out}")
                break
            except Exception as e:
                print(f"  解压失败: {e}")
        
        # 检查是不是脚本内容
        if b"#include" in dec[:3000] or b"Func " in dec[:3000] or b"#NoTrayIcon" in dec[:3000]:
            print(f"  脚本片段 @ offset={offset}")
            print(f"  前 200 字符: {dec[:200]}")
            break

print()
print("[EA06M 后的原始数据前 64 字节]")
print(enc_data[:64].hex())

# 也尝试直接从 EA06M 后的第 16 字节起解压（假定头是 16 字节）
print()
print("[尝试从 EA06M + 16 处直接解 LZMA]")
for offset in [16, 20, 24]:
    chunk = enc_data[offset:offset+2_000_000]
    for ds in [0x100000, 0x400000, 0x1000000, 0x4000000, 0x10000000]:
        filters = [{"id": lzma.FILTER_LZMA1, "dict_size": ds, "lc": 3, "lp": 0, "pb": 2}]
        try:
            decomp = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=filters)
            result = decomp.decompress(chunk[:500_000])
            if len(result) > 1000:
                print(f"  offset={offset} ds=0x{ds:x}: {len(result)} 字节")
                print(f"  前 200: {result[:200]}")
                break
        except: pass
