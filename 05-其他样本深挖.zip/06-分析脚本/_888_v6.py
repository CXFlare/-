# -*- coding: utf-8 -*-
"""888RAT EA06 解密 - 深度尝试多种算法"""
import struct, lzma, zlib

p = r"C:\malware_work\888RAT\888RAT 1.1.1 cracked.exe"
with open(p, "rb") as f:
    data = f.read()

marker = data.find(b"AU3!EA06M")
# 从 marker 后 4 字节开始加密数据
enc_start = marker + 8  # 跳过 "AU3!EA06M"
enc_data = data[enc_start:enc_start+40_000_000]  # 4MB 加密数据

print(f"EA06M @ 0x{marker:x}  加密数据长度: {len(enc_data)}")
print(f"前 32 字节: {enc_data[:32].hex()}")
print()

# 尝试多种方式：EA06 头 8 字节后是 LZMA，但可能被自定义 XOR
# 已知 key seed = 0x73ffa84d

# 方式1：直接 lzma 解压
try:
    r = lzma.decompress(enc_data[:5_000_000])
    print("[1] 直接 LZMA 成功:", len(r))
except Exception as e:
    print("[1] 直接 LZMA 失败:", str(e)[:80])

# 方式2：跳过头部后解压
for skip in [8, 12, 16, 24, 32, 64, 128, 256]:
    try:
        r = lzma.decompress(enc_data[skip:skip+5_000_000])
        print(f"[2] 跳过 {skip} 字节 LZMA 成功: {len(r)}")
        print(f"    前 200: {r[:200]}")
        with open(r"C:\malware_work\888RAT\decrypted.au3", "wb") as f:
            f.write(r)
        break
    except: pass

# 方式3：XOR + LZMA
key_bytes = struct.pack("<I", 0x73ffa84d)
for xor_off in range(0, 64):
    chunk = enc_data[xor_off:xor_off+5_000_000]
    dec = bytes(b ^ key_bytes[i % 4] for i, b in enumerate(chunk))
    if dec[:3] == b"\x5D\x00\x00" or dec[:2] == b"\x78\x9C":
        print(f"[3] XOR @ offset {xor_off} 得到 LZMA/zlib 头")
        for algo_name, algo in [("lzma", lzma.decompress), ("zlib", zlib.decompress)]:
            try:
                r = algo(dec)
                print(f"    {algo_name} 成功: {len(r)}")
                break
            except: pass

# 方式4：从 PE 末尾倒推
print()
print("[4] 扫描 LZMA 头 (5D 00 00 任意字典大小)]")
found = 0
for m in __import__("re").finditer(rb"\x5D\x00\x00", enc_data[:5_000_000]):
    pos = m.start()
    if pos + 13 > len(enc_data): break
    dict_size = struct.unpack("<I", enc_data[pos+1:pos+5])[0]
    if 0x1000 <= dict_size <= 0x40000000:
        print(f"  LZMA 候选 @ 0x{pos:x} dict_size=0x{dict_size:x}")
        # 尝试解压
        for lc in [3]:
            for lp in [0]:
                for pb in [2]:
                    try:
                        filters = [{"id": lzma.FILTER_LZMA1, "dict_size": dict_size, "lc": lc, "lp": lp, "pb": pb}]
                        decomp = lzma.LZMADecompressor(format=lzma.FORMAT_ALONE)
                        r = decomp.decompress(enc_data[pos:pos+5_000_000])
                        if len(r) > 100:
                            print(f"    解压成功: {len(r)} 字节")
                            with open(r"C:\malware_work\888RAT\decrypted.au3", "wb") as f:
                                f.write(r)
                            found = 1
                            break
                    except Exception as e:
                        pass
                if found: break
            if found: break
        if found: break
        if found >= 5: break

if not found:
    print("  未找到标准 LZMA 头")
    # 打印前几个字节看看
    print("  加密数据前 16 字节:", enc_data[:16].hex())
