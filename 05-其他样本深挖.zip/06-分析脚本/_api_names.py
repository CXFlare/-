# -*- coding: utf-8 -*-
"""修正：42Fxxx 是执行代码不是数据，真实 IAT 位于 0x4312B0 开始"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"
with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000
def va2off(va):
    rva = va - IMAGE_BASE
    secs = [(0x1000, 0x7F6C, 0x400, 0x7F6C), (0x9000, 0x213B0, 0x0, 0x0), (0x2B000, 0x33D0, 0x8400, 0x33D0), (0x2F000, 0xEA4, 0xB800, 0xEA4), (0x30000, 0x1000, 0xCA00, 0x200), (0x31000, 0x1200, 0xCC00, 0x1200)]
    for va_, vs, raw, rs in secs:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

# 导入描述符（IAT 表实际从 0x4312B0 开始，按解析结果）
pe_off = struct.unpack("<I", data[0x3C:0x40])[0]
opt_off = pe_off + 24
magic = struct.unpack("<H", data[opt_off:opt_off+2])[0]
dd_off = opt_off + (96 if magic == 0x10B else 112)
imp_rva = struct.unpack("<I", data[dd_off+1*8:dd_off+1*8+4])[0]
imp_off = va2off(IMAGE_BASE + imp_rva)

# 解析导入表，只取 IAT VA
iat_va_to_name = {}
i = 0
while True:
    d = imp_off + i*20
    oft = struct.unpack("<I", data[d:d+4])[0]
    name_rva = struct.unpack("<I", data[d+12:d+16])[0]
    ft = struct.unpack("<I", data[d+16:d+20])[0]
    if oft == 0 and ft == 0 and name_rva == 0: break
    dll_off = va2off(IMAGE_BASE + name_rva)
    e = data.find(b"\x00", dll_off)
    dll = data[dll_off:e].decode("ascii", "replace")
    thunk_rva = oft or ft
    thunk_off = va2off(IMAGE_BASE + thunk_rva)
    j = 0
    while True:
        t = thunk_off + j*4
        if t+4 > len(data): break
        v = struct.unpack("<I", data[t:t+4])[0]
        if v == 0: break
        iat_va = IMAGE_BASE + ft + j*4
        if v & 0x80000000:
            name = f"#{v & 0x7FFFFFFF}"
        else:
            h = va2off(IMAGE_BASE + v)
            if h:
                end = data.find(b"\x00", h+2, h+200)
                name = data[h+2:end].decode("ascii", "replace")
        iat_va_to_name[iat_va] = f"{dll}!{name}"
        j += 1
    i += 1

# 42Fxxx 里的值指向 0x43xxxx，那就是 IAT 表
# 42Fxxx 是经过 obfuscation 的转发表：每条 jmp + call + ret 的混淆链
# 等等 —— 42F30C 处的字节是 e8 00 00 00 00 58 05... 这是 call $+5; pop eax; add eax, xxx
# 这是 **PIC 位置无关代码**计算字符串地址的方式，不是 IAT 表

# 我搞错了。42Fxxx 段其实是 **代码**（被 obfuscate 的 wrapper）
# 真正的 IAT 在 0x4312B0-0x431490 那段，用 jmp dword [...] 里引用的 42Fxxx 是错的 —— 反汇编器识别错了？

# 让我换一种思路：直接从反汇编的 API 字符串调用（比如 push "InternetOpen"）开始
# 找每个 API 名字对应的 wrapper
# API 名字在 .l1 段后面（0x42F5xx 附近）

# 打印所有 42F5xx 及以后的字符串
print("=== .idata 段中 0x42F5xx 之后的内容（API 名字） ===")
for va in range(0x42F500, 0x42FE00, 4):
    off = va2off(va)
    if off is None: continue
    b = data[off:off+4]
    if len(b) < 4: continue
    # 简单打印
    try:
        s = b.rstrip(b"\x00").decode("ascii")
        if all(32 <= ord(c) < 127 for c in s) and len(s) >= 3:
            print(f"  0x{va:x}: {repr(s)}")
    except: pass
