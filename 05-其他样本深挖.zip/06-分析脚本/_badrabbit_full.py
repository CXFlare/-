# -*- coding: utf-8 -*-
"""BadRabbit + BlackMoon + BlackGuard 深挖"""
import re, hashlib, os

samples = [
    ("BadRabbit", r"C:\malware_work\BadRabbit\BadRabbit.exe"),
    ("BlackMoon", r"C:\malware_work\BlackMoon\2024-05-03_eebffcc6416914b2b3c31f935bd802ca_icedid_xiaobaminer"),
    ("FakeAV", r"C:\malware_work\FakeAV\90307e8421fc5314379ba87f56a11034_NeikiAnalytics.exe"),
]

for name, path in samples:
    print("=" * 70)
    print(name)
    print("=" * 70)
    if not os.path.exists(path):
        print("[!] 不存在")
        continue
    with open(path, "rb") as f:
        data = f.read()
    print(f"大小: {len(data)}  MD5: {hashlib.md5(data).hexdigest()}")
    
    # BadRabbit 特征
    print("[特征]")
    for kw in [b"BadRabbit", b"diskpart", b"vssadmin", b"wevtutil", b"schtasks",
               b"RunOnce", b"\.\pipe", b"\\.\pipe", b"mimikatz", b"Tor",
               b"onion", b"cafebabe", b"diactor", b"9DPH", b"IcedID",
               b"XiaoBa", b"clipboard", b"Firefox"]:
        c = data.count(kw)
        if c > 0:
            print(f"  {kw.decode('ascii','replace'):<20} x{c}")
    
    # 关键字符串
    print("[关键字符串]")
    seen = set()
    cnt = 0
    for m in re.finditer(rb"[\x20-\x7e]{10,200}", data):
        t = m.group().decode("ascii", "replace")
        if t in seen: continue
        seen.add(t)
        tl = t.lower()
        if any(k in tl for k in ["badrabbit", "diskpart", "vssadmin", "wevtutil",
                                  "schtasks", "onion", "bitcoin", "decrypt",
                                  "encrypt", "readme", "install.bat",
                                  "1dptfhs", "cafebabe"]):
            if 10 < len(t) < 200:
                print(f"  {t[:180]}")
                cnt += 1
                if cnt >= 12: break
    print()
