# -*- coding: utf-8 -*-
"""关键：IAT 表在 .l1 段而不是 .idata，重新映射"""
import re, struct

asm = r"C:\malware_work\NJRAT\njrat_decrypted.asm"
pe = r"C:\malware_work\NJRAT\njrat_decrypted.exe"

with open(asm, "r", encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
with open(pe, "rb") as f:
    data = f.read()

IMAGE_BASE = 0x400000

# 关键：导入表描述符在 .l1 段（RVA 0x31000）
# IAT 也是从 0x31000 开始（RVA），VA = 0x431000
# 而反汇编里 jmp dword [42F4DCh] 里的 42F4DC 是 **VA**，不是 RVA！
# 42F4DC - 0x400000 = 0x2F4DC => 在 .idata 段
# 但是导入表的 first_thunk 是 0x31000 (RVA) => 0x431000 (VA)
# 所以反汇编里 42F4DC 不是 IAT 表，而是**另一个**数据段

# 看 0x42F4DC 在 .idata 段，里面存的内容是什么
def va2off(va):
    rva = va - IMAGE_BASE
    sections = [
        (".text",  0x1000, 0x7F6C, 0x400, 0x7F6C),
        (".data",  0x2B000, 0x33D0, 0x8400, 0x33D0),
        (".idata", 0x2F000, 0xEA4, 0xB800, 0xEA4),
        (".fldo",  0x30000, 0x1000, 0xCA00, 0x200),
        (".l1",    0x31000, 0x1200, 0xCC00, 0x1200),
    ]
    for _, va_, vs, raw, rs in sections:
        if va_ <= rva < va_ + max(vs, rs):
            return raw + (rva - va_)
    return None

for va in [0x42F4DC, 0x42F4F0, 0x42F4E4, 0x42F454, 0x42F3E0, 0x42F3AC, 0x42F3B0]:
    off = va2off(va)
    if off:
        bytes_ = data[off:off+8]
        val = struct.unpack("<I", bytes_[:4])[0]
        print(f"  VA=0x{va:x}  off=0x{off:x}  bytes={bytes_.hex()}  ptr={hex(val)}")
    else:
        print(f"  VA=0x{va:x}  无映射")

print()
print("IAT 描述符（first_thunk）应该在 0x31000（RVA）")
print(f"  0x431000 的文件偏移 = 0x{va2off(0x431000):X}")
print(f"  0x42F000 的文件偏移 = 0x{va2off(0x42F000):X}")

# 看 0x431000 附近的数据
off = va2off(0x431000)
print(f"\n0x431000 附近前 64 字节: {data[off:off+64].hex()}")
