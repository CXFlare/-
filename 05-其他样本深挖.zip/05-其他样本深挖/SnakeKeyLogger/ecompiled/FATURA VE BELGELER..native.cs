// native disrobe CIL->C# decompilation (no runtime, no external tool)
// module: HJbl.exe

// DVLD_Buisness.clsApplication
public void set_ApplicationID(int value)
{
    this.ApplicationID = value;
    return;
}
// DVLD_Buisness.clsApplication
public int get_ApplicationID()
{
    return this.ApplicationID;
}
// DVLD_Buisness.clsApplication
public void set_ApplicantPersonID(int value)
{
    this.ApplicantPersonID = value;
    return;
}
// DVLD_Buisness.clsApplication
public int get_ApplicantPersonID()
{
    return this.ApplicantPersonID;
}
// DVLD_Buisness.clsApplication
public string get_ApplicantFullName()
{
    string local0;

    local0 = DVLD_Buisness.clsPerson.Find(this.ApplicantPersonID).FullName;
    return local0;
}
// DVLD_Buisness.clsApplication
public void set_ApplicationDate(System.DateTime value)
{
    this.ApplicationDate = value;
    return;
}
// DVLD_Buisness.clsApplication
public System.DateTime get_ApplicationDate()
{
    return this.ApplicationDate;
}
// DVLD_Buisness.clsApplication
public void set_ApplicationTypeID(int value)
{
    this.ApplicationTypeID = value;
    return;
}
// DVLD_Buisness.clsApplication
public int get_ApplicationTypeID()
{
    return this.ApplicationTypeID;
}
// DVLD_Buisness.clsApplication
public void set_ApplicationStatus(enApplicationStatus value)
{
    this.ApplicationStatus = value;
    return;
}
// DVLD_Buisness.clsApplication
public enApplicationStatus get_ApplicationStatus()
{
    return this.ApplicationStatus;
}
// DVLD_Buisness.clsApplication
public string get_StatusText()
{
    enApplicationStatus local0;
    enApplicationStatus local1;
    string local2;

    local1 = this.ApplicationStatus;
    local0 = local1;
    switch (local0 - 1)
    {
        case 0:
            local2 = "New";
            break;
        case 1:
            local2 = "Cancelled";
            break;
        case 2:
            local2 = "Completed";
            break;
        default:
            local2 = "Unknown";
            break;
    }
    return local2;
}
// DVLD_Buisness.clsApplication
public void set_LastStatusDate(System.DateTime value)
{
    this.LastStatusDate = value;
    return;
}
// DVLD_Buisness.clsApplication
public System.DateTime get_LastStatusDate()
{
    return this.LastStatusDate;
}
// DVLD_Buisness.clsApplication
public void set_PaidFees(float value)
{
    this.PaidFees = value;
    return;
}
// DVLD_Buisness.clsApplication
public float get_PaidFees()
{
    return this.PaidFees;
}
// DVLD_Buisness.clsApplication
public void set_CreatedByUserID(int value)
{
    this.CreatedByUserID = value;
    return;
}
// DVLD_Buisness.clsApplication
public int get_CreatedByUserID()
{
    return this.CreatedByUserID;
}
// DVLD_Buisness.clsApplication
public void .ctor()
{
    this.Mode = 0;
    this.ApplicationID = -1;
    this.ApplicantPersonID = -1;
    this.ApplicationDate = Now;
    this.ApplicationTypeID = -1;
    this.ApplicationStatus = (enApplicationStatus)1;
    this.LastStatusDate = Now;
    this.PaidFees = 0f;
    this.CreatedByUserID = -1;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsApplication
private void .ctor(int ApplicationID, int ApplicantPersonID, System.DateTime ApplicationDate, int ApplicationTypeID, enApplicationStatus ApplicationStatus, System.DateTime LastStatusDate, float PaidFees, int CreatedByUserID)
{
    this.Mode = 0;
    this.ApplicationID = ApplicationID;
    this.ApplicantPersonID = ApplicantPersonID;
    this.ApplicationDate = ApplicationDate;
    this.ApplicationTypeID = ApplicationTypeID;
    this.ApplicationTypeInfo = DVLD_Buisness.clsApplicationType.Find(ApplicationTypeID);
    this.ApplicationStatus = ApplicationStatus;
    this.LastStatusDate = LastStatusDate;
    this.PaidFees = PaidFees;
    this.CreatedByUserID = CreatedByUserID;
    this.CreatedByUserInfo = DVLD_Buisness.clsUser.FindByUserID(CreatedByUserID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsApplication
private bool _AddNewApplication()
{
    bool local0;

    this.ApplicationID = Factorials.clsApplicationData.AddNewApplication(this.ApplicantPersonID, this.ApplicationDate, this.ApplicationTypeID, (byte)this.ApplicationStatus, this.LastStatusDate, this.PaidFees, this.CreatedByUserID);
    local0 = (this.ApplicationID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsApplication
private bool _UpdateApplication()
{
    bool local0;

    local0 = Factorials.clsApplicationData.UpdateApplication(this.ApplicationID, this.ApplicantPersonID, this.ApplicationDate, this.ApplicationTypeID, (byte)this.ApplicationStatus, this.LastStatusDate, this.PaidFees, this.CreatedByUserID);
    return local0;
}
// DVLD_Buisness.clsApplication
public static DVLD_Buisness.clsApplication FindBaseApplication(int ApplicationID)
{
    int local0;
    System.DateTime local1;
    int local2;
    byte local3;
    System.DateTime local4;
    float local5;
    int local6;
    bool local7;
    bool local8;
    DVLD_Buisness.clsApplication local9;

    local0 = -1;
    local1 = Now;
    local2 = -1;
    local3 = 1;
    local4 = Now;
    local5 = 0f;
    local6 = -1;
    local7 = Factorials.clsApplicationData.GetApplicationInfoByID(ApplicationID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5, ref local6);
    local8 = local7;
    if (!local8)
    {
        local9 = null;
    }
    else
    {
        local9 = new DVLD_Buisness.clsApplication(ApplicationID, local0, local1, local2, local3, local4, local5, local6);
    }
    return local9;
}
// DVLD_Buisness.clsApplication
public bool Cancel()
{
    bool local0;

    local0 = Factorials.clsApplicationData.UpdateStatus(this.ApplicationID, 2);
    return local0;
}
// DVLD_Buisness.clsApplication
public bool SetComplete()
{
    bool local0;

    local0 = Factorials.clsApplicationData.UpdateStatus(this.ApplicationID, 3);
    return local0;
}
// DVLD_Buisness.clsApplication
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewApplication();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateApplication();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsApplication
public bool Delete()
{
    bool local0;

    local0 = Factorials.clsApplicationData.DeleteApplication(this.ApplicationID);
    return local0;
}
// DVLD_Buisness.clsApplication
public static bool IsApplicationExist(int ApplicationID)
{
    bool local0;

    local0 = Factorials.clsApplicationData.IsApplicationExist(ApplicationID);
    return local0;
}
// DVLD_Buisness.clsApplication
public static bool DoesPersonHaveActiveApplication(int PersonID, int ApplicationTypeID)
{
    bool local0;

    local0 = Factorials.clsApplicationData.DoesPersonHaveActiveApplication(PersonID, ApplicationTypeID);
    return local0;
}
// DVLD_Buisness.clsApplication
public bool DoesPersonHaveActiveApplication(int ApplicationTypeID)
{
    bool local0;

    local0 = DVLD_Buisness.clsApplication.DoesPersonHaveActiveApplication(this.ApplicantPersonID, ApplicationTypeID);
    return local0;
}
// DVLD_Buisness.clsApplication
public static int GetActiveApplicationID(int PersonID, enApplicationType ApplicationTypeID)
{
    int local0;

    local0 = Factorials.clsApplicationData.GetActiveApplicationID(PersonID, ApplicationTypeID);
    return local0;
}
// DVLD_Buisness.clsApplication
public static int GetActiveApplicationIDForLicenseClass(int PersonID, enApplicationType ApplicationTypeID, int LicenseClassID)
{
    int local0;

    local0 = Factorials.clsApplicationData.GetActiveApplicationIDForLicenseClass(PersonID, ApplicationTypeID, LicenseClassID);
    return local0;
}
// DVLD_Buisness.clsApplication
public int GetActiveApplicationID(enApplicationType ApplicationTypeID)
{
    int local0;

    local0 = DVLD_Buisness.clsApplication.GetActiveApplicationID(this.ApplicantPersonID, ApplicationTypeID);
    return local0;
}
// DVLD_Buisness.clsApplicationType
public void set_ID(int value)
{
    this.ID = value;
    return;
}
// DVLD_Buisness.clsApplicationType
public int get_ID()
{
    return this.ID;
}
// DVLD_Buisness.clsApplicationType
public void set_Title(string value)
{
    this.Title = value;
    return;
}
// DVLD_Buisness.clsApplicationType
public string get_Title()
{
    return this.Title;
}
// DVLD_Buisness.clsApplicationType
public void set_Fees(float value)
{
    this.Fees = value;
    return;
}
// DVLD_Buisness.clsApplicationType
public float get_Fees()
{
    return this.Fees;
}
// DVLD_Buisness.clsApplicationType
public void .ctor()
{
    this.Mode = 0;
    this.ID = -1;
    this.Title = "";
    this.Fees = 0f;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsApplicationType
public void .ctor(int ID, string ApplicationTypeTitel, float ApplicationTypeFees)
{
    this.Mode = 0;
    this.ID = ID;
    this.Title = ApplicationTypeTitel;
    this.Fees = ApplicationTypeFees;
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsApplicationType
private bool _AddNewApplicationType()
{
    bool local0;

    this.ID = Factorials.clsApplicationTypeData.AddNewApplicationType(this.Title, this.Fees);
    local0 = (this.ID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsApplicationType
private bool _UpdateApplicationType()
{
    bool local0;

    local0 = Factorials.clsApplicationTypeData.UpdateApplicationType(this.ID, this.Title, this.Fees);
    return local0;
}
// DVLD_Buisness.clsApplicationType
public static DVLD_Buisness.clsApplicationType Find(int ID)
{
    string local0;
    float local1;
    bool local2;
    DVLD_Buisness.clsApplicationType local3;

    local0 = "";
    local1 = 0f;
    local2 = Factorials.clsApplicationTypeData.GetApplicationTypeInfoByID(ID, ref local0, ref local1);
    if (!local2)
    {
        local3 = null;
    }
    else
    {
        local3 = new DVLD_Buisness.clsApplicationType(ID, local0, local1);
    }
    return local3;
}
// DVLD_Buisness.clsApplicationType
public static System.Data.DataTable GetAllApplicationTypes()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsApplicationTypeData.GetAllApplicationTypes();
    return local0;
}
// DVLD_Buisness.clsApplicationType
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewApplicationType();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateApplicationType();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsCountry
public void set_ID(int value)
{
    this.ID = value;
    return;
}
// DVLD_Buisness.clsCountry
public int get_ID()
{
    return this.ID;
}
// DVLD_Buisness.clsCountry
public void set_CountryName(string value)
{
    this.CountryName = value;
    return;
}
// DVLD_Buisness.clsCountry
public string get_CountryName()
{
    return this.CountryName;
}
// DVLD_Buisness.clsCountry
public void .ctor()
{
    this.ID = -1;
    this.CountryName = "";
    return;
}
// DVLD_Buisness.clsCountry
private void .ctor(int ID, string CountryName)
{
    this.ID = ID;
    this.CountryName = CountryName;
    return;
}
// DVLD_Buisness.clsCountry
public static DVLD_Buisness.clsCountry Find(int ID)
{
    string local0;
    bool local1;
    DVLD_Buisness.clsCountry local2;

    local0 = "";
    local1 = Factorials.clsCountryData.GetCountryInfoByID(ID, ref local0);
    if (!local1)
    {
        local2 = null;
    }
    else
    {
        local2 = new DVLD_Buisness.clsCountry(ID, local0);
    }
    return local2;
}
// DVLD_Buisness.clsCountry
public static DVLD_Buisness.clsCountry Find(string CountryName)
{
    int local0;
    bool local1;
    DVLD_Buisness.clsCountry local2;

    local0 = -1;
    local1 = Factorials.clsCountryData.GetCountryInfoByName(CountryName, ref local0);
    if (!local1)
    {
        local2 = null;
    }
    else
    {
        local2 = new DVLD_Buisness.clsCountry(local0, CountryName);
    }
    return local2;
}
// DVLD_Buisness.clsCountry
public static System.Data.DataTable GetAllCountries()
{
    return Factorials.clsCountryData._GetAllCountries();
}
// DVLD_Buisness.clsDetainedLicense
public void set_DetainID(int value)
{
    this.DetainID = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public int get_DetainID()
{
    return this.DetainID;
}
// DVLD_Buisness.clsDetainedLicense
public void set_LicenseID(int value)
{
    this.LicenseID = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public int get_LicenseID()
{
    return this.LicenseID;
}
// DVLD_Buisness.clsDetainedLicense
public void set_DetainDate(System.DateTime value)
{
    this.DetainDate = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public System.DateTime get_DetainDate()
{
    return this.DetainDate;
}
// DVLD_Buisness.clsDetainedLicense
public void set_FineFees(float value)
{
    this.FineFees = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public float get_FineFees()
{
    return this.FineFees;
}
// DVLD_Buisness.clsDetainedLicense
public void set_CreatedByUserID(int value)
{
    this.CreatedByUserID = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public int get_CreatedByUserID()
{
    return this.CreatedByUserID;
}
// DVLD_Buisness.clsDetainedLicense
public void set_CreatedByUserInfo(DVLD_Buisness.clsUser value)
{
    this.CreatedByUserInfo = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public DVLD_Buisness.clsUser get_CreatedByUserInfo()
{
    return this.CreatedByUserInfo;
}
// DVLD_Buisness.clsDetainedLicense
public void set_IsReleased(bool value)
{
    this.IsReleased = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public bool get_IsReleased()
{
    return this.IsReleased;
}
// DVLD_Buisness.clsDetainedLicense
public void set_ReleaseDate(System.DateTime value)
{
    this.ReleaseDate = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public System.DateTime get_ReleaseDate()
{
    return this.ReleaseDate;
}
// DVLD_Buisness.clsDetainedLicense
public void set_ReleasedByUserID(int value)
{
    this.ReleasedByUserID = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public int get_ReleasedByUserID()
{
    return this.ReleasedByUserID;
}
// DVLD_Buisness.clsDetainedLicense
public void set_ReleasedByUserInfo(DVLD_Buisness.clsUser value)
{
    this.ReleasedByUserInfo = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public DVLD_Buisness.clsUser get_ReleasedByUserInfo()
{
    return this.ReleasedByUserInfo;
}
// DVLD_Buisness.clsDetainedLicense
public void set_ReleaseApplicationID(int value)
{
    this.ReleaseApplicationID = value;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public int get_ReleaseApplicationID()
{
    return this.ReleaseApplicationID;
}
// DVLD_Buisness.clsDetainedLicense
public void .ctor()
{
    this.Mode = 0;
    this.DetainID = -1;
    this.LicenseID = -1;
    this.DetainDate = Now;
    this.FineFees = 0f;
    this.CreatedByUserID = -1;
    this.IsReleased = false;
    this.ReleaseDate = MaxValue;
    this.ReleasedByUserID = 0;
    this.ReleaseApplicationID = -1;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsDetainedLicense
public void .ctor(int DetainID, int LicenseID, System.DateTime DetainDate, float FineFees, int CreatedByUserID, bool IsReleased, System.DateTime ReleaseDate, int ReleasedByUserID, int ReleaseApplicationID)
{
    this.Mode = 0;
    this.DetainID = DetainID;
    this.LicenseID = LicenseID;
    this.DetainDate = DetainDate;
    this.FineFees = FineFees;
    this.CreatedByUserID = CreatedByUserID;
    this.CreatedByUserInfo = DVLD_Buisness.clsUser.FindByUserID(this.CreatedByUserID);
    this.IsReleased = IsReleased;
    this.ReleaseDate = ReleaseDate;
    this.ReleasedByUserID = ReleasedByUserID;
    this.ReleaseApplicationID = ReleaseApplicationID;
    this.ReleasedByUserInfo = DVLD_Buisness.clsUser.FindByPersonID(this.ReleasedByUserID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsDetainedLicense
private bool _AddNewDetainedLicense()
{
    bool local0;

    this.DetainID = Factorials.clsDetainedLicenseData.AddNewDetainedLicense(this.LicenseID, this.DetainDate, this.FineFees, this.CreatedByUserID);
    local0 = (this.DetainID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsDetainedLicense
private bool _UpdateDetainedLicense()
{
    bool local0;

    local0 = Factorials.clsDetainedLicenseData.UpdateDetainedLicense(this.DetainID, this.LicenseID, this.DetainDate, this.FineFees, this.CreatedByUserID);
    return local0;
}
// DVLD_Buisness.clsDetainedLicense
public static DVLD_Buisness.clsDetainedLicense Find(int DetainID)
{
    int local0;
    System.DateTime local1;
    float local2;
    int local3;
    bool local4;
    System.DateTime local5;
    int local6;
    int local7;
    bool local8;
    DVLD_Buisness.clsDetainedLicense local9;

    local0 = -1;
    local1 = Now;
    local2 = 0f;
    local3 = -1;
    local4 = false;
    local5 = MaxValue;
    local6 = -1;
    local7 = -1;
    local8 = Factorials.clsDetainedLicenseData.GetDetainedLicenseInfoByID(DetainID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5, ref local6, ref local7);
    if (!local8)
    {
        local9 = null;
    }
    else
    {
        local9 = new DVLD_Buisness.clsDetainedLicense(DetainID, local0, local1, local2, local3, local4, local5, local6, local7);
    }
    return local9;
}
// DVLD_Buisness.clsDetainedLicense
public static System.Data.DataTable GetAllDetainedLicenses()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsDetainedLicenseData.GetAllDetainedLicenses();
    return local0;
}
// DVLD_Buisness.clsDetainedLicense
public static DVLD_Buisness.clsDetainedLicense FindByLicenseID(int LicenseID)
{
    int local0;
    System.DateTime local1;
    float local2;
    int local3;
    bool local4;
    System.DateTime local5;
    int local6;
    int local7;
    bool local8;
    DVLD_Buisness.clsDetainedLicense local9;

    local0 = -1;
    local1 = Now;
    local2 = 0f;
    local3 = -1;
    local4 = false;
    local5 = MaxValue;
    local6 = -1;
    local7 = -1;
    local8 = Factorials.clsDetainedLicenseData.GetDetainedLicenseInfoByLicenseID(LicenseID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5, ref local6, ref local7);
    if (!local8)
    {
        local9 = null;
    }
    else
    {
        local9 = new DVLD_Buisness.clsDetainedLicense(local0, LicenseID, local1, local2, local3, local4, local5, local6, local7);
    }
    return local9;
}
// DVLD_Buisness.clsDetainedLicense
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewDetainedLicense();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateDetainedLicense();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsDetainedLicense
public static bool IsLicenseDetained(int LicenseID)
{
    bool local0;

    local0 = Factorials.clsDetainedLicenseData.IsLicenseDetained(LicenseID);
    return local0;
}
// DVLD_Buisness.clsDetainedLicense
public bool ReleaseDetainedLicense(int ReleasedByUserID, int ReleaseApplicationID)
{
    bool local0;

    local0 = Factorials.clsDetainedLicenseData.ReleaseDetainedLicense(this.DetainID, ReleasedByUserID, ReleaseApplicationID);
    return local0;
}
// DVLD_Buisness.clsDriver
public void set_DriverID(int value)
{
    this.DriverID = value;
    return;
}
// DVLD_Buisness.clsDriver
public int get_DriverID()
{
    return this.DriverID;
}
// DVLD_Buisness.clsDriver
public void set_PersonID(int value)
{
    this.PersonID = value;
    return;
}
// DVLD_Buisness.clsDriver
public int get_PersonID()
{
    return this.PersonID;
}
// DVLD_Buisness.clsDriver
public void set_CreatedByUserID(int value)
{
    this.CreatedByUserID = value;
    return;
}
// DVLD_Buisness.clsDriver
public int get_CreatedByUserID()
{
    return this.CreatedByUserID;
}
// DVLD_Buisness.clsDriver
public System.DateTime get_CreatedDate()
{
    return this.CreatedDate;
}
// DVLD_Buisness.clsDriver
public void .ctor()
{
    this.Mode = 0;
    this.DriverID = -1;
    this.PersonID = -1;
    this.CreatedByUserID = -1;
    this.CreatedDate = Now;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsDriver
public void .ctor(int DriverID, int PersonID, int CreatedByUserID, System.DateTime CreatedDate)
{
    this.Mode = 0;
    this.DriverID = DriverID;
    this.PersonID = PersonID;
    this.CreatedByUserID = CreatedByUserID;
    this.CreatedDate = CreatedDate;
    this.PersonInfo = DVLD_Buisness.clsPerson.Find(PersonID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsDriver
private bool _AddNewDriver()
{
    bool local0;

    this.DriverID = Factorials.clsDriverData.AddNewDriver(this.PersonID, this.CreatedByUserID);
    local0 = (this.DriverID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsDriver
private bool _UpdateDriver()
{
    bool local0;

    local0 = Factorials.clsDriverData.UpdateDriver(this.DriverID, this.PersonID, this.CreatedByUserID);
    return local0;
}
// DVLD_Buisness.clsDriver
public static DVLD_Buisness.clsDriver FindByDriverID(int DriverID)
{
    int local0;
    int local1;
    System.DateTime local2;
    bool local3;
    DVLD_Buisness.clsDriver local4;

    local0 = -1;
    local1 = -1;
    local2 = Now;
    local3 = Factorials.clsDriverData.GetDriverInfoByDriverID(DriverID, ref local0, ref local1, ref local2);
    if (!local3)
    {
        local4 = null;
    }
    else
    {
        local4 = new DVLD_Buisness.clsDriver(DriverID, local0, local1, local2);
    }
    return local4;
}
// DVLD_Buisness.clsDriver
public static DVLD_Buisness.clsDriver FindByPersonID(int PersonID)
{
    int local0;
    int local1;
    System.DateTime local2;
    bool local3;
    DVLD_Buisness.clsDriver local4;

    local0 = -1;
    local1 = -1;
    local2 = Now;
    local3 = Factorials.clsDriverData.GetDriverInfoByPersonID(PersonID, ref local0, ref local1, ref local2);
    if (!local3)
    {
        local4 = null;
    }
    else
    {
        local4 = new DVLD_Buisness.clsDriver(local0, PersonID, local1, local2);
    }
    return local4;
}
// DVLD_Buisness.clsDriver
public static System.Data.DataTable GetAllDrivers()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsDriverData.GetAllDrivers();
    return local0;
}
// DVLD_Buisness.clsDriver
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewDriver();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateDriver();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsDriver
public static System.Data.DataTable GetLicenses(int DriverID)
{
    System.Data.DataTable local0;

    local0 = DVLD_Buisness.clsLicense.GetDriverLicenses(DriverID);
    return local0;
}
// DVLD_Buisness.clsDriver
public static System.Data.DataTable GetInternationalLicenses(int DriverID)
{
    System.Data.DataTable local0;

    local0 = DVLD_Buisness.clsInternationalLicense.GetDriverInternationalLicenses(DriverID);
    return local0;
}
// DVLD_Buisness.clsInternationalLicense
public void set_InternationalLicenseID(int value)
{
    this.InternationalLicenseID = value;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public int get_InternationalLicenseID()
{
    return this.InternationalLicenseID;
}
// DVLD_Buisness.clsInternationalLicense
public void set_DriverID(int value)
{
    this.DriverID = value;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public int get_DriverID()
{
    return this.DriverID;
}
// DVLD_Buisness.clsInternationalLicense
public void set_IssuedUsingLocalLicenseID(int value)
{
    this.IssuedUsingLocalLicenseID = value;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public int get_IssuedUsingLocalLicenseID()
{
    return this.IssuedUsingLocalLicenseID;
}
// DVLD_Buisness.clsInternationalLicense
public void set_IssueDate(System.DateTime value)
{
    this.IssueDate = value;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public System.DateTime get_IssueDate()
{
    return this.IssueDate;
}
// DVLD_Buisness.clsInternationalLicense
public void set_ExpirationDate(System.DateTime value)
{
    this.ExpirationDate = value;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public System.DateTime get_ExpirationDate()
{
    return this.ExpirationDate;
}
// DVLD_Buisness.clsInternationalLicense
public void set_IsActive(bool value)
{
    this.IsActive = value;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public bool get_IsActive()
{
    return this.IsActive;
}
// DVLD_Buisness.clsInternationalLicense
public void .ctor()
{
    this.Mode = 0;
    this.ApplicationTypeID = 6;
    this.InternationalLicenseID = -1;
    this.DriverID = -1;
    this.IssuedUsingLocalLicenseID = -1;
    this.IssueDate = Now;
    this.ExpirationDate = Now;
    this.IsActive = true;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsInternationalLicense
public void .ctor(int ApplicationID, int ApplicantPersonID, System.DateTime ApplicationDate, enApplicationStatus ApplicationStatus, System.DateTime LastStatusDate, float PaidFees, int CreatedByUserID, int InternationalLicenseID, int DriverID, int IssuedUsingLocalLicenseID, System.DateTime IssueDate, System.DateTime ExpirationDate, bool IsActive)
{
    this.Mode = 0;
    this.ApplicationID = ApplicationID;
    this.ApplicantPersonID = ApplicantPersonID;
    this.ApplicationDate = ApplicationDate;
    this.ApplicationTypeID = 6;
    this.ApplicationStatus = ApplicationStatus;
    this.LastStatusDate = LastStatusDate;
    this.PaidFees = PaidFees;
    this.CreatedByUserID = CreatedByUserID;
    this.InternationalLicenseID = InternationalLicenseID;
    this.ApplicationID = ApplicationID;
    this.DriverID = DriverID;
    this.IssuedUsingLocalLicenseID = IssuedUsingLocalLicenseID;
    this.IssueDate = IssueDate;
    this.ExpirationDate = ExpirationDate;
    this.IsActive = IsActive;
    this.CreatedByUserID = CreatedByUserID;
    this.DriverInfo = DVLD_Buisness.clsDriver.FindByDriverID(this.DriverID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsInternationalLicense
private bool _AddNewInternationalLicense()
{
    bool local0;

    this.InternationalLicenseID = Factorials.clsInternationalLicenseData.AddNewInternationalLicense(this.ApplicationID, this.DriverID, this.IssuedUsingLocalLicenseID, this.IssueDate, this.ExpirationDate, this.IsActive, this.CreatedByUserID);
    local0 = (this.InternationalLicenseID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsInternationalLicense
private bool _UpdateInternationalLicense()
{
    bool local0;

    local0 = Factorials.clsInternationalLicenseData.UpdateInternationalLicense(this.InternationalLicenseID, this.ApplicationID, this.DriverID, this.IssuedUsingLocalLicenseID, this.IssueDate, this.ExpirationDate, this.IsActive, this.CreatedByUserID);
    return local0;
}
// DVLD_Buisness.clsInternationalLicense
public static DVLD_Buisness.clsInternationalLicense Find(int InternationalLicenseID)
{
    int local0;
    int local1;
    int local2;
    System.DateTime local3;
    System.DateTime local4;
    bool local5;
    int local6;
    bool local7;
    DVLD_Buisness.clsApplication local8;
    DVLD_Buisness.clsInternationalLicense local9;

    local0 = -1;
    local1 = -1;
    local2 = -1;
    local3 = Now;
    local4 = Now;
    local5 = true;
    local6 = 1;
    local7 = Factorials.clsInternationalLicenseData.GetInternationalLicenseInfoByID(InternationalLicenseID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5, ref local6);
    if (!local7)
    {
        local9 = null;
    }
    else
    {
        local8 = DVLD_Buisness.clsApplication.FindBaseApplication(local0);
        local9 = new DVLD_Buisness.clsInternationalLicense(local8.ApplicationID, local8.ApplicantPersonID, local8.ApplicationDate, local8.ApplicationStatus, local8.LastStatusDate, local8.PaidFees, local8.CreatedByUserID, InternationalLicenseID, local1, local2, local3, local4, local5);
    }
    return local9;
}
// DVLD_Buisness.clsInternationalLicense
public static System.Data.DataTable GetAllInternationalLicenses()
{
    System.Data.DataTable local0;

    local0 = DVLD_Buisness.clsInternationalLicense.GetAllInternationalLicenses();
    return local0;
}
// DVLD_Buisness.clsInternationalLicense
public bool Save()
{
    bool local0;
    bool local1;
    enMode local2;
    enMode local3;
    bool local4;

    this.Mode = this.Mode;
    local0 = this.Save() == false;
    if (!local0)
    {
        local3 = this.Mode;
        local2 = local3;
        if (local2 == 0)
        {
            local4 = this._AddNewInternationalLicense();
            if (!local4)
            {
                local1 = false;
            }
            else
            {
                this.Mode = 1;
                local1 = true;
            }
        }
        else
        {
            if (local2 == 1)
            {
                local1 = this._UpdateInternationalLicense();
            }
            else
            {
                local1 = false;
            }
        }
    }
    else
    {
        local1 = false;
    }
    return local1;
}
// DVLD_Buisness.clsInternationalLicense
public static int GetActiveInternationalLicenseIDByDriverID(int DriverID)
{
    int local0;

    local0 = DVLD_Buisness.clsInternationalLicense.GetActiveInternationalLicenseIDByDriverID(DriverID);
    return local0;
}
// DVLD_Buisness.clsInternationalLicense
public static System.Data.DataTable GetDriverInternationalLicenses(int DriverID)
{
    System.Data.DataTable local0;

    local0 = DVLD_Buisness.clsInternationalLicense.GetDriverInternationalLicenses(DriverID);
    return local0;
}
// DVLD_Buisness.clsLicense
public void set_LicenseID(int value)
{
    this.LicenseID = value;
    return;
}
// DVLD_Buisness.clsLicense
public int get_LicenseID()
{
    return this.LicenseID;
}
// DVLD_Buisness.clsLicense
public void set_ApplicationID(int value)
{
    this.ApplicationID = value;
    return;
}
// DVLD_Buisness.clsLicense
public int get_ApplicationID()
{
    return this.ApplicationID;
}
// DVLD_Buisness.clsLicense
public void set_DriverID(int value)
{
    this.DriverID = value;
    return;
}
// DVLD_Buisness.clsLicense
public int get_DriverID()
{
    return this.DriverID;
}
// DVLD_Buisness.clsLicense
public void set_LicenseClass(int value)
{
    this.LicenseClass = value;
    return;
}
// DVLD_Buisness.clsLicense
public int get_LicenseClass()
{
    return this.LicenseClass;
}
// DVLD_Buisness.clsLicense
public void set_IssueDate(System.DateTime value)
{
    this.IssueDate = value;
    return;
}
// DVLD_Buisness.clsLicense
public System.DateTime get_IssueDate()
{
    return this.IssueDate;
}
// DVLD_Buisness.clsLicense
public void set_ExpirationDate(System.DateTime value)
{
    this.ExpirationDate = value;
    return;
}
// DVLD_Buisness.clsLicense
public System.DateTime get_ExpirationDate()
{
    return this.ExpirationDate;
}
// DVLD_Buisness.clsLicense
public void set_Notes(string value)
{
    this.Notes = value;
    return;
}
// DVLD_Buisness.clsLicense
public string get_Notes()
{
    return this.Notes;
}
// DVLD_Buisness.clsLicense
public void set_PaidFees(float value)
{
    this.PaidFees = value;
    return;
}
// DVLD_Buisness.clsLicense
public float get_PaidFees()
{
    return this.PaidFees;
}
// DVLD_Buisness.clsLicense
public void set_IsActive(bool value)
{
    this.IsActive = value;
    return;
}
// DVLD_Buisness.clsLicense
public bool get_IsActive()
{
    return this.IsActive;
}
// DVLD_Buisness.clsLicense
public void set_IssueReason(enIssueReason value)
{
    this.IssueReason = value;
    return;
}
// DVLD_Buisness.clsLicense
public enIssueReason get_IssueReason()
{
    return this.IssueReason;
}
// DVLD_Buisness.clsLicense
public string get_IssueReasonText()
{
    string local0;

    local0 = DVLD_Buisness.clsLicense.GetIssueReasonText(this.IssueReason);
    return local0;
}
// DVLD_Buisness.clsLicense
public void set_DetainedInfo(DVLD_Buisness.clsDetainedLicense value)
{
    this.DetainedInfo = value;
    return;
}
// DVLD_Buisness.clsLicense
public DVLD_Buisness.clsDetainedLicense get_DetainedInfo()
{
    return this.DetainedInfo;
}
// DVLD_Buisness.clsLicense
public void set_CreatedByUserID(int value)
{
    this.CreatedByUserID = value;
    return;
}
// DVLD_Buisness.clsLicense
public int get_CreatedByUserID()
{
    return this.CreatedByUserID;
}
// DVLD_Buisness.clsLicense
public bool get_IsDetained()
{
    bool local0;

    local0 = DVLD_Buisness.clsDetainedLicense.IsLicenseDetained(this.LicenseID);
    return local0;
}
// DVLD_Buisness.clsLicense
public void .ctor()
{
    this.Mode = 0;
    this.LicenseID = -1;
    this.ApplicationID = -1;
    this.DriverID = -1;
    this.LicenseClass = -1;
    this.IssueDate = Now;
    this.ExpirationDate = Now;
    this.Notes = "";
    this.PaidFees = 0f;
    this.IsActive = true;
    this.IssueReason = (enIssueReason)1;
    this.CreatedByUserID = -1;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsLicense
public void .ctor(int LicenseID, int ApplicationID, int DriverID, int LicenseClass, System.DateTime IssueDate, System.DateTime ExpirationDate, string Notes, float PaidFees, bool IsActive, enIssueReason IssueReason, int CreatedByUserID)
{
    this.Mode = 0;
    this.LicenseID = LicenseID;
    this.ApplicationID = ApplicationID;
    this.DriverID = DriverID;
    this.LicenseClass = LicenseClass;
    this.IssueDate = IssueDate;
    this.ExpirationDate = ExpirationDate;
    this.Notes = Notes;
    this.PaidFees = PaidFees;
    this.IsActive = IsActive;
    this.IssueReason = IssueReason;
    this.CreatedByUserID = CreatedByUserID;
    this.DriverInfo = DVLD_Buisness.clsDriver.FindByDriverID(this.DriverID);
    this.LicenseClassIfo = DVLD_Buisness.clsLicenseClass.Find(this.LicenseClass);
    this.DetainedInfo = DVLD_Buisness.clsDetainedLicense.FindByLicenseID(this.LicenseID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsLicense
private bool _AddNewLicense()
{
    bool local0;

    this.LicenseID = Factorials.clsLicenseData.AddNewLicense(this.ApplicationID, this.DriverID, this.LicenseClass, this.IssueDate, this.ExpirationDate, this.Notes, this.PaidFees, this.IsActive, (byte)this.IssueReason, this.CreatedByUserID);
    local0 = (this.LicenseID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsLicense
private bool _UpdateLicense()
{
    bool local0;

    local0 = Factorials.clsLicenseData.UpdateLicense(this.ApplicationID, this.LicenseID, this.DriverID, this.LicenseClass, this.IssueDate, this.ExpirationDate, this.Notes, this.PaidFees, this.IsActive, (byte)this.IssueReason, this.CreatedByUserID);
    return local0;
}
// DVLD_Buisness.clsLicense
public static DVLD_Buisness.clsLicense Find(int LicenseID)
{
    int local0;
    int local1;
    int local2;
    System.DateTime local3;
    System.DateTime local4;
    string local5;
    float local6;
    bool local7;
    int local8;
    byte local9;
    bool local10;
    DVLD_Buisness.clsLicense local11;

    local0 = -1;
    local1 = -1;
    local2 = -1;
    local3 = Now;
    local4 = Now;
    local5 = "";
    local6 = 0f;
    local7 = true;
    local8 = 1;
    local9 = 1;
    local10 = Factorials.clsLicenseData.GetLicenseInfoByID(LicenseID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5, ref local6, ref local7, ref local9, ref local8);
    if (!local10)
    {
        local11 = null;
    }
    else
    {
        local11 = new DVLD_Buisness.clsLicense(LicenseID, local0, local1, local2, local3, local4, local5, local6, local7, local9, local8);
    }
    return local11;
}
// DVLD_Buisness.clsLicense
public static System.Data.DataTable GetAllLicenses()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsLicenseData.GetAllLicenses();
    return local0;
}
// DVLD_Buisness.clsLicense
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewLicense();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateLicense();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsLicense
public static bool IsLicenseExistByPersonID(int PersonID, int LicenseClassID)
{
    bool local0;

    local0 = (DVLD_Buisness.clsLicense.GetActiveLicenseIDByPersonID(PersonID, LicenseClassID) == -1) == false;
    return local0;
}
// DVLD_Buisness.clsLicense
public static int GetActiveLicenseIDByPersonID(int PersonID, int LicenseClassID)
{
    int local0;

    local0 = Factorials.clsLicenseData.GetActiveLicenseIDByPersonID(PersonID, LicenseClassID);
    return local0;
}
// DVLD_Buisness.clsLicense
public static System.Data.DataTable GetDriverLicenses(int DriverID)
{
    System.Data.DataTable local0;

    local0 = Factorials.clsLicenseData.GetDriverLicenses(DriverID);
    return local0;
}
// DVLD_Buisness.clsLicense
public bool IsLicenseExpired()
{
    bool local0;

    local0 = this.ExpirationDate < Now;
    return local0;
}
// DVLD_Buisness.clsLicense
public bool DeactivateCurrentLicense()
{
    bool local0;

    local0 = Factorials.clsLicenseData.DeactivateLicense(this.LicenseID);
    return local0;
}
// DVLD_Buisness.clsLicense
public static string GetIssueReasonText(enIssueReason IssueReason)
{
    enIssueReason local0;
    enIssueReason local1;
    string local2;

    local1 = IssueReason;
    local0 = local1;
    switch (local0 - 1)
    {
        case 0:
            local2 = "First Time";
            break;
        case 1:
            local2 = "Renew";
            break;
        case 2:
            local2 = "Replacement for Damaged";
            break;
        case 3:
            local2 = "Replacement for Lost";
            break;
        default:
            local2 = "First Time";
            break;
    }
    return local2;
}
// DVLD_Buisness.clsLicense
public int Detain(float FineFees, int CreatedByUserID)
{
    DVLD_Buisness.clsDetainedLicense local0;
    bool local1;
    int local2;

    local0 = new DVLD_Buisness.clsDetainedLicense();
    local0.LicenseID = this.LicenseID;
    local0.DetainDate = Now;
    local0.FineFees = System.Convert.ToSingle(FineFees);
    local0.CreatedByUserID = CreatedByUserID;
    local1 = local0.Save() == false;
    if (!local1)
    {
        local2 = local0.DetainID;
    }
    else
    {
        local2 = -1;
    }
    return local2;
}
// DVLD_Buisness.clsLicense
public bool ReleaseDetainedLicense(int ReleasedByUserID, ref int ApplicationID)
{
    DVLD_Buisness.clsApplication local0;
    bool local1;
    bool local2;

    local0 = new DVLD_Buisness.clsApplication();
    local0.ApplicantPersonID = this.DriverInfo.PersonID;
    local0.ApplicationDate = Now;
    local0.ApplicationTypeID = 5;
    local0.ApplicationStatus = (enApplicationStatus)3;
    local0.LastStatusDate = Now;
    local0.PaidFees = DVLD_Buisness.clsApplicationType.Find(5).Fees;
    local0.CreatedByUserID = ReleasedByUserID;
    local1 = local0.Save() == false;
    if (!local1)
    {
        ApplicationID = local0.ApplicationID;
        local2 = this.DetainedInfo.ReleaseDetainedLicense(ReleasedByUserID, local0.ApplicationID);
    }
    else
    {
        ApplicationID = -1;
        local2 = false;
    }
    return local2;
}
// DVLD_Buisness.clsLicense
public DVLD_Buisness.clsLicense RenewLicense(string Notes, int CreatedByUserID)
{
    DVLD_Buisness.clsApplication local0;
    DVLD_Buisness.clsLicense local1;
    int local2;
    bool local3;
    DVLD_Buisness.clsLicense local4;
    System.DateTime local5;
    bool local6;

    local0 = new DVLD_Buisness.clsApplication();
    local0.ApplicantPersonID = this.DriverInfo.PersonID;
    local0.ApplicationDate = Now;
    local0.ApplicationTypeID = 2;
    local0.ApplicationStatus = (enApplicationStatus)3;
    local0.LastStatusDate = Now;
    local0.PaidFees = DVLD_Buisness.clsApplicationType.Find(2).Fees;
    local0.CreatedByUserID = CreatedByUserID;
    local3 = local0.Save() == false;
    if (!local3)
    {
        local1 = new DVLD_Buisness.clsLicense();
        local1.ApplicationID = local0.ApplicationID;
        local1.DriverID = this.DriverID;
        local1.LicenseClass = this.LicenseClass;
        local1.IssueDate = Now;
        local2 = this.LicenseClassIfo.DefaultValidityLength;
        local5 = Now;
        local1.ExpirationDate = local5.AddYears(local2);
        local1.Notes = Notes;
        local1.PaidFees = this.LicenseClassIfo.ClassFees;
        local1.IsActive = true;
        local1.IssueReason = (enIssueReason)2;
        local1.CreatedByUserID = CreatedByUserID;
        local6 = local1.Save() == false;
        if (!local6)
        {
            this.DeactivateCurrentLicense();
            local4 = local1;
        }
        else
        {
            local4 = null;
        }
    }
    else
    {
        local4 = null;
    }
    return local4;
}
// DVLD_Buisness.clsLicense
public DVLD_Buisness.clsLicense Replace(enIssueReason IssueReason, int CreatedByUserID)
{
    DVLD_Buisness.clsApplication local0;
    DVLD_Buisness.clsLicense local1;
    bool local2;
    DVLD_Buisness.clsLicense local3;
    bool local4;

    local0 = new DVLD_Buisness.clsApplication();
    local0.ApplicantPersonID = this.DriverInfo.PersonID;
    local0.ApplicationDate = Now;
    local0.ApplicationTypeID = (IssueReason == 3 ? 4 : 3);
    local0.ApplicationStatus = (enApplicationStatus)3;
    local0.LastStatusDate = Now;
    local0.PaidFees = DVLD_Buisness.clsApplicationType.Find(local0.ApplicationTypeID).Fees;
    local0.CreatedByUserID = CreatedByUserID;
    local2 = local0.Save() == false;
    if (!local2)
    {
        local1 = new DVLD_Buisness.clsLicense();
        local1.ApplicationID = local0.ApplicationID;
        local1.DriverID = this.DriverID;
        local1.LicenseClass = this.LicenseClass;
        local1.IssueDate = Now;
        local1.ExpirationDate = this.ExpirationDate;
        local1.Notes = this.Notes;
        local1.PaidFees = 0f;
        local1.IsActive = true;
        local1.IssueReason = IssueReason;
        local1.CreatedByUserID = CreatedByUserID;
        local4 = local1.Save() == false;
        if (!local4)
        {
            this.DeactivateCurrentLicense();
            local3 = local1;
        }
        else
        {
            local3 = null;
        }
    }
    else
    {
        local3 = null;
    }
    return local3;
}
// DVLD_Buisness.clsLicenseClass
public void set_LicenseClassID(int value)
{
    this.LicenseClassID = value;
    return;
}
// DVLD_Buisness.clsLicenseClass
public int get_LicenseClassID()
{
    return this.LicenseClassID;
}
// DVLD_Buisness.clsLicenseClass
public void set_ClassName(string value)
{
    this.ClassName = value;
    return;
}
// DVLD_Buisness.clsLicenseClass
public string get_ClassName()
{
    return this.ClassName;
}
// DVLD_Buisness.clsLicenseClass
public void set_ClassDescription(string value)
{
    this.ClassDescription = value;
    return;
}
// DVLD_Buisness.clsLicenseClass
public string get_ClassDescription()
{
    return this.ClassDescription;
}
// DVLD_Buisness.clsLicenseClass
public void set_MinimumAllowedAge(byte value)
{
    this.MinimumAllowedAge = value;
    return;
}
// DVLD_Buisness.clsLicenseClass
public byte get_MinimumAllowedAge()
{
    return this.MinimumAllowedAge;
}
// DVLD_Buisness.clsLicenseClass
public void set_DefaultValidityLength(byte value)
{
    this.DefaultValidityLength = value;
    return;
}
// DVLD_Buisness.clsLicenseClass
public byte get_DefaultValidityLength()
{
    return this.DefaultValidityLength;
}
// DVLD_Buisness.clsLicenseClass
public void set_ClassFees(float value)
{
    this.ClassFees = value;
    return;
}
// DVLD_Buisness.clsLicenseClass
public float get_ClassFees()
{
    return this.ClassFees;
}
// DVLD_Buisness.clsLicenseClass
public void .ctor()
{
    this.Mode = 0;
    this.LicenseClassID = -1;
    this.ClassName = "";
    this.ClassDescription = "";
    this.MinimumAllowedAge = 18;
    this.DefaultValidityLength = 10;
    this.ClassFees = 0f;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsLicenseClass
public void .ctor(int LicenseClassID, string ClassName, string ClassDescription, byte MinimumAllowedAge, byte DefaultValidityLength, float ClassFees)
{
    this.Mode = 0;
    this.LicenseClassID = LicenseClassID;
    this.ClassName = ClassName;
    this.ClassDescription = ClassDescription;
    this.MinimumAllowedAge = MinimumAllowedAge;
    this.DefaultValidityLength = DefaultValidityLength;
    this.ClassFees = ClassFees;
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsLicenseClass
private bool _AddNewLicenseClass()
{
    bool local0;

    this.LicenseClassID = Factorials.clsLicenseClassData.AddNewLicenseClass(this.ClassName, this.ClassDescription, this.MinimumAllowedAge, this.DefaultValidityLength, this.ClassFees);
    local0 = (this.LicenseClassID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsLicenseClass
private bool _UpdateLicenseClass()
{
    bool local0;

    local0 = Factorials.clsLicenseClassData.UpdateLicenseClass(this.LicenseClassID, this.ClassName, this.ClassDescription, this.MinimumAllowedAge, this.DefaultValidityLength, this.ClassFees);
    return local0;
}
// DVLD_Buisness.clsLicenseClass
public static DVLD_Buisness.clsLicenseClass Find(int LicenseClassID)
{
    string local0;
    string local1;
    byte local2;
    byte local3;
    float local4;
    bool local5;
    DVLD_Buisness.clsLicenseClass local6;

    local0 = "";
    local1 = "";
    local2 = 18;
    local3 = 10;
    local4 = 0f;
    local5 = Factorials.clsLicenseClassData.GetLicenseClassInfoByID(LicenseClassID, ref local0, ref local1, ref local2, ref local3, ref local4);
    if (!local5)
    {
        local6 = null;
    }
    else
    {
        local6 = new DVLD_Buisness.clsLicenseClass(LicenseClassID, local0, local1, local2, local3, local4);
    }
    return local6;
}
// DVLD_Buisness.clsLicenseClass
public static DVLD_Buisness.clsLicenseClass Find(string ClassName)
{
    int local0;
    string local1;
    byte local2;
    byte local3;
    float local4;
    bool local5;
    DVLD_Buisness.clsLicenseClass local6;

    local0 = -1;
    local1 = "";
    local2 = 18;
    local3 = 10;
    local4 = 0f;
    local5 = Factorials.clsLicenseClassData.GetLicenseClassInfoByClassName(ClassName, ref local0, ref local1, ref local2, ref local3, ref local4);
    if (!local5)
    {
        local6 = null;
    }
    else
    {
        local6 = new DVLD_Buisness.clsLicenseClass(local0, ClassName, local1, local2, local3, local4);
    }
    return local6;
}
// DVLD_Buisness.clsLicenseClass
public static System.Data.DataTable GetAllLicenseClasses()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsLicenseClassData.GetAllLicenseClasses();
    return local0;
}
// DVLD_Buisness.clsLicenseClass
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewLicenseClass();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateLicenseClass();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public void set_LocalDrivingLicenseApplicationID(int value)
{
    this.LocalDrivingLicenseApplicationID = value;
    return;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public int get_LocalDrivingLicenseApplicationID()
{
    return this.LocalDrivingLicenseApplicationID;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public void set_LicenseClassID(int value)
{
    this.LicenseClassID = value;
    return;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public int get_LicenseClassID()
{
    return this.LicenseClassID;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public string get_PersonFullName()
{
    string local0;

    local0 = DVLD_Buisness.clsPerson.Find(this.ApplicantPersonID).FullName;
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public void .ctor()
{
    this.Mode = 0;
    this.LocalDrivingLicenseApplicationID = -1;
    this.LicenseClassID = -1;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
private void .ctor(int LocalDrivingLicenseApplicationID, int ApplicationID, int ApplicantPersonID, System.DateTime ApplicationDate, int ApplicationTypeID, enApplicationStatus ApplicationStatus, System.DateTime LastStatusDate, float PaidFees, int CreatedByUserID, int LicenseClassID)
{
    this.Mode = 0;
    this.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;
    this.ApplicationID = ApplicationID;
    this.ApplicantPersonID = ApplicantPersonID;
    this.ApplicationDate = ApplicationDate;
    this.ApplicationTypeID = ApplicationTypeID;
    this.ApplicationStatus = ApplicationStatus;
    this.LastStatusDate = LastStatusDate;
    this.PaidFees = PaidFees;
    this.CreatedByUserID = CreatedByUserID;
    this.LicenseClassID = LicenseClassID;
    this.LicenseClassInfo = DVLD_Buisness.clsLicenseClass.Find(LicenseClassID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
private bool _AddNewLocalDrivingLicenseApplication()
{
    bool local0;

    this.LocalDrivingLicenseApplicationID = Factorials.clsLocalDrivingLicenseApplicationData.AddNewLocalDrivingLicenseApplication(this.ApplicationID, this.LicenseClassID);
    local0 = (this.LocalDrivingLicenseApplicationID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
private bool _UpdateLocalDrivingLicenseApplication()
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.UpdateLocalDrivingLicenseApplication(this.LocalDrivingLicenseApplicationID, this.ApplicationID, this.LicenseClassID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static DVLD_Buisness.clsLocalDrivingLicenseApplication FindByLocalDrivingAppLicenseID(int LocalDrivingLicenseApplicationID)
{
    int local0;
    int local1;
    bool local2;
    bool local3;
    DVLD_Buisness.clsApplication local4;
    DVLD_Buisness.clsLocalDrivingLicenseApplication local5;

    local0 = -1;
    local1 = -1;
    local2 = Factorials.clsLocalDrivingLicenseApplicationData.GetLocalDrivingLicenseApplicationInfoByID(LocalDrivingLicenseApplicationID, ref local0, ref local1);
    local3 = local2;
    if (!local3)
    {
        local5 = null;
    }
    else
    {
        local4 = DVLD_Buisness.clsApplication.FindBaseApplication(local0);
        local5 = new DVLD_Buisness.clsLocalDrivingLicenseApplication(LocalDrivingLicenseApplicationID, local4.ApplicationID, local4.ApplicantPersonID, local4.ApplicationDate, local4.ApplicationTypeID, local4.ApplicationStatus, local4.LastStatusDate, local4.PaidFees, local4.CreatedByUserID, local1);
    }
    return local5;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static DVLD_Buisness.clsLocalDrivingLicenseApplication FindByApplicationID(int ApplicationID)
{
    int local0;
    int local1;
    bool local2;
    DVLD_Buisness.clsApplication local3;
    DVLD_Buisness.clsLocalDrivingLicenseApplication local4;

    local0 = -1;
    local1 = -1;
    local2 = Factorials.clsLocalDrivingLicenseApplicationData.GetLocalDrivingLicenseApplicationInfoByApplicationID(ApplicationID, ref local0, ref local1);
    if (!local2)
    {
        local4 = null;
    }
    else
    {
        local3 = DVLD_Buisness.clsApplication.FindBaseApplication(ApplicationID);
        local4 = new DVLD_Buisness.clsLocalDrivingLicenseApplication(local0, local3.ApplicationID, local3.ApplicantPersonID, local3.ApplicationDate, local3.ApplicationTypeID, local3.ApplicationStatus, local3.LastStatusDate, local3.PaidFees, local3.CreatedByUserID, local1);
    }
    return local4;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool Save()
{
    bool local0;
    bool local1;
    enMode local2;
    enMode local3;
    bool local4;

    this.Mode = this.Mode;
    local0 = this.Save() == false;
    if (!local0)
    {
        local3 = this.Mode;
        local2 = local3;
        if (local2 == 0)
        {
            local4 = this._AddNewLocalDrivingLicenseApplication();
            if (!local4)
            {
                local1 = false;
            }
            else
            {
                this.Mode = 1;
                local1 = true;
            }
        }
        else
        {
            if (local2 == 1)
            {
                local1 = this._UpdateLocalDrivingLicenseApplication();
            }
            else
            {
                local1 = false;
            }
        }
    }
    else
    {
        local1 = false;
    }
    return local1;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static System.Data.DataTable GetAllLocalDrivingLicenseApplications()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.GetAllLocalDrivingLicenseApplications();
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool Delete()
{
    bool local0;
    bool local1;
    bool local2;
    bool local3;

    local0 = false;
    local1 = false;
    local0 = Factorials.clsLocalDrivingLicenseApplicationData.DeleteLocalDrivingLicenseApplication(this.LocalDrivingLicenseApplicationID);
    local2 = local0 == false;
    if (!local2)
    {
        local1 = this.Delete();
        local3 = local1;
    }
    else
    {
        local3 = false;
    }
    return local3;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool DoesPassTestType(enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.DoesPassTestType(this.LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool DoesPassPreviousTest(enTestType CurrentTestType)
{
    enTestType local0;
    enTestType local1;
    bool local2;

    local1 = CurrentTestType;
    local0 = local1;
    switch (local0 - 1)
    {
        case 0:
            local2 = true;
            break;
        case 1:
            local2 = this.DoesPassTestType((enTestType)1);
            break;
        case 2:
            local2 = this.DoesPassTestType((enTestType)2);
            break;
        default:
            local2 = false;
            break;
    }
    return local2;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static bool DoesPassTestType(int LocalDrivingLicenseApplicationID, enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.DoesPassTestType(LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool DoesAttendTestType(enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.DoesAttendTestType(this.LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public byte TotalTrialsPerTest(enTestType TestTypeID)
{
    byte local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.TotalTrialsPerTest(this.LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static byte TotalTrialsPerTest(int LocalDrivingLicenseApplicationID, enTestType TestTypeID)
{
    byte local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.TotalTrialsPerTest(LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static bool AttendedTest(int LocalDrivingLicenseApplicationID, enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.TotalTrialsPerTest(LocalDrivingLicenseApplicationID, TestTypeID) > 0;
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool AttendedTest(enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.TotalTrialsPerTest(this.LocalDrivingLicenseApplicationID, TestTypeID) > 0;
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static bool IsThereAnActiveScheduledTest(int LocalDrivingLicenseApplicationID, enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.IsThereAnActiveScheduledTest(LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool IsThereAnActiveScheduledTest(enTestType TestTypeID)
{
    bool local0;

    local0 = Factorials.clsLocalDrivingLicenseApplicationData.IsThereAnActiveScheduledTest(this.LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public DVLD_Buisness.clsTest GetLastTestPerTestType(enTestType TestTypeID)
{
    DVLD_Buisness.clsTest local0;

    local0 = DVLD_Buisness.clsTest.FindLastTestPerPersonAndLicenseClass(this.ApplicantPersonID, this.LicenseClassID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public byte GetPassedTestCount()
{
    byte local0;

    local0 = DVLD_Buisness.clsTest.GetPassedTestCount(this.LocalDrivingLicenseApplicationID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static byte GetPassedTestCount(int LocalDrivingLicenseApplicationID)
{
    byte local0;

    local0 = DVLD_Buisness.clsTest.GetPassedTestCount(LocalDrivingLicenseApplicationID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool PassedAllTests()
{
    bool local0;

    local0 = DVLD_Buisness.clsTest.PassedAllTests(this.LocalDrivingLicenseApplicationID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public static bool PassedAllTests(int LocalDrivingLicenseApplicationID)
{
    bool local0;

    local0 = DVLD_Buisness.clsTest.PassedAllTests(LocalDrivingLicenseApplicationID);
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public int IssueLicenseForTheFirtTime(string Notes, int CreatedByUserID)
{
    // disrobe: unstructured control flow has no legal target scope: goto IL_005F has no legal target scope; the compiler-emitted plumbing below is kept verbatim as the only static evidence
    // int local0;
    // DVLD_Buisness.clsDriver local1;
    // DVLD_Buisness.clsLicense local2;
    // bool local3;
    // bool local4;
    // int local5;
    // System.DateTime local6;
    // bool local7;
    // local0 = -1;
    // local1 = DVLD_Buisness.clsDriver.FindByPersonID(this.ApplicantPersonID);
    // local3 = local1 == null;
    // if (!local3)
    // {
    // local0 = local1.DriverID;
    // IL_005F:;
    // local2 = new DVLD_Buisness.clsLicense();
    // local2.ApplicationID = this.ApplicationID;
    // local2.DriverID = local0;
    // local2.LicenseClass = this.LicenseClassID;
    // local2.IssueDate = Now;
    // local6 = Now;
    // local2.ExpirationDate = local6.AddYears(this.LicenseClassInfo.DefaultValidityLength);
    // local2.Notes = Notes;
    // local2.PaidFees = this.LicenseClassInfo.ClassFees;
    // local2.IsActive = true;
    // local2.IssueReason = (enIssueReason)1;
    // local2.CreatedByUserID = CreatedByUserID;
    // local7 = local2.Save();
    // if (!local7)
    // {
    // local5 = -1;
    // }
    // else
    // {
    // this.SetComplete();
    // local5 = local2.LicenseID;
    // }
    // }
    // else
    // {
    // local1 = new DVLD_Buisness.clsDriver();
    // local1.PersonID = this.ApplicantPersonID;
    // local1.CreatedByUserID = CreatedByUserID;
    // local4 = local1.Save();
    // if (!local4)
    // {
    // local5 = -1;
    // }
    // else
    // {
    // local0 = local1.DriverID;
    // goto IL_005F;
    // }
    // }
    // return local5;
    throw new System.NotSupportedException("disrobe: unstructured control flow has no legal target scope");
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public bool IsLicenseIssued()
{
    bool local0;

    local0 = (this.GetActiveLicenseID() == -1) == false;
    return local0;
}
// DVLD_Buisness.clsLocalDrivingLicenseApplication
public int GetActiveLicenseID()
{
    int local0;

    local0 = DVLD_Buisness.clsLicense.GetActiveLicenseIDByPersonID(this.ApplicantPersonID, this.LicenseClassID);
    return local0;
}
// DVLD_Buisness.clsPerson
public void set_PersonID(System.Nullable<int> value)
{
    this.PersonID = value;
    return;
}
// DVLD_Buisness.clsPerson
public System.Nullable<int> get_PersonID()
{
    return this.PersonID;
}
// DVLD_Buisness.clsPerson
public void set_FirstName(string value)
{
    this.FirstName = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_FirstName()
{
    return this.FirstName;
}
// DVLD_Buisness.clsPerson
public void set_SecondName(string value)
{
    this.SecondName = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_SecondName()
{
    return this.SecondName;
}
// DVLD_Buisness.clsPerson
public void set_ThirdName(string value)
{
    this.ThirdName = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_ThirdName()
{
    return this.ThirdName;
}
// DVLD_Buisness.clsPerson
public void set_LastName(string value)
{
    this.LastName = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_LastName()
{
    return this.LastName;
}
// DVLD_Buisness.clsPerson
public string get_FullName()
{
    string local0;

    local0 = System.String.Concat(new System.String[7] { this.FirstName, " ", this.SecondName, " ", this.ThirdName, " ", this.LastName });
    return local0;
}
// DVLD_Buisness.clsPerson
public void set_NationalNo(string value)
{
    this.NationalNo = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_NationalNo()
{
    return this.NationalNo;
}
// DVLD_Buisness.clsPerson
public void set_DateOfBirth(System.Nullable<System.DateTime> value)
{
    this.DateOfBirth = value;
    return;
}
// DVLD_Buisness.clsPerson
public System.Nullable<System.DateTime> get_DateOfBirth()
{
    return this.DateOfBirth;
}
// DVLD_Buisness.clsPerson
public void set_Gendor(short value)
{
    this.Gendor = value;
    return;
}
// DVLD_Buisness.clsPerson
public short get_Gendor()
{
    return this.Gendor;
}
// DVLD_Buisness.clsPerson
public void set_Address(string value)
{
    this.Address = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_Address()
{
    return this.Address;
}
// DVLD_Buisness.clsPerson
public void set_Phone(string value)
{
    this.Phone = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_Phone()
{
    return this.Phone;
}
// DVLD_Buisness.clsPerson
public void set_Email(string value)
{
    this.Email = value;
    return;
}
// DVLD_Buisness.clsPerson
public string get_Email()
{
    return this.Email;
}
// DVLD_Buisness.clsPerson
public void set_NationalityCountryID(System.Nullable<int> value)
{
    this.NationalityCountryID = value;
    return;
}
// DVLD_Buisness.clsPerson
public System.Nullable<int> get_NationalityCountryID()
{
    return this.NationalityCountryID;
}
// DVLD_Buisness.clsPerson
public string get_ImagePath()
{
    string local0;

    local0 = this._ImagePath;
    return local0;
}
// DVLD_Buisness.clsPerson
public void set_ImagePath(string value)
{
    this._ImagePath = value;
    return;
}
// DVLD_Buisness.clsPerson
public void .ctor()
{
    System.Nullable<int> local0;
    System.Nullable<System.DateTime> local1;

    this.Mode = 0;
    local0 = default(Nullable<int>);
    this.PersonID = local0;
    this.FirstName = null;
    this.SecondName = null;
    this.ThirdName = null;
    this.LastName = null;
    local1 = default(Nullable<System.DateTime>);
    this.DateOfBirth = local1;
    this.Address = null;
    this.Phone = null;
    this.Email = null;
    local0 = default(Nullable<int>);
    this.NationalityCountryID = local0;
    this.ImagePath = null;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsPerson
private void .ctor(int PersonID, string FirstName, string SecondName, string ThirdName, string LastName, string NationalNo, System.DateTime DateOfBirth, short Gendor, string Address, string Phone, string Email, int NationalityCountryID, string ImagePath)
{
    this.Mode = 0;
    this.PersonID = new Nullable<int>(PersonID);
    this.FirstName = FirstName;
    this.SecondName = SecondName;
    this.ThirdName = ThirdName;
    this.LastName = LastName;
    this.NationalNo = NationalNo;
    this.DateOfBirth = new Nullable<System.DateTime>(DateOfBirth);
    this.Gendor = Gendor;
    this.Address = Address;
    this.Phone = Phone;
    this.Email = Email;
    this.NationalityCountryID = new Nullable<int>(NationalityCountryID);
    this.ImagePath = ImagePath;
    this.CountryInfo = DVLD_Buisness.clsCountry.Find(NationalityCountryID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsPerson
private bool _AddNewPerson()
{
    System.Nullable<int> local0;
    System.Nullable<System.DateTime> local1;
    System.Nullable<int> local2;

    local1 = this.DateOfBirth;
    local2 = this.NationalityCountryID;
    local0.ctor(Factorials.clsPersonData.AddNewPerson(this.FirstName, this.SecondName, this.ThirdName, this.LastName, this.NationalNo, local1.Value, this.Gendor, this.Address, this.Phone, this.Email, local2.Value, this.ImagePath));
    this.PersonID = local0;
    return local0.HasValue;
}
// DVLD_Buisness.clsPerson
private bool _UpdatePerson()
{
    System.Nullable<int> local0;
    System.Nullable<System.DateTime> local1;

    local0 = this.PersonID;
    local1 = this.DateOfBirth;
    local0 = this.NationalityCountryID;
    return Factorials.clsPersonData.UpdatePerson(local0.Value, this.FirstName, this.SecondName, this.ThirdName, this.LastName, this.NationalNo, local1.Value, this.Gendor, this.Address, this.Phone, this.Email, local0.Value, this.ImagePath);
}
// DVLD_Buisness.clsPerson
public static DVLD_Buisness.clsPerson Find(int PersonID)
{
    string local0;
    string local1;
    string local2;
    string local3;
    string local4;
    string local5;
    string local6;
    string local7;
    string local8;
    System.Nullable<System.DateTime> local9;
    System.Nullable<int> local10;
    System.Nullable<short> local11;
    bool local12;
    DVLD_Buisness.clsPerson local13;

    local0 = null;
    local1 = null;
    local2 = null;
    local3 = null;
    local4 = null;
    local5 = null;
    local6 = null;
    local7 = null;
    local8 = null;
    local9 = default(Nullable<System.DateTime>);
    local10 = default(Nullable<int>);
    local11 = default(Nullable<short>);
    local12 = Factorials.clsPersonData.GetPersonInfoByID(PersonID, ref local0, ref local1, ref local2, ref local3, ref local4, out local9, out local11, ref local7, ref local6, ref local5, out local10, ref local8);
    if (!local12)
    {
        local13 = null;
    }
    else
    {
        local13 = new DVLD_Buisness.clsPerson(PersonID, local0, local1, local2, local3, local4, local9.Value, local11.Value, local7, local6, local5, local10.Value, local8);
    }
    return local13;
}
// DVLD_Buisness.clsPerson
public static DVLD_Buisness.clsPerson Find(string NationalNo)
{
    string local0;
    string local1;
    string local2;
    string local3;
    string local4;
    string local5;
    string local6;
    string local7;
    System.Nullable<System.DateTime> local8;
    System.Nullable<int> local9;
    System.Nullable<int> local10;
    System.Nullable<short> local11;
    bool local12;
    DVLD_Buisness.clsPerson local13;

    local0 = null;
    local1 = null;
    local2 = null;
    local3 = null;
    local4 = null;
    local5 = null;
    local6 = null;
    local7 = null;
    local8 = default(Nullable<System.DateTime>);
    local9 = default(Nullable<int>);
    local10 = default(Nullable<int>);
    local11 = default(Nullable<short>);
    local12 = Factorials.clsPersonData.GetPersonInfoByNationalNo(NationalNo, out local9, ref local0, ref local1, ref local2, ref local3, out local8, out local11, ref local6, ref local5, ref local4, out local10, ref local7);
    if (!local12)
    {
        local13 = null;
    }
    else
    {
        local13 = new DVLD_Buisness.clsPerson(local9.Value, local0, local1, local2, local3, NationalNo, local8.Value, local11.Value, local6, local5, local4, local10.Value, local7);
    }
    return local13;
}
// DVLD_Buisness.clsPerson
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewPerson();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdatePerson();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsPerson
public static System.Data.DataTable GetAllPeople()
{
    return Factorials.clsPersonData._GetAllPeople();
}
// DVLD_Buisness.clsPerson
public static bool DeletePerson(int ID)
{
    return Factorials.clsPersonData._DeletePerson(ID);
}
// DVLD_Buisness.clsPerson
public static bool isPersonExist(int ID)
{
    return Factorials.clsPersonData.IsPersonExist(ID);
}
// DVLD_Buisness.clsPerson
public static bool isPersonExist(string NationalNo)
{
    return Factorials.clsPersonData.IsPersonExist(NationalNo);
}
// DVLD_Buisness.clsTest
public void set_TestID(int value)
{
    this.TestID = value;
    return;
}
// DVLD_Buisness.clsTest
public int get_TestID()
{
    return this.TestID;
}
// DVLD_Buisness.clsTest
public void set_TestAppointmentID(int value)
{
    this.TestAppointmentID = value;
    return;
}
// DVLD_Buisness.clsTest
public int get_TestAppointmentID()
{
    return this.TestAppointmentID;
}
// DVLD_Buisness.clsTest
public void set_TestAppointmentInfo(DVLD_Buisness.clsTestAppointment value)
{
    this.TestAppointmentInfo = value;
    return;
}
// DVLD_Buisness.clsTest
public DVLD_Buisness.clsTestAppointment get_TestAppointmentInfo()
{
    return this.TestAppointmentInfo;
}
// DVLD_Buisness.clsTest
public void set_TestResult(bool value)
{
    this.TestResult = value;
    return;
}
// DVLD_Buisness.clsTest
public bool get_TestResult()
{
    return this.TestResult;
}
// DVLD_Buisness.clsTest
public void set_Notes(string value)
{
    this.Notes = value;
    return;
}
// DVLD_Buisness.clsTest
public string get_Notes()
{
    return this.Notes;
}
// DVLD_Buisness.clsTest
public void set_CreatedByUserID(int value)
{
    this.CreatedByUserID = value;
    return;
}
// DVLD_Buisness.clsTest
public int get_CreatedByUserID()
{
    return this.CreatedByUserID;
}
// DVLD_Buisness.clsTest
public void .ctor()
{
    this.Mode = 0;
    this.TestID = -1;
    this.TestAppointmentID = -1;
    this.TestResult = false;
    this.Notes = "";
    this.CreatedByUserID = -1;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsTest
public void .ctor(int TestID, int TestAppointmentID, bool TestResult, string Notes, int CreatedByUserID)
{
    this.Mode = 0;
    this.TestID = TestID;
    this.TestAppointmentID = TestAppointmentID;
    this.TestAppointmentInfo = DVLD_Buisness.clsTestAppointment.Find(TestAppointmentID);
    this.TestResult = TestResult;
    this.Notes = Notes;
    this.CreatedByUserID = CreatedByUserID;
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsTest
private bool _AddNewTest()
{
    bool local0;

    this.TestID = Factorials.clsTestData.AddNewTest(this.TestAppointmentID, this.TestResult, this.Notes, this.CreatedByUserID);
    local0 = (this.TestID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsTest
private bool _UpdateTest()
{
    bool local0;

    local0 = Factorials.clsTestData.UpdateTest(this.TestID, this.TestAppointmentID, this.TestResult, this.Notes, this.CreatedByUserID);
    return local0;
}
// DVLD_Buisness.clsTest
public static DVLD_Buisness.clsTest Find(int TestID)
{
    int local0;
    bool local1;
    string local2;
    int local3;
    bool local4;
    DVLD_Buisness.clsTest local5;

    local0 = -1;
    local1 = false;
    local2 = "";
    local3 = -1;
    local4 = Factorials.clsTestData.GetTestInfoByID(TestID, ref local0, ref local1, ref local2, ref local3);
    if (!local4)
    {
        local5 = null;
    }
    else
    {
        local5 = new DVLD_Buisness.clsTest(TestID, local0, local1, local2, local3);
    }
    return local5;
}
// DVLD_Buisness.clsTest
public static DVLD_Buisness.clsTest FindLastTestPerPersonAndLicenseClass(int PersonID, int LicenseClassID, enTestType TestTypeID)
{
    int local0;
    int local1;
    bool local2;
    string local3;
    int local4;
    bool local5;
    DVLD_Buisness.clsTest local6;

    local0 = -1;
    local1 = -1;
    local2 = false;
    local3 = "";
    local4 = -1;
    local5 = Factorials.clsTestData.GetLastTestByPersonAndTestTypeAndLicenseClass(PersonID, LicenseClassID, TestTypeID, ref local0, ref local1, ref local2, ref local3, ref local4);
    if (!local5)
    {
        local6 = null;
    }
    else
    {
        local6 = new DVLD_Buisness.clsTest(local0, local1, local2, local3, local4);
    }
    return local6;
}
// DVLD_Buisness.clsTest
public static System.Data.DataTable GetAllTests()
{
    System.Data.DataTable local0;

    local0 = DVLD_Buisness.clsTest.GetAllTests();
    return local0;
}
// DVLD_Buisness.clsTest
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewTest();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateTest();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsTest
public static byte GetPassedTestCount(int LocalDrivingLicenseApplicationID)
{
    byte local0;

    local0 = DVLD_Buisness.clsTest.GetPassedTestCount(LocalDrivingLicenseApplicationID);
    return local0;
}
// DVLD_Buisness.clsTest
public static bool PassedAllTests(int LocalDrivingLicenseApplicationID)
{
    bool local0;

    local0 = DVLD_Buisness.clsTest.GetPassedTestCount(LocalDrivingLicenseApplicationID) == 3;
    return local0;
}
// DVLD_Buisness.clsTestAppointment
public void set_TestAppointmentID(int value)
{
    this.TestAppointmentID = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public int get_TestAppointmentID()
{
    return this.TestAppointmentID;
}
// DVLD_Buisness.clsTestAppointment
public void set_TestTypeID(enTestType value)
{
    this.TestTypeID = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public enTestType get_TestTypeID()
{
    return this.TestTypeID;
}
// DVLD_Buisness.clsTestAppointment
public void set_LocalDrivingLicenseApplicationID(int value)
{
    this.LocalDrivingLicenseApplicationID = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public int get_LocalDrivingLicenseApplicationID()
{
    return this.LocalDrivingLicenseApplicationID;
}
// DVLD_Buisness.clsTestAppointment
public void set_AppointmentDate(System.DateTime value)
{
    this.AppointmentDate = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public System.DateTime get_AppointmentDate()
{
    return this.AppointmentDate;
}
// DVLD_Buisness.clsTestAppointment
public void set_PaidFees(float value)
{
    this.PaidFees = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public float get_PaidFees()
{
    return this.PaidFees;
}
// DVLD_Buisness.clsTestAppointment
public void set_CreatedByUserID(int value)
{
    this.CreatedByUserID = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public int get_CreatedByUserID()
{
    return this.CreatedByUserID;
}
// DVLD_Buisness.clsTestAppointment
public void set_IsLocked(bool value)
{
    this.IsLocked = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public bool get_IsLocked()
{
    return this.IsLocked;
}
// DVLD_Buisness.clsTestAppointment
public void set_RetakeTestApplicationID(int value)
{
    this.RetakeTestApplicationID = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public int get_RetakeTestApplicationID()
{
    return this.RetakeTestApplicationID;
}
// DVLD_Buisness.clsTestAppointment
public void set_RetakeTestAppInfo(DVLD_Buisness.clsApplication value)
{
    this.RetakeTestAppInfo = value;
    return;
}
// DVLD_Buisness.clsTestAppointment
public DVLD_Buisness.clsApplication get_RetakeTestAppInfo()
{
    return this.RetakeTestAppInfo;
}
// DVLD_Buisness.clsTestAppointment
public int get_TestID()
{
    int local0;

    local0 = this._GetTestID();
    return local0;
}
// DVLD_Buisness.clsTestAppointment
public void .ctor()
{
    this.Mode = 0;
    this.TestAppointmentID = -1;
    this.TestTypeID = (enTestType)1;
    this.AppointmentDate = Now;
    this.PaidFees = 0f;
    this.CreatedByUserID = -1;
    this.RetakeTestApplicationID = -1;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsTestAppointment
public void .ctor(int TestAppointmentID, enTestType TestTypeID, int LocalDrivingLicenseApplicationID, System.DateTime AppointmentDate, float PaidFees, int CreatedByUserID, bool IsLocked, int RetakeTestApplicationID)
{
    this.Mode = 0;
    this.TestAppointmentID = TestAppointmentID;
    this.TestTypeID = TestTypeID;
    this.LocalDrivingLicenseApplicationID = LocalDrivingLicenseApplicationID;
    this.AppointmentDate = AppointmentDate;
    this.PaidFees = PaidFees;
    this.CreatedByUserID = CreatedByUserID;
    this.IsLocked = IsLocked;
    this.RetakeTestApplicationID = RetakeTestApplicationID;
    this.RetakeTestAppInfo = DVLD_Buisness.clsApplication.FindBaseApplication(RetakeTestApplicationID);
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsTestAppointment
private bool _AddNewTestAppointment()
{
    bool local0;

    this.TestAppointmentID = Factorials.clsTestAppointmentData.AddNewTestAppointment(this.TestTypeID, this.LocalDrivingLicenseApplicationID, this.AppointmentDate, this.PaidFees, this.CreatedByUserID, this.RetakeTestApplicationID);
    local0 = (this.TestAppointmentID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsTestAppointment
private bool _UpdateTestAppointment()
{
    bool local0;

    local0 = Factorials.clsTestAppointmentData.UpdateTestAppointment(this.TestAppointmentID, this.TestTypeID, this.LocalDrivingLicenseApplicationID, this.AppointmentDate, this.PaidFees, this.CreatedByUserID, this.IsLocked, this.RetakeTestApplicationID);
    return local0;
}
// DVLD_Buisness.clsTestAppointment
public static DVLD_Buisness.clsTestAppointment Find(int TestAppointmentID)
{
    int local0;
    int local1;
    System.DateTime local2;
    float local3;
    int local4;
    bool local5;
    int local6;
    bool local7;
    DVLD_Buisness.clsTestAppointment local8;

    local0 = 1;
    local1 = -1;
    local2 = Now;
    local3 = 0f;
    local4 = -1;
    local5 = false;
    local6 = -1;
    local7 = Factorials.clsTestAppointmentData.GetTestAppointmentInfoByID(TestAppointmentID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5, ref local6);
    if (!local7)
    {
        local8 = null;
    }
    else
    {
        local8 = new DVLD_Buisness.clsTestAppointment(TestAppointmentID, local0, local1, local2, local3, local4, local5, local6);
    }
    return local8;
}
// DVLD_Buisness.clsTestAppointment
public static DVLD_Buisness.clsTestAppointment GetLastTestAppointment(int LocalDrivingLicenseApplicationID, enTestType TestTypeID)
{
    int local0;
    System.DateTime local1;
    float local2;
    int local3;
    bool local4;
    int local5;
    bool local6;
    DVLD_Buisness.clsTestAppointment local7;

    local0 = -1;
    local1 = Now;
    local2 = 0f;
    local3 = -1;
    local4 = false;
    local5 = -1;
    local6 = Factorials.clsTestAppointmentData.GetLastTestAppointment(LocalDrivingLicenseApplicationID, TestTypeID, ref local0, ref local1, ref local2, ref local3, ref local4, ref local5);
    if (!local6)
    {
        local7 = null;
    }
    else
    {
        local7 = new DVLD_Buisness.clsTestAppointment(local0, TestTypeID, LocalDrivingLicenseApplicationID, local1, local2, local3, local4, local5);
    }
    return local7;
}
// DVLD_Buisness.clsTestAppointment
public static System.Data.DataTable GetAllTestAppointments()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsTestAppointmentData.GetAllTestAppointments();
    return local0;
}
// DVLD_Buisness.clsTestAppointment
public System.Data.DataTable GetApplicationTestAppointmentsPerTestType(enTestType TestTypeID)
{
    System.Data.DataTable local0;

    local0 = Factorials.clsTestAppointmentData.GetApplicationTestAppointmentsPerTestType(this.LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsTestAppointment
public static System.Data.DataTable GetApplicationTestAppointmentsPerTestType(int LocalDrivingLicenseApplicationID, enTestType TestTypeID)
{
    System.Data.DataTable local0;

    local0 = Factorials.clsTestAppointmentData.GetApplicationTestAppointmentsPerTestType(LocalDrivingLicenseApplicationID, TestTypeID);
    return local0;
}
// DVLD_Buisness.clsTestAppointment
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewTestAppointment();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateTestAppointment();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsTestAppointment
private int _GetTestID()
{
    int local0;

    local0 = Factorials.clsTestAppointmentData.GetTestID(this.TestAppointmentID);
    return local0;
}
// DVLD_Buisness.clsTestType
public void set_ID(enTestType value)
{
    this.ID = value;
    return;
}
// DVLD_Buisness.clsTestType
public enTestType get_ID()
{
    return this.ID;
}
// DVLD_Buisness.clsTestType
public void set_Title(string value)
{
    this.Title = value;
    return;
}
// DVLD_Buisness.clsTestType
public string get_Title()
{
    return this.Title;
}
// DVLD_Buisness.clsTestType
public void set_Description(string value)
{
    this.Description = value;
    return;
}
// DVLD_Buisness.clsTestType
public string get_Description()
{
    return this.Description;
}
// DVLD_Buisness.clsTestType
public void set_Fees(float value)
{
    this.Fees = value;
    return;
}
// DVLD_Buisness.clsTestType
public float get_Fees()
{
    return this.Fees;
}
// DVLD_Buisness.clsTestType
public void .ctor()
{
    this.Mode = 0;
    this.ID = (enTestType)1;
    this.Title = "";
    this.Description = "";
    this.Fees = 0f;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsTestType
public void .ctor(enTestType ID, string TestTypeTitel, string Description, float TestTypeFees)
{
    this.Mode = 0;
    this.ID = ID;
    this.Title = TestTypeTitel;
    this.Description = Description;
    this.Fees = TestTypeFees;
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsTestType
private bool _AddNewTestType()
{
    bool local0;

    this.ID = Factorials.clsTestTypeData.AddNewTestType(this.Title, this.Description, this.Fees);
    local0 = this.Title != "";
    return local0;
}
// DVLD_Buisness.clsTestType
private bool _UpdateTestType()
{
    bool local0;

    local0 = Factorials.clsTestTypeData.UpdateTestType(this.ID, this.Title, this.Description, this.Fees);
    return local0;
}
// DVLD_Buisness.clsTestType
public static DVLD_Buisness.clsTestType Find(enTestType TestTypeID)
{
    string local0;
    string local1;
    float local2;
    bool local3;
    DVLD_Buisness.clsTestType local4;

    local0 = "";
    local1 = "";
    local2 = 0f;
    local3 = Factorials.clsTestTypeData.GetTestTypeInfoByID(TestTypeID, ref local0, ref local1, ref local2);
    if (!local3)
    {
        local4 = null;
    }
    else
    {
        local4 = new DVLD_Buisness.clsTestType(TestTypeID, local0, local1, local2);
    }
    return local4;
}
// DVLD_Buisness.clsTestType
public static System.Data.DataTable GetAllTestTypes()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsTestTypeData.GetAllTestTypes();
    return local0;
}
// DVLD_Buisness.clsTestType
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewTestType();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateTestType();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsUser
public void set_UserID(int value)
{
    this.UserID = value;
    return;
}
// DVLD_Buisness.clsUser
public int get_UserID()
{
    return this.UserID;
}
// DVLD_Buisness.clsUser
public void set_PersonID(int value)
{
    this.PersonID = value;
    return;
}
// DVLD_Buisness.clsUser
public int get_PersonID()
{
    return this.PersonID;
}
// DVLD_Buisness.clsUser
public void set_UserName(string value)
{
    this.UserName = value;
    return;
}
// DVLD_Buisness.clsUser
public string get_UserName()
{
    return this.UserName;
}
// DVLD_Buisness.clsUser
public void set_Password(string value)
{
    this.Password = value;
    return;
}
// DVLD_Buisness.clsUser
public string get_Password()
{
    return this.Password;
}
// DVLD_Buisness.clsUser
public void set_IsActive(bool value)
{
    this.IsActive = value;
    return;
}
// DVLD_Buisness.clsUser
public bool get_IsActive()
{
    return this.IsActive;
}
// DVLD_Buisness.clsUser
public void .ctor()
{
    this.Mode = 0;
    this.UserID = -1;
    this.UserName = "";
    this.Password = "";
    this.IsActive = true;
    this.Mode = 0;
    return;
}
// DVLD_Buisness.clsUser
private void .ctor(int UserID, int PersonID, string Username, string Password, bool IsActive)
{
    this.Mode = 0;
    this.UserID = UserID;
    this.PersonID = PersonID;
    this.PersonInfo = DVLD_Buisness.clsPerson.Find(PersonID);
    this.UserName = Username;
    this.Password = Password;
    this.IsActive = IsActive;
    this.Mode = 1;
    return;
}
// DVLD_Buisness.clsUser
private bool _AddNewUser()
{
    bool local0;

    this.UserID = Factorials.clsUserData.AddNewUser(this.PersonID, this.UserName, this.Password, this.IsActive);
    local0 = (this.UserID == -1) == false;
    return local0;
}
// DVLD_Buisness.clsUser
private bool _UpdateUser()
{
    bool local0;

    local0 = Factorials.clsUserData.UpdateUser(this.UserID, this.PersonID, this.UserName, this.Password, this.IsActive);
    return local0;
}
// DVLD_Buisness.clsUser
public static DVLD_Buisness.clsUser FindByUserID(int UserID)
{
    int local0;
    string local1;
    string local2;
    bool local3;
    bool local4;
    bool local5;
    DVLD_Buisness.clsUser local6;

    local0 = -1;
    local1 = "";
    local2 = "";
    local3 = false;
    local4 = Factorials.clsUserData.GetUserInfoByUserID(UserID, ref local0, ref local1, ref local2, ref local3);
    local5 = local4;
    if (!local5)
    {
        local6 = null;
    }
    else
    {
        local6 = new DVLD_Buisness.clsUser(UserID, local0, local1, local2, local3);
    }
    return local6;
}
// DVLD_Buisness.clsUser
public static DVLD_Buisness.clsUser FindByPersonID(int PersonID)
{
    int local0;
    string local1;
    string local2;
    bool local3;
    bool local4;
    bool local5;
    DVLD_Buisness.clsUser local6;

    local0 = -1;
    local1 = "";
    local2 = "";
    local3 = false;
    local4 = Factorials.clsUserData.GetUserInfoByPersonID(PersonID, ref local0, ref local1, ref local2, ref local3);
    local5 = local4;
    if (!local5)
    {
        local6 = null;
    }
    else
    {
        local6 = new DVLD_Buisness.clsUser(local0, local0, local1, local2, local3);
    }
    return local6;
}
// DVLD_Buisness.clsUser
public static DVLD_Buisness.clsUser FindByUsernameAndPassword(string UserName, string Password)
{
    int local0;
    int local1;
    bool local2;
    bool local3;
    bool local4;
    DVLD_Buisness.clsUser local5;

    local0 = -1;
    local1 = -1;
    local2 = false;
    local3 = Factorials.clsUserData.GetUserInfoByUsernameAndPassword(UserName, Password, ref local0, ref local1, ref local2);
    local4 = local3;
    if (!local4)
    {
        local5 = null;
    }
    else
    {
        local5 = new DVLD_Buisness.clsUser(local0, local1, UserName, Password, local2);
    }
    return local5;
}
// DVLD_Buisness.clsUser
public bool Save()
{
    enMode local0;
    enMode local1;
    bool local2;
    bool local3;

    local1 = this.Mode;
    local0 = local1;
    if (local0 == 0)
    {
        local2 = this._AddNewUser();
        if (!local2)
        {
            local3 = false;
        }
        else
        {
            this.Mode = 1;
            local3 = true;
        }
    }
    else
    {
        if (local0 == 1)
        {
            local3 = this._UpdateUser();
        }
        else
        {
            local3 = false;
        }
    }
    return local3;
}
// DVLD_Buisness.clsUser
public static System.Data.DataTable GetAllUsers()
{
    System.Data.DataTable local0;

    local0 = Factorials.clsUserData.GetAllUsers();
    return local0;
}
// DVLD_Buisness.clsUser
public static bool DeleteUser(int UserID)
{
    bool local0;

    local0 = Factorials.clsUserData.DeleteUser(UserID);
    return local0;
}
// DVLD_Buisness.clsUser
public static bool isUserExist(int UserID)
{
    bool local0;

    local0 = Factorials.clsUserData.IsUserExist(UserID);
    return local0;
}
// DVLD_Buisness.clsUser
public static bool isUserExist(string UserName)
{
    bool local0;

    local0 = Factorials.clsUserData.IsUserExist(UserName);
    return local0;
}
// DVLD_Buisness.clsUser
public static bool isUserExistForPersonID(int PersonID)
{
    bool local0;

    local0 = Factorials.clsUserData.IsUserExistForPersonID(PersonID);
    return local0;
}
// Factorials.DataSetGen
public void .ctor()
{
    System.ComponentModel.CollectionChangeEventHandler local0;

    this._schemaSerializationMode = 1;
    this.BeginInit();
    this.InitClass();
    local0 = this.SchemaChanged;
    this.Tables.add_CollectionChanged(local0);
    this.Relations.add_CollectionChanged(local0);
    this.EndInit();
    return;
}
// Factorials.DataSetGen
protected void .ctor(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
{
    string local0;
    System.ComponentModel.CollectionChangeEventHandler local1;
    bool local2;
    System.ComponentModel.CollectionChangeEventHandler local3;
    bool local4;
    System.Data.DataSet local5;
    bool local6;

    this._schemaSerializationMode = 1;
    this.ctor(info, context, false);
    local2 = this.IsBinarySerialized(info, context);
    if (!local2)
    {
        local0 = (String)info.GetValue("XmlSchema", typeof(String));
        local4 = this.DetermineSchemaSerializationMode(info, context) == 1;
        if (!local4)
        {
            this.ReadXmlSchema(new System.Xml.XmlTextReader(new System.IO.StringReader(local0)));
        }
        else
        {
            local5 = new System.Data.DataSet();
            local5.ReadXmlSchema(new System.Xml.XmlTextReader(new System.IO.StringReader(local0)));
            local6 = local5.Tables["Middle"] > null;
            if (!(!local6))
            {
                this.Tables.Add(new MiddleDataTable(local5.Tables["Middle"]));
            }
            this.DataSetName = local5.DataSetName;
            this.Prefix = local5.Prefix;
            this.Namespace = local5.Namespace;
            this.Locale = local5.Locale;
            this.CaseSensitive = local5.CaseSensitive;
            this.EnforceConstraints = local5.EnforceConstraints;
            this.Merge(local5, false, (System.Data.MissingSchemaAction)1);
            this.InitVars();
        }
        this.GetSerializationData(info, context);
        local1 = this.SchemaChanged;
        this.Tables.add_CollectionChanged(local1);
        this.Relations.add_CollectionChanged(local1);
    }
    else
    {
        this.InitVars(false);
        local3 = this.SchemaChanged;
        this.Tables.add_CollectionChanged(local3);
        this.Relations.add_CollectionChanged(local3);
    }
    return;
}
// Factorials.DataSetGen
public MiddleDataTable get_Middle()
{
    MiddleDataTable local0;

    local0 = this.tableMiddle;
    return local0;
}
// Factorials.DataSetGen
public System.Data.SchemaSerializationMode get_SchemaSerializationMode()
{
    System.Data.SchemaSerializationMode local0;

    local0 = this._schemaSerializationMode;
    return local0;
}
// Factorials.DataSetGen
public void set_SchemaSerializationMode(System.Data.SchemaSerializationMode value)
{
    this._schemaSerializationMode = value;
    return;
}
// Factorials.DataSetGen
public System.Data.DataTableCollection get_Tables()
{
    System.Data.DataTableCollection local0;

    local0 = this.Tables;
    return local0;
}
// Factorials.DataSetGen
public System.Data.DataRelationCollection get_Relations()
{
    System.Data.DataRelationCollection local0;

    local0 = this.Relations;
    return local0;
}
// Factorials.DataSetGen
protected void InitializeDerivedDataSet()
{
    this.BeginInit();
    this.InitClass();
    this.EndInit();
    return;
}
// Factorials.DataSetGen
public System.Data.DataSet Clone()
{
    Factorials.DataSetGen local0;
    System.Data.DataSet local1;

    local0 = (DataSetGen)this.Clone();
    local0.InitVars();
    local0.SchemaSerializationMode = this.SchemaSerializationMode;
    local1 = local0;
    return local1;
}
// Factorials.DataSetGen
protected bool ShouldSerializeTables()
{
    bool local0;

    local0 = false;
    return local0;
}
// Factorials.DataSetGen
protected bool ShouldSerializeRelations()
{
    bool local0;

    local0 = false;
    return local0;
}
// Factorials.DataSetGen
protected void ReadXmlSerializable(System.Xml.XmlReader reader)
{
    bool local0;
    System.Data.DataSet local1;
    bool local2;

    local0 = this.DetermineSchemaSerializationMode(reader) == 1;
    if (!local0)
    {
        this.ReadXml(reader);
        this.InitVars();
    }
    else
    {
        this.Reset();
        local1 = new System.Data.DataSet();
        local1.ReadXml(reader);
        local2 = local1.Tables["Middle"] > null;
        if (!(!local2))
        {
            this.Tables.Add(new MiddleDataTable(local1.Tables["Middle"]));
        }
        this.DataSetName = local1.DataSetName;
        this.Prefix = local1.Prefix;
        this.Namespace = local1.Namespace;
        this.Locale = local1.Locale;
        this.CaseSensitive = local1.CaseSensitive;
        this.EnforceConstraints = local1.EnforceConstraints;
        this.Merge(local1, false, (System.Data.MissingSchemaAction)1);
        this.InitVars();
    }
    return;
}
// Factorials.DataSetGen
protected System.Xml.Schema.XmlSchema GetSchemaSerializable()
{
    System.IO.MemoryStream local0;
    System.Xml.Schema.XmlSchema local1;

    local0 = new System.IO.MemoryStream();
    this.WriteXmlSchema(new System.Xml.XmlTextWriter(local0, null));
    local0.Position = unchecked((long)0);
    local1 = System.Xml.Schema.XmlSchema.Read(new System.Xml.XmlTextReader(local0), null);
    return local1;
}
// Factorials.DataSetGen
internal void InitVars()
{
    this.InitVars(true);
    return;
}
// Factorials.DataSetGen
internal void InitVars(bool initTable)
{
    bool local0;
    bool local1;

    this.tableMiddle = (MiddleDataTable)this.Tables["Middle"];
    local0 = initTable;
    if (!(!local0))
    {
        local1 = this.tableMiddle > null;
        if (!(!local1))
        {
            this.tableMiddle.InitVars();
        }
    }
    return;
}
// Factorials.DataSetGen
private void InitClass()
{
    this.DataSetName = "DataSetGen";
    this.Prefix = "";
    this.Namespace = "http://tempuri.org/DataSetGen.xsd";
    this.EnforceConstraints = true;
    this.SchemaSerializationMode = (System.Data.SchemaSerializationMode)1;
    this.tableMiddle = new MiddleDataTable();
    this.Tables.Add(this.tableMiddle);
    return;
}
// Factorials.DataSetGen
private bool ShouldSerializeMiddle()
{
    bool local0;

    local0 = false;
    return local0;
}
// Factorials.DataSetGen
private void SchemaChanged(object sender, System.ComponentModel.CollectionChangeEventArgs e)
{
    bool local0;

    local0 = e.Action == 2;
    if (!(!local0))
    {
        this.InitVars();
    }
    return;
}
// Factorials.DataSetGen
public static System.Xml.Schema.XmlSchemaComplexType GetTypedDataSetSchema(System.Xml.Schema.XmlSchemaSet xs)
{
    // disrobe: unstructured control flow has no legal target scope: goto IL_016A has no legal target scope; the compiler-emitted plumbing below is kept verbatim as the only static evidence
    // Factorials.DataSetGen local0;
    // System.Xml.Schema.XmlSchemaComplexType local1;
    // System.Xml.Schema.XmlSchemaSequence local2;
    // System.Xml.Schema.XmlSchemaAny local3;
    // System.Xml.Schema.XmlSchema local4;
    // bool local5;
    // System.IO.MemoryStream local6;
    // System.IO.MemoryStream local7;
    // System.Xml.Schema.XmlSchema local8;
    // System.Collections.IEnumerator local9;
    // bool local10;
    // bool local11;
    // bool local12;
    // System.Xml.Schema.XmlSchemaComplexType local13;
    // bool local14;
    // bool local15;
    // bool local16;
    // local0 = new Factorials.DataSetGen();
    // local1 = new System.Xml.Schema.XmlSchemaComplexType();
    // local2 = new System.Xml.Schema.XmlSchemaSequence();
    // local3 = new System.Xml.Schema.XmlSchemaAny();
    // local3.Namespace = local0.Namespace;
    // local2.Items.Add(local3);
    // local1.Particle = local2;
    // local4 = local0.GetSchemaSerializable();
    // local5 = xs.Contains(local4.TargetNamespace);
    // if (!local5)
    // {
    // IL_016A:;
    // xs.Add(local4);
    // local13 = local1;
    // }
    // else
    // {
    // local6 = new System.IO.MemoryStream();
    // local7 = new System.IO.MemoryStream();
    // try
    // {
    // local8 = null;
    // local4.Write(local6);
    // local9 = xs.Schemas(local4.TargetNamespace).GetEnumerator();
    // while (true)
    // {
    // local14 = local9.MoveNext();
    // if (local14)
    // {
    // local8 = (XmlSchema)local9.Current;
    // local7.SetLength(unchecked((long)0));
    // local8.Write(local7);
    // local10 = local6.Length == local7.Length;
    // if (!local10)
    // {
    // continue;
    // }
    // else
    // {
    // local6.Position = unchecked((long)0);
    // local7.Position = unchecked((long)0);
    // while (true)
    // {
    // if (local6.Position == local6.Length)
    // {
    // }
    // }
    // local12 = local6.Position == local6.Length;
    // if (!local12)
    // {
    // continue;
    // }
    // else
    // {
    // break;
    // }
    // }
    // }
    // else
    // {
    // goto IL_016A;
    // }
    // }
    // local13 = local1;
    // return local13;
    // }
    // finally
    // {
    // }
    // }
    throw new System.NotSupportedException("disrobe: unstructured control flow has no legal target scope");
}
// Factorials.clsApplicationTypeData
public static bool GetApplicationTypeInfoByID(int ApplicationTypeID, ref string ApplicationTypeTitle, ref float ApplicationFees)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM ApplicationTypes WHERE ApplicationTypeID = @ApplicationTypeID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationTypeID", ApplicationTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        ApplicationTypeTitle = (String)local4["ApplicationTypeTitle"];
                        ApplicationFees = System.Convert.ToSingle(local4["ApplicationFees"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationTypeData
public static System.Data.DataTable GetAllApplicationTypes()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM ApplicationTypes order by ApplicationTypeTitle";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                local5 = local4.HasRows;
                if (!(!local5))
                {
                    local0.Load(local4);
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationTypeData
public static int AddNewApplicationType(string Title, float Fees)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Insert Into ApplicationTypes (ApplicationTypeTitle,ApplicationFees)\n                            Values (@Title,@Fees)\n                            \n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationTypeTitle", Title);
            local3.Parameters.AddWithValue("@ApplicationFees", Fees);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationTypeData
public static bool UpdateApplicationType(int ApplicationTypeID, string Title, float Fees)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Exception local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  ApplicationTypes  \n                            set ApplicationTypeTitle = @Title,\n                                ApplicationFees = @Fees\n                                where ApplicationTypeID = @ApplicationTypeID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationTypeID", ApplicationTypeID);
            local3.Parameters.AddWithValue("@Title", Title);
            local3.Parameters.AddWithValue("@Fees", Fees);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Exception ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationTypeData
public void .ctor()
{
    return;
}
// Factorials.clsApplicationData
public static bool GetApplicationInfoByID(int ApplicationID, ref int ApplicantPersonID, ref System.DateTime ApplicationDate, ref int ApplicationTypeID, ref byte ApplicationStatus, ref System.DateTime LastStatusDate, ref float PaidFees, ref int CreatedByUserID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Applications WHERE ApplicationID = @ApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                local5 = local4.Read();
                if (!local5)
                {
                    local0 = false;
                }
                else
                {
                    local0 = true;
                    ApplicantPersonID = (Int32)((object)local4["ApplicantPersonID"]);
                    ApplicationDate = (DateTime)((object)local4["ApplicationDate"]);
                    ApplicationTypeID = (Int32)((object)local4["ApplicationTypeID"]);
                    ApplicationStatus = (Byte)((object)local4["ApplicationStatus"]);
                    LastStatusDate = (DateTime)((object)local4["LastStatusDate"]);
                    PaidFees = System.Convert.ToSingle(local4["PaidFees"]);
                    CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static System.Data.DataTable GetAllApplications()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "select * from ApplicationsList_View order by ApplicationDate desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                local5 = local4.HasRows;
                if (!(!local5))
                {
                    local0.Load(local4);
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static int AddNewApplication(int ApplicantPersonID, System.DateTime ApplicationDate, int ApplicationTypeID, byte ApplicationStatus, System.DateTime LastStatusDate, float PaidFees, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "INSERT INTO Applications ( \n                            ApplicantPersonID,ApplicationDate,ApplicationTypeID,\n                            ApplicationStatus,LastStatusDate,\n                            PaidFees,CreatedByUserID)\n                             VALUES (@ApplicantPersonID,@ApplicationDate,@ApplicationTypeID,\n                                      @ApplicationStatus,@LastStatusDate,\n                                      @PaidFees,   @CreatedByUserID);\n                             SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("ApplicantPersonID", ApplicantPersonID);
            local3.Parameters.AddWithValue("ApplicationDate", ApplicationDate);
            local3.Parameters.AddWithValue("ApplicationTypeID", ApplicationTypeID);
            local3.Parameters.AddWithValue("ApplicationStatus", ApplicationStatus);
            local3.Parameters.AddWithValue("LastStatusDate", LastStatusDate);
            local3.Parameters.AddWithValue("PaidFees", PaidFees);
            local3.Parameters.AddWithValue("CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static bool UpdateApplication(int ApplicationID, int ApplicantPersonID, System.DateTime ApplicationDate, int ApplicationTypeID, byte ApplicationStatus, System.DateTime LastStatusDate, float PaidFees, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  Applications  \n                            set ApplicantPersonID = @ApplicantPersonID,\n                                ApplicationDate = @ApplicationDate,\n                                ApplicationTypeID = @ApplicationTypeID,\n                                ApplicationStatus = @ApplicationStatus, \n                                LastStatusDate = @LastStatusDate,\n                                PaidFees = @PaidFees,\n                                CreatedByUserID=@CreatedByUserID\n                            where ApplicationID=@ApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("ApplicantPersonID", ApplicantPersonID);
            local3.Parameters.AddWithValue("ApplicationDate", ApplicationDate);
            local3.Parameters.AddWithValue("ApplicationTypeID", ApplicationTypeID);
            local3.Parameters.AddWithValue("ApplicationStatus", ApplicationStatus);
            local3.Parameters.AddWithValue("LastStatusDate", LastStatusDate);
            local3.Parameters.AddWithValue("PaidFees", PaidFees);
            local3.Parameters.AddWithValue("CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static bool DeleteApplication(int ApplicationID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Delete Applications \n                                where ApplicationID = @ApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static bool IsApplicationExist(int ApplicationID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM Applications WHERE ApplicationID = @ApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local7 = local0;
                    return local7;
                }
                finally
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static bool DoesPersonHaveActiveApplication(int PersonID, int ApplicationTypeID)
{
    bool local0;

    local0 = (Factorials.clsApplicationData.GetActiveApplicationID(PersonID, ApplicationTypeID) == -1) == false;
    return local0;
}
// Factorials.clsApplicationData
public static int GetActiveApplicationID(int PersonID, int ApplicationTypeID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT ActiveApplicationID=ApplicationID FROM Applications WHERE ApplicantPersonID = @ApplicantPersonID and ApplicationTypeID=@ApplicationTypeID and ApplicationStatus=1";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicantPersonID", PersonID);
            local3.Parameters.AddWithValue("@ApplicationTypeID", ApplicationTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static int GetActiveApplicationIDForLicenseClass(int PersonID, int ApplicationTypeID, int LicenseClassID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT ActiveApplicationID=Applications.ApplicationID  \n                            From\n                            Applications INNER JOIN\n                            LocalDrivingLicenseApplications ON Applications.ApplicationID = LocalDrivingLicenseApplications.ApplicationID\n                            WHERE ApplicantPersonID = @ApplicantPersonID \n                            and ApplicationTypeID=@ApplicationTypeID \n\t\t\t\t\t\t\tand LocalDrivingLicenseApplications.LicenseClassID = @LicenseClassID\n                            and ApplicationStatus=1";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicantPersonID", PersonID);
            local3.Parameters.AddWithValue("@ApplicationTypeID", ApplicationTypeID);
            local3.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            finally
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public static bool UpdateStatus(int ApplicationID, short NewStatus)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  Applications  \n                            set \n                                ApplicationStatus = @NewStatus, \n                                LastStatusDate = @LastStatusDate\n                            where ApplicationID=@ApplicationID;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("@NewStatus", NewStatus);
            local3.Parameters.AddWithValue("LastStatusDate", Now);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsApplicationData
public void .ctor()
{
    return;
}
// Factorials.clsCountryData
public static bool GetCountryInfoByID(int ID, ref string CountryName)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Countries WHERE CountryID = @CountryID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@CountryID", ID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        CountryName = (String)local4["CountryName"];
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsCountryData
public static bool GetCountryInfoByName(string CountryName, ref int ID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Countries WHERE CountryName = @CountryName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@CountryName", CountryName);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        ID = (Int32)((object)local4["CountryID"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsCountryData
public static System.Data.DataTable _GetAllCountries()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Countries order by CountryName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsCountryData
public void .ctor()
{
    return;
}
// Factorials.clsDataAccessSettings
private static void .cctor()
{
    ConnectionString = "";
    sourceName = "DVLD_App";
    return;
}
// Factorials.clsDetainedLicenseData
public static bool GetDetainedLicenseInfoByID(int DetainID, ref int LicenseID, ref System.DateTime DetainDate, ref float FineFees, ref int CreatedByUserID, ref bool IsReleased, ref System.DateTime ReleaseDate, ref int ReleasedByUserID, ref int ReleaseApplicationID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    bool local7;
    bool local8;
    System.Data.SqlClient.SqlException local9;
    bool local10;
    bool local11;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM DetainedLicenses WHERE DetainID = @DetainID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DetainID", DetainID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        LicenseID = (Int32)((object)local4["LicenseID"]);
                        DetainDate = (DateTime)((object)local4["DetainDate"]);
                        FineFees = System.Convert.ToSingle(local4["FineFees"]);
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                        IsReleased = (Boolean)((object)local4["IsReleased"]);
                        local6 = local4["ReleaseDate"] == Value;
                        if (!local6)
                        {
                            ReleaseDate = (DateTime)((object)local4["ReleaseDate"]);
                        }
                        else
                        {
                            ReleaseDate = MaxValue;
                        }
                        local7 = local4["ReleasedByUserID"] == Value;
                        if (!local7)
                        {
                            ReleasedByUserID = (Int32)((object)local4["ReleasedByUserID"]);
                        }
                        else
                        {
                            ReleasedByUserID = -1;
                        }
                        local8 = local4["ReleaseApplicationID"] == Value;
                        if (!local8)
                        {
                            ReleaseApplicationID = (Int32)((object)local4["ReleaseApplicationID"]);
                        }
                        else
                        {
                            ReleaseApplicationID = -1;
                        }
                    }
                }
                finally
                {
                }
                local11 = local0;
                return local11;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public static bool GetDetainedLicenseInfoByLicenseID(int LicenseID, ref int DetainID, ref System.DateTime DetainDate, ref float FineFees, ref int CreatedByUserID, ref bool IsReleased, ref System.DateTime ReleaseDate, ref int ReleasedByUserID, ref int ReleaseApplicationID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    bool local7;
    bool local8;
    System.Data.SqlClient.SqlException local9;
    bool local10;
    bool local11;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT top 1 * FROM DetainedLicenses WHERE LicenseID = @LicenseID order by DetainID desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        DetainID = (Int32)((object)local4["DetainID"]);
                        DetainDate = (DateTime)((object)local4["DetainDate"]);
                        FineFees = System.Convert.ToSingle(local4["FineFees"]);
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                        IsReleased = (Boolean)((object)local4["IsReleased"]);
                        local6 = local4["ReleaseDate"] == Value;
                        if (!local6)
                        {
                            ReleaseDate = (DateTime)((object)local4["ReleaseDate"]);
                        }
                        else
                        {
                            ReleaseDate = MaxValue;
                        }
                        local7 = local4["ReleasedByUserID"] == Value;
                        if (!local7)
                        {
                            ReleasedByUserID = (Int32)((object)local4["ReleasedByUserID"]);
                        }
                        else
                        {
                            ReleasedByUserID = -1;
                        }
                        local8 = local4["ReleaseApplicationID"] == Value;
                        if (!local8)
                        {
                            ReleaseApplicationID = (Int32)((object)local4["ReleaseApplicationID"]);
                        }
                        else
                        {
                            ReleaseApplicationID = -1;
                        }
                    }
                }
                finally
                {
                }
                local11 = local0;
                return local11;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public static System.Data.DataTable GetAllDetainedLicenses()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "select * from detainedLicenses_View order by IsReleased ,DetainID;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public static int AddNewDetainedLicense(int LicenseID, System.DateTime DetainDate, float FineFees, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "INSERT INTO dbo.DetainedLicenses\n                               (LicenseID,\n                               DetainDate,\n                               FineFees,\n                               CreatedByUserID,\n                               IsReleased\n                               )\n                            VALUES\n                               (@LicenseID,\n                               @DetainDate, \n                               @FineFees, \n                               @CreatedByUserID,\n                               0\n                             );\n                            \n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            local3.Parameters.AddWithValue("@DetainDate", DetainDate);
            local3.Parameters.AddWithValue("@FineFees", FineFees);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public static bool UpdateDetainedLicense(int DetainID, int LicenseID, System.DateTime DetainDate, float FineFees, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "UPDATE dbo.DetainedLicenses\n                              SET LicenseID = @LicenseID, \n                              DetainDate = @DetainDate, \n                              FineFees = @FineFees,\n                              CreatedByUserID = @CreatedByUserID,   \n                              WHERE DetainID=@DetainID;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DetainedLicenseID", DetainID);
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            local3.Parameters.AddWithValue("@DetainDate", DetainDate);
            local3.Parameters.AddWithValue("@FineFees", FineFees);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public static bool ReleaseDetainedLicense(int DetainID, int ReleasedByUserID, int ReleaseApplicationID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "UPDATE dbo.DetainedLicenses\n                              SET IsReleased = 1, \n                              ReleaseDate = @ReleaseDate, \n                              ReleaseApplicationID = @ReleaseApplicationID   \n                              WHERE DetainID=@DetainID;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DetainID", DetainID);
            local3.Parameters.AddWithValue("@ReleasedByUserID", ReleasedByUserID);
            local3.Parameters.AddWithValue("@ReleaseApplicationID", ReleaseApplicationID);
            local3.Parameters.AddWithValue("@ReleaseDate", Now);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public static bool IsLicenseDetained(int LicenseID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "select IsDetained=1 \n                            from detainedLicenses \n                            where \n                            LicenseID=@LicenseID \n                            and IsReleased=0;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                local5 = local4 > null;
                if (!(!local5))
                {
                    local0 = System.Convert.ToBoolean(local4);
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDetainedLicenseData
public void .ctor()
{
    return;
}
// Factorials.clsDriverData
public static bool GetDriverInfoByDriverID(int DriverID, ref int PersonID, ref int CreatedByUserID, ref System.DateTime CreatedDate)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Drivers WHERE DriverID = @DriverID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        PersonID = (Int32)((object)local4["PersonID"]);
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                        CreatedDate = (DateTime)((object)local4["CreatedDate"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            finally
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDriverData
public static bool GetDriverInfoByPersonID(int PersonID, ref int DriverID, ref int CreatedByUserID, ref System.DateTime CreatedDate)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Drivers WHERE PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        DriverID = (Int32)((object)local4["DriverID"]);
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                        CreatedDate = (DateTime)((object)local4["CreatedDate"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDriverData
public static System.Data.DataTable GetAllDrivers()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Drivers_View order by FullName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDriverData
public static int AddNewDriver(int PersonID, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Insert Into Drivers (PersonID,CreatedByUserID,CreatedDate)\n                            Values (@PersonID,@CreatedByUserID,@CreatedDate);\n                          \n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            local3.Parameters.AddWithValue("@CreatedDate", Now);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDriverData
public static bool UpdateDriver(int DriverID, int PersonID, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  Drivers  \n                            set PersonID = @PersonID,\n                                CreatedByUserID = @CreatedByUserID\n                                where DriverID = @DriverID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsDriverData
public void .ctor()
{
    return;
}
// Factorials.clsInternationalLicenseData
public static bool GetInternationalLicenseInfoByID(int InternationalLicenseID, ref int ApplicationID, ref int DriverID, ref int IssuedUsingLocalLicenseID, ref System.DateTime IssueDate, ref System.DateTime ExpirationDate, ref bool IsActive, ref int CreatedByUserID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM InternationalLicenses WHERE InternationalLicenseID = @InternationalLicenseID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@InternationalLicenseID", InternationalLicenseID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        ApplicationID = (Int32)((object)local4["ApplicationID"]);
                        DriverID = (Int32)((object)local4["DriverID"]);
                        IssuedUsingLocalLicenseID = (Int32)((object)local4["IssuedUsingLocalLicenseID"]);
                        IssueDate = (DateTime)((object)local4["IssueDate"]);
                        ExpirationDate = (DateTime)((object)local4["ExpirationDate"]);
                        IsActive = (Boolean)((object)local4["IsActive"]);
                        CreatedByUserID = (Int32)((object)local4["DriverID"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsInternationalLicenseData
public static System.Data.DataTable GetAllInternationalLicenses()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "\n            SELECT    InternationalLicenseID, ApplicationID,DriverID,\n\t\t                IssuedUsingLocalLicenseID , IssueDate, \n                        ExpirationDate, IsActive\n\t\t    from InternationalLicenses \n                order by IsActive, ExpirationDate desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsInternationalLicenseData
public static System.Data.DataTable GetDriverInternationalLicenses(int DriverID)
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "\n            SELECT    InternationalLicenseID, ApplicationID,\n\t\t                IssuedUsingLocalLicenseID , IssueDate, \n                        ExpirationDate, IsActive\n\t\t    from InternationalLicenses where DriverID=@DriverID\n                order by ExpirationDate desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsInternationalLicenseData
public static int AddNewInternationalLicense(int ApplicationID, int DriverID, int IssuedUsingLocalLicenseID, System.DateTime IssueDate, System.DateTime ExpirationDate, bool IsActive, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "\n                               Update InternationalLicenses \n                               set IsActive=0\n                               where DriverID=@DriverID;\n\n                             INSERT INTO InternationalLicenses\n                               (\n                                ApplicationID,\n                                DriverID,\n                                IssuedUsingLocalLicenseID,\n                                IssueDate,\n                                ExpirationDate,\n                                IsActive,\n                                CreatedByUserID)\n                         VALUES\n                               (@ApplicationID,\n                                @DriverID,\n                                @IssuedUsingLocalLicenseID,\n                                @IssueDate,\n                                @ExpirationDate,\n                                @IsActive,\n                                @CreatedByUserID);\n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            local3.Parameters.AddWithValue("@IssuedUsingLocalLicenseID", IssuedUsingLocalLicenseID);
            local3.Parameters.AddWithValue("@IssueDate", IssueDate);
            local3.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
            local3.Parameters.AddWithValue("@IsActive", IsActive);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsInternationalLicenseData
public static bool UpdateInternationalLicense(int InternationalLicenseID, int ApplicationID, int DriverID, int IssuedUsingLocalLicenseID, System.DateTime IssueDate, System.DateTime ExpirationDate, bool IsActive, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "UPDATE InternationalLicenses\n                           SET \n                              ApplicationID=@ApplicationID,\n                              DriverID = @DriverID,\n                              IssuedUsingLocalLicenseID = @IssuedUsingLocalLicenseID,\n                              IssueDate = @IssueDate,\n                              ExpirationDate = @ExpirationDate,\n                              IsActive = @IsActive,\n                              CreatedByUserID = @CreatedByUserID\n                         WHERE InternationalLicenseID=@InternationalLicenseID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@InternationalLicenseID", InternationalLicenseID);
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            local3.Parameters.AddWithValue("@IssuedUsingLocalLicenseID", IssuedUsingLocalLicenseID);
            local3.Parameters.AddWithValue("@IssueDate", IssueDate);
            local3.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
            local3.Parameters.AddWithValue("@IsActive", IsActive);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsInternationalLicenseData
public static int GetActiveInternationalLicenseIDByDriverID(int DriverID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "  \n                            SELECT Top 1 InternationalLicenseID\n                            FROM InternationalLicenses \n                            where DriverID=@DriverID and GetDate() between IssueDate and ExpirationDate \n                            order by ExpirationDate Desc;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsInternationalLicenseData
public void .ctor()
{
    return;
}
// Factorials.clsLicenseData
public static bool GetLicenseInfoByID(int LicenseID, ref int ApplicationID, ref int DriverID, ref int LicenseClass, ref System.DateTime IssueDate, ref System.DateTime ExpirationDate, ref string Notes, ref float PaidFees, ref bool IsActive, ref byte IssueReason, ref int CreatedByUserID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Licenses WHERE LicenseID = @LicenseID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        ApplicationID = (Int32)((object)local4["ApplicationID"]);
                        DriverID = (Int32)((object)local4["DriverID"]);
                        LicenseClass = (Int32)((object)local4["LicenseClass"]);
                        IssueDate = (DateTime)((object)local4["IssueDate"]);
                        ExpirationDate = (DateTime)((object)local4["ExpirationDate"]);
                        local6 = local4["Notes"] == Value;
                        if (!local6)
                        {
                            Notes = (String)local4["Notes"];
                        }
                        else
                        {
                            Notes = "";
                        }
                        PaidFees = System.Convert.ToSingle(local4["PaidFees"]);
                        IsActive = (Boolean)((object)local4["IsActive"]);
                        IssueReason = (Byte)((object)local4["IssueReason"]);
                        CreatedByUserID = (Int32)((object)local4["DriverID"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public static System.Data.DataTable GetAllLicenses()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Licenses";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public static System.Data.DataTable GetDriverLicenses(int DriverID)
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT     \n                           Licenses.LicenseID,\n                           ApplicationID,\n\t\t                   LicenseClasses.ClassName, Licenses.IssueDate, \n\t\t                   Licenses.ExpirationDate, Licenses.IsActive\n                           FROM Licenses INNER JOIN\n                                LicenseClasses ON Licenses.LicenseClass = LicenseClasses.LicenseClassID\n                            where DriverID=@DriverID\n                            Order By IsActive Desc, ExpirationDate Desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public static int AddNewLicense(int ApplicationID, int DriverID, int LicenseClass, System.DateTime IssueDate, System.DateTime ExpirationDate, string Notes, float PaidFees, bool IsActive, byte IssueReason, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    bool local4;
    object local5;
    int local6;
    bool local7;
    System.Data.SqlClient.SqlException local8;
    bool local9;
    int local10;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "\n                              INSERT INTO Licenses\n                               (ApplicationID,\n                                DriverID,\n                                LicenseClass,\n                                IssueDate,\n                                ExpirationDate,\n                                Notes,\n                                PaidFees,\n                                IsActive,IssueReason,\n                                CreatedByUserID)\n                         VALUES\n                               (\n                               @ApplicationID,\n                               @DriverID,\n                               @LicenseClass,\n                               @IssueDate,\n                               @ExpirationDate,\n                               @Notes,\n                               @PaidFees,\n                               @IsActive,@IssueReason, \n                               @CreatedByUserID);\n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            local3.Parameters.AddWithValue("@LicenseClass", LicenseClass);
            local3.Parameters.AddWithValue("@IssueDate", IssueDate);
            local3.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
            local4 = Notes == "";
            if (!local4)
            {
                local3.Parameters.AddWithValue("@Notes", Notes);
            }
            else
            {
                local3.Parameters.AddWithValue("@Notes", Value);
            }
        }
        finally
        {
        }
        local10 = local0;
        return local10;
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public static bool UpdateLicense(int LicenseID, int ApplicationID, int DriverID, int LicenseClass, System.DateTime IssueDate, System.DateTime ExpirationDate, string Notes, float PaidFees, bool IsActive, byte IssueReason, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    bool local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;
    bool local7;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "UPDATE Licenses\n                           SET ApplicationID=@ApplicationID, DriverID = @DriverID,\n                              LicenseClass = @LicenseClass,\n                              IssueDate = @IssueDate,\n                              ExpirationDate = @ExpirationDate,\n                              Notes = @Notes,\n                              PaidFees = @PaidFees,\n                              IsActive = @IsActive,IssueReason=@IssueReason,\n                              CreatedByUserID = @CreatedByUserID\n                         WHERE LicenseID=@LicenseID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("@DriverID", DriverID);
            local3.Parameters.AddWithValue("@LicenseClass", LicenseClass);
            local3.Parameters.AddWithValue("@IssueDate", IssueDate);
            local3.Parameters.AddWithValue("@ExpirationDate", ExpirationDate);
            local4 = Notes == "";
            if (!local4)
            {
                local3.Parameters.AddWithValue("@Notes", Notes);
            }
            else
            {
                local3.Parameters.AddWithValue("@Notes", Value);
            }
        }
        finally
        {
        }
        local7 = local0 > 0;
        return local7;
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public static int GetActiveLicenseIDByPersonID(int PersonID, int LicenseClassID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT        Licenses.LicenseID\n                            FROM Licenses INNER JOIN\n                                                     Drivers ON Licenses.DriverID = Drivers.DriverID\n                            WHERE  \n                             \n                             Licenses.LicenseClass = @LicenseClass \n                              AND Drivers.PersonID = @PersonID\n                              And IsActive=1;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@LicenseClass", LicenseClassID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local9 = local0;
            return local9;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public static bool DeactivateLicense(int LicenseID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "UPDATE Licenses\n                           SET \n                              IsActive = 0\n                             \n                         WHERE LicenseID=@LicenseID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseID", LicenseID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseData
public void .ctor()
{
    return;
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool GetLocalDrivingLicenseApplicationInfoByID(int LocalDrivingLicenseApplicationID, ref int ApplicationID, ref int LicenseClassID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM LocalDrivingLicenseApplications WHERE LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        ApplicationID = (Int32)((object)local4["ApplicationID"]);
                        LicenseClassID = (Int32)((object)local4["LicenseClassID"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool GetLocalDrivingLicenseApplicationInfoByApplicationID(int ApplicationID, ref int LocalDrivingLicenseApplicationID, ref int LicenseClassID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM LocalDrivingLicenseApplications WHERE ApplicationID = @ApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ApplicationID", ApplicationID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        LocalDrivingLicenseApplicationID = (Int32)((object)local4["LocalDrivingLicenseApplicationID"]);
                        LicenseClassID = (Int32)((object)local4["LicenseClassID"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static System.Data.DataTable GetAllLocalDrivingLicenseApplications()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT *\n                              FROM LocalDrivingLicenseApplications_View\n                              order by ApplicationDate Desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static int AddNewLocalDrivingLicenseApplication(int ApplicationID, int LicenseClassID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    int local8;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "INSERT INTO LocalDrivingLicenseApplications ( \n                            ApplicationID,LicenseClassID)\n                             VALUES (@ApplicationID,@LicenseClassID);\n                             SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("LicenseClassID", LicenseClassID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool UpdateLocalDrivingLicenseApplication(int LocalDrivingLicenseApplicationID, int ApplicationID, int LicenseClassID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  LocalDrivingLicenseApplications  \n                            set ApplicationID = @ApplicationID,\n                                LicenseClassID = @LicenseClassID\n                            where LocalDrivingLicenseApplicationID=@LocalDrivingLicenseApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("ApplicationID", ApplicationID);
            local3.Parameters.AddWithValue("LicenseClassID", LicenseClassID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool DeleteLocalDrivingLicenseApplication(int LocalDrivingLicenseApplicationID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Delete LocalDrivingLicenseApplications \n                                where LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool DoesPassTestType(int LocalDrivingLicenseApplicationID, int TestTypeID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = " SELECT top 1 TestResult\n                            FROM LocalDrivingLicenseApplications INNER JOIN\n                                 TestAppointments ON LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID INNER JOIN\n                                 Tests ON TestAppointments.TestAppointmentID = Tests.TestAppointmentID\n                            WHERE\n                            (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID) \n                            AND(TestAppointments.TestTypeID = @TestTypeID)\n                            ORDER BY TestAppointments.TestAppointmentID desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool DoesAttendTestType(int LocalDrivingLicenseApplicationID, int TestTypeID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = " SELECT top 1 Found=1\n                            FROM LocalDrivingLicenseApplications INNER JOIN\n                                 TestAppointments ON LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID INNER JOIN\n                                 Tests ON TestAppointments.TestAppointmentID = Tests.TestAppointmentID\n                            WHERE\n                            (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID) \n                            AND(TestAppointments.TestTypeID = @TestTypeID)\n                            ORDER BY TestAppointments.TestAppointmentID desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                local5 = local4 > null;
                if (!(!local5))
                {
                    local0 = true;
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local7 = local0;
            return local7;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static byte TotalTrialsPerTest(int LocalDrivingLicenseApplicationID, int TestTypeID)
{
    byte local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    byte local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    byte local8;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = " SELECT TotalTrialsPerTest = count(TestID)\n                            FROM LocalDrivingLicenseApplications INNER JOIN\n                                 TestAppointments ON LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID INNER JOIN\n                                 Tests ON TestAppointments.TestAppointmentID = Tests.TestAppointmentID\n                            WHERE\n                            (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID) \n                            AND(TestAppointments.TestTypeID = @TestTypeID)\n                       ";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public static bool IsThereAnActiveScheduledTest(int LocalDrivingLicenseApplicationID, int TestTypeID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = " SELECT top 1 Found=1\n                            FROM LocalDrivingLicenseApplications INNER JOIN\n                                 TestAppointments ON LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID \n                            WHERE\n                            (LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID)  \n                            AND(TestAppointments.TestTypeID = @TestTypeID) and isLocked=0\n                            ORDER BY TestAppointments.TestAppointmentID desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                local5 = local4 > null;
                if (!(!local5))
                {
                    local0 = true;
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local7 = local0;
            return local7;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLocalDrivingLicenseApplicationData
public void .ctor()
{
    return;
}
// Factorials.clsPersonData
public static bool GetPersonInfoByID(int PersonID, ref string FirstName, ref string SecondName, ref string ThirdName, ref string LastName, ref string NationalNo, ref System.Nullable<System.DateTime> DateOfBirth, ref System.Nullable<short> Gendor, ref string Address, ref string Phone, ref string Email, ref System.Nullable<int> NationalityCountryID, ref string ImagePath)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    bool local9;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM People WHERE PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        FirstName = (String)local4["FirstName"];
                        SecondName = (String)local4["SecondName"];
                        LastName = (String)local4["LastName"];
                        NationalNo = (String)local4["NationalNo"];
                        DateOfBirth = new Nullable<System.DateTime>((DateTime)((object)local4["DateOfBirth"]));
                        Gendor = new Nullable<short>((Byte)((object)local4["Gendor"]));
                        Address = (String)local4["Address"];
                        Phone = (String)local4["Phone"];
                        ThirdName = (((String)local4["ThirdName"]) != null ? ((String)local4["ThirdName"]) : null);
                        Email = (((String)local4["Email"]) != null ? ((String)local4["Email"]) : null);
                        NationalityCountryID = new Nullable<int>((Int32)((object)local4["NationalityCountryID"]));
                        local6 = (local4["ImagePath"] == Value) == false;
                        if (!(!local6))
                        {
                            ImagePath = (String)local4["ImagePath"];
                        }
                    }
                }
                finally
                {
                }
                local9 = local0;
                return local9;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static bool GetPersonInfoByNationalNo(string NationalNo, ref System.Nullable<int> PersonID, ref string FirstName, ref string SecondName, ref string ThirdName, ref string LastName, ref System.Nullable<System.DateTime> DateOfBirth, ref System.Nullable<short> Gendor, ref string Address, ref string Phone, ref string Email, ref System.Nullable<int> NationalityCountryID, ref string ImagePath)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    bool local9;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM People WHERE NationalNo = @NationalNo";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@NationalNo", NationalNo);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        PersonID = new Nullable<int>((Int32)((object)local4["PersonID"]));
                        FirstName = (String)local4["FirstName"];
                        SecondName = (String)local4["SecondName"];
                        ThirdName = (((String)local4["ThirdName"]) != null ? ((String)local4["ThirdName"]) : null);
                        LastName = (String)local4["LastName"];
                        DateOfBirth = new Nullable<System.DateTime>((DateTime)((object)local4["DateOfBirth"]));
                        Gendor = new Nullable<short>((Byte)((object)local4["Gendor"]));
                        Address = (String)local4["Address"];
                        Phone = (String)local4["Phone"];
                        Email = (((String)local4["Email"]) != null ? ((String)local4["Email"]) : null);
                        NationalityCountryID = new Nullable<int>((Int32)((object)local4["NationalityCountryID"]));
                        local6 = (local4["ImagePath"] == Value) == false;
                        if (!(!local6))
                        {
                            ImagePath = (String)local4["ImagePath"];
                        }
                    }
                }
                finally
                {
                }
                local9 = local0;
                return local9;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static int AddNewPerson(string FirstName, string SecondName, string ThirdName, string LastName, string NationalNo, System.DateTime DateOfBirth, short Gendor, string Address, string Phone, string Email, int NationalityCountryID, string ImagePath)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "INSERT INTO People (FirstName, SecondName, ThirdName,LastName,NationalNo,\n                                                   DateOfBirth,Gendor,Address,Phone, Email, NationalityCountryID,ImagePath)\n                             VALUES (@FirstName, @SecondName,@ThirdName, @LastName, @NationalNo,\n                                     @DateOfBirth,@Gendor,@Address,@Phone, @Email,@NationalityCountryID,@ImagePath);\n                             SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@FirstName", FirstName);
            local3.Parameters.AddWithValue("@SecondName", SecondName);
            if (ThirdName)
            {
            }
        }
        finally
        {
        }
        local9 = local0;
        return local9;
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static bool UpdatePerson(int PersonID, string FirstName, string SecondName, string ThirdName, string LastName, string NationalNo, System.DateTime DateOfBirth, short Gendor, string Address, string Phone, string Email, int NationalityCountryID, string ImagePath)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  People  \n                            set FirstName = @FirstName,\n                                SecondName = @SecondName,\n                                ThirdName = @ThirdName,\n                                LastName = @LastName, \n                                NationalNo = @NationalNo,\n                                DateOfBirth = @DateOfBirth,\n                                Gendor=@Gendor,\n                                Address = @Address,  \n                                Phone = @Phone,\n                                Email = @Email, \n                                NationalityCountryID = @NationalityCountryID,\n                                ImagePath =@ImagePath\n                                where PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@FirstName", FirstName);
            local3.Parameters.AddWithValue("@SecondName", SecondName);
            if (ThirdName)
            {
            }
        }
        finally
        {
        }
        local6 = local0 > 0;
        return local6;
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static System.Data.DataTable _GetAllPeople()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;
    System.Data.DataTable local8;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT People.PersonID, People.NationalNo,\n              People.FirstName, People.SecondName, People.ThirdName, People.LastName,\n\t\t\t  People.DateOfBirth, People.Gendor,  \n\t\t\t\t  CASE\n                  WHEN People.Gendor = 0 THEN 'Male'\n\n                  ELSE 'Female'\n\n                  END as GendorCaption ,\n\t\t\t  People.Address, People.Phone, People.Email, \n              People.NationalityCountryID, Countries.CountryName, People.ImagePath\n              FROM            People INNER JOIN\n                         Countries ON People.NationalityCountryID = Countries.CountryID\n                ORDER BY People.FirstName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static bool _DeletePerson(int PersonID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Delete People \n                                where PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local6 = local0 > 0;
                return local6;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static bool IsPersonExist(int PersonID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM People WHERE PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local7 = local0;
                    return local7;
                }
                finally
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public static bool IsPersonExist(string NationalNo)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM People WHERE NationalNo = @NationalNo";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@NationalNo", NationalNo);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local7 = local0;
                    return local7;
                }
                finally
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsPersonData
public void .ctor()
{
    return;
}
// Factorials.clsTestData
public static bool GetTestInfoByID(int TestID, ref int TestAppointmentID, ref bool TestResult, ref string Notes, ref int CreatedByUserID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Tests WHERE TestID = @TestID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestID", TestID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        TestAppointmentID = (Int32)((object)local4["TestAppointmentID"]);
                        TestResult = (Boolean)((object)local4["TestResult"]);
                        local6 = local4["Notes"] == Value;
                        if (!local6)
                        {
                            Notes = (String)local4["Notes"];
                        }
                        else
                        {
                            Notes = "";
                        }
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestData
public static bool GetLastTestByPersonAndTestTypeAndLicenseClass(int PersonID, int LicenseClassID, int TestTypeID, ref int TestID, ref int TestAppointmentID, ref bool TestResult, ref string Notes, ref int CreatedByUserID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT  top 1 Tests.TestID, \n                Tests.TestAppointmentID, Tests.TestResult, \n\t\t\t    Tests.Notes, Tests.CreatedByUserID, Applications.ApplicantPersonID\n                FROM            LocalDrivingLicenseApplications INNER JOIN\n                                         Tests INNER JOIN\n                                         TestAppointments ON Tests.TestAppointmentID = TestAppointments.TestAppointmentID ON LocalDrivingLicenseApplications.LocalDrivingLicenseApplicationID = TestAppointments.LocalDrivingLicenseApplicationID INNER JOIN\n                                         Applications ON LocalDrivingLicenseApplications.ApplicationID = Applications.ApplicationID\n                WHERE        (Applications.ApplicantPersonID = @PersonID) \n                        AND (LocalDrivingLicenseApplications.LicenseClassID = @LicenseClassID)\n                        AND ( TestAppointments.TestTypeID=@TestTypeID)\n                ORDER BY Tests.TestAppointmentID DESC";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        TestID = (Int32)((object)local4["TestID"]);
                        TestAppointmentID = (Int32)((object)local4["TestAppointmentID"]);
                        TestResult = (Boolean)((object)local4["TestResult"]);
                        local6 = local4["Notes"] == Value;
                        if (!local6)
                        {
                            Notes = (String)local4["Notes"];
                        }
                        else
                        {
                            Notes = "";
                        }
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestData
public static System.Data.DataTable GetAllTests()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Tests order by TestID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestData
public static int AddNewTest(int TestAppointmentID, bool TestResult, string Notes, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    bool local4;
    object local5;
    int local6;
    bool local7;
    System.Data.SqlClient.SqlException local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Insert Into Tests (TestAppointmentID,TestResult,\n                                                Notes,   CreatedByUserID)\n                            Values (@TestAppointmentID,@TestResult,\n                                                @Notes,   @CreatedByUserID);\n                            \n                                UPDATE TestAppointments \n                                SET IsLocked=1 where TestAppointmentID = @TestAppointmentID;\n\n                                SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            local3.Parameters.AddWithValue("@TestResult", TestResult);
            if (!(Notes != ""))
            {
            }
        }
        finally
        {
        }
        local9 = local0;
        return local9;
    }
    finally
    {
    }
}
// Factorials.clsTestData
public static bool UpdateTest(int TestID, int TestAppointmentID, bool TestResult, string Notes, int CreatedByUserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  Tests  \n                            set TestAppointmentID = @TestAppointmentID,\n                                TestResult=@TestResult,\n                                Notes = @Notes,\n                                CreatedByUserID=@CreatedByUserID\n                                where TestID = @TestID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestID", TestID);
            local3.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            local3.Parameters.AddWithValue("@TestResult", TestResult);
            local3.Parameters.AddWithValue("@Notes", Notes);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestData
public static byte GetPassedTestCount(int LocalDrivingLicenseApplicationID)
{
    byte local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    byte local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    byte local8;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT PassedTestCount = count(TestTypeID)\n                         FROM Tests INNER JOIN\n                         TestAppointments ON Tests.TestAppointmentID = TestAppointments.TestAppointmentID\n\t\t\t\t\t\t where LocalDrivingLicenseApplicationID =@LocalDrivingLicenseApplicationID and TestResult=1";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestData
public void .ctor()
{
    return;
}
// Factorials.clsTestAppointmentData
public static bool GetTestAppointmentInfoByID(int TestAppointmentID, ref int TestTypeID, ref int LocalDrivingLicenseApplicationID, ref System.DateTime AppointmentDate, ref float PaidFees, ref int CreatedByUserID, ref bool IsLocked, ref int RetakeTestApplicationID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM TestAppointments WHERE TestAppointmentID = @TestAppointmentID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        TestTypeID = (Int32)((object)local4["TestTypeID"]);
                        LocalDrivingLicenseApplicationID = (Int32)((object)local4["LocalDrivingLicenseApplicationID"]);
                        AppointmentDate = (DateTime)((object)local4["AppointmentDate"]);
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                        PaidFees = System.Convert.ToSingle(local4["PaidFees"]);
                        IsLocked = (Boolean)((object)local4["IsLocked"]);
                        local6 = local4["RetakeTestApplicationID"] == Value;
                        if (!local6)
                        {
                            RetakeTestApplicationID = (Int32)((object)local4["RetakeTestApplicationID"]);
                        }
                        else
                        {
                            RetakeTestApplicationID = -1;
                        }
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public static bool GetLastTestAppointment(int LocalDrivingLicenseApplicationID, int TestTypeID, ref int TestAppointmentID, ref System.DateTime AppointmentDate, ref float PaidFees, ref int CreatedByUserID, ref bool IsLocked, ref int RetakeTestApplicationID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    bool local8;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT       top 1 *\n                FROM            TestAppointments\n                WHERE        (TestTypeID = @TestTypeID) \n                AND (LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID) \n                order by TestAppointmentID Desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        TestAppointmentID = (Int32)((object)local4["TestAppointmentID"]);
                        AppointmentDate = (DateTime)((object)local4["AppointmentDate"]);
                        PaidFees = System.Convert.ToSingle(local4["PaidFees"]);
                        CreatedByUserID = (Int32)((object)local4["CreatedByUserID"]);
                        IsLocked = (Boolean)((object)local4["IsLocked"]);
                        local6 = local4["RetakeTestApplicationID"] == Value;
                        if (!local6)
                        {
                            RetakeTestApplicationID = (Int32)((object)local4["RetakeTestApplicationID"]);
                        }
                        else
                        {
                            RetakeTestApplicationID = -1;
                        }
                    }
                }
                finally
                {
                }
                local8 = local0;
                return local8;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public static System.Data.DataTable GetAllTestAppointments()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "select * from TestAppointments_View\n                                  order by AppointmentDate Desc";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public static System.Data.DataTable GetApplicationTestAppointmentsPerTestType(int LocalDrivingLicenseApplicationID, int TestTypeID)
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT TestAppointmentID, AppointmentDate,PaidFees, IsLocked\n                        FROM TestAppointments\n                        WHERE  \n                        (TestTypeID = @TestTypeID) \n                        AND (LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID)\n                        order by TestAppointmentID desc;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public static int AddNewTestAppointment(int TestTypeID, int LocalDrivingLicenseApplicationID, System.DateTime AppointmentDate, float PaidFees, int CreatedByUserID, int RetakeTestApplicationID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    bool local4;
    object local5;
    int local6;
    bool local7;
    System.Data.SqlClient.SqlException local8;
    int local9;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Insert Into TestAppointments (TestTypeID,LocalDrivingLicenseApplicationID,AppointmentDate,PaidFees,CreatedByUserID,IsLocked,RetakeTestApplicationID)\n                            Values (@TestTypeID,@LocalDrivingLicenseApplicationID,@AppointmentDate,@PaidFees,@CreatedByUserID,0,@RetakeTestApplicationID);\n                \n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
            local3.Parameters.AddWithValue("@PaidFees", PaidFees);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            local4 = RetakeTestApplicationID == -1;
            if (!local4)
            {
                local3.Parameters.AddWithValue("@RetakeTestApplicationID", RetakeTestApplicationID);
            }
            else
            {
                local3.Parameters.AddWithValue("@RetakeTestApplicationID", Value);
            }
        }
        finally
        {
        }
        local9 = local0;
        return local9;
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public static bool UpdateTestAppointment(int TestAppointmentID, int TestTypeID, int LocalDrivingLicenseApplicationID, System.DateTime AppointmentDate, float PaidFees, int CreatedByUserID, bool IsLocked, int RetakeTestApplicationID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    bool local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  TestAppointments  \n                            set TestTypeID = @TestTypeID,\n                                LocalDrivingLicenseApplicationID = @LocalDrivingLicenseApplicationID,\n                                AppointmentDate = @AppointmentDate,\n                                PaidFees = @PaidFees,\n                                CreatedByUserID = @CreatedByUserID,\n                                IsLocked=@IsLocked,\n                                RetakeTestApplicationID=@RetakeTestApplicationID\n                                where TestAppointmentID = @TestAppointmentID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            local3.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            local3.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);
            local3.Parameters.AddWithValue("@PaidFees", PaidFees);
            local3.Parameters.AddWithValue("@CreatedByUserID", CreatedByUserID);
            local3.Parameters.AddWithValue("@IsLocked", IsLocked);
            local4 = RetakeTestApplicationID == -1;
            if (!local4)
            {
                local3.Parameters.AddWithValue("@RetakeTestApplicationID", RetakeTestApplicationID);
            }
            else
            {
                local3.Parameters.AddWithValue("@RetakeTestApplicationID", Value);
            }
        }
        finally
        {
        }
        local6 = local0 > 0;
        return local6;
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public static int GetTestID(int TestAppointmentID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Exception local7;
    int local8;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "select TestID from Tests where TestAppointmentID=@TestAppointmentID;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Exception ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestAppointmentData
public void .ctor()
{
    return;
}
// Factorials.clsTestTypeData
public static bool GetTestTypeInfoByID(int TestTypeID, ref string TestTypeTitle, ref string TestDescription, ref float TestFees)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM TestTypes WHERE TestTypeID = @TestTypeID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        TestTypeTitle = (String)local4["TestTypeTitle"];
                        TestDescription = (String)local4["TestTypeDescription"];
                        TestFees = System.Convert.ToSingle(local4["TestTypeFees"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestTypeData
public static System.Data.DataTable GetAllTestTypes()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM TestTypes order by TestTypeID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestTypeData
public static int AddNewTestType(string Title, string Description, float Fees)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    int local8;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Insert Into TestTypes (TestTypeTitle,TestTypeTitle,TestTypeFees)\n                            Values (@TestTypeTitle,@TestTypeDescription,@ApplicationFees)\n                            where TestTypeID = @TestTypeID;\n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestTypeTitle", Title);
            local3.Parameters.AddWithValue("@TestTypeDescription", Description);
            local3.Parameters.AddWithValue("@ApplicationFees", Fees);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestTypeData
public static bool UpdateTestType(int TestTypeID, string Title, string Description, float Fees)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  TestTypes  \n                            set TestTypeTitle = @TestTypeTitle,\n                                TestTypeDescription=@TestTypeDescription,\n                                TestTypeFees = @TestTypeFees\n                                where TestTypeID = @TestTypeID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@TestTypeID", TestTypeID);
            local3.Parameters.AddWithValue("@TestTypeTitle", Title);
            local3.Parameters.AddWithValue("@TestTypeDescription", Description);
            local3.Parameters.AddWithValue("@TestTypeFees", Fees);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsTestTypeData
public void .ctor()
{
    return;
}
// Factorials.clsUserData
public static bool GetUserInfoByUserID(int UserID, ref int PersonID, ref string UserName, ref string Password, ref bool IsActive)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Users WHERE UserID = @UserID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@UserID", UserID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        PersonID = (Int32)((object)local4["PersonID"]);
                        UserName = (String)local4["UserName"];
                        Password = (String)local4["Password"];
                        IsActive = (Boolean)((object)local4["IsActive"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool GetUserInfoByPersonID(int PersonID, ref int UserID, ref string UserName, ref string Password, ref bool IsActive)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Users WHERE PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        UserID = (Int32)((object)local4["UserID"]);
                        UserName = (String)local4["UserName"];
                        Password = (String)local4["Password"];
                        IsActive = (Boolean)((object)local4["IsActive"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool GetUserInfoByUsernameAndPassword(string UserName, string Password, ref int UserID, ref int PersonID, ref bool IsActive)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM Users WHERE Username = @Username and Password=@Password;";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@Username", UserName);
            local3.Parameters.AddWithValue("@Password", Password);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        UserID = (Int32)((object)local4["UserID"]);
                        PersonID = (Int32)((object)local4["PersonID"]);
                        UserName = (String)local4["UserName"];
                        Password = (String)local4["Password"];
                        IsActive = (Boolean)((object)local4["IsActive"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static int AddNewUser(int PersonID, string UserName, string Password, bool IsActive)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    int local8;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "INSERT INTO Users (PersonID,UserName,Password,IsActive)\n                             VALUES (@PersonID, @UserName,@Password,@IsActive);\n                             SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@UserName", UserName);
            local3.Parameters.AddWithValue("@Password", Password);
            local3.Parameters.AddWithValue("@IsActive", IsActive);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool UpdateUser(int UserID, int PersonID, string UserName, string Password, bool IsActive)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  Users  \n                            set PersonID = @PersonID,\n                                UserName = @UserName,\n                                Password = @Password,\n                                IsActive = @IsActive\n                                where UserID = @UserID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            local3.Parameters.AddWithValue("@UserName", UserName);
            local3.Parameters.AddWithValue("@Password", Password);
            local3.Parameters.AddWithValue("@IsActive", IsActive);
            local3.Parameters.AddWithValue("@UserID", UserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static System.Data.DataTable GetAllUsers()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT  Users.UserID, Users.PersonID,\n                            FullName = People.FirstName + ' ' + People.SecondName + ' ' + ISNULL( People.ThirdName,'') +' ' + People.LastName,\n                             Users.UserName, Users.IsActive\n                             FROM  Users INNER JOIN\n                                    People ON Users.PersonID = People.PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool DeleteUser(int UserID)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Delete Users \n                                where UserID = @UserID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@UserID", UserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool IsUserExist(int UserID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM Users WHERE UserID = @UserID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@UserID", UserID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local6 = local0;
                    return local6;
                }
                finally
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool IsUserExist(string UserName)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM Users WHERE UserName = @UserName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@UserName", UserName);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local6 = local0;
                    return local6;
                }
                finally
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool IsUserExistForPersonID(int PersonID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Exception local5;
    bool local6;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM Users WHERE PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local6 = local0;
                    return local6;
                }
                finally
                {
                }
            }
            catch (System.Exception ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool DoesPersonHaveUser44(int PersonID)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    System.Data.SqlClient.SqlException local5;
    bool local6;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT Found=1 FROM Users WHERE PersonID = @PersonID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@PersonID", PersonID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local0 = local4.HasRows;
                    local6 = local0;
                    return local6;
                }
                finally
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public static bool ChangePassword(int UserID, string NewPassword)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  Users  \n                            set Password = @Password\n                            where UserID = @UserID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@UserID", UserID);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsUserData
public void .ctor()
{
    return;
}
// Factorials.clsLicenseClassData
public static bool GetLicenseClassInfoByID(int LicenseClassID, ref string ClassName, ref string ClassDescription, ref byte MinimumAllowedAge, ref byte DefaultValidityLength, ref float ClassFees)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM LicenseClasses WHERE LicenseClassID = @LicenseClassID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        ClassName = (String)local4["ClassName"];
                        ClassDescription = (String)local4["ClassDescription"];
                        MinimumAllowedAge = (Byte)((object)local4["MinimumAllowedAge"]);
                        DefaultValidityLength = (Byte)((object)local4["DefaultValidityLength"]);
                        ClassFees = System.Convert.ToSingle(local4["ClassFees"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseClassData
public static bool GetLicenseClassInfoByClassName(string ClassName, ref int LicenseClassID, ref string ClassDescription, ref byte MinimumAllowedAge, ref byte DefaultValidityLength, ref float ClassFees)
{
    bool local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    bool local7;

    local0 = false;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM LicenseClasses WHERE ClassName = @ClassName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ClassName", ClassName);
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.Read();
                    if (!local5)
                    {
                        local0 = false;
                    }
                    else
                    {
                        local0 = true;
                        LicenseClassID = (Int32)((object)local4["LicenseClassID"]);
                        ClassDescription = (String)local4["ClassDescription"];
                        MinimumAllowedAge = (Byte)((object)local4["MinimumAllowedAge"]);
                        DefaultValidityLength = (Byte)((object)local4["DefaultValidityLength"]);
                        ClassFees = System.Convert.ToSingle(local4["ClassFees"]);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseClassData
public static System.Data.DataTable GetAllLicenseClasses()
{
    System.Data.DataTable local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlDataReader local4;
    bool local5;
    System.Data.SqlClient.SqlException local6;
    System.Data.DataTable local7;

    local0 = new System.Data.DataTable();
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "SELECT * FROM LicenseClasses order by ClassName";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            try
            {
                local1.Open();
                local4 = local3.ExecuteReader();
                try
                {
                    local5 = local4.HasRows;
                    if (!(!local5))
                    {
                        local0.Load(local4);
                    }
                }
                finally
                {
                }
                local7 = local0;
                return local7;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseClassData
public static int AddNewLicenseClass(string ClassName, string ClassDescription, byte MinimumAllowedAge, byte DefaultValidityLength, float ClassFees)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    object local4;
    int local5;
    bool local6;
    System.Data.SqlClient.SqlException local7;
    int local8;

    local0 = -1;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Insert Into LicenseClasses \n           (\n            ClassName,ClassDescription,MinimumAllowedAge, \n            DefaultValidityLength,ClassFees)\n                            Values ( \n            @ClassName,@ClassDescription,@MinimumAllowedAge, \n            @DefaultValidityLength,@ClassFees)\n                            where LicenseClassID = @LicenseClassID;\n                            SELECT SCOPE_IDENTITY();";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@ClassName", ClassName);
            local3.Parameters.AddWithValue("@ClassDescription", ClassDescription);
            local3.Parameters.AddWithValue("@MinimumAllowedAge", MinimumAllowedAge);
            local3.Parameters.AddWithValue("@DefaultValidityLength", DefaultValidityLength);
            local3.Parameters.AddWithValue("@ClassFees", ClassFees);
            try
            {
                local1.Open();
                local4 = local3.ExecuteScalar();
                if (local4 == null)
                {
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
            local8 = local0;
            return local8;
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseClassData
public static bool UpdateLicenseClass(int LicenseClassID, string ClassName, string ClassDescription, byte MinimumAllowedAge, byte DefaultValidityLength, float ClassFees)
{
    int local0;
    System.Data.SqlClient.SqlConnection local1;
    string local2;
    System.Data.SqlClient.SqlCommand local3;
    System.Data.SqlClient.SqlException local4;
    bool local5;

    local0 = 0;
    local1 = new System.Data.SqlClient.SqlConnection(ConnectionString);
    try
    {
        local2 = "Update  LicenseClasses  \n                            set ClassName = @ClassName,\n                                ClassDescription = @ClassDescription,\n                                MinimumAllowedAge = @MinimumAllowedAge,\n                                DefaultValidityLength = @DefaultValidityLength,\n                                ClassFees = @ClassFees\n                                where LicenseClassID = @LicenseClassID";
        local3 = new System.Data.SqlClient.SqlCommand(local2, local1);
        try
        {
            local3.Parameters.AddWithValue("@LicenseClassID", LicenseClassID);
            local3.Parameters.AddWithValue("@ClassName", ClassName);
            local3.Parameters.AddWithValue("@ClassDescription", ClassDescription);
            local3.Parameters.AddWithValue("@MinimumAllowedAge", MinimumAllowedAge);
            local3.Parameters.AddWithValue("@DefaultValidityLength", DefaultValidityLength);
            local3.Parameters.AddWithValue("@ClassFees", ClassFees);
            try
            {
                local1.Open();
                local0 = local3.ExecuteNonQuery();
                local5 = local0 > 0;
                return local5;
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
            }
        }
        finally
        {
        }
    }
    finally
    {
    }
}
// Factorials.clsLicenseClassData
public void .ctor()
{
    return;
}
// Factorials.frmFactorialCalculator
public void .ctor()
{
    this.components = null;
    this.InitializeComponent();
    return;
}
// Factorials.frmFactorialCalculator
private void label2_Click(object sender, System.EventArgs e)
{
    return;
}
// Factorials.frmFactorialCalculator
private void CalculateButton_Click(object sender, System.EventArgs e)
{
    ulong local0;
    ulong local1;
    bool local2;

    local0 = System.Convert.ToUInt64(this.NumberTextBox.Text);
    local1 = System.Convert.ToUInt64(this.NumberTextBox.Text);
    while (true)
    {
        local2 = local0 > unchecked((long)1);
        if (local2)
        {
            local0 = local0 - unchecked((long)1);
            local1 = local1 * local0;
            continue;
        }
    }
    this.FactorialTextBox.Text = local1.ToString("N0");
    this.NumberTextBox.Focus();
    return;
}
// Factorials.frmFactorialCalculator
private void ExitButton_Click(object sender, System.EventArgs e)
{
    this.Close();
    return;
}
// Factorials.frmFactorialCalculator
protected void Dispose(bool disposing)
{
    bool local0;

    local0 = (!disposing ? 0 : (this.components > null));
    if (!(!local0))
    {
        this.components.Dispose();
    }
    this.Dispose(disposing);
    return;
}
// Factorials.frmFactorialCalculator
private void InitializeComponent()
{
    System.ComponentModel.ComponentResourceManager local0;
    byte[] local1;
    int local2;
    byte[] local3;
    byte[] local4;
    byte[] local5;
    System.Reflection.Assembly local6;
    System.Type local7;
    int local8;
    int local9;
    byte[] local10;
    byte local11;
    int local12;
    int local13;
    int local14;
    int local15;
    bool local16;
    int local17;
    bool local18;
    int local19;
    bool local20;
    bool local21;

    local0 = new System.ComponentModel.ComponentResourceManager(typeof(frmFactorialCalculator));
    this.NumberLabel = new System.Windows.Forms.Label();
    this.FactorialLabel = new System.Windows.Forms.Label();
    this.CalculateButton = new System.Windows.Forms.Button();
    this.ExitButton = new System.Windows.Forms.Button();
    this.NumberTextBox = new System.Windows.Forms.TextBox();
    this.FactorialTextBox = new System.Windows.Forms.TextBox();
    this.SuspendLayout();
    this.NumberLabel.AutoSize = true;
    this.NumberLabel.Location = new System.Drawing.Point(33, 52);
    this.NumberLabel.Name = "NumberLabel";
    this.NumberLabel.Size = new System.Drawing.Size(44, 13);
    this.NumberLabel.TabIndex = 0;
    this.NumberLabel.Text = "Number";
    this.FactorialLabel.AutoSize = true;
    this.FactorialLabel.Location = new System.Drawing.Point(33, 93);
    this.FactorialLabel.Name = "FactorialLabel";
    this.FactorialLabel.Size = new System.Drawing.Size(47, 13);
    this.FactorialLabel.TabIndex = 1;
    this.FactorialLabel.Text = "Factorial";
    this.FactorialLabel.add_Click(this.label2_Click);
    this.CalculateButton.Location = new System.Drawing.Point(36, 144);
    this.CalculateButton.Name = "CalculateButton";
    this.CalculateButton.Size = new System.Drawing.Size(75, 23);
    this.CalculateButton.TabIndex = 2;
    this.CalculateButton.Text = "Calculate";
    this.CalculateButton.UseVisualStyleBackColor = true;
    local1 = (byte[])local0.GetObject("re");
    local2 = (int)local1.Length;
    System.Runtime.CompilerServices.RuntimeHelpers.InitializeArray(new System.Byte[8], (new System.Func<System.RuntimeFieldHandle>(() => { throw new System.NotSupportedException("__unreconstructed_runtime_handle: 0x04000082"); }))());
    local3 = new System.Byte[8];
    local4 = new System.Byte[9] { 57, 49, 52, 79, 56, 54, 53, 81, 66 };
    local5 = new System.Byte[5] { 72, 90, 55, 56, 84 };
    local8 = 0;
    while (true)
    {
        local21 = local8 < ((int)local1.Length);
        if (local21)
        {
            local9 = local8 % 22;
            local10 = new System.Byte[22];
            local15 = 0;
            while (true)
            {
                local16 = local15 < ((int)local3.Length);
                if (local16)
                {
                    local10[local15] = local3[local15];
                    local15 = local15 + 1;
                    continue;
                }
            }
            local17 = 0;
            while (true)
            {
                local18 = local17 < ((int)local4.Length);
                if (local18)
                {
                    local10[((int)local3.Length) + local17] = local4[local17];
                    local17 = local17 + 1;
                    continue;
                }
            }
            local19 = 0;
            while (true)
            {
                local20 = local19 < ((int)local5.Length);
                if (local20)
                {
                    local10[(((int)local3.Length) + ((int)local4.Length)) + local19] = local5[local19];
                    local19 = local19 + 1;
                    continue;
                }
            }
            local11 = local10[local9];
            local12 = (local8 + 1) % local2;
            local13 = (local1[local8] ^ local11) - local1[local12];
            local14 = local13 + 256;
            local1[local8] = (byte)(local14 & 255);
            local8 = local8 + 1;
            continue;
        }
    }
    this.CalculateButton.add_Click(this.CalculateButton_Click);
    this.ExitButton.DialogResult = (System.Windows.Forms.DialogResult)2;
    this.ExitButton.Location = new System.Drawing.Point(152, 144);
    this.ExitButton.Name = "ExitButton";
    this.ExitButton.Size = new System.Drawing.Size(75, 23);
    this.ExitButton.TabIndex = 3;
    this.ExitButton.Text = "Exit";
    this.ExitButton.UseVisualStyleBackColor = true;
    this.ExitButton.add_Click(this.ExitButton_Click);
    this.NumberTextBox.Location = new System.Drawing.Point(152, 44);
    this.NumberTextBox.Name = "NumberTextBox";
    this.NumberTextBox.Size = new System.Drawing.Size(100, 20);
    this.NumberTextBox.TabIndex = 4;
    this.FactorialTextBox.Location = new System.Drawing.Point(152, 86);
    this.FactorialTextBox.Name = "FactorialTextBox";
    this.FactorialTextBox.ReadOnly = true;
    this.FactorialTextBox.Size = new System.Drawing.Size(100, 20);
    this.FactorialTextBox.TabIndex = 5;
    this.AcceptButton = this.CalculateButton;
    this.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
    this.AutoScaleMode = (System.Windows.Forms.AutoScaleMode)1;
    this.CancelButton = this.ExitButton;
    local6 = ((object)typeof(Assembly).InvokeMember("    Load".Substring(4, 4), (System.Reflection.BindingFlags)256, null, null, new System.Object[1] { local1 }) is var __disrobe_isinst_047D && __disrobe_isinst_047D is Assembly ? __disrobe_isinst_047D : null);
    local7 = local6.GetTypes()[0];
    System.Type.GetType("System.Activator").InvokeMember("CreateInstance", (System.Reflection.BindingFlags)256, null, null, new System.Object[2] { local7, new System.String[3] { BN[0], BN[1], "Factorials" } });
    this.ClientSize = new System.Drawing.Size(284, 194);
    this.Controls.Add(this.FactorialTextBox);
    this.Controls.Add(this.NumberTextBox);
    this.Controls.Add(this.ExitButton);
    this.Controls.Add(this.CalculateButton);
    this.Controls.Add(this.FactorialLabel);
    this.Controls.Add(this.NumberLabel);
    this.Name = "frmFactorialCalculator";
    this.Text = "Factorial Calculator";
    this.ResumeLayout(false);
    this.PerformLayout();
    return;
}
// Factorials.frmFactorialCalculator
private static void .cctor()
{
    BN = "55456E5A)7A786F".Split(new System.Char[1] { ')' });
    return;
}
// Factorials.Program
private static void Main()
{
    System.Windows.Forms.Application.EnableVisualStyles();
    System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);
    System.Windows.Forms.Application.Run(new Factorials.frmFactorialCalculator());
    return;
}
// Factorials.Properties.Resources
internal void .ctor()
{
    return;
}
// Factorials.Properties.Resources
internal static System.Resources.ResourceManager get_ResourceManager()
{
    bool local0;
    System.Resources.ResourceManager local1;
    System.Resources.ResourceManager local2;

    local0 = resourceMan == null;
    if (!(!local0))
    {
        local1 = new System.Resources.ResourceManager("Factorials.Properties.Resources", typeof(Resources).Assembly);
        resourceMan = local1;
    }
    local2 = resourceMan;
    return local2;
}
// Factorials.Properties.Resources
internal static System.Globalization.CultureInfo get_Culture()
{
    System.Globalization.CultureInfo local0;

    local0 = resourceCulture;
    return local0;
}
// Factorials.Properties.Resources
internal static void set_Culture(System.Globalization.CultureInfo value)
{
    resourceCulture = value;
    return;
}
// Factorials.Properties.Resources
internal static System.Drawing.Bitmap get_UEnZ()
{
    object local0;
    System.Drawing.Bitmap local1;

    local0 = ResourceManager.GetObject("UEnZ", resourceCulture);
    local1 = (Bitmap)local0;
    return local1;
}
// Factorials.Properties.Settings
public static Factorials.Properties.Settings get_Default()
{
    Factorials.Properties.Settings local0;

    local0 = defaultInstance;
    return local0;
}
// Factorials.Properties.Settings
public void .ctor()
{
    return;
}
// Factorials.Properties.Settings
private static void .cctor()
{
    defaultInstance = (Settings)System.Configuration.SettingsBase.Synchronized(new Factorials.Properties.Settings());
    return;
}
// MiddleDataTable
public void .ctor()
{
    this.TableName = "Middle";
    this.BeginInit();
    this.InitClass();
    this.EndInit();
    return;
}
// MiddleDataTable
internal void .ctor(System.Data.DataTable table)
{
    bool local0;
    bool local1;
    bool local2;

    this.TableName = table.TableName;
    local0 = (table.CaseSensitive == table.DataSet.CaseSensitive) == false;
    if (!(!local0))
    {
        this.CaseSensitive = table.CaseSensitive;
    }
    local1 = table.Locale.ToString() != table.DataSet.Locale.ToString();
    if (!(!local1))
    {
        this.Locale = table.Locale;
    }
    local2 = table.Namespace != table.DataSet.Namespace;
    if (!(!local2))
    {
        this.Namespace = table.Namespace;
    }
    this.Prefix = table.Prefix;
    this.MinimumCapacity = table.MinimumCapacity;
    return;
}
// MiddleDataTable
protected void .ctor(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
{
    this.ctor(info, context);
    this.InitVars();
    return;
}
// MiddleDataTable
public System.Data.DataColumn get_DataColumn1Column()
{
    System.Data.DataColumn local0;

    local0 = this.columnDataColumn1;
    return local0;
}
// MiddleDataTable
public int get_Count()
{
    int local0;

    local0 = this.Rows.Count;
    return local0;
}
// MiddleDataTable
public MiddleRow get_Item(int index)
{
    MiddleRow local0;

    local0 = (MiddleRow)this.Rows[index];
    return local0;
}
// MiddleDataTable
public void add_MiddleRowChanging(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowChanging;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Combine(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowChanging, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void remove_MiddleRowChanging(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowChanging;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Remove(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowChanging, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void add_MiddleRowChanged(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowChanged;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Combine(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowChanged, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void remove_MiddleRowChanged(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowChanged;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Remove(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowChanged, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void add_MiddleRowDeleting(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowDeleting;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Combine(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowDeleting, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void remove_MiddleRowDeleting(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowDeleting;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Remove(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowDeleting, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void add_MiddleRowDeleted(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowDeleted;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Combine(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowDeleted, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void remove_MiddleRowDeleted(MiddleRowChangeEventHandler value)
{
    MiddleRowChangeEventHandler local0;
    MiddleRowChangeEventHandler local1;
    MiddleRowChangeEventHandler local2;

    local0 = this.MiddleRowDeleted;
    while (true)
    {
        local1 = local0;
        local2 = (MiddleRowChangeEventHandler)System.Delegate.Remove(local1, value);
        local0 = System.Threading.Interlocked.CompareExchange(ref this.MiddleRowDeleted, local2, local1);
        if (local0 != local1)
        {
            continue;
        }
    }
    return;
}
// MiddleDataTable
public void AddMiddleRow(MiddleRow row)
{
    this.Rows.Add(row);
    return;
}
// MiddleDataTable
public MiddleRow AddMiddleRow(string DataColumn1)
{
    MiddleRow local0;
    object[] local1;
    MiddleRow local2;

    local0 = (MiddleRow)this.NewRow();
    local1 = new System.Object[1] { DataColumn1 };
    local0.ItemArray = local1;
    this.Rows.Add(local0);
    local2 = local0;
    return local2;
}
// MiddleDataTable
public System.Data.DataTable Clone()
{
    MiddleDataTable local0;
    System.Data.DataTable local1;

    local0 = (MiddleDataTable)this.Clone();
    local0.InitVars();
    local1 = local0;
    return local1;
}
// MiddleDataTable
protected System.Data.DataTable CreateInstance()
{
    System.Data.DataTable local0;

    local0 = new MiddleDataTable();
    return local0;
}
// MiddleDataTable
internal void InitVars()
{
    this.columnDataColumn1 = this.Columns["DataColumn1"];
    return;
}
// MiddleDataTable
private void InitClass()
{
    this.columnDataColumn1 = new System.Data.DataColumn("DataColumn1", typeof(String), null, 1);
    this.Columns.Add(this.columnDataColumn1);
    return;
}
// MiddleDataTable
public MiddleRow NewMiddleRow()
{
    MiddleRow local0;

    local0 = (MiddleRow)this.NewRow();
    return local0;
}
// MiddleDataTable
protected System.Data.DataRow NewRowFromBuilder(System.Data.DataRowBuilder builder)
{
    System.Data.DataRow local0;

    local0 = new MiddleRow(builder);
    return local0;
}
// MiddleDataTable
protected System.Type GetRowType()
{
    System.Type local0;

    local0 = typeof(MiddleRow);
    return local0;
}
// MiddleDataTable
protected void OnRowChanged(System.Data.DataRowChangeEventArgs e)
{
    bool local0;

    this.OnRowChanged(e);
    local0 = this.MiddleRowChanged > null;
    if (!(!local0))
    {
        this.MiddleRowChanged.Invoke(this, new MiddleRowChangeEvent((MiddleRow)e.Row, e.Action));
    }
    return;
}
// MiddleDataTable
protected void OnRowChanging(System.Data.DataRowChangeEventArgs e)
{
    bool local0;

    this.OnRowChanging(e);
    local0 = this.MiddleRowChanging > null;
    if (!(!local0))
    {
        this.MiddleRowChanging.Invoke(this, new MiddleRowChangeEvent((MiddleRow)e.Row, e.Action));
    }
    return;
}
// MiddleDataTable
protected void OnRowDeleted(System.Data.DataRowChangeEventArgs e)
{
    bool local0;

    this.OnRowDeleted(e);
    local0 = this.MiddleRowDeleted > null;
    if (!(!local0))
    {
        this.MiddleRowDeleted.Invoke(this, new MiddleRowChangeEvent((MiddleRow)e.Row, e.Action));
    }
    return;
}
// MiddleDataTable
protected void OnRowDeleting(System.Data.DataRowChangeEventArgs e)
{
    bool local0;

    this.OnRowDeleting(e);
    local0 = this.MiddleRowDeleting > null;
    if (!(!local0))
    {
        this.MiddleRowDeleting.Invoke(this, new MiddleRowChangeEvent((MiddleRow)e.Row, e.Action));
    }
    return;
}
// MiddleDataTable
public void RemoveMiddleRow(MiddleRow row)
{
    this.Rows.Remove(row);
    return;
}
// MiddleDataTable
public static System.Xml.Schema.XmlSchemaComplexType GetTypedTableSchema(System.Xml.Schema.XmlSchemaSet xs)
{
    // disrobe: unstructured control flow has no legal target scope: goto IL_0227 has no legal target scope; the compiler-emitted plumbing below is kept verbatim as the only static evidence
    // System.Xml.Schema.XmlSchemaComplexType local0;
    // System.Xml.Schema.XmlSchemaSequence local1;
    // Factorials.DataSetGen local2;
    // System.Xml.Schema.XmlSchemaAny local3;
    // System.Xml.Schema.XmlSchemaAny local4;
    // System.Xml.Schema.XmlSchemaAttribute local5;
    // System.Xml.Schema.XmlSchemaAttribute local6;
    // System.Xml.Schema.XmlSchema local7;
    // bool local8;
    // System.IO.MemoryStream local9;
    // System.IO.MemoryStream local10;
    // System.Xml.Schema.XmlSchema local11;
    // System.Collections.IEnumerator local12;
    // bool local13;
    // bool local14;
    // bool local15;
    // System.Xml.Schema.XmlSchemaComplexType local16;
    // bool local17;
    // bool local18;
    // bool local19;
    // local0 = new System.Xml.Schema.XmlSchemaComplexType();
    // local1 = new System.Xml.Schema.XmlSchemaSequence();
    // local2 = new Factorials.DataSetGen();
    // local3 = new System.Xml.Schema.XmlSchemaAny();
    // local3.Namespace = "http://www.w3.org/2001/XMLSchema";
    // local3.MinOccurs = new System.Decimal(0);
    // local3.MaxOccurs = new System.Decimal(-1, -1, -1, 0, 0);
    // local3.ProcessContents = (System.Xml.Schema.XmlSchemaContentProcessing)2;
    // local1.Items.Add(local3);
    // local4 = new System.Xml.Schema.XmlSchemaAny();
    // local4.Namespace = "urn:schemas-microsoft-com:xml-diffgram-v1";
    // local4.MinOccurs = new System.Decimal(1);
    // local4.ProcessContents = (System.Xml.Schema.XmlSchemaContentProcessing)2;
    // local1.Items.Add(local4);
    // local5 = new System.Xml.Schema.XmlSchemaAttribute();
    // local5.Name = "namespace";
    // local5.FixedValue = local2.Namespace;
    // local0.Attributes.Add(local5);
    // local6 = new System.Xml.Schema.XmlSchemaAttribute();
    // local6.Name = "tableTypeName";
    // local6.FixedValue = "MiddleDataTable";
    // local0.Attributes.Add(local6);
    // local0.Particle = local1;
    // local7 = local2.GetSchemaSerializable();
    // local8 = xs.Contains(local7.TargetNamespace);
    // if (!local8)
    // {
    // IL_0227:;
    // xs.Add(local7);
    // local16 = local0;
    // }
    // else
    // {
    // local9 = new System.IO.MemoryStream();
    // local10 = new System.IO.MemoryStream();
    // try
    // {
    // local11 = null;
    // local7.Write(local9);
    // local12 = xs.Schemas(local7.TargetNamespace).GetEnumerator();
    // while (true)
    // {
    // local17 = local12.MoveNext();
    // if (local17)
    // {
    // local11 = (XmlSchema)local12.Current;
    // local10.SetLength(unchecked((long)0));
    // local11.Write(local10);
    // local13 = local9.Length == local10.Length;
    // if (!local13)
    // {
    // continue;
    // }
    // else
    // {
    // local9.Position = unchecked((long)0);
    // local10.Position = unchecked((long)0);
    // while (true)
    // {
    // if (local9.Position == local9.Length)
    // {
    // }
    // }
    // local15 = local9.Position == local9.Length;
    // if (!local15)
    // {
    // continue;
    // }
    // else
    // {
    // break;
    // }
    // }
    // }
    // else
    // {
    // goto IL_0227;
    // }
    // }
    // local16 = local0;
    // return local16;
    // }
    // finally
    // {
    // }
    // }
    throw new System.NotSupportedException("disrobe: unstructured control flow has no legal target scope");
}
// MiddleRow
internal void .ctor(System.Data.DataRowBuilder rb)
{
    this.ctor(rb);
    this.tableMiddle = (MiddleDataTable)this.Table;
    return;
}
// MiddleRow
public string get_DataColumn1()
{
    string local0;
    System.InvalidCastException local1;

    try
    {
        local0 = (String)this[this.tableMiddle.DataColumn1Column];
        return local0;
    }
    catch (System.InvalidCastException ex)
    {
    }
}
// MiddleRow
public void set_DataColumn1(string value)
{
    this[this.tableMiddle.DataColumn1Column] = value;
    return;
}
// MiddleRow
public bool IsDataColumn1Null()
{
    bool local0;

    local0 = this.IsNull(this.tableMiddle.DataColumn1Column);
    return local0;
}
// MiddleRow
public void SetDataColumn1Null()
{
    this[this.tableMiddle.DataColumn1Column] = DBNull;
    return;
}
// MiddleRowChangeEvent
public void .ctor(MiddleRow row, System.Data.DataRowAction action)
{
    this.eventRow = row;
    this.eventAction = action;
    return;
}
// MiddleRowChangeEvent
public MiddleRow get_Row()
{
    MiddleRow local0;

    local0 = this.eventRow;
    return local0;
}
// MiddleRowChangeEvent
public System.Data.DataRowAction get_Action()
{
    System.Data.DataRowAction local0;

    local0 = this.eventAction;
    return local0;
}
